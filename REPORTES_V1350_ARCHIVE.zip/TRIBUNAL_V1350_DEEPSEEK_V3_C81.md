# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 81)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 81 · Six-Component Adversarial Review

**Presiding note.** The Tribunal treats each target as a *claim of correctness* under adversarial input. We do not accept "it compiles" or "it runs on my machine" as evidence. We require: (i) numerical stability proofs in the limits `step → 0` and `step → ∞`, (ii) byte-level conformance to the 88-byte PMTP descriptor, (iii) vendor-neutrality under Rule 27, and (iv) FFI hardening under Rule 22.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor: `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly (little-endian, standard `struct` alignment disabled by `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major | `H` | 2 |
| version_minor | `H` | 2 |
| flags | `Q` | 8 |
| n_rows | `Q` | 8 |
| n_cols | `Q` | 8 |
| stride | `Q` | 8 |
| scale_bits | `Q` | 8 |
| dtype | `B` | 1 |
| rank | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

✅ **Byte count is exact.** `struct.calcsize('<4sHHQQQQQBB6x4Q') == 88`.

**Adversarial finding 1.1 (alignment trap).** The `<` prefix disables native alignment. If any downstream C/Rust/CUDA consumer reads this struct with `#[repr(C)]` or a packed C struct *without* `__attribute__((packed))`, the compiler will insert padding after `version_minor` (offset 8) to align the first `Q`. That silently shifts every subsequent field by 4 bytes. **Recommendation:** publish a single canonical header (`pmtp_v1350.h`) with `#pragma pack(push,1)` and a `static_assert(sizeof(PmtpDescriptor)==88, ...)`. Rust must use `#[repr(C, packed)]` and `bytemuck::Pod`.

**Adversarial finding 1.2 (endianness).** `<` forces little-endian. On a big-endian POWER10 or s390x node, the orchestrator will emit descriptors that the C++/Rust kernels misread. Rule 27 (vendor neutrality) is *technically* satisfied but *practically* violated on non-x86/ARM hosts. **Recommendation:** either mandate LE-only silicon in the contract, or add a `flags` bit `PMTP_FLAG_BIG_ENDIAN` and byte-swap at the FFI boundary.

**Adversarial finding 1.3 (12/12 conformance checks).** The Tribunal cannot verify the 12 checks without the source. We flag this as **unproven claim**. Required evidence: a table mapping each check → invariant → falsifying input. In particular, checks must include:
- `magic == b'PMTP'`
- `version_major == 1350`
- `n_rows * n_cols * dtype_size == payload_bytes`
- `stride >= n_cols * dtype_size`
- `scale_bits` decodes to a finite positive float (see §2.2)
- `rank <= min(n_rows, n_cols)`

### 1.2 `PmtpSlabAllocator`

**Adversarial finding 1.4 (slab fragmentation under adversarial rank).** If `rank` is attacker-controlled and the allocator uses `rank` to size sub-slabs, a rank of `2^32-1` triggers an integer overflow in `rank * sizeof(slab_header)`. **Recommendation:** clamp `rank ≤ min(n_rows, n_cols)` *before* any multiplication, and use `checked_mul` in Rust / `__builtin_mul_overflow` in C++.

### 1.3 `HardwareProbe` multi-silicon

**Adversarial finding 1.5 (TOCTOU on device enumeration).** Probing CUDA/ROCm/TPU/Trainium at orchestrator startup and caching the result is a TOCTOU hazard: a device can be hot-unplugged or MIG-repartitioned between probe and dispatch. **Recommendation:** re-validate device UUID at dispatch time; treat probe as a *hint*, not a *guarantee*.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan–Babuška:

```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|:  c += (s - t) + x_i*y_i
    else:                 c += (x_i*y_i - t) + s
    s = t
return s + c
```

**Theorem 2.1 (error bound).** For `n` terms with `|x_i y_i| ≤ M` and unit roundoff `u`, Neumaier's sum satisfies

```
|computed − exact| ≤ (2u + O(n u²)) · Σ|x_i y_i|
```

i.e. **relative error is bounded independent of `n`** (unlike naive summation's `n u`). This is the correct choice for the dot products in the Cayley/Woodbury path.

**Adversarial finding 2.1 (compiler contraction).** With `-ffast-math` or `-ffp-contract=fast`, the compiler may fuse `s + x_i*y_i` into an FMA, which *changes the rounding* and can break the Neumaier compensation (the compensation term assumes the product is rounded *before* the add). **Recommendation:** compile the compensated kernel with `-ffp-contract=off` and `-fno-fast-math`, or use `std::fma` explicitly and re-derive the compensation. This is a **hard correctness requirement**, not a performance preference.

### 2.2 Subnormal audits at `-12`, `-14`

The notation `(-12, -14)` almost certainly refers to exponents near `2^-12` and `2^-14` (FP16 subnormal boundary is `2^-14`; FP32 subnormal boundary is `2^-126`). Two cases:

**Case A: FP32 path.** `2^-12` and `2^-14` are *normal* FP32 numbers. No subnormal hazard. The audit is vacuous unless the kernel is doing FP16/BF16 intermediate math.

**Case B: FP16/BF16 path.** `2^-14` is the smallest *normal* FP16; below it, subnormals down to `2^-24`. If the kernel accumulates in FP16, catastrophic cancellation in the Neumaier compensation can push `c` into the subnormal range, where FP16 has *reduced precision* (fewer significand bits). The compensation term then loses its correction power.

**Adversarial finding 2.2 (subnormal flush).** AVX-512 with `MXCSR.FTZ=1` (flush-to-zero) will silently zero subnormal `c`, destroying the compensation. **Recommendation:** explicitly clear FTZ/DAZ in the kernel prologue (`_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`), or accumulate in FP32/FP64 regardless of input dtype. The Tribunal demands a **unit test** that feeds `x = [2^-14, -2^-14 + 2^-24]` and asserts the compensated result is nonzero.

### 2.3 Zero-copy PMTP validation

**Adversarial finding 2.3 (aliasing).** Zero-copy means the kernel reads the orchestrator's slab directly. If the orchestrator can `munmap` or `mprotect` the slab while the kernel is mid-flight, the kernel reads freed memory. **Recommendation:** the FFI contract must specify that the slab is pinned for the kernel's lifetime; enforce via `mlock` + a generation counter in the descriptor's `reserved` field.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier

**Adversarial finding 3.1 (this is the wrong default).** `panic=unwind` across an FFI boundary is **undefined behavior** in Rust unless the panic is caught with `std::panic::catch_unwind` *before* returning to C/C++. The correct setting for a kernel that is called from C++/CUDA is `panic=abort`, or `panic=unwind` + a mandatory `catch_unwind` wrapper at every `extern "C"` entry point.

**Recommendation (concrete FFI hardening):**

```rust
#[no_mangle]
pub extern "C" fn pmtp_kernel_entry(desc: *const PmtpDescriptor, ...) -> i32 {
    let result = std::panic::catch_unwind(|| {
        // real work
    });
    match result {
        Ok(Ok(())) => 0,
        Ok(Err(e)) => e.code(),
        Err(_)     => -1, // panic caught, no UB
    }
}
```

Additionally: `extern "C"` functions must not unwind. Rust 2021's `extern "C-unwind"` is the *only* ABI that permits unwinding across the boundary, and even then the C++ side must be compiled with exceptions enabled and a matching personality routine. **The Tribunal rules: `panic=unwind` without `catch_unwind` is a Rule 22 violation** (it leaks a non-token control-flow event across the inter-agent boundary).

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

**Adversarial finding 3.2.** `#[repr(C, packed)]` on a struct containing `u64` fields produces *unaligned* field accesses. On x86 this is slow but correct; on ARM64 it is a **SIGBUS** for some instructions. **Recommendation:** use `#[repr(C)]` with explicit `_pad: [u8; 6]` and `static_assert` via `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`. If packing is mandatory, access fields via `read_unaligned`.

### 3.3 Safe SIMD

**Adversarial finding 3.3.** `std::simd` is still nightly-only as of Rust 2021 stable. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe` and the "Safe SIMD" claim is **false advertising**. The Tribunal requires the source to demonstrate that all `unsafe` blocks are wrapped in a safe API with documented invariants.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in `R^(2K × 2K)`

The Cayley retraction on the Stiefel manifold `