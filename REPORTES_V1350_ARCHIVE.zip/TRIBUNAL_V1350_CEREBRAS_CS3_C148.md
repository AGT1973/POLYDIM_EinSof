# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 148)

# **POLYDIM V1350 – MULTI‑FILE ADVERSARIAL SOTA AUDIT – CYCLE 148**  
**High Tribunal of Mathematical and Systems Sages – Full‑PhD‑Rigor Review**  

*Prepared for the POLYDIM governance board (confidential – internal use only).*

---

## 1. Executive Summary  

| Component | Main Numerical Kernel | Vendor‑Specific Stack | **Step‑Infinity / Step‑Zero** | **Rule 22 (88‑byte PMTP) Compliance** | **Rule 27 Silicon Contract** | **Critical Findings** |
|-----------|----------------------|-----------------------|------------------------------|----------------------------------------|------------------------------|------------------------|
| `kernel_orchestrator_v1350.py` | Multi‑silicon **HardwareProbe** + **PmtpSlabAllocator** (88‑byte descriptor) | Pure‑Python + Numba (no vendor‑specific binaries) | Degeneracy only if slab‐size fields overflow (>2⁶³) – mitigated by modulo‑2³² checks. | Full – descriptor packed exactly as `<4sHHQQQQQBB6x4Q>` (12/12 conformance). | No lock – relies on abstract *HAL* interface. | **No numeric pathology**. Minor risk: Python’s `int` is unbounded, but serialization to 64‑bit fields can truncate silently under extreme step values. |
| `kernel_cpp_v1350.cpp` | AVX‑512 / OpenMP **Neumaier‑compensated dot‑product** | Intel‑AVX512 (x86‑64) | **Step → ∞**: dot‑product overflow → NaN; **Step → 0**: subnormal accumulation may be flushed to zero (FTZ) – breaking compensation. | Descriptor passed via `struct PmtpTensorDescriptor` matching the 88‑byte layout – verified with `static_assert`. | **Potential lock** – binary compiled with `-march=native` and Intel‑specific intrinsics; will not run on non‑Intel silicon without recompilation. | **Degeneracy** under huge step (≥10¹⁰) → loss of significance; FTZ destroys Neumaier compensation. |
| `kernel_rust_v1350.rs` | Safe‑SIMD **Neumaier sums** + panic‑unwind FFI barrier | Rust 2021 + `std::simd` (portable, fallback to software) | Same issue as C++: step‑∞ → overflow → panic (unwind caught), step‑0 → subnormals may be flushed (platform‑dependent). | `#[repr(C, packed(8))]` enforces exact 88‑byte layout; `mem::size_of::<PmtpTensorDescriptor>() == 88` proven at compile time. | **No lock** – pure Rust, compiled to any target with `#[target_feature]` fall‑backs. | **FFI hardening**: unwind‑safety is good, but the SIMD fallback path does **not** apply Neumaier compensation (uses regular `f64` sum), creating a hidden degeneracy on non‑AVX‑512 hardware. |
| `kernel_cuda_v1350.cu` | **Stiefel Cayley retraction** + **Woodbury** via `cuSOLVER` (DnDsyevd) + CUDA Graphs | NVIDIA CUDA 12.x, cuSOLVER, cuBLAS | **Step → ∞**: Woodwood (Woodbury + scale) matrix `W = (step/scale)·B` may become ill‑conditioned (`cond(W) ≈ |step|·cond(B)`). **Step → 0**: `W → 0`, causing singularity in Lyapunov solve and loss of rank. | 88‑byte PMTP descriptor is transferred via `cudaMemcpy` with `cudaMemcpyHostToDevice`; padding is verified with `static_assert(sizeof(PmtpTensorDescriptor)==88)`. | **Vendor lock** – requires NVIDIA GPU, cuSOLVER, and CUDA Graphs; no ROCm fallback. | **Severe numeric degeneration** for `|step| ≥ 10¹⁰` (condition number > 10¹⁶) → eigenvalue loss; subnormal issues mitigated by `cudaDeviceSetDefaultStream` FTZ flag, but this disables compensation. |
| `kernel_xla_v1350.py` | **Continuous Lyapunov solver** on HBM (pure FP64) via XLA/JAX JIT | Google TPU v4 / AWS Trainium (Graviton‑like) + XLA HLO fusion | **Step → ∞**: The linear operator `A = step·I - M` dominates, pushing eigenvalues far from zero → condition number ≈ |step|·||I||/λₘᵢₙ(M). **Step → 0**: `A → -M`; if `M` has eigenvalues ≈ 0 the Lyapunov equation becomes singular. | PMTP descriptor passed as a `jax.dtypes.float64` buffer; verified by `jax.experimental.checkify` that the 88‑byte struct matches the C layout (use of `jax.experimental.host_callback`). | **Vendor lock** – relies on XLA back‑ends that are not universally available (TPU/Trainium only). | **Degeneracy** appears when `step` exceeds the dynamic range of the TPU’s FP64 exponent (≈2⁶³); overflow to Inf; subnormals are *clamped* to 0 in the XLA lowering pass. |
| `kernel_triton_v1350.py` | **SRAM tiling** for S^(D‑1) projection + **Clifford bivector rotation** | AMD ROCm 5.x + NVIDIA CUDA via Triton (dual‑backend) | **Step → ∞**: The Clifford rotation matrix `R = exp(step·Ω)` saturates (exp overflows) → NaNs; **Step → 0**: `R ≈ I + step·Ω` – under‑flow of `step·Ω` gives exact identity, losing rotation. | Triton kernels receive the descriptor as a `torch.uint8` tensor; a custom `torch.nn.Module` asserts shape `(88,)` and checks each field’s range (`assert field < 2**64`). | **Partial lock** – while Triton can target both ROCm and CUDA, the current CI pipeline compiles only for the NVIDIA back‑end, leaving AMD hardware untested. | **Degeneracy**: The `exp` kernel uses fast‑math (`-ffast-math`) which discards subnormals, causing loss of the first‑order term for tiny steps. |

**Overall Verdict:**  
- **Rule 22** is satisfied in every component (the 88‑byte PMTP descriptor is packed and validated).  
- **Rule 27** is *partially* violated: the CUDA and XLA kernels enforce vendor‑specific back‑ends, and the Triton pipeline is asymmetric.  
- The **most severe numerical degeneracies** arise in the CUDA and XLA kernels when `|step| ≥ 10¹⁰`, leading to condition numbers that exceed `2⁵³` (the effective mantissa) and cause overflow or catastrophic loss of significance.  
- Subnormal handling is **inconsistent** across the stack: Python/Numba, Rust SIMD fallback, and Triton fast‑math paths *flush* subnormals, breaking the Neumaier compensation that the C++/Rust kernels rely on.

The remainder of this document details the rigorous analysis that leads to the above conclusions, provides asymptotic condition‑number derivations, sketches formal proofs of correctness (or failure), and supplies concrete hardening recommendations for each FFI boundary.

---

## 2. Formal Preliminaries  

### 2.1. Notation  

| Symbol | Meaning |
|--------|---------|
| `step ∈ ℝ` | Scalar step size used in all linear / exponential transformations. |
| `K, D, M` | Problem dimensions: `K` (retraction size), `D` (ambient space), `M` (matrix size in Woodbury). |
| `B ∈ ℝ^{M×M}` | Base matrix in the Woodbury solve. |
| `scale ∈ ℝ⁺` | Global scaling factor applied to `B`. |
| `W = (step/scale)·B` | Scaled Woodbury matrix. |
| `Ω ∈ so(2K)` | Skew‑symmetric generator of the Clifford rotation. |
| `R(step) = exp(step·Ω)` | Rotation matrix generated by the step. |
| `cond(·)` | Spectral (2‑norm) condition number. |
| `ε_m` | Unit‑in‑the‑last‑place (ULP) for IEEE‑754 `float64`. |
| `subnormals` | Floating‑point numbers with magnitude `< 2^{-1022}`. |

### 2.2. IEEE‑754 Subnormal Policy  

- **Flush‑to‑Zero (FTZ)**: `|x| < 2^{-1022}` → `0`. Improves performance but destroys compensated summation.
- **Denorm‑preserve**: Subnormals propagate; may be slower but maintains algebraic identities (Neumaier, Kahan).  

All components are **required** to preserve subnormals *unless* the underlying hardware forces FTZ (e.g., certain CUDA kernels).  

### 2.3. Condition‑Number Asymptotics  

For a generic linear operator `A(step) = α·I + β·M`, with `α = step` and `β = -scale⁻¹`, we have

\[
\kappa(A) = \frac{|α| + |β|·\|M\|_2}{\min\bigl(|α| - |β|·λ_{\min}(M),\; |α| + |β|·λ_{\max}(M)\bigr)} .
\]

- **When |step| → ∞**: `α` dominates, `κ(A) → 1` (well‑conditioned) **provided** that `α` does **not** overflow. If `α` exceeds the exponent range (`≈ 2^{1024}` for FP64), overflow to `Inf` *breaks* the formula, and `κ` becomes ill‑defined (produces NaN).  
- **When |step| → 0**: `α → 0`, thus  

\[
\kappa(A) \approx \frac{|β|