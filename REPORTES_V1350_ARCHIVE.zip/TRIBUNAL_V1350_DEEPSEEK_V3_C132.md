# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 132)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 132 · Six-Component Adversarial Review

**Preliminary note on evidentiary basis.** The Tribunal has been presented with *architectural claims* (file names, descriptor layouts, algorithm names) but no source listings, no build artifacts, no conformance logs, and no numerical test vectors. Under Rule 22's spirit — *no 1D tokens, no unverified assertions* — the Tribunal must therefore distinguish between (a) claims that are **structurally checkable from the specification alone**, (b) claims that are **conditionally sound if the stated algorithm is implemented as described**, and (c) claims that are **unfalsifiable without artifacts**. Every finding below is tagged accordingly. The Tribunal will not rubber-stamp.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us actually do the arithmetic, because this is the one claim that is *fully* checkable from the spec.

| Field | Format | Size (bytes) |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Verdict: 88 bytes confirmed.** Alignment: `struct.calcsize` with native alignment would *not* be 88 — the `6x` pad is only correct under `=` (standard, no alignment) or `<` (little-endian, no alignment). The format string uses `<`, so this is consistent. **However**: the Tribunal flags that `4Q` at offset 56 requires the producer and consumer to agree on endianness. If any component (notably the CUDA or XLA path) serializes via `memcpy` of a native struct, the `<` contract is silently violated on big-endian hosts (POWER9, some s390x). **Recommendation:** assert `sys.byteorder == 'little'` at import, or emit a `>4s...` variant.

### 1.2 "12/12 physical conformance checks"

The number 12 is asserted, not derived. Without the check list, the Tribunal cannot verify that the checks are *independent* (rank-12 constraint system) or *sufficient* (do they pin the descriptor uniquely?). A conformance suite that checks 12 correlated predicates has effective rank < 12 and provides false assurance. **Demand:** publish the Jacobian rank of the check system, or at minimum the pairwise correlation matrix of check outcomes on a fuzzed corpus.

### 1.3 `PmtpSlabAllocator` — numerical degeneracy

Slab allocators are integer-domain; no `step → ∞` or `step → 0` degeneracy arises *in the allocator itself*. The risk is **descriptor aliasing**: if the allocator hands out 88-byte slabs and a caller writes a 96-byte struct (e.g., a Rust `#[repr(C)]` with default alignment padding), the next slab's magic is corrupted. **FFI hardening:** require every producer to `static_assert(sizeof(desc) == 88)` and every consumer to validate magic + a CRC16 over bytes [4,88) before dereferencing.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuska gives a *forward* error bound

$$
|\hat{s} - s| \le \big(2u + O(nu^2)\big)\sum_{i=1}^{n}|x_i y_i|,
$$

with $u = 2^{-53}$ for FP64. This is **unconditional** in $n$ (no $nu$ growth in the leading term), which is the correct claim. But the Tribunal notes two adversarial cases:

- **Catastrophic cancellation with subnormal products.** If $x_i y_i$ underflows to subnormal, the compensation term $c$ itself loses precision. The stated "subnormal audits (-12, -14)" suggest the authors are aware. **Demand:** the audit must report the *minimum exponent* of $|x_i y_i|$ across the reduction, not just a flag. A dot product whose terms span $[10^{-320}, 10^{300}]$ has a dynamic range of $2^{2060}$ — Neumaier does **not** save you; you need a two-float (double-double) accumulator or a Kulisch superaccumulator.
- **Condition number.** For the dot product itself, $\kappa = \sum|x_i y_i| / |\sum x_i y_i|$. Neumaier's *relative* error is bounded by $2u\kappa$. When $\kappa \to \infty$ (near-orthogonal vectors), the result is dominated by rounding. This is intrinsic, not a bug — but the audit must report $\kappa$ per call, not just pass/fail.

### 2.2 AVX-512 + OpenMP — determinism hazard

OpenMP `reduction(+:)` is **not** bit-reproducible across thread counts. If POLYDIM's inter-agent protocol assumes deterministic descriptors (Rule 22), then a Neumaier sum computed with 8 threads vs. 16 threads will differ in the last ULP, and the 88-byte descriptor's `Q` fields (if they encode a hash of the result) will diverge. **This is a Rule 22 violation risk.** Mitigation: fixed-tree reduction (pairwise, log-depth) with `#pragma omp parallel for schedule(static)` and explicit tree combine, or a deterministic reduction flag (`OMP_DETERMINISTIC_REDUCTION` is not standard; use `reduction` on a fixed-size array then serial combine).

### 2.3 Zero-copy PMTP validation

"Zero-copy" + "validation" is a tension. If you validate the 88-byte descriptor in-place, you must not fault on a page that the producer hasn't committed. **FFI hardening:** use `madvise(MADV_WILLNEED)` or `userfaultfd` for cross-process PMTP; for intra-process, `std::atomic<uint64_t>` on the magic field with acquire semantics.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier — **this is backwards**

The Tribunal must be blunt: `panic = unwind` is the *default* and is **not** a safety barrier across FFI. A Rust panic unwinding into C++ is **undefined behavior** unless the C++ side is compiled with `-fexceptions` and the boundary is wrapped in `catch_unwind`. The correct barrier is:

```rust
#[no_mangle]
pub extern "C" fn poly_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(v) => v,
        Err(_) => POLY_ERR_PANIC,
    }
}
```

`panic = abort` is *safer* for FFI (no unwinding across the boundary) but kills the process. **Recommendation:** `panic = abort` in the cdylib profile, plus `catch_unwind` at every `extern "C"` entry point, plus `#[repr(C)]` on every shared struct. The claim as stated is **rejected**.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust's `#[repr(C, packed)]` gives 88 bytes but **unaligned field access** — reading a `u64` from a packed struct is UB-adjacent (actually defined but generates `memcpy` and can fault on some architectures if the compiler emits a direct load; modern rustc handles it, but `&packed.field` is a hard error). **Recommendation:** use `#[repr(C)]` with explicit `_pad: [u8; 6]` and `static_assert` via `const _: () = assert!(size_of::<Desc>() == 88);`. This is the only way to get both 88 bytes and aligned access.

### 3.3 Safe SIMD + Neumaier

`std::simd` is still nightly. If the crate uses `core::arch::x86_64::_mm512_*`, it is **not** "Safe SIMD" — it is `unsafe` intrinsics. The claim of "Safe SIMD" is only true if the crate uses `wide` or `pulp` or `std::simd` (nightly). **Demand:** name the SIMD abstraction. If it's `core::arch`, the safety claim is false.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction — the real degeneracy

The Cayley retraction on the Stiefel manifold $St(n,p)$ is

$$
Y(\tau) = \left(I + \tfrac{\tau}{2} A\right)^{-1}\left(I - \tfrac{\tau}{2} A\right) X, \quad A = GX^\top - XG^\top,
$$

where $G$ is the Euclidean gradient. The **condition number** of the solve is

$$
\kappa\!\left(I + \tfrac{\tau}{2}A\right) = \frac{1 + \tfrac{\tau}{2}\|A\|_2}{1 - \tfrac{\tau}{2}\|A\|_2} \quad (\text{for } A \text{ skew-symmetric, eigenvalues } \pm i\lambda).
$$

**As $\tau \to \infty$:** the solve becomes singular when $\tfrac{\tau}{2}\lambda_{\max}(A) \to 1$ in the *imaginary* sense — actually for skew-symmetric $A$, $I + \tfrac{\tau}{2}A$ has eigenvalues $1 \pm i\tfrac{\tau}{2}\lambda$, so $\|(I+\tfrac{\tau}{2}A)^{-1}\|_2 = 1/\sqrt{1 + (\tfrac{\tau}{2}\lambda_{\min})^2} \to 0$. **The Cayley retraction is unconditionally stable for skew-symmetric $A$** — this is a *feature*, not a bug. But the *step* $\tau$ is not the same as the optimizer step; if the caller passes `step = 1e10`, the retraction is fine but the *descent direction* is garbage. **The degeneracy is upstream, not in the retraction.**

**As $\tau \to 0$:** $Y \to X$, and the update is lost to rounding. The relative change is $O(\tau\|A\|)$, so for $\tau < u/\|A\| \approx 10^{-16}/\|A\|$, the retraction is a no-op. **Demand:** the kernel must clamp $\tau$ to $[\tau_{\min}, \tau_{\max}]$ with $\tau_{\min} = 10^{-12}/\|A\|$ and $\tau_{\max}$ set by the trust region.

### 4.2 Woodbury solve $(M/\text{scale}) W = (\text{