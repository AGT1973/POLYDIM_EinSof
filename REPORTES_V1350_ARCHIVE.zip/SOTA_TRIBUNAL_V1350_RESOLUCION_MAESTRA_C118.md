# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 118

No verifiable public specification or the eight Tribunal reports for **POLYDIM V1350 / PMTP** were provided, so a literal arbitration of their individual findings is not possible. The defensible SOTA result is therefore a **conditional architectural synthesis**, not a claim that these guarantees have been demonstrated.

## Arbitration

### 1. Cayley–Stiefel retraction under \(\lvert\mathrm{step}\rvert \ge 10^{10}\)

A Cayley retraction is not intrinsically stable merely because it preserves orthogonality algebraically. Its usual form,

\[
Q_{+}=\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
       \left(I+\frac{\alpha}{2}\Omega\right)Q,
\qquad \Omega^{T}=-\Omega,
\]

is well-defined in exact arithmetic for real \(\alpha\), because the spectrum of a real skew-symmetric \(\Omega\) is purely imaginary. In finite precision, however, extreme scaling creates overflow, loss of relative accuracy, poorly conditioned linear solves, and stagnation in iterative implementations.

The correct arbitration is:

- **Householder QR:** preferred default for a general large step when a robust orthonormal factor is required. It is backward stable, but it does not preserve the exact Cayley path or necessarily provide the same smooth retraction derivative.
- **Polar retraction:** geometrically natural and often highly accurate, but its implementation requires a reliable matrix inverse square root or equivalent iteration. Newton–Schulz variants need scaling and convergence safeguards.
- **Cayley:** attractive for structure preservation and low-rank updates, but only conditionally stable. A fixed-point Cayley iteration cannot be certified for arbitrary extreme steps without a contraction bound; its step must be scaled, solved with a stable factorization, and monitored.

Published numerical analysis gives the canonical Cayley retraction a favorable local condition bound, while Householder QR is a standard way to construct Stiefel maps; those are **local or algorithmic stability results**, not a proof of safe execution at \(\lvert\mathrm{step}\rvert\ge10^{10}\).[5] The available comparative literature also reports that QR and polar methods can become unstable in particular unscaled experiments, demonstrating that “QR” or “polar” alone is not a complete implementation guarantee.[10]

**Definitive kernel rule**

Use a scaled hybrid:

1. Compute a scale \(s\) so that \(\widehat{\alpha}=\alpha/s\) lies in a safe numerical range.
2. Apply the Cayley update using a backward-stable solve, preferably QR or pivoting-aware LU for the relevant system.
3. If the residual
   \[
   r=\lVert Q_{+}^{T}Q_{+}-I\rVert
   \]
   exceeds tolerance, reorthogonalize with Householder QR.
4. Reject or subdivide the step if scaling, overflow, residual, or solver-iteration limits fail.

Thus, the strongest justified guarantee is:

> **Bounded-step or safeguarded-step orthogonality:** if scaling, stable solve, and residual checks succeed, the returned matrix satisfies the configured backward-error tolerance. There is no unconditional guarantee for arbitrary raw steps of magnitude \(10^{10}\) in finite precision.

A claim that unmodified Cayley is categorically superior to Householder QR or polar retraction under such steps is not supported.

### 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

Acquire/release ordering is sufficient to publish a fully initialized descriptor **only when all readers and writers participate in the same synchronization protocol**:

1. Writer initializes the descriptor’s ordinary fields.
2. Writer publishes its pointer, index, or generation with a **release** store.
3. Reader performs an **acquire** load of that same publication variable.
4. Reader announces its read-side critical section before dereferencing.
5. Writer retires the old descriptor only after RCU/QSBR grace-period completion.
6. Reclamation occurs only after every preexisting reader has quiesced.

A release store followed by an acquire load that reads from it establishes the required synchronizes-with relation in C++ memory ordering.[1] Rust exposes the same acquire/release model as C++20 and specifies that prior writes become visible after a matching acquire.[2] Linux RCU documentation likewise distinguishes release publication operations from acquire loads.[11]

The 88-byte size is **not itself a memory-model guarantee**. It does not ensure:

- atomicity of the whole descriptor;
- absence of tearing on every target;
- cache-line atomicity;
- safe reclamation;
- consistency if fields are independently mutated;
- correctness across devices or programming models.

**Required descriptor contract**

- Treat the 88-byte object as immutable after publication, or version every mutable field.
- Publish one atomic pointer/handle/generation—not the 88 bytes as a pseudo-atomic blob.
- Align the descriptor and define its ABI layout explicitly.
- Use release publication and acquire consumption.
- Use QSBR/RCU read-side registration and grace periods for reclamation.
- Include an ABA-resistant generation or tagged handle if addresses can be reused.
- Validate descriptor length, version, alignment, and checksum or invariant fields where corruption is possible.

The exact guarantee is therefore:

> **Snapshot isolation for immutable descriptors:** an acquired reader sees a fully initialized descriptor associated with the publication it observed, and reclamation cannot occur before the required grace period—provided every access follows the protocol.

Acquire/release alone does **not** provide isolation for concurrent in-place mutation, nor does it synchronize arbitrary CUDA/XLA/Triton device memory with host RCU.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or execution model shared identically by all five environments. C++20 and Rust provide closely related language-level atomic ordering models; Rust explicitly states that its orderings correspond to C++20.[2] CUDA, XLA, and Triton introduce separate compilation, launch, device-memory, and synchronization semantics. A host-language acquire operation cannot by itself establish visibility for a device kernel, and a device fence cannot by itself complete a host RCU grace period.

The portable architecture must therefore separate **semantic layers**:

| Layer | Required mechanism | Guarantee |
|---|---|---|
| C++20/Rust host | Atomic release publication, acquire consumption, explicit lifetime protocol | Language-level publication and ordering |
| CUDA device | Device-supported atomics, fences, stream/event synchronization, explicit address-space rules | Device-level visibility under the selected scope |
| Triton | Operations expressible in the target backend’s supported atomic/fence model | Backend-dependent device ordering |
| XLA | Token/control dependencies, buffer donation/aliasing rules, executable boundaries | Compiler-preserved dependency ordering |
| RCU/QSBR | Reader registration, quiescent states, grace-period completion | Safe retirement and reclamation |

**Conformance should be defined by invariants, not source-code identity:**

- descriptor ABI: exact 88-byte size, alignment, offsets, endianness, and version;
- publication: release/acquire or a stronger backend-equivalent;
- snapshot: no reader observes partially initialized immutable state;
- lifetime: no reclamation before grace-period completion;
- retraction: orthogonality residual and finite-value checks;
- determinism: specified tolerance and behavior under retries or fallback;
- failure behavior: explicit rejection, subdivision, or QR repair;
- cross-backend tests: litmus tests, randomized stress, extreme-step tests, race detection, and differential numerical checks.

## Final architectural guarantees

The mathematically strongest defensible specification is:

1. **Retraction guarantee:** the kernel returns either a finite near-Stiefel matrix satisfying a declared residual bound, or an explicit failure/fallback result. It must not promise unconditional stability for raw steps \(\ge10^{10}\).
2. **Publication guarantee:** an acquired descriptor is fully initialized if and only if it was published through the defined release/acquire channel.
3. **Snapshot guarantee:** an immutable descriptor remains valid throughout a registered RCU/QSBR read-side critical section.
4. **Reclamation guarantee:** retired descriptors are reclaimed only after a completed grace period covering all readers that could have observed them.
5. **Portability guarantee:** C++20 and Rust can share the host protocol; CUDA, Triton, and XLA require backend-specific adapters preserving the same abstract invariants.
6. **Non-guarantees:** descriptor width does not imply atomic whole-object updates; acquire/release does not solve reclamation; host atomics do not automatically synchronize device memory; and Cayley algebra does not guarantee finite-precision robustness at arbitrary extreme steps.

Any Tribunal conclusion stronger than these—especially unconditional extreme-step Cayley stability or universal cross-silicon memory equivalence—should be classified as **unproven unless accompanied by backend-specific proofs, litmus tests, and numerical stress evidence**.