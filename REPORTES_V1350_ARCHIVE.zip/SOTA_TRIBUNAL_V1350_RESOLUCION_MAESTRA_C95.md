# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 95

The requested “Cycle 95” arbitration cannot be validated as stated: no public, authoritative record of **POLYDIM V1350**, its six kernels, the six Tribunal reports, or the **PMTP 88-byte descriptor** was found. The available evidence supports only a general technical synthesis, not exact product-specific guarantees.

## 1. Stiefel retraction under extreme steps

For \(X \in \mathrm{St}(n,p)\) and tangent direction \(\Xi\), the relevant maps include

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)\left(I+\Xi^{\mathsf T}\Xi\right)^{-1/2},
\]

QR retraction

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley map of the form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=
\left(I-\frac12 A\right)^{-1}
\left(I+\frac12 A\right)X,
\]

where \(A\) is skew-symmetric and constructed from \(X,\Xi\). These are established alternatives for Stiefel optimization; published comparisons characterize polar, QR, and Cayley methods primarily by accuracy, cost, and implementation properties—not by an unconditional guarantee of numerical stability for arbitrary step magnitudes.[1]

For \(\lVert \Xi\rVert \ge 10^{10}\), no mathematically valid implementation can promise ordinary floating-point accuracy merely because the map is called “Cayley,” “polar,” or “QR.” The dominant issues are overflow, loss of relative precision, conditioning, cancellation, and failure of the linear solve or factorization. In particular:

- A **Cayley formulation** can preserve orthogonality algebraically because its transform is orthogonal when evaluated exactly, but this does not guarantee stable finite-precision evaluation. The solve should use a backward-stable factorization, not an explicit inverse.
- **Householder QR** is generally the strongest default for robust orthogonalization in finite precision, provided the input is scaled and rank deficiency is handled.
- **Polar retraction** gives the closest orthonormal factor in Frobenius norm and has an attractive geometric interpretation, but computing \((I+\Xi^{\mathsf T}\Xi)^{-1/2}\) for extreme scales requires scaling and a stable matrix-square-root method.
- A raw “Cayley Stiefel retraction” should therefore not be declared superior to Householder QR or scaled polar decomposition at \(\lvert\text{step}\rvert \ge 10^{10}\).

The defensible arbitration is:

> **Use scaled Cayley only when its skew operator and solve are proven well-conditioned; otherwise fall back to Householder QR or a scaled polar factorization.**

A meaningful guarantee requires explicit bounds such as

\[
\frac{\lVert \widehat Q^{\mathsf T}\widehat Q-I\rVert}
{\epsilon_{\mathrm{mach}}}
\le C(n,p,\kappa,\text{implementation}),
\]

along with overflow-safe scaling and a defined rank-deficiency policy. Without those conditions, “stable for extreme step” is not an architectural guarantee.

## 2. PMTP descriptor barriers and RCU/QSBR isolation

The descriptor layout and ownership protocol are not publicly specified, so its exact 88-byte field semantics cannot be independently arbitrated. The correct memory-ordering principle is nevertheless clear:

- A publisher must initialize the descriptor and referenced immutable state, then publish the pointer or generation with **release** semantics.
- A reader must acquire that publication before dereferencing the descriptor or its immutable payload.
- Reclamation must occur only after the reader has passed through a valid **RCU read-side critical section** or has reported a sufficiently advanced **QSBR quiescent state**.
- The lifetime guarantee is separate from visibility: acquire/release orders initialization and observation, while RCU/QSBR prevents reclamation during use.

A typical publication rule is conceptually:

\[
\text{initialize}(D,S)
\;\prec\;
\operatorname{store\_release}(P,D),
\]

with the reader performing

\[
D=\operatorname{load\_acquire}(P)
\;\prec\;
\text{read}(D,S).
\]

For reclamation, the publisher must satisfy

\[
\operatorname{retire}(D)
\;\prec\;
\text{wait for all pre-existing readers to quiesce}
\;\prec\;
\operatorname{free}(D).
\]

Therefore, a descriptor-sized structure alone cannot guarantee snapshot isolation. The exact guarantee is available only if the protocol specifies:

1. atomicity and alignment of every published pointer, version, and state field;
2. release publication and acquire consumption;
3. immutable-after-publication payload rules, or separately synchronized mutable fields;
4. reader registration/critical-section boundaries;
5. grace-period or QSBR epoch advancement;
6. reclamation only after the grace period;
7. ABA protection through generations, hazard mechanisms, or equivalent identity validation.

A plain acquire load does **not** by itself prevent use-after-free, and a release store does **not** by itself create RCU isolation. Any Tribunal finding claiming otherwise would be technically unsound.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no basis for asserting bitwise or memory-model equivalence across all five environments without a conformance specification and executable tests. These systems expose materially different execution and synchronization models:

- **C++20 and Rust** provide host-language atomic and ownership abstractions, but device execution and foreign-memory interoperability require additional contracts.
- **CUDA** has device-specific memory scopes, stream ordering, and host/device visibility rules.
- **Triton** expresses GPU kernels through compiler-defined program instances and synchronization primitives rather than the full C++ memory model.
- **XLA** uses an optimizing graph/compiler model in which buffer aliasing, ordering, and side effects must be represented through supported compiler operations.

The strongest portable contract is thus not “identical semantics everywhere,” but a restricted common subset:

- descriptors are immutable after publication;
- publication uses an explicitly supported release operation;
- consumption uses the corresponding acquire operation;
- no unsynchronized host/device concurrent mutation is permitted;
- reclamation is performed only by an authority that can observe all relevant readers;
- numerical kernels use deterministic scaling, defined tolerances, and explicit handling of NaN, infinity, overflow, rank deficiency, and nonconvergence;
- conformance is tested by litmus tests and numerical equivalence tests on every backend.

The exact guarantee should be stated as:

> **Cross-backend observational conformance within a declared numerical tolerance and under a declared execution/memory contract—not universal bitwise identity or unrestricted C++20 memory-model equivalence.**

## Definitive synthesis

The mathematically strongest defensible architecture is a **guarded hybrid design**:

1. Normalize or rescale extreme retraction inputs before forming products or solves.
2. Attempt the Cayley update only with a stable factorization and conditioning checks.
3. Verify the result using an orthogonality residual.
4. Fall back to Householder QR, or to a scaled polar factorization when closest-factor behavior is required.
5. Publish descriptors with release semantics and consume them with acquire semantics.
6. Treat RCU/QSBR grace periods as the reclamation guarantee; do not confuse them with acquire/release visibility.
7. Define one backend-neutral semantic contract, then implement backend-specific synchronization and test it with litmus tests.
8. Guarantee numerical bounds and lifetime safety only under explicit preconditions.

Accordingly, the exact unconditional claims that can be made are limited:

- **Orthogonality:** guaranteed mathematically by the ideal retraction, but finite-precision accuracy requires scaling, stable algorithms, and residual checks.
- **Extreme-step safety:** not guaranteed for an unscaled Cayley implementation at \(\lvert\text{step}\rvert \ge 10^{10}\).
- **Snapshot visibility:** guaranteed only by release publication paired with acquire observation.
- **Snapshot lifetime:** guaranteed only by correct RCU/QSBR grace-period reclamation.
- **Multi-silicon conformance:** guaranteed only for the explicitly tested common subset and declared tolerances.
- **Bitwise identity across CUDA, XLA, Triton, C++20, and Rust:** not inferable and should not be promised.

The public technical literature supports the existence and standard forms of Cayley, QR, and polar Stiefel retractions, including their differing computational costs and geometric properties, but it does not substantiate the POLYDIM-specific Tribunal findings or the requested “SOTA” product-level guarantees.[1]