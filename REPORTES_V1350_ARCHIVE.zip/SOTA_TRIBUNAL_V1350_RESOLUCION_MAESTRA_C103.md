# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 103

A **definitive arbitration is not possible from the supplied record**: the six Tribunal outputs, the six V1350 kernel specifications, and reproducible benchmark/conformance artifacts are absent. The available search evidence does not identify a public “POLYDIM V1350” specification; it instead points to unrelated PolyDiM PDE software and general QSBR/RCU implementations.[7][8][9][1] Therefore, no claim that one Tribunal model prevailed—or that V1350 has exact cross-platform guarantees—can be responsibly certified.

The strongest technically defensible synthesis is:

## 1. Cayley–Stiefel retraction under extreme steps

A Cayley retraction is not automatically stable for \(\lvert \mathrm{step}\rvert \ge 10^{10}\). For a tangent-space update \(A^\top \Delta+\Delta^\top A=0\), the usual form is

\[
A_{+}
=
\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
\left(I+\frac{\alpha}{2}\Omega\right)A,
\]

with \(\Omega^\top=-\Omega\). In exact arithmetic, the Cayley factor is orthogonal whenever the inverse exists. In floating-point arithmetic, however, the decisive quantity is not the scalar step alone but

\[
\kappa\!\left(I-\frac{\alpha}{2}\Omega\right),
\qquad
u\|\alpha\Omega\|,
\]

where \(u\) is unit roundoff.

At extreme step magnitudes:

- The matrix solve can become ill-conditioned or dominated by overflow, underflow, cancellation, or loss of significance.
- Orthogonality is not guaranteed merely because the exact Cayley transform is orthogonal.
- A stable implementation must use a factorized solve, scaling or step decomposition, finite-value checks, residual tests, and an explicit fallback.
- If the required invariant is numerical orthogonality, a **polar or Householder/QR retraction** is generally the stronger postcondition mechanism: it can explicitly re-project the computed result and measure the residual
  \[
  \|Q^\top Q-I\|.
  \]

The correct arbitration is therefore conditional:

| Claim | Arbitration |
|---|---|
| Cayley is mathematically orthogonal in exact arithmetic | Valid |
| Cayley is unconditionally more stable than QR/polar QR at \(\lvert\mathrm{step}\rvert\ge10^{10}\) | Unsupported |
| Householder QR is a robust orthogonalization fallback | Generally valid, subject to rank and conditioning assumptions |
| Polar retraction gives the closest orthogonal factor for the chosen norm | Valid for the standard full-rank polar decomposition |
| Any method guarantees success for arbitrary finite inputs and extreme steps | False |

The strongest architectural guarantee that can be made is:

> The kernel guarantees a Stiefel-feasible output only if it verifies finite arithmetic, successful factorization, and an orthogonality residual below a declared tolerance; otherwise it returns a failure status or invokes a certified QR/polar fallback. It must not silently claim unconditional stability.

A suitable contract is

\[
\|A_{+}^{\top}A_{+}-I\| \le \tau_{\mathrm{orth}},
\]

with \(\tau_{\mathrm{orth}}\) specified by datatype, backend, matrix dimension, and reduction mode.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

The descriptor’s size—88 bytes—does not itself establish memory ordering, atomicity, ABI safety, or snapshot isolation. Those properties depend on:

- field alignment and packing;
- which fields are immutable;
- whether the descriptor is published by pointer or copied;
- the atomicity of each publication operation;
- the reader/writer memory-order protocol;
- object lifetime and reclamation;
- the supported memory model on each target.

For RCU/QSBR, the minimum sound publication pattern is conceptually:

1. Construct a complete immutable descriptor.
2. Publish its pointer with **release** semantics.
3. Load the pointer with **acquire** semantics before reading the descriptor.
4. Ensure readers enter a protected RCU/QSBR read-side interval before dereferencing.
5. Retire the old descriptor only after a grace period has completed.

Acquire/release establishes ordering around publication; it does **not**, by itself, solve reclamation. A reader that performs an acquire load outside a valid read-side protection interval can still access freed storage. Conversely, a QSBR grace period is meaningful only if every participating reader reports quiescence according to the protocol. Established QSBR implementations explicitly track reader observations and quiescent states, and require ordering around publication and grace-period progression.[1]

Thus the exact guarantee should be:

> A reader observes either the fully initialized old descriptor or the fully initialized new descriptor, provided publication uses release, observation uses acquire, readers register and correctly participate in RCU/QSBR, and reclamation occurs only after a completed grace period.

The following stronger claims are not justified:

- “Acquire/release makes an 88-byte descriptor atomically snapshotted.”
- “A descriptor copy is tear-free on every target.”
- “Acquire/release alone prevents use-after-free.”
- “QSBR provides isolation from readers that fail to report quiescence.”

If the descriptor must be copied rather than accessed through an immutable pointer, the implementation needs a versioned seqlock-style protocol or an atomic representation whose width and alignment are guaranteed by the target ABI. An 88-byte object should not be treated as one atomic unit merely because it is naturally aligned.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or numerical model shared identically by these environments. “Conformance” must therefore mean conformance to a deliberately defined abstract contract, not bit-for-bit identity by default.

Important differences include:

- CUDA and Triton expose GPU execution, synchronization, and memory scopes that are not interchangeable with C++20 atomics.
- XLA may reorder, fuse, replicate, or lower operations according to its compiler-level semantics; host-language acquire/release does not automatically constrain device-side transformations.
- C++20 defines a language memory model, but backend libraries and device code may provide different guarantees.
- Rust’s safety and atomic APIs do not automatically make foreign GPU memory accesses safe or establish synchronization across an FFI boundary.
- Floating-point contraction, reduction order, flush-to-zero behavior, fast-math settings, and matrix instruction selection can produce numerically different—but potentially contract-compliant—results.

A valid conformance specification should separate:

### Functional invariants

- Descriptor schema, offsets, alignment, endianness, and version.
- Validity predicates for all fields.
- Stiefel residual tolerance.
- NaN, infinity, overflow, and failure behavior.
- RCU publication and reclamation protocol.

### Synchronization invariants

- Which operation publishes a descriptor.
- Which operation acquires it.
- Scope: thread, block, device, host, or system.
- Required reader critical-section lifetime.
- Grace-period completion condition.
- Prohibited data races and reclamation-before-grace behavior.

### Numerical invariants

- Allowed normwise error:
  \[
  \|f_{\text{backend}}(x)-f_{\text{reference}}(x)\|
  \le
  \tau_{\text{abs}}+\tau_{\text{rel}}\|f_{\text{reference}}(x)\|.
  \]
- Orthogonality bound:
  \[
  \|Q^\top Q-I\|\le\tau_{\mathrm{orth}}.
  \]
- Whether deterministic reduction order is required.
- Whether fused multiply-add and mixed precision are permitted.

### Failure invariants

- No silent fallback that changes semantics.
- Explicit status for singular factorization, invalid descriptor, timeout, failed grace period, or numerical residual violation.
- No reclamation until the specified grace period completes.
- No “success” result when the postcondition was not checked.

## Definitive arbitration

The mathematically superior SOTA design is not a single unconditional kernel. It is a **verified adaptive implementation**:

1. Use the Cayley update when conditioning estimates, scaling checks, and residual checks pass.
2. Use Householder QR or a polar-based retraction when the Cayley solve is ill-conditioned, the step is extreme, or the residual exceeds tolerance.
3. Publish immutable descriptors through release/acquire pointer publication.
4. Protect all dereferences with a complete RCU/QSBR protocol.
5. Reclaim only after a verified grace period.
6. Define backend-independent mathematical contracts, while permitting backend-specific implementations.
7. Require differential tests, adversarial extreme-step tests, litmus tests for publication/reclamation, ABI layout tests, and cross-backend numerical tolerance tests before declaring conformance.

Accordingly, the only exact guarantees supportable from the available information are **conditional guarantees** of the form:

\[
\text{success}
\Rightarrow
\begin{cases}
\|Q^\top Q-I\|\le\tau_{\mathrm{orth}},\\
\text{all descriptor reads observe a released immutable version},\\
\text{no reclamation precedes the required grace period},\\
\text{backend result lies within the declared numerical tolerance}.
\end{cases}
\]

Unconditional guarantees of extreme-step stability, 88-byte atomic snapshotting, universal acquire/release isolation, or identical behavior across CUDA, XLA, Triton, C++20, and Rust are not mathematically or architecturally established by the supplied evidence.