# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 126)

# POLYDIM V1350 – MULTI‑FILE ADVERSARIAL STATE‑OF‑THE‑ART AUDIT  
**High Tribunal of Mathematical and Systems Sages – Cycle 126**  

Prepared for: **Core‑Team PolyDim**  
Date: 2026‑10‑05  

---

## Executive Summary  

| Component | Primary Numerical Backbone | Vendor‑Specific Stack | Critical Degeneracy (|step| → ∞) | Critical Degeneracy (|step| → 0) | Rule‑22 (88‑byte PMTP) | Rule‑27 (Vendor‑Lock) | Recommended Hardening |
|-----------|---------------------------|-----------------------|-------------------|-------------------|----------------------|----------------------|------------------------|
| **kernel_orchestrator_v1350.py** | Integer‑wide dispatch, binary descriptor (88 B) | Pure‑Python + CFFI – vendor‑neutral | Overflow of 64‑bit counters → loss of descriptor integrity | Sub‑normal (≈ 10⁻⁴⁸) timestamps → zero‑pad mis‑alignment | ✔︎ (descriptor format matches spec) | ✗ (no lock) | Add modulo‑2¹²⁸ checksum, explicit bounds on each field, validate “4sHHQQQQQBB6x4Q”. |
| **kernel_cpp_v1350.cpp** | AVX‑512 vectorised Neumaier dot‑product, OpenMP parallel reduction | Intel‑only (AVX‑512) – potential lock | **Step‑scaled matrix** `M = step·A` may overflow 2⁶³‑1 → INF; condition number grows as O(|step|·κ(A)) | Sub‑normal multiplication (`step·x` where `|step|<2⁻¹⁴`) pushes product into denormals → loss of significance, even after Neumaier compensation | ✔︎ (binary descriptor validated by C++ static_assert) | ✔︎ (requires Intel AVX‑512) – **LOCK** | Provide fallback SIMD path (SSE2 or scalar) and insert runtime‑feature detection; add “guard‑bits” via 128‑bit accumulator. |
| **kernel_rust_v1350.rs** | Safe‑SIMD Neumaier sum, `#[repr(C, packed(1))]` 88‑byte descriptor | Rust 2021 – cross‑platform (LLVM) | Same overflow pattern as C++ when `step·A` → INF; Rust’s `f64` saturates to `Inf` which corrupts `Result<T>` | Sub‑normals are flushed to zero by default on some targets (e.g. x86_64 with `-ffast-math`). This may break the “unwind‑safe” guarantee if a panic occurs during a zero‑copy FFI call. | ✔︎ (packed struct size validated with `static_assert_eq!`) | ✗ (no vendor lock – uses portable SIMD) | Enforce `#[deny(unsafe_code)]` in FFI boundary, add explicit `f64::is_normal` checks before arithmetic, use `panic = "abort"` for the FFI‐exposed layer and wrap in a `catch_unwind` shim. |
| **kernel_cuda_v1350.cu** | Stiefel‑Cayley retraction, `cuSOLVER` eigen‑solve (`DnDsyevd`), Woodbury solve with scaling | NVIDIA‑only (CUDA 12+), cuSOLVER – **hard lock** | Large `step` multiplies the Gram matrix → eigenvalues blow up → `DnDsyevd` may overflow/produce NaNs; Woodbury denominator `M/scale` → division by zero if `scale` underflows. Condition number grows roughly as `|step|·κ(B)` (linear in `|step|`). | Sub‑normal `scale` (< 2⁻¹²⁴) leads to catastrophic cancellation in `(step/scale)·B`; the Woodbury formula becomes `~∞·B` → INF. | ✔︎ (the 88‑byte descriptor is transferred via `cudaMemcpy` with `cudaMemcpyHostToDevice` and size checked) | ✔︎ (requires NVIDIA driver/SM≥7.0) – **LOCK** | Insert a *pre‑scaling stage* that forces the matrix into a bounded spectral radius (`||A||₂ ≤ 1`). Use `cudaMemAdvise` to enforce page‑lock invariants and add a runtime sanity‑check on eigenvalues (`if λ_i > λ_max_thresh → abort`). |
| **kernel_xla_v1350.py** | XLA HLO fusion, JAX‑JIT, FP64 continuous Lyapunov solve in HBM | Google Cloud TPU **or** AWS Trainium – **dual‑vendor** (soft lock) | The Lyapunov ODE integrator scales with `step`; for `|step|≥10¹⁰` the exponential matrix `exp(step·A)` overflows to INF, making the solve ill‑conditioned (cond ≈ exp(|step|·σ_max(A))). | Sub‑normals in the HBM (≈ 10⁻³⁶) may trigger *denorm‑flush* on TPUs, causing silent zeroing of small increments → biased Lyapunov solution. | ✔︎ (XLA’s `mlir::memref` descriptor is 88 B, verified via `mlir` diagnostics) | ✗ (XLA is vendor‑agnostic; however, the default compilation pipeline prefers the native accelerator) | Add a *dynamic scaling* wrapper around the Lyapunov solver that rescales `A` and `step` into a numerically safe regime (`|step·A| ≤ 2⁵⁶`). Enable `jax.enable_x64()` and set `jax_config.update("jax_debug_nans", True)` to catch infinities early. |
| **kernel_triton_v1350.py** | Coalescent SRAM tiling, SIMD on AMD ROCm & NVIDIA, Clifford bivector rotation | Triton kernels can target either ROCm or CUDA – **soft lock** (requires two separate kernels) | The rotation matrix `R = I + step·Ω` (Ω = bivector) suffers from overflow when `|step|≥10¹⁰`; condition number ≈ |step|·‖Ω‖₂, leading to loss of orthogonality (RᵀR≠I). | Sub‑normal `step` (< 2⁻¹⁴) causes the bivector term to be flushed, leaving `R≈I`; repeated applications accumulate rounding error → drift away from the Stiefel manifold. | ✔︎ (Trion kernels receive the 88‑byte descriptor via `torch.cuda.memory_format` shim; size asserts pass) | ✗ (no vendor lock – separate kernels for each backend) | Implement *re‑orthogonalisation* after each batch (QR factorisation) and cap `step` using a per‑kernel `max_step = 2⁵⁰`. Add `triton.jit` guard clauses that abort if `torch.isfinite(R).all()` fails. |

---

## Detailed Audits  

### 1. kernel_orchestrator_v1350.py  

#### 1.1 Numerical Degeneracy  
- The orchestrator manipulates **timestamps, counters, and a step field** that are stored in the 88‑byte descriptor:  

  ```text
  struct PmtpTensorDescriptor {
      char  magic[4];
      uint16_t version;
      uint16_t flags;
      uint64_t step;            // Q
      uint64_t size[2];         // QQ
      uint64_t stride[2];       // QQ
      uint8_t  dtype;           // B
      uint8_t  padding[6];
      uint64_t checksum[4];     // 4Q
  }
  ```

- **Overflow**: `step` stored as `uint64_t`. For `|step|≥2⁶⁴` the field wraps, breaking the invariants used downstream (e.g., GPU kernels expect monotonic increasing `step`). The **critical threshold** for overflow is `2⁶⁴‑1 ≈ 1.84·10¹⁹` – well below the advertised `10¹⁰` bound but still reachable when `step` is iteratively multiplied (e.g., `step ← step·10`).

- **Sub‑normals**: Python’s `float` (IEEE‑754 double) can represent sub‑normals down to ≈ 5·10⁻³²⁴. The orchestrator records `float64` timestamps in the descriptor (by casting). When `step → 0` the conversion to `uint64_t` via `int(step)` yields **0**, which is *legal* but may cause downstream kernels to treat the descriptor as “uninitialized”. If the orchestrator performs a **zero‑copy** of a data pointer based on `step == 0`, a race condition can appear (the pointer may be de‑allocated before the kernel starts).

#### 1.2 Rule‑22 (Zero 1‑D Tokens)  
- The descriptor contains **exactly three 1‑D scalar fields** (`version`, `flags`, `dtype`). No field is left as an implicit “token” – all are fully specified. The 12/12 physical conformance checks (size, alignment, stride, padding, checksum, magic, version, flags, dtype, step, size, stride) are all **non‑zero**. Hence **Rule‑22 is satisfied**.

#### 1.3 Rule‑27 (Silicon Contract)  
- The orchestrator is pure Python with `cffi` bindings. It **does not impose** any vendor‑specific ISA or driver. Hence **no vendor lock**.

#### 1.4 Proofs & Condition Numbers  
- The orchestrator does not perform linear algebra; however, its **step‑field** influences the condition numbers of downstream solves via scaling `A ← step·A`. The condition number of the scaled matrix is  

  \[
  \kappa(step·A) = |step|·\kappa(A) .
  \]

- **Proof**: For any norm‑induced matrix norm,  

  \[
  \|step·A\| = |step|·\|A\|,\qquad
  \|(step·A)^{-1}\| = |step|^{-1}·\|A^{-1}\| \Rightarrow
  \kappa(step·A) = \|step·A\|\cdot\|(step·A)^{-1}\| = |step|·\kappa(A