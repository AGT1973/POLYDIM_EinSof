# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 125

I cannot produce a **definitive arbitration of the eight Tribunal models or the six V1350 kernels** because their reports, specifications, test vectors, and implementation details were not provided. I found no verifiable public specification for “POLYDIM V1350,” “PMTP,” or the claimed Cycle 125 tribunal record. The available literature supports only general conclusions about Stiefel retractions and cannot establish V1350-specific guarantees.

The strongest technically defensible synthesis is:

## 1. Cayley retraction under extreme steps

For a Stiefel point \(X\) and tangent direction \(\Xi\), common retractions include

\[
R_{\mathrm{polar}}(X,\Xi)
 = (X+\Xi)\bigl(I+\Xi^\top\Xi\bigr)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)
 = \operatorname{qf}(X+\Xi),
\]

and a Cayley transform based on a skew-symmetric generator. These are established alternatives, with different cost and numerical behavior.[3]

No mathematically valid unconditional claim can be made that Cayley is stable for \(|\mathrm{step}|\ge 10^{10}\). At such scales:

- **Cayley** avoids explicitly orthogonalizing \(X+\Xi\), but its linear solve can become ill-conditioned, overflow, or lose skew-symmetry through floating-point error.
- **Polar** preserves orthogonality in exact arithmetic and is generally robust when the matrix has adequate numerical rank, but forming \(\Xi^\top\Xi\) can overflow or suffer severe scaling loss.
- **Householder/QR** is usually the preferred production fallback because orthogonal transformations are backward stable; however, it can fail or become non-deterministic when \(X+\Xi\) is numerically rank-deficient unless pivoting, scaling, and sign conventions are specified.
- **No method can guarantee finite-precision stability for arbitrary unscaled inputs of magnitude \(10^{10}\) or larger.** A valid guarantee requires norm scaling, overflow-safe kernels, finite-input preconditions, and a residual test.

The defensible architectural rule is therefore:

\[
\text{scale}(\Xi),\quad
\text{compute candidate},\quad
\text{verify } \|Q^\top Q-I\|,\quad
\text{fallback to robust QR/Householder if needed}.
\]

A meaningful contract would specify tolerances such as

\[
\|Q^\top Q-I\|_2
 \le c\,u\,\kappa_{\mathrm{eff}},
\]

where \(u\) is machine unit roundoff and \(\kappa_{\mathrm{eff}}\) is a bounded, documented conditioning factor. Claiming exact orthogonality or unconditional stability is incorrect.

## 2. PMTP 88-byte descriptors and RCU/QSBR

An 88-byte descriptor has no inherent memory-ordering semantics. Correct snapshot isolation depends on the protocol and on the target memory model, not on the descriptor size.

A sound publication protocol is:

1. Writer constructs the complete immutable snapshot.
2. Writer performs ordinary or relaxed initialization stores.
3. Writer publishes the descriptor pointer/version with **release** semantics.
4. Reader loads the publication pointer/version with **acquire** semantics.
5. Reader announces its read-side critical section before dereferencing the snapshot.
6. Writer retires the old snapshot only after an RCU grace period or QSBR quiescence condition.

The central happens-before requirement is

\[
\text{initialize snapshot}
\;\xrightarrow{\text{release/acquire}}\;
\text{reader dereference}.
\]

Acquire/release alone does **not** solve reclamation. It prevents publication reordering, but safe destruction additionally requires:

- reader registration or hazard protection,
- a grace-period mechanism,
- generation/version validation where ABA is possible,
- alignment and atomicity guarantees for all concurrently accessed fields,
- a defined rule for descriptor tearing and cache-line placement.

If the descriptor contains multiword state, an atomic 88-byte load/store should not be assumed. Most platforms do not provide native lock-free atomicity for an 88-byte object. The usual guarantee should be **atomic publication of a pointer, index, or compact generation token**, with the 88-byte record treated as immutable after publication.

The strongest accurate contract is:

> Readers observe either a fully initialized old snapshot or a fully initialized new snapshot; they never observe a partially initialized snapshot, provided publication uses release/acquire and reclamation waits for a valid RCU/QSBR grace period.

That is a conditional guarantee, not an unconditional property of an 88-byte layout.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

“Conformance” cannot mean identical behavior unless the specification defines:

- arithmetic precision and permitted contraction/FMA behavior,
- NaN, infinity, subnormal, and signed-zero handling,
- reduction order,
- atomic scopes and memory orders,
- synchronization and stream/event semantics,
- alignment and ABI layout,
- ownership and reclamation rules,
- deterministic tie-breaking and sign conventions,
- error and fallback behavior.

The five environments expose materially different execution models:

| Environment | Required conformance interpretation |
|---|---|
| CUDA | Must specify thread scope, block/device/system scope, synchronization, stream ordering, and GPU memory-order semantics. |
| XLA | Must account for compiler fusion, reassociation, layout changes, asynchronous execution, and potentially nondeterministic reductions. |
| Triton | Must specify program-instance ordering, masks, barriers, atomic operations, and supported data types. |
| C++20 | Must map the protocol to the C++ memory model, including atomic ordering, object lifetime, alignment, and data races. |
| Rust | Must preserve the same ordering and lifetime contract through atomics, `UnsafeCell`/FFI boundaries, `Send`/`Sync` invariants, and explicit reclamation. |

Bitwise identity across all five is not a reasonable default guarantee. A realistic conformance hierarchy is:

1. **Safety:** no data races, invalid reclamation, out-of-bounds access, or undefined behavior.
2. **Algebraic correctness:** orthogonality and descriptor invariants within specified tolerances.
3. **Memory-order correctness:** release/acquire publication and grace-period reclamation.
4. **Numerical equivalence:** bounded error under a specified norm and conditioning domain.
5. **Bitwise determinism:** guaranteed only with fixed precision, operation order, compiler restrictions, and deterministic reductions.

## Definitive arbitration

On the evidence available, the following claims are supportable:

- **Cayley is not proven superior to Householder/QR for extreme steps.** A guarded hybrid using scaling, residual verification, and Householder/QR fallback is the stronger architecture.
- **Acquire/release is necessary but insufficient for PMTP snapshot isolation.** Safe reclamation requires RCU/QSBR grace-period enforcement; an 88-byte descriptor should not itself be atomically copied.
- **Cross-silicon conformance requires a formal semantic contract.** Source-level similarity across CUDA, XLA, Triton, C++20, and Rust is not evidence of equivalent memory or numerical behavior.
- **No exact architectural guarantee can be issued without the six kernel definitions, descriptor schema, synchronization protocol, target architectures, numerical tolerances, and the eight model reports.**

Thus, the mathematically superior SOTA position is a **verified hybrid design**:

\[
\boxed{
\text{scaled candidate generation}
+
\text{stable Householder/QR fallback}
+
\text{orthogonality residual checks}
+
\text{release/acquire publication}
+
\text{RCU/QSBR reclamation}
+
\text{explicit cross-backend semantic tests}
}
\]

Anything stronger—especially unconditional \(10^{10}\)-step stability, atomicity of an 88-byte descriptor, or bitwise multi-silicon equivalence—would be an unsupported architectural claim.