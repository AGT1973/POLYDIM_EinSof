# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 93

No public specification or tribunal reports for **POLYDIM V1350**, its six kernels, or the **PMTP 88-byte descriptor** were found in the available evidence. Therefore, a definitive implementation-specific arbitration is not possible. The strongest technically defensible synthesis is a set of conditional guarantees based on established numerical-linear-algebra and weak-memory principles.

## Arbitration

### 1. Extreme-step Stiefel retraction

For a Stiefel point \(X \in \mathrm{St}(n,p)\) and tangent direction \(\Xi\), the update must return a matrix satisfying

\[
R(X,\Xi)^{\mathsf T}R(X,\Xi)=I_p
\]

up to the target floating-point error.

For \(\lvert \text{step}\rvert \ge 10^{10}\), a **raw Cayley transform is not unconditionally stable**. Its defining linear system contains a matrix of the form

\[
I-\frac{\alpha}{2}A,
\]

where \(A\) is skew-symmetric. Although the exact Cayley map is orthogonal whenever the inverse exists, finite-precision behavior can degrade through:

- ill-conditioned or poorly scaled solves;
- overflow in forming \(\alpha A\);
- loss of significance in \(I-\frac{\alpha}{2}A\);
- failure when the transformed problem approaches a pole or a numerically singular solve;
- large backward error despite an apparently orthogonal output.

A recent analysis reports favorable local condition bounds for canonical Cayley and polar-light Stiefel retractions, but also identifies the essential exclusion of an eigenvalue at \(-1\) for well-defined inverses.[8] Those local bounds do not establish stability for arbitrary unscaled steps of magnitude \(10^{10}\).

**Householder QR** is the strongest default for robust retraction. It avoids explicitly forming \(X+\alpha\Xi\) as a badly scaled orthogonalization problem, has a well-understood backward-stability theory, and can enforce a deterministic sign convention on \(R\). **Polar retraction** is also mathematically attractive and generally stable when computed through a stable SVD or carefully implemented polar decomposition, but it costs more and can be sensitive near rank deficiency.

The arbitration is therefore:

1. **Householder QR wins as the default extreme-step implementation** for reliability and portability.
2. **Polar/SVD wins when nearest-point geometry, symmetric treatment of singular values, or higher-quality projection is the primary objective.**
3. **Cayley is acceptable only with mandatory safeguards**:
   - step scaling or bounded internal \(\alpha\);
   - a stable factorization rather than explicit inversion;
   - residual and orthogonality checks;
   - fallback to Householder QR or polar decomposition;
   - explicit handling of overflow, non-finite values, and near-pole conditions.

The mathematically superior architecture is thus a **guarded hybrid retraction**, not an unconditional Cayley kernel:

\[
Y = X+\widehat{\alpha}\Xi,
\qquad
\widehat{\alpha}
=
\operatorname{clip}(\alpha,-\alpha_{\max},\alpha_{\max}),
\]

followed by Cayley only when its factorization and residual tests pass; otherwise use Householder QR, with polar/SVD as an optional high-accuracy mode.

The exact guarantee should be stated as:

\[
\left\|Q^{\mathsf T}Q-I\right\| \le \tau_{\mathrm{orth}},
\]

and, for a successful Cayley solve,

\[
\frac{\left\|\left(I-\frac{\alpha}{2}A\right)Z-
\left(I+\frac{\alpha}{2}A\right)X\right\|}
{\left\|\left(I+\frac{\alpha}{2}A\right)X\right\|}
\le \tau_{\mathrm{solve}}.
\]

Without such numerical predicates, “stable for all \(\lvert\text{step}\rvert\ge10^{10}\)” is not a valid guarantee.

### 2. PMTP descriptor and RCU/QSBR ordering

Acquire/release operations establish ordering only when they operate on the **same synchronization atomic** and the acquire observes the release or an appropriate release sequence. A release store followed by an acquire load that reads its value creates a synchronizes-with relationship in C++ memory semantics.[3]

For a published immutable snapshot, the minimum correct pattern is:

```cpp
// Writer
initialize_descriptor_and_payload();
current.store(new_snapshot, std::memory_order_release);

// Reader
auto* p = current.load(std::memory_order_acquire);
consume_immutable_snapshot(*p);
```

For QSBR/RCU, acquire/release alone does **not** constitute the grace-period protocol. The implementation must additionally guarantee that:

1. the reader publishes entry, epoch, or quiescent-state information using the prescribed atomic protocol;
2. the writer publishes the replacement snapshot;
3. reclamation occurs only after every reader that could have observed the old snapshot has passed through a quiescent state;
4. the descriptor, payload, and reclamation metadata are accessed without data races;
5. descriptor lifetime extends through the entire read-side critical section.

Established QSBR implementations explicitly use release operations when publishing changes and acquire operations when workers observe the corresponding grace-period state.[5] Formal RCU treatments likewise rely on release/acquire ordering both for publication of links and for proving that reader activity has ended before reclamation.[6]

The exact architectural guarantee should therefore be:

> A reader that successfully acquires snapshot pointer \(S_k\) observes all descriptor and payload writes sequenced before the corresponding release publication of \(S_k\), and \(S_k\) remains allocated until every pre-existing reader capable of observing \(S_k\) has passed a registered quiescent state.

This does **not** guarantee:

- global sequential consistency;
- a coherent multi-field snapshot if fields are read independently;
- safety from a relaxed load of the publication pointer;
- safe reclamation merely because a counter was incremented;
- GPU/device visibility across CUDA/XLA/Triton boundaries without an explicit device-scoped synchronization mechanism.

The 88-byte size is an ABI/layout property, not a memory-ordering property. A conforming descriptor must specify alignment, padding, endianness, atomic field representation, ownership, versioning, and publication protocol. If the descriptor contains atomics, their lock-free status and representation must be tested per target rather than assumed.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no basis for claiming bit-identical or memory-model-identical behavior across these systems without a formal intermediate representation and conformance suite.

The systems have different execution and memory models:

- **C++20** defines host-language atomic ordering and object-lifetime rules.
- **Rust** inherits analogous atomic ordering concepts but adds ownership and aliasing constraints.
- **CUDA** has host/device scopes, stream ordering, kernel-launch ordering, and device-specific synchronization behavior.
- **Triton** exposes GPU-level program and memory operations whose exact guarantees depend on its compiler and target backend.
- **XLA** uses compiler-managed buffers, asynchronous execution, and backend-specific lowering; source-level atomic assumptions cannot be transferred automatically.

The correct portability boundary is a contract, not source-code equivalence. Each backend should implement the same abstract operations:

\[
\operatorname{publish}(S_k),\quad
\operatorname{acquire}(),\quad
\operatorname{enter}(),\quad
\operatorname{quiesce}(),\quad
\operatorname{retire}(S_k),\quad
\operatorname{reclaim}().
\]

Conformance requires proving or testing:

- descriptor size and alignment;
- field offsets and serialization;
- publication-before-observation;
- no use-after-reclamation;
- snapshot immutability;
- retraction orthogonality;
- deterministic handling of non-finite and overflow inputs;
- matching numerical tolerances;
- stream/device synchronization;
- failure and fallback behavior.

A practical requirement is a **reference semantic model**. The host C++20 implementation can serve as the specification, while Rust, CUDA, Triton, and XLA implementations are validated against generated traces and numerical reference outputs. Tests should include randomized schedules, delayed quiescent states, concurrent publication, device synchronization delays, extreme steps, rank-deficient inputs, NaNs, infinities, and cross-device serialization.

## Definitive SOTA synthesis

The strongest architecture is:

1. **Retraction layer:** guarded Cayley for moderate, well-conditioned steps; Householder QR as the mandatory robust fallback; polar/SVD as an accuracy-oriented option.
2. **Publication layer:** immutable versioned snapshots published with release semantics and read with acquire semantics.
3. **Reclamation layer:** a complete RCU/QSBR grace-period protocol, not merely acquire/release fields.
4. **Portability layer:** an explicit backend-neutral contract with target-specific synchronization adapters.
5. **Verification layer:** runtime residual checks plus exhaustive cross-backend conformance tests.

The exact guarantees that can legitimately be claimed are conditional:

\[
\text{If the backend satisfies the publication and grace-period contract,}
\]

then readers obtain a consistent immutable snapshot and reclamation cannot occur while a protected reader retains access.

\[
\text{If the retraction acceptance test passes,}
\]

then the returned matrix satisfies the specified orthogonality tolerance; otherwise the implementation must fall back or report failure.

No stronger unconditional guarantee—especially “Cayley is stable for every step of magnitude at least \(10^{10}\)” or “C++ acquire/release automatically guarantees CUDA/XLA/Triton visibility”—is mathematically or architecturally justified by the available findings.