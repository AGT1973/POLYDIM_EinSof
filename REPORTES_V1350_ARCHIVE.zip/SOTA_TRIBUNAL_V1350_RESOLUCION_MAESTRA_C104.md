# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 104

A definitive arbitration is **not possible from the supplied record**. The public search evidence does not identify a POLYDIM “V1350” specification, six-kernel implementation, benchmark suite, or the six Tribunal reports; the only clearly relevant results concern general RCU/QSBR behavior and an unrelated PolyDiM PDE library.[3][10][14] Therefore, any model-by-model verdict or exact V1350 guarantee would be fabricated.

The strongest technically defensible synthesis is the following conditional architecture.

## 1. Cayley–Stiefel retraction versus Householder or polar QR

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\) satisfying \(X^{T}X=I\), a Cayley update typically has the form

\[
X_{+}
=
\left(I-\frac{\alpha}{2}W\right)^{-1}
\left(I+\frac{\alpha}{2}W\right)X,
\]

where \(W^{T}=-W\). In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists, so it preserves the Stiefel constraint algebraically.

That does **not** imply stability for \(|\alpha|\ge 10^{10}\). The implementation must address:

- overflow and underflow in forming \(\alpha W\);
- conditioning of \(I-\frac{\alpha}{2}W\);
- loss of orthogonality from finite-precision solves;
- singular or nearly singular shifted systems;
- residual growth in iterative or batched GPU solvers.

For extreme steps, the mathematically safer guarantee is not “Cayley is always stable,” but:

\[
\|X_{+}^{T}X_{+}-I\|
\le
c\,u\,\kappa\!\left(I-\frac{\alpha}{2}W\right)
+
\varepsilon_{\mathrm{solve}},
\]

provided the shifted solve is backward stable and the condition number remains controlled.

Householder QR is generally the preferable **orthogonalization fallback** because it can be implemented with backward-stable reflectors and avoids explicitly forming normal equations. Polar retraction has the attractive characterization

\[
\operatorname{polar}(Y)=Y(Y^{T}Y)^{-1/2},
\]

but its numerical quality depends on the symmetric inverse-square-root computation. A robust hierarchy is therefore:

1. scaled Cayley solve when its conditioning and residual tests pass;
2. Householder QR when reorthogonalization is required;
3. polar decomposition when the nearest-Stiefel-point objective is required and a stable eigensolver or SVD is available.

The exact guarantee should be stated as **conditional**, not absolute:

> The kernel preserves the Stiefel constraint up to a certified residual and never silently accepts an unstable extreme-step update. It either returns a result satisfying the configured orthogonality tolerance or returns a failure/fallback status.

No claim that Cayley dominates Householder or polar QR for every \(|\mathrm{step}|\ge 10^{10}\) is mathematically justified without the missing algorithm, scaling policy, precision mode, and residual bounds.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

The relevant memory-ordering rule is standard: an RCU reader must acquire the published descriptor or pointer, while a writer must release-publish a fully initialized immutable snapshot. Public QSBR documentation likewise describes acquire loads as preventing later shared-data loads from moving before the synchronization load.[15] QSBR reclamation is safe only after every participating reader has reported a quiescent state after the publication generation; the general principle is that reclamation is deferred until all readers have passed through a quiescent state.[13]

A sound publication protocol is:

\[
\text{initialize snapshot}
\;\prec\;
\text{release-store}(P_{\text{new}})
\]

and on the reader:

\[
P_{\text{old}}
\leftarrow
\text{acquire-load}(P).
\]

The 88-byte size itself provides **no** memory-ordering guarantee. It must additionally specify:

- alignment and atomicity of the publication field;
- whether the descriptor is immutable after publication;
- generation/version encoding;
- ownership and reclamation protocol;
- reader registration and quiescent-state reporting;
- behavior under descriptor reuse and ABA;
- cache-coherency scope across CPU, GPU, and device agents.

The precise architectural guarantee should be:

> A reader that successfully acquire-loads generation \(g\) observes a fully initialized, immutable snapshot for \(g\), and that snapshot is not reclaimed or reused until the applicable RCU/QSBR grace-period condition has completed.

Acquire/release alone does **not** guarantee snapshot isolation if fields are mutated in place, if reclamation occurs prematurely, or if a non-coherent device accesses the descriptor. In those cases, sequence counters, hazard pointers, epochs, explicit fences, or platform-specific device synchronization are required.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

Cross-silicon conformance cannot be inferred from language-level atomic syntax. CUDA, XLA, Triton, C++20, and Rust expose different execution and memory models:

- C++20 and Rust atomics define host-language ordering rules, but do not automatically establish visibility to an accelerator.
- CUDA requires explicit reasoning about scopes, streams, events, cooperative groups, and system/device visibility.
- Triton inherits constraints from its generated GPU program and backend.
- XLA may fuse, reorder, replicate, or lower operations according to its compiler IR semantics; host-side acquire/release does not by itself constrain device-side execution.
- Different GPU architectures may vary in supported atomic widths, scopes, flush behavior, and numerical contraction.

The only defensible conformance claim is a **validated contract**, comprising:

\[
\text{semantic specification}
+
\text{backend lowering rules}
+
\text{litmus tests}
+
\text{numerical error bounds}
+
\text{hardware matrix}.
\]

Required tests include:

- publication-before-read visibility;
- no reader observes a partially initialized descriptor;
- no reclamation before the grace period;
- generation monotonicity and ABA resistance;
- Stiefel residual after ordinary and extreme updates;
- deterministic behavior under concurrent readers and writers;
- supported atomic widths and alignment on every target;
- compiler-fusion and stream-ordering tests;
- differential comparison against a high-precision reference.

## Arbitration

The mathematically superior synthesis is therefore a **contract-first, fail-closed design**:

- Use a scaled Cayley retraction only when its solve residual and conditioning certificate pass.
- Use Householder QR as the default robust orthogonalization fallback; use polar decomposition when nearest-point projection is the explicit objective.
- Publish immutable PMTP snapshots with release semantics and consume them with acquire semantics.
- Treat QSBR/RCU grace periods as reclamation requirements, not as substitutes for publication ordering.
- Add explicit accelerator-scope synchronization where host/device coherence is not guaranteed.
- Define conformance by observable invariants and litmus tests across each backend, not by source-level portability.
- On unsupported atomics, failed residual checks, missing fences, or uncertain reclamation, return an error or fallback rather than claiming correctness.

Thus the exact guarantees that can legitimately be made are **conditional residual, visibility, and reclamation guarantees** under a stated memory scope, precision, hardware set, and fallback policy. Absolute extreme-step stability, universal multi-silicon equivalence, and snapshot isolation from acquire/release alone are not established by the available evidence.