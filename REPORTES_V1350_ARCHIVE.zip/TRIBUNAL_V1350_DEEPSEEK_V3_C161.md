# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 161)

# POLYDIM V1350 — High Tribunal Audit, Cycle 161

**Presiding note.** The following is a *forensic* audit. Where the submission asserts a property (e.g., "12/12 physical conformance checks", "88-byte descriptor", "Neumaier compensated dot"), I treat the assertion as a *claim to be falsified*, not a fact. Where I cannot see the source, I state the *conditional* verdict and the *falsification test* the submitter must run. I do not rubber-stamp.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Claimed layout: `<4sHHQQQQQBB6x4Q` under CPython `struct` with native alignment disabled (`<`).

Let me actually sum it:

| Field | Type | Bytes |
|---|---|---|
| `4s` | char[4] | 4 |
| `H` | uint16 | 2 |
| `H` | uint16 | 2 |
| `Q`×5 | uint64 | 40 |
| `B` | uint8 | 1 |
| `B` | uint8 | 1 |
| `6x` | pad | 6 |
| `Q`×4 | uint64 | 32 |
| **Total** | | **88** |

**Verdict: arithmetically correct.** 4+2+2+40+1+1+6+32 = 88. ✅

**But two hard problems remain, and the Tribunal flags them as *findings*, not nitpicks:**

**(F1) Endianness vs. silicon contract.** `<` forces little-endian. This is fine on x86-64, AArch64-LE, and NVIDIA/AMD GPUs (all LE). It is **not** fine on any big-endian host (POWER9 in BE mode, s390x, some MIPS). If POLYDIM claims "multi-silicon", the descriptor is *not* portable as written. Either (a) mandate LE-only in the silicon contract, or (b) emit a `>4sHHQQQQQBB6x4Q` variant and tag it in the first 4 bytes.

**(F2) The `6x` pad is a *lie* under `=` alignment but a *truth* under `<`.** Under `<`, no padding is inserted, so the explicit `6x` is the *only* padding. Under `=` (native), the compiler would insert padding after the two `B`s to align the following `Q`s to 8 bytes — and the explicit `6x` would then be *redundant*, producing 94 bytes. **The descriptor is only 88 bytes if every producer and consumer uses `<`.** This must be enforced by a static assertion in C++ (`static_assert(sizeof(desc)==88)`), a `const _: () = assert!(size_of::<Desc>()==88);` in Rust, and a `struct.calcsize('<4sHHQQQQQBB6x4Q')==88` assertion in Python. If any of these is missing, the "12/12 conformance" claim is unverified.

**(F3) Rule 22 compliance — "zero 1D tokens".** The descriptor is a *packed struct*, not a token stream. Rule 22 as stated ("zero 1D tokens in inter-agent communication") is satisfied *iff* every inter-agent message is either (a) a fixed-size 88-byte descriptor, or (b) a tensor with rank ≥ 2. **A `Q` field carrying a length, followed by a variable-length payload, would violate Rule 22** — that is a 1D token stream in disguise. The audit demands: enumerate every IPC/FFI boundary and prove each payload is either exactly 88 bytes or rank ≥ 2.

### 0.2 Rule 27 — vendor lock

| Target | Vendor lock risk | Verdict |
|---|---|---|
| 1 (orchestrator) | None if `HardwareProbe` is a *capability* probe, not a *vendor* probe | **Conditional pass** |
| 2 (C++ AVX-512) | **HIGH** — AVX-512 is Intel/AMD-only; ARM SVE, Apple AMX, RISC-V V are excluded | **FAIL as written** |
| 3 (Rust SIMD) | Depends on `std::simd` vs. `core::arch` intrinsics | **Conditional** |
| 4 (CUDA) | **TOTAL** — cuSOLVER, CUDA Graphs are NVIDIA-only | **FAIL as written** |
| 5 (XLA) | **TOTAL** — TPU/Trainium only; no x86 fallback shown | **FAIL as written** |
| 6 (Triton) | ROCm + CUDA — *dual* vendor, but no CPU fallback | **Partial** |

**Finding (F4):** The architecture as described is a *federation of vendor-specific kernels*, not a vendor-neutral one. Rule 27 is satisfied only if the orchestrator (Target 1) can *dispatch* to a portable fallback (e.g., a scalar C++ reference) when no accelerator is present. The submission does not mention such a fallback. **This is a Rule 27 violation unless the fallback exists and is documented.**

---

## 1. Target 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy

The orchestrator itself does no arithmetic, so degeneracy is *inherited*. The relevant question is: **does the orchestrator validate `step` before dispatch?**

- If `|step| ≥ 10^10`: the orchestrator must reject or rescale. A raw `step` of 10^10 fed into a Cayley retraction `(I - (step/2)W)^{-1}(I + (step/2)W)` will produce a matrix whose condition number scales as `O(step)`. **The orchestrator must enforce `|step| ≤ step_max` where `step_max` is derived from the smallest singular value of `W`.**
- If `step → 0` (subnormal, `|step| < 2^-1022`): the retraction degenerates to identity, and the *update* is lost. The orchestrator must either (a) flush to zero and skip, or (b) use compensated arithmetic. **Silent subnormal loss is a correctness bug.**

**Recommendation:** The orchestrator must carry a `step_scale` field in the 88-byte descriptor (one of the `Q`s) and a `step_exponent` (one of the `H`s), so that the *effective* step is `step_scale × 2^step_exponent`, keeping the mantissa in `[1, 2)`. This is the standard "block floating point" trick and it eliminates both degeneracies.

### 1.2 Rule 22 / 88-byte compliance

The orchestrator is the *producer* of the descriptor. It must:
1. Assert `struct.calcsize('<4sHHQQQQQBB6x4Q') == 88` at import time.
2. Never emit a variable-length payload alongside the descriptor.
3. Tag the first 4 bytes with a magic that encodes endianness and version.

### 1.3 Rule 27

`HardwareProbe` must probe *capabilities* (AVX-512F, SVE width, SM count, HBM bandwidth), not *vendor strings*. If it branches on `"NVIDIA"` vs `"AMD"`, it is vendor-locked.

### 1.4 FFI hardening

- The orchestrator's Python→C++ boundary must use `ctypes` with `argtypes`/`restype` *explicitly set*, or `cffi` with a compiled header. **Never** rely on default `int` conversion.
- The 88-byte descriptor must be passed as `ctypes.c_char * 88`, not as a Python `bytes` object (which is immutable and may be copied).

---

## 2. Target 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot — correctness

Neumaier's variant of Kahan:

```
s = 0; c = 0;
for i: t = s + x[i]*y[i];
       if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i];
       else:                  c += (x[i]*y[i] - t) + s;
       s = t;
return s + c;
```

**This is correct** and gives `O(ε)` error independent of `n` for the *sum*, but **not** for the *products* `x[i]*y[i]`. Each product has relative error `ε`, so the total error is `O(n ε)` in the worst case unless FMA is used. **The audit demands: is `std::fma` used for the products?** If not, the "compensated" claim is half-true.

### 2.2 Subnormal audit (-12, -14)

The notation `(-12, -14)` presumably refers to exponents `2^-12` and `2^-14` (FP16 subnormal range) or to *decimal* exponents `10^-12`, `10^-14`. Either way:

- **FP32 subnormals** begin at `2^-126`. `2^-12` and `2^-14` are *normal* in FP32. So if the audit is in FP32, there is no subnormal issue at these magnitudes.
- **FP16 subnormals** begin at `2^-14`. So `2^-14` is the *first* subnormal, and `2^-12` is normal. **The audit must specify the format.**
- **The real risk:** if the kernel uses `-ffast-math` or `-ffinite-math-only`, subnormals are flushed to zero, and the audit is meaningless. **The audit demands: compile with `-fno-fast-math -fsignaling-nans` and verify with `std::fpclassify`.**

### 2.3 Zero-copy PMTP validation

"Zero-copy" means the 88-byte descriptor points into a shared memory region (e.g., `mmap`, `cudaHostAlloc`, or `shm_open`). The validation must:
1. Check the pointer is 64-byte aligned (AVX-512 requirement).
2. Check the region is *pinned* (not pageable) for DMA.
3. Check the descriptor's `Q` fields are within the region bounds — **integer overflow in `offset + length` is a classic CVE.**

### 2.4 AVX-512 vendor lock

**Finding (F5):** AVX-512 is not available on:
- All Apple Silicon (ARM).
- All pre-Skylake-X Intel.
- All AMD pre-Zen 4 (Zen 4 has AVX-512, Zen 1–3 do not).
- All RISC-V, POWER, s390x.

**Rule 27 violation.** The kernel must be compiled with runtime dispatch (`__builtin_cpu_supports("avx512f")`) and a scalar fallback. If the submission claims "12/12 conformance" without a fallback, the claim is false on non-AVX-512 hardware.

### 2