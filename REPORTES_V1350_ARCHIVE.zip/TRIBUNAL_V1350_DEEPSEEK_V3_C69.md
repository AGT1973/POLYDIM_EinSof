# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 69)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 69 · Six-Component Adversarial SOTA Review

**Presiding note.** The Tribunal treats every claim as unproven until a proof, a bound, or a counterexample is supplied. Where the source files are not in evidence, we audit the *stated* contract and flag every place where the contract is under-specified. Verdicts are per-target; a global synthesis closes the cycle.

---

## 0. Notation & Standing Assumptions

- `step ∈ ℝ` is the optimizer step scalar; `M ∈ ℝ^{2K×2K}` is the metric/preconditioner; `B ∈ ℝ^{2K×2K}` is the update.
- `ε_mach ≈ 2.22e-16` (FP64), `ε_mach ≈ 5.96e-8` (FP32).
- Subnormal threshold FP64: `≈ 4.94e-324`; FP32: `≈ 1.40e-45`.
- Rule 22: inter-agent messages carry **zero 1-D token streams**; all payloads are 88-byte PMTP descriptors.
- Rule 27: no component may impose vendor lock; every silicon path must be substitutable behind the same ABI.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| ver_major, ver_minor | `HH` | 4 |
| flags_a, flags_b, flags_c | `QQQ` | 24 |
| ptr_a, ptr_b | `QQ` | 16 |
| dims (K, D, rank, lanes) | `BB` | 2 |
| pad | `6x` | 6 |
| tail (4×u64) | `4Q` | 32 |
| **Total** | | **88** |

✅ **88-byte conformance holds** under native alignment (`<` little-endian, no padding). **Caveat:** `struct.calcsize('<4sHHQQQQQBB6x4Q')` must be asserted at import; if the platform's `Q` is not 8 bytes (non-IEEE-754 hosts, exotic ABIs), the contract silently breaks. **Recommendation:** add a module-level `assert struct.calcsize(...) == 88` and a `_Static_assert` mirror in C++/Rust.

### 1.2 Multi-silicon HardwareProbe

The probe must be **idempotent** and **side-effect-free** w.r.t. the descriptor. Two failure modes:

1. **Probe races** — if two orchestrators probe concurrently and both write `flags_*`, the descriptor becomes non-deterministic. Fix: probe into a local, then CAS-publish.
2. **Vendor leakage** — if the probe returns a vendor enum that downstream code branches on, Rule 27 is violated. The probe must return a **capability bitmask** (AVX512, AMX, HMMA, MFMA, TPU-XLA, …), not a vendor ID.

### 1.3 PmtpSlabAllocator

Slab allocation of 88-byte records is **not** a power of two. Consequences:

- If the slab uses `mmap` with 4 KiB pages, 88-byte records pack 46 per page with 48 bytes waste — acceptable.
- If the slab uses a buddy allocator, 88 rounds to 128 → **45 % internal fragmentation**. Demand a **slab-of-slabs** design: 128-byte slots, 88 used, 40 reserved for future flags. Document this.

### 1.4 12/12 physical conformance checks

The Tribunal demands the **list** of the 12 checks. Without it, "12/12" is a marketing claim. Minimum admissible set:

1. `sizeof == 88`
2. `alignof == 8`
3. magic == `b'PMTP'`
4. version monotone
5. pointer fields 8-byte aligned
6. dims ≤ 255
7. pad bytes zero
8. tail reserved-zero
9. endianness tag
10. checksum (CRC-32 over first 84 bytes)
11. no NaN in float-reinterpreted fields
12. round-trip `pack(unpack(x)) == x`

**Verdict T1:** ✅ 88-byte contract holds; ⚠️ probe must be capability-based (Rule 27); ⚠️ 12-check list must be published.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant:

```
s = 0; c = 0
for i: t = s + x_i*y_i
       if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
       else:                c += (x_i*y_i - t) + s
       s = t
return s + c
```

**Error bound (Ogita–Rump–Oishi):** for `n` terms with `|x_i y_i| ≤ M`,

```
|fl(Σ x_i y_i) − Σ x_i y_i| ≤ (n·ε + O(n²ε²)) · Σ|x_i y_i|
```

i.e. **condition-number-independent** to first order. This is the correct choice for the Stiefel retraction inner products.

**Degeneracy at `step → ∞`:** the compensated sum is *not* the problem — the problem is the **outer** scaling. If `step ≥ 1e10`, then `step · B` overflows FP32 (max ≈ 3.4e38) only at `step ≥ 1e38`, but **loses precision** at `step ≥ 1e10` because `B`'s low bits are shifted out. **Mitigation:** the Woodbury form `(M/scale) W = (step/scale) B` must choose `scale = max(|step|, ‖M‖_F, ‖B‖_F)` **before** any multiply. This is exactly what Target 4 claims; Targets 2/3 must mirror it.

**Degeneracy at `step → 0` (subnormals):** if `step < 4.94e-324`, `step·B` underflows to zero. The audit flags `-12, -14` as **subnormal exponents** — these are FP32 subnormals (`2^-126 ≈ 1.18e-38`, so `-12` and `-14` in log10 are `≈ 1e-12, 1e-14`, which are **normal** in FP32). **The audit's own labels are inconsistent.** Demand clarification: are `-12, -14` log10 magnitudes or binary exponents? If binary, they are normal; if log10, they are normal; either way the "subnormal audit" is mislabeled.

### 2.2 Zero-copy PMTP validation

Zero-copy requires:

- The 88-byte descriptor is **POD** and **trivially copyable** (`static_assert(std::is_trivially_copyable_v<PmtpDescriptor>)`).
- The pointer fields are `uint64_t` (not `T*`) to survive FFI.
- Validation must **not** dereference the pointers (that would fault on a foreign address space). Validate only the descriptor bytes.

### 2.3 AVX-512 / OpenMP

- AVX-512 downclocking on Skylake-X is a **throughput** hazard, not correctness. Document.
- OpenMP `reduction(+:s,c)` on Neumaier is **not** associative-safe: the compensation term `c` must be reduced with the same pairing as `s`. Use a **two-pass** or **Kahan-tree** reduction. **This is a real bug class.**

**Verdict T2:** ⚠️ Neumaier correct in principle; ❌ OpenMP reduction of `(s,c)` is unsound as stated; ❌ subnormal labels `-12, -14` are misclassified; ⚠️ zero-copy requires `is_trivially_copyable` static_assert.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI barrier

**This is a serious finding.** `panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is `extern "C-unwind"` (stabilized 1.71). The correct hardening:

```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> i32 {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```

or compile the FFI crate with `panic = "abort"`. **`panic = unwind` alone is not a safety barrier — it is a UB vector.**

### 3.2 Safe SIMD

Rust's `std::simd` is nightly-only. If the crate uses `core::arch::x86_64::*`, it is `unsafe`. The claim "Safe SIMD" is therefore **false** unless the crate pins a nightly toolchain and documents it. Demand `#![feature(portable_simd)]` in evidence.

### 3.3 Packed 88-byte descriptor

Rust's default `repr(Rust)` reorders fields. The descriptor **must** be `#[repr(C, packed(8))]` or `#[repr(C)]` with explicit padding. `packed(8)` is correct here; `packed(1)` would break alignment. Demand `const _: () = assert!(std::mem::size_of::<PmtpTensorDescriptor>() == 88);`.

**Verdict T3:** ❌ `panic = unwind` is not an FFI barrier (UB); ❌ "Safe SIMD" is unsupported without nightly; ✅ 88-byte packing achievable with `repr(C, packed(8))` + const assert.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in `R^{2K×2K}`

Cayley retraction: `Y = (I − ½W)^{-1}(I + ½W) X`, where `W = A X^T − X A^T` is skew-symmetric. For `X ∈ St(2K, p)`:

- `W` is `2K×2K` skew.
- The solve `(I − ½W) Y = (I + ½W) X` is a **2K×2K** linear system.
- `cuSOLVER DnDsyevd` is for **symmetric** eigenproblems. `W` is **skew-symmetric**, so `iW` is Hermitian. **`DnDsyevd` cannot be applied to `W` directly.** The correct routine is `cusolverDnZheevd` on `iW` (complex Hermitian), or a real **skew-symmetric Schur** via `cusolverDnD