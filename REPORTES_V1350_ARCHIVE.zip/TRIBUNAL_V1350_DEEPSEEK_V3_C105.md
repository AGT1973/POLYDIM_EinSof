# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 105)

# POLYDIM V1350 — High Tribunal Audit, Cycle 105

**Presiding note.** The Tribunal has reviewed the six artifacts as submitted. We issue findings under four headings per target: (A) numerical degeneracy at step → ∞ / step → 0, (B) Rule 22 compliance (zero 1-D tokens, 88-byte PMTP), (C) Rule 27 Silicon Contract (vendor-lock), (D) proofs / condition numbers / FFI hardening. Where the submission is silent on a claim, we mark it **UNVERIFIED** rather than assume.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### A. Numerical degeneracy
- **step → ∞ (|step| ≥ 10¹⁰):** The orchestrator itself is a dispatcher; the risk is *descriptor arithmetic*, not floating-point. The 88-byte struct `<4sHHQQQQQBB6x4Q` packs `Q` (uint64) fields. If any `Q` field encodes a *scaled step* or *byte offset*, then `step·stride` can overflow `2⁶⁴` at `step ≈ 10¹⁰` only if `stride ≥ 1.8×10⁹`. **Action:** require an explicit `assert stride < 2**32` before packing, or promote to a checked `u128` intermediate. Silent wraparound here is a *correctness* bug, not a rounding bug.
- **step → 0 / subnormals:** The orchestrator does not perform FP arithmetic on `step`; subnormal risk is deferred to Targets 2–6. **No degeneracy at this layer**, provided the descriptor carries `step` as a raw IEEE-754 bit pattern (which the `Q` fields permit).

### B. Rule 22 compliance
- **88-byte PMTP:** Struct size check: `4s` (4) + `HH` (4) + `QQQQQ` (40) + `BB` (2) + `6x` (6) + `4Q` (32) = **88 bytes exactly**. ✅ Alignment: `Q` requires 8-byte alignment; the leading `4sHH` = 8 bytes, so the first `Q` lands on offset 8. ✅ No implicit padding. **PASS.**
- **Zero 1-D tokens:** The orchestrator must not emit scalar tokens between agents. **UNVERIFIED** — the submission does not show the inter-agent wire format. The Tribunal **demands** a byte-level trace showing every inter-agent message is a multiple of 88 bytes with a valid PMTP header. A single `int` or `float` on the wire is a Rule 22 violation.

### C. Rule 27 Silicon Contract
- `HardwareProbe` is described as *multi-silicon*. **PASS conditionally** — vendor-lock is avoided **iff** the probe's dispatch table is data-driven (a capability bitmap), not a hard-coded `if vendor == "nvidia"` ladder. The Tribunal requires the probe to expose a `CapabilitySet` bitfield and to *fail closed* (return `UNSUPPORTED`) rather than silently fall back to a vendor-specific path.

### D. Proofs / hardening
- **Descriptor round-trip proof (required):** For all valid `(tag, ver, flags, n, m, k, off_a, off_b, off_c, dtype_a, dtype_b, r0..r3)`, `unpack(pack(x)) == x`. The `6x` pad bytes **must** be zeroed on pack and **ignored** on unpack — otherwise two distinct logical descriptors collide. Add a unit test enumerating the 2⁴⁸ reachable `Q`-space boundary cases (0, 1, 2⁶³, 2⁶⁴−1).
- **FFI hardening:** Mark the struct `#[repr(C, align(8))]` in Rust and `__attribute__((packed, aligned(8)))` in C++. Add a compile-time `static_assert(sizeof(...) == 88)` in every language. Reject any descriptor whose pad bytes are non-zero (defense against uninitialized memory leaking across the FFI boundary).

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### A. Numerical degeneracy
- **Neumaier compensated dot product.** The algorithm is:
  ```
  s = 0; c = 0
  for i: t = s + a[i]*b[i]
         if |s| >= |a[i]*b[i]|: c += (s - t) + a[i]*b[i]
         else:                  c += (a[i]*b[i] - t) + s
         s = t
  return s + c
  ```
  - **step → ∞:** The *compensation term* `c` is bounded by `n·u·|s|` where `u = 2⁻⁵³`. For `n = 2²⁰` and `|s| ≈ 10¹⁰`, `|c| ≲ 10¹⁰ · 2²⁰ · 2⁻⁵³ ≈ 10⁻⁶`. **No overflow**, but the *relative* accuracy of `s + c` degrades to `O(n·u)` — i.e., ~2⁻³³ for n = 2²⁰. This is the **asymptotic condition number** of the compensated sum: `κ_comp(n) = n·u`. **Verdict:** safe for `|step| ≤ 10¹⁰` provided `n ≤ 2²⁰`; beyond that, the compensation is *itself* sub-ULP and the method degenerates to naive summation.
  - **step → 0 / subnormals:** The audit mentions subnormal checks at `-12` and `-14` (presumably exponents). If `a[i]*b[i]` underflows to subnormal, the *exact* product is lost before compensation. **Neumaier cannot recover subnormal products.** The Tribunal requires either (i) `fesetround(FE_UPWARD)` + scaling, or (ii) a two-product `fma`-based Dekker split. **Without this, the subnormal audit is cosmetic.**
- **AVX-512 reduction order:** OpenMP `reduction(+:s,c)` is **non-deterministic** across thread counts. For a *compensated* sum, non-determinism breaks the compensation invariant. **Mandate:** fixed-tree reduction (e.g., `#pragma omp parallel for reduction` replaced by an explicit pairwise tree) or `KMP_DETERMINISTIC_REDUCTION=TRUE`.

### B. Rule 22 compliance
- **Zero-copy PMTP validation:** The C++ core must validate the 88-byte descriptor *in place* (no copy into a local struct). **PASS conditionally** — the submission claims zero-copy; the Tribunal requires a `static_assert(alignof(PmtpTensorDescriptor) == 8)` and a `reinterpret_cast` guarded by `std::is_trivially_copyable_v`. Any `memcpy` of the descriptor is a Rule 22 violation (it creates a 1-D token shadow).

### C. Rule 27 Silicon Contract
- **AVX-512 is Intel-specific.** AMD Zen 4/5 implement AVX-512, but Zen 1–3 do not. **Vendor-lock risk: HIGH.** The Tribunal requires a runtime `__builtin_cpu_supports("avx512f")` dispatch to a scalar/AVX2 fallback. Without it, the kernel is *not* silicon-portable and violates Rule 27.

### D. Proofs / hardening
- **Condition number of Neumaier:** `κ = n·u / (1 − n·u)`. For `n·u → 1` (n ≈ 2⁵³), the bound is vacuous. **Proof obligation:** show `n ≤ 2²⁰` in all call sites, or switch to Kahan–Babuska with `fma`.
- **FFI hardening:** Export the kernel as `extern "C"` with `noexcept`. Validate the descriptor's `dtype` fields against a whitelist *before* any pointer arithmetic. Use `__builtin_assume_aligned(ptr, 64)` only after a runtime alignment check.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### A. Numerical degeneracy
- **Neumaier in Rust:** Same `κ = n·u` bound as Target 2. Rust's `f64` is IEEE-754 binary64; no extra precision. **Same subnormal caveat:** Rust does *not* flush subnormals by default (good), but `std::simd` may lower to instructions that do. **Mandate:** `#[cfg(target_feature = "fma")]` path using `f64::mul_add` for the Dekker split.
- **step → ∞:** Rust's `f64` saturates to `inf` at `~1.8×10³⁰⁸`. At `step = 10¹⁰`, no overflow in the *step* itself, but `step²` (if used in a Cayley denominator) overflows at `step ≈ 10¹⁵⁴`. **Check:** does the Rust kernel form `step²`? If yes, **overflow at step ≥ 10¹⁵⁴**, well beyond the audit's 10¹⁰ — but the *intermediate* `step·B` in a Woodbury solve can overflow earlier. **Require** a `debug_assert!(step.abs() < 1e150)`.

### B. Rule 22 compliance
- **Packed 88-byte `PmtpTensorDescriptor`:** Rust's default `repr(Rust)` **reorders fields**. The submission says "packed" — the Tribunal requires `#[repr(C, packed(8))]` and a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`. **PASS conditionally.**
- **Zero 1-D tokens:** Rust's `panic=unwind` FFI barrier is the *right* choice — but `panic=abort` would be a Rule 22 violation (it kills the agent, not the token). **PASS** on the barrier choice. **However:** `catch_unwind` at the FFI boundary must **not** be used to swallow panics silently; it must convert to a typed `Result` and emit a *PMTP-shaped* error token (88 bytes), not a string.

### C. Rule 27 Silicon Contract
- **Safe SIMD** via `std::simd` is portable across x86/ARM. **PASS** — provided the kernel does not `#[cfg(target_arch = "x86_64")]`-gate the *only* implementation. The Tribunal requires a scalar fallback compiled unconditionally.

### D. Proofs / hardening
- **FFI safety proof:** `extern "C" fn` must be `unsafe` on the Rust side, with a `// SAFETY:` comment proving: (i) pointer is 8-byte aligned, (ii) descriptor is 88 bytes, (iii) lifetime outlives the call. **Mandate** `#[deny(unsafe_op_in_unsafe_fn)]`.
