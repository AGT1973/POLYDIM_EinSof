# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 140

No public evidence in the available results identifies **POLYDIM V1350**, its six kernels, or the eight purported Tribunal reports. Therefore, a literal arbitration of those model findings—and any claim that it establishes exact V1350 architectural guarantees—would be unsupported. The defensible synthesis is a set of conditional engineering conclusions grounded in established numerical-linear-algebra and memory-model principles.

## 1. Cayley/Stiefel retraction under \(\lvert\text{step}\rvert \ge 10^{10}\)

For a Stiefel point \(X\), \(X^\top X=I\), a Cayley update commonly has the form

\[
X_{+}
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

where \(W^\top=-W\). Polar and QR alternatives instead orthonormalize \(X+\xi\); the polar form is

\[
R_{\mathrm{polar}}(X,\xi)
=
(X+\xi)(I+\xi^\top \xi)^{-1/2},
\]

while QR uses the \(Q\) factor of \(X+\xi\).[1][2]

**Arbitration:** no method is automatically “stable” merely because it is a Cayley retraction.

- **Cayley:** preserves orthogonality algebraically when \(W\) is exactly skew-symmetric and the linear solve is accurate. It avoids explicitly forming a potentially enormous \(X+\xi\), but at extreme step magnitudes it can suffer from conditioning, overflow in coefficient construction, inaccurate skew-symmetrization, and unstable linear solves.
- **Polar:** has a strong geometric normalization property, but \(I+\xi^\top\xi\) can overflow or become badly scaled at \(10^{10}\)-scale steps unless the computation is rescaled.
- **Householder/QR:** is generally robust for orthogonalization when implemented with blocked, pivot-free Householder reflectors and appropriate scaling. However, the raw matrix \(X+\xi\) still needs safe formation, and QR sign conventions must be deterministic if bitwise reproducibility matters.

The available literature supports treating Cayley, polar, and QR as distinct retractions with different costs and numerical behavior, not as a universal ranking.[1][2] A published discussion also notes that certain favorable vector-transport properties of Cayley-based methods do not generally hold for differentiated QR and polar retractions; that is a convergence-analysis distinction, not proof of extreme-step floating-point superiority.[7]

### Definitive engineering rule

For \(\lvert\text{step}\rvert\ge 10^{10}\), the kernel may guarantee only the following if explicitly implemented and tested:

1. **Finite-output guarantee:** input scaling, overflow checks, and a defined fallback are mandatory.
2. **Manifold-residual guarantee:** accept the result only if
   \[
   \|X_+^\top X_+-I\| \le \tau_{\mathrm{orth}},
   \]
   with \(\tau_{\mathrm{orth}}\) specified by precision and backend.
3. **Algorithmic fallback:** use scaled Householder QR or a scaled polar decomposition when the Cayley solve is ill-conditioned.
4. **No unconditional exactness claim:** finite-precision arithmetic cannot guarantee exact orthogonality or bounded backward error for arbitrary \(10^{10}\)-scale inputs.

Thus, the mathematically superior SOTA design is **adaptive**, not a single retraction: scaled Cayley when its skew system is well-conditioned, otherwise stable Householder QR or polar normalization.

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

The search results provide no specification for “PMTP,” no 88-byte layout, and no V1350 memory protocol. The fact that a descriptor occupies 88 bytes does **not** establish atomicity, ABI safety, cache-line safety, or snapshot isolation.

The exact guarantee must instead be defined by a publication protocol. A sound immutable-snapshot pattern is:

1. Writer constructs a complete descriptor and immutable payload privately.
2. Writer performs ordinary initialization writes.
3. Writer publishes a pointer, generation, or descriptor handle with **release** semantics.
4. Reader loads the publication value with **acquire** semantics.
5. Reader accesses only the immutable snapshot reachable from that acquired value.
6. Reclamation occurs only after an RCU grace period or after QSBR confirms that every pre-existing reader has passed a quiescent state.

Acquire/release orders publication and observation; it does not, by itself, solve reclamation. QSBR additionally requires correct reader registration, quiescent-state reporting, and a writer-side grace-period test. A stale reader that has not reported quiescence must prevent reclamation.

### Required architectural guarantee

The strongest defensible statement is:

> A reader that successfully acquires a published snapshot observes a fully initialized, internally consistent immutable descriptor and payload; that snapshot is not reclaimed until the applicable RCU/QSBR grace-period condition has been satisfied.

This guarantee requires:

- a single, specified publication variable or atomic handle;
- release publication and acquire consumption;
- no unsynchronized mutation of published fields;
- a defined lifetime for pointed-to objects;
- correct fences or atomics for each target memory model;
- alignment and representation rules for the 88-byte object;
- a prohibition on assuming that an 88-byte structure is atomically copied or atomically visible.

If the descriptor itself is updated in place, acquire/release alone does **not** provide snapshot isolation. The design must use immutable versions, copy-on-write, sequence validation, or a transactional/versioned protocol.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no basis for claiming identical semantics across these ecosystems. They have different compilation, synchronization, aliasing, and memory-model boundaries.

A valid conformance definition must separate:

- **numerical conformance:** tolerance-bounded outputs and residuals;
- **layout conformance:** byte offsets, alignment, endianness, and padding;
- **ordering conformance:** publication and observation rules;
- **lifetime conformance:** reclamation only after grace periods;
- **failure conformance:** behavior for NaNs, overflow, singular solves, and unsupported steps;
- **determinism conformance:** whether results are reproducible bit-for-bit or only within tolerances.

The common portable contract should be expressed at the algorithmic level:

\[
\text{publish} \prec_{\mathrm{release}} \text{acquire-read},
\]

and

\[
\text{reclaim} \succ \text{all readers' grace-period completion}.
\]

Backend-specific implementations may realize that contract differently. CUDA and Triton require explicit attention to device scope, block scope, stream ordering, and host/device visibility. XLA may reorder or fuse operations unless the required effects are represented through supported synchronization and buffer semantics. C++20 requires atomics and object-lifetime rules to be respected. Rust adds type-level ownership guarantees, but unsafe foreign-memory, device-memory, atomics, and reclamation code still require explicit synchronization proofs.

## Arbitration of the eight-model findings

Because the actual Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, and Perplexity reports were not supplied, they cannot be ranked or reconciled individually. Any purported “majority finding” would be unverifiable.

The evidence-based arbitration is:

| Question | Defensible ruling |
|---|---|
| Extreme-step retraction | No unconditional Cayley victory; require scaling, conditioning checks, residual tests, and QR/polar fallback. |
| 88-byte PMTP descriptor | Size alone gives no memory-order or atomicity guarantee. Use release publication, acquire consumption, immutable snapshots, and RCU/QSBR reclamation. |
| Five-target conformance | Possible only through an explicit backend-neutral contract plus backend-specific implementations and validation; source-level similarity is insufficient. |
| Exact architectural guarantees | Can be claimed only after the missing V1350 ABI, memory protocol, kernel definitions, precision targets, and cross-backend test results are provided. |

The strongest SOTA synthesis is therefore **conditional and contract-based**: adaptive, scaled manifold retraction; immutable acquire-published snapshots with separately proven grace-period reclamation; and conformance defined by numerical, memory-order, layout, lifetime, and failure-mode tests. It would be mathematically and architecturally unsound to certify stronger V1350 guarantees from the currently available evidence.