# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 107

The supplied record does **not contain the six tribunal models’ actual reports or the six V1350 kernel specifications**. Therefore, no genuine model-by-model arbitration is possible, and the “definitive” synthesis below must be stated as a **conditional architectural ruling**, not as a verified audit of POLYDIM V1350.

## Arbitration ruling

| Issue | Superior decision | Required guarantee |
|---|---|---|
| Extreme-step Stiefel retraction | **Polar/Householder-QR fallback**, not unguarded Cayley | The result must be orthonormal within a specified floating-point tolerance, with finite outputs and explicit failure/status reporting |
| PMTP descriptor ordering | **Release publication + acquire snapshot validation**, with QSBR/RCU grace-period reclamation | A reader sees either a complete old descriptor or a complete new descriptor—never a mixed descriptor |
| Multi-silicon conformance | **One normative semantic specification plus backend-specific implementations** | CUDA, XLA, Triton, C++20, and Rust must satisfy identical observable invariants, while not being assumed to have identical instruction-level behavior |

## 1. Cayley versus Householder/Polar QR for \(\lvert\text{step}\rvert \ge 10^{10}\)

An unguarded Cayley update has the form

\[
Y=\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
  \left(I+\frac{\alpha}{2}\Omega\right)X,
\]

where \(\Omega^\mathsf{T}=-\Omega\). In exact arithmetic, the Cayley transform preserves orthogonality whenever the inverse exists. That is **not sufficient** for extreme-step numerical stability.

The relevant conditioning issue is that the transform becomes highly sensitive when the scaled skew operator approaches a Cayley pole, namely when

\[
-\!1\in \sigma\!\left(\frac{\alpha}{2}\Omega\right)
\]

in the corresponding transformed formulation. The search evidence specifically notes that the canonical Cayley retraction requires the relevant matrix not to have eigenvalue \(-1\), while also reporting bounded condition estimates only under the stated regularity assumptions.[1]

Consequently:

- **Cayley is not entitled to an unconditional guarantee at \(\lvert\alpha\rvert\ge10^{10}\).**
- A large scalar step by itself does not prove failure; the decisive quantities are scaling, spectrum, conditioning, precision, and how the linear solve is performed.
- A Cayley implementation that forms explicit inverses, uses poorly scaled normal equations, or silently accepts a failed solve cannot be classified as SOTA-safe.
- **Householder QR** is the preferred robust fallback for producing an orthonormal \(Q\) from \(X+\eta\). QR retractions are standard Stiefel constructions and generally cost less than a full polar factorization.[2]
- **Polar retraction** has the clean formula
  \[
  R_{\mathrm{polar}}(X,\eta)
  =(X+\eta)\bigl(I+\eta^\mathsf{T}\eta\bigr)^{-1/2},
  \]
  and is attractive when the closest orthonormal factor and smoothness are more important than minimum cost.[3]

The mathematically strongest kernel policy is therefore:

1. Compute a scaled Cayley candidate only when conditioning and residual tests pass.
2. Verify both
   \[
   \|Y^\mathsf{T}Y-I\|
   \quad\text{and}\quad
   \left\|\left(I-\frac{\alpha}{2}\Omega\right)Y-
   \left(I+\frac{\alpha}{2}\Omega\right)X\right\|.
   \]
3. If either test fails, use Householder QR or a numerically stable polar implementation.
4. If all candidates fail, return an explicit numerical-status code; never emit an unchecked matrix.

Thus the definitive ruling is:

> **Cayley may be an optimized conditional path, but Householder QR or polar retraction must be the correctness path for extreme steps.** No architecture-level guarantee should claim unconditional Cayley stability for \(\lvert\text{step}\rvert\ge10^{10}\).

A further limitation is essential: the available evidence describes general Stiefel retractions, not the undocumented V1350 kernels themselves. It therefore cannot establish their empirical error bounds, overflow behavior, or performance.

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

Acquire/release ordering is necessary but, by itself, does not make an 88-byte descriptor atomic.

The required publication protocol is conceptually:

```text
writer:
    construct complete descriptor in private storage
    publish pointer/version with release semantics
    wait for the reclamation grace period
    reclaim old storage only after readers quiesce

reader:
    load pointer/version with acquire semantics
    read descriptor fields
    validate version or generation
    retry if validation fails
    report quiescent state before reclamation can proceed
```

A release operation orders prior writes before publication, and a matching acquire of the same synchronization location makes those prior writes visible to the reader.[4] This establishes visibility of the initialized descriptor; it does **not** make concurrent in-place mutation of the descriptor safe.

The exact guarantees should be:

- **Initialization visibility:** after an acquire observes a release publication, all descriptor fields initialized before publication are visible.
- **No torn logical snapshot:** readers access immutable descriptor storage, or use a seqlock/version-validation protocol.
- **No premature reclamation:** old storage is freed only after the RCU/QSBR grace period confirms that all pre-existing readers have passed through a quiescent state.
- **ABA protection:** the publication record includes a generation/version, or uses a reclamation scheme that prevents address reuse from being mistaken for the same descriptor.
- **Alignment and representation:** the 88-byte layout is fixed by an ABI specification, including offsets, padding, endianness, scalar widths, and validity rules.
- **Atomicity scope:** only the pointer, index, generation, or publication word is required to be atomic. The 88-byte payload need not—and generally cannot—be atomically loaded as one unit.
- **Memory-domain scope:** CPU acquire/release does not automatically establish ordering with GPU memory, DMA, or another device. Device-specific fences and stream/event synchronization are required for those domains.

The strongest safe design is **immutable, out-of-place publication**:

\[
D_{\text{new}}\leftarrow\text{fully initialize},
\qquad
P\leftarrow_{\mathrm{release}}(g_{\text{new}},D_{\text{new}}).
\]

Readers perform

\[
(g,D)\leftarrow_{\mathrm{acquire}}P
\]

and use \(D\) only while their RCU read-side critical section remains active. If descriptors must be updated in place, use a versioned protocol:

\[
v_{\text{odd}}\to\text{write fields}\to v_{\text{even}},
\]

with readers rejecting odd or changed versions. Even then, reclamation and lifetime remain separate obligations.

Therefore:

> **Acquire/release provides publication visibility; RCU/QSBR provides lifetime isolation; version validation provides snapshot consistency when mutation or multiword observation is possible.** None of these alone guarantees all three properties.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

The correct conformance claim is semantic, not syntactic. These systems have materially different execution and memory models:

- C++20 and Rust can express host-side atomic publication and RCU/QSBR protocols.
- CUDA adds device scopes, stream ordering, and GPU fence requirements.
- Triton exposes compiler-managed GPU kernels and does not automatically inherit arbitrary C++ memory-model assumptions.
- XLA uses graph-level compilation and may fuse, reorder, or replicate operations unless the program expresses the required dependency through supported synchronization mechanisms.

A single portable guarantee should therefore be stated as an **abstract contract**:

### Numerical contract

For every successful Stiefel kernel:

\[
\|Y^\mathsf{T}Y-I\|\le \tau_{\mathrm{orth}},
\]

where \(\tau_{\mathrm{orth}}\) is explicitly parameterized by precision, dimensions, backend, and conditioning. The kernel must also define behavior for overflow, nonfinite input, failed factorization, and excessive condition number.

### Publication contract

For every successful descriptor read:

- the reader observes one valid generation;
- all fields belong to that generation;
- publication happens-before observation;
- reclamation happens-after the final protected reader exits.

### Cross-backend contract

Each backend must pass:

- deterministic layout and offset tests for the 88-byte descriptor;
- randomized orthogonality and residual tests;
- extreme-step tests, including \(\lvert\text{step}\rvert\ge10^{10}\);
- adversarial near-singular and near-pole tests;
- concurrent publication/reclamation tests under sanitizers and race detectors where available;
- differential tests against a high-precision reference implementation;
- explicit tests for NaN, infinity, overflow, underflow, and failed solver paths.

The implementations may differ internally—for example, QR in one backend and a guarded polar or Cayley path in another—but they must expose the same status codes, tolerance policy, layout, generation rules, and observable guarantees.

## Final SOTA specification

The strongest defensible V1350 architecture is:

1. **Numerics:** guarded Cayley fast path; Householder QR or polar fallback; residual and orthogonality certification; no silent failure.
2. **Descriptors:** immutable 88-byte payloads; release publication of pointer-plus-generation; acquire readers; QSBR/RCU grace-period reclamation; ABA prevention.
3. **Portability:** normative backend-neutral contract; backend-specific fences and synchronization; no claim that host atomics alone order GPU or DMA accesses.
4. **Certification:** guarantees expressed with explicit tolerances, precision, dimensions, memory scopes, and failure modes.

Any tribunal finding that claims unconditional Cayley stability at extreme steps, atomicity of the entire 88-byte descriptor from acquire/release alone, or automatic semantic equivalence across all five execution ecosystems is technically overstated.