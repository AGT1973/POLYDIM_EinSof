# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 130

The requested **definitive arbitration cannot be performed from the available evidence**: no verifiable records of the eight Tribunal outputs, the six V1350 kernels, or the PMTP 88-byte descriptor specification were provided or found. The only identifiable “POLYDIM” result is an unrelated C++ library for polytopal discretization methods.[11] Public literature does support general claims about Cayley retractions, but not the claimed V1350 implementation or its cross-platform guarantees.[1][3]

## Evidence-based arbitration

### 1. Cayley–Stiefel retraction versus Householder or polar QR at \(|\mathrm{step}| \ge 10^{10}\)

A Cayley map has the form

\[
R_X(\alpha\Omega)
=
\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
\left(I+\frac{\alpha}{2}\Omega\right)X,
\qquad
\Omega^\mathsf{T}=-\Omega.
\]

For exact arithmetic, the transformation is orthogonal whenever the inverse exists, so it preserves the Stiefel constraint \(R_X^\mathsf{T}R_X=I\). The literature identifies Cayley as a valid Stiefel retraction and as second-order under the canonical metric.[1][3][10]

That does **not** imply numerical stability for arbitrarily large steps:

- The matrices \(I-\frac{\alpha}{2}\Omega\) and \(I+\frac{\alpha}{2}\Omega\) can become badly scaled or ill-conditioned in floating-point arithmetic.
- A large step magnifies rounding, overflow, loss of significance, and errors in forming or solving the linear system.
- “Constraint-preserving in exact arithmetic” is therefore weaker than “stable for \(|\alpha|\ge10^{10}\).”

Householder QR and polar retraction provide orthonormalization through backward-stable factorization or inverse-square-root procedures, but they also require explicit conditioning, scaling, and rank assumptions. No method can honestly guarantee bounded forward error at \(10^{10}\) solely from the algorithm name.

**Arbitrated result:** the strongest defensible design is a **scaled Cayley method with condition estimation and a certified fallback to Householder QR or a numerically stable polar method**. A universal claim that Cayley is superior under extreme steps is unsupported. The exact guarantee should be conditional:

\[
\widehat X^\mathsf{T}\widehat X
=
I+\Delta,
\qquad
\|\Delta\|
\le
C\,u\,\kappa_{\mathrm{solve}}\,p(n),
\]

provided scaling prevents overflow and the linear solve meets its backward-error tolerance. If those conditions fail, the implementation must fall back or reject the step.

### 2. PMTP 88-byte descriptors and Acquire/Release RCU/QSBR isolation

An 88-byte layout alone provides **no memory-ordering guarantee**. Correct snapshot isolation requires a protocol, not merely a structure size.

A minimally sound publication pattern is:

1. The writer initializes the descriptor and all reachable immutable payload.
2. The writer publishes the descriptor pointer or generation with **release** semantics.
3. The reader loads the publication object with **acquire** semantics.
4. The reader announces entry into the read-side critical section before dereferencing the snapshot.
5. Reclamation occurs only after every preexisting reader has passed a quiescent state or otherwise acknowledged the new epoch.

Acquire/release orders visibility of initialization; it does not, by itself, prevent reclamation while a reader still holds a pointer. Conversely, QSBR grace-period tracking does not replace the release/acquire publication edge.

**Arbitrated result:** the exact guarantee is:

> A reader that acquires a published snapshot and enters the prescribed RCU/QSBR read-side protocol observes a fully initialized immutable descriptor and its immutable reachable state; reclamation is deferred until all readers that could have observed the retired snapshot have reported a quiescent state.

This guarantee depends on all of the following:

- atomic publication and generation fields;
- release publication and acquire consumption;
- no unsynchronized mutation of reachable snapshot data;
- correct reader registration and quiescent-state reporting;
- a reclamation mechanism that handles stalled readers;
- avoidance of ABA through generations, hazard protection, or equivalent reclamation.

It does **not** guarantee that every ordinary non-atomic field is independently safe to mutate, nor that an 88-byte descriptor is naturally atomic as a whole. If the descriptor spans multiple machine words, readers must acquire a pointer, version, or seqlock protocol—not copy the entire descriptor non-atomically while it is being modified.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no general semantic equivalence across these environments. They differ in:

- memory scopes and synchronization domains;
- supported atomic widths and memory orders;
- alignment and aliasing rules;
- floating-point contraction, reassociation, and fast-math behavior;
- asynchronous execution and stream/device ordering;
- ownership and lifetime models;
- compiler lowering and backend-specific behavior.

C++20 and Rust can specify host-language atomic and ownership properties, but those properties do not automatically transfer to CUDA device code, Triton kernels, or XLA graphs. XLA may legally fuse, reorder, or replicate operations subject to its own HLO semantics. Triton and CUDA require explicit device-level synchronization and appropriate memory scopes. A host-side release store does not automatically establish a device-side acquire relationship without a documented host/device synchronization edge.

**Arbitrated result:** conformance should be defined as **observational equivalence under an explicit contract**, not source-level identity. The contract must specify:

- tensor shapes, strides, layouts, and alignment;
- permitted numerical error and determinism level;
- NaN, infinity, overflow, and denormal behavior;
- memory publication and reclamation protocol;
- synchronization scope;
- lifetime and ownership rules;
- supported atomic widths;
- fallback behavior when a backend lacks an operation or memory order.

The appropriate guarantee is conditional:

\[
\text{Backend result}
\equiv_{\varepsilon,\mathcal{M},\mathcal{D}}
\text{reference result},
\]

where \(\varepsilon\) is the numerical tolerance, \(\mathcal{M}\) is the specified memory model, and \(\mathcal{D}\) is the permitted determinism class. Without those parameters, “multi-silicon conformance” is not a mathematically meaningful guarantee.

## Definitive synthesis

The mathematically strongest architecture is a **contract-driven, adaptive implementation**:

- **Retraction layer:** use scaled Cayley only when conditioning and representability checks pass; otherwise use Householder QR or stable polar orthonormalization.
- **Publication layer:** publish immutable snapshots through an atomic pointer/version with release/acquire ordering and protect readers with RCU/QSBR or hazard-style reclamation.
- **Portability layer:** define one language-independent semantic contract, then implement backend-specific synchronization, layout, and numerical paths.
- **Verification layer:** test algebraic invariants, backward error, race freedom, reclamation safety, numerical tolerances, and cross-backend observational equivalence.

The following claims cannot be made from the available information:

- unconditional Cayley stability for \(|\mathrm{step}|\ge10^{10}\);
- snapshot isolation from descriptor size or Acquire/Release alone;
- automatic conformance across CUDA, XLA, Triton, C++20, and Rust;
- a valid ranking or majority arbitration of Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, and Perplexity without their actual reports.

The available sources establish only the general mathematical status of Cayley retractions—not the V1350-specific kernels, descriptor ABI, Tribunal findings, or requested architectural guarantees.[1][3][10]