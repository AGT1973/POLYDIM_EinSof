# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 69

The public evidence retrieved does **not contain the six Tribunal models’ reports or a verifiable V1350 specification**. The search results identify PolyDiM as a general C++ polytopal-discretization library, but do not substantiate “POLYDIM V1350,” six named kernels, or an 88-byte PMTP descriptor.[6][9] Therefore, no defensible model-by-model arbitration or claim of tested multi-silicon conformance can be made. The following is the strongest technically justified synthesis under explicit assumptions.

## 1. Extreme-step Stiefel retraction

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), \(X^\top X=I\), and tangent update \(\Delta\), the Cayley transform is typically formed from a skew-symmetric matrix such as

\[
A=\Delta X^\top-X\Delta^\top,\qquad A^\top=-A,
\]

with a step-scaled update

\[
X_{+}=\left(I-\frac{\alpha}{2}A\right)^{-1}
       \left(I+\frac{\alpha}{2}A\right)X.
\]

A mathematically valid Cayley transform remains orthogonal in exact arithmetic whenever the inverse exists. However, this does **not** imply numerical stability for \(|\alpha|\ge 10^{10}\). The practical problem is that both factors become severely ill-conditioned relative to the identity, and forming or solving the linear system naively can amplify roundoff, overflow, cancellation, and loss of rank.

### Arbitration

- A **naive Cayley implementation has no unconditional stability guarantee** at extreme step sizes.
- A **Householder QR retraction** is generally more robust for producing an orthonormal basis because Householder transformations are backward stable.
- A **polar retraction**, especially computed by a stable SVD or carefully implemented Newton–Schulz iteration with scaling, provides the most direct orthogonal projection onto the Stiefel manifold, but its cost and convergence behavior differ.
- Cayley is attractive when preserving structure and avoiding a full factorization matters, but it requires scaling, stable solves, and residual checks.

The SOTA guarantee should therefore be conditional:

\[
\widehat X_{+}=Q+\delta Q,\qquad
\|\delta Q\| \lesssim \kappa_{\mathrm{solve}}\,
\mathrm{poly}(n,p)\,u,
\]

provided that:

1. the Cayley system is solved by a backward-stable method;
2. scaling or factorization avoids overflow and underflow;
3. \(\kappa_{\mathrm{solve}}\) is bounded;
4. the result is verified using
   \[
   \| \widehat X_{+}^{\top}\widehat X_{+}-I\| \le \tau_{\mathrm{orth}};
   \]
5. a fallback to Householder QR or polar projection is taken when the residual, condition estimate, or factorization test fails.

The exact architectural guarantee should be:

> For \(|\alpha|\ge 10^{10}\), V1350 guarantees **no silent acceptance of an invalid Stiefel point**. It guarantees either a verified orthogonality residual below the configured tolerance or an explicit fallback/error status. It must not claim unconditional Cayley stability merely from the algebraic orthogonality of the exact transform.

A robust policy is:

\[
\text{Cayley} \rightarrow
\begin{cases}
\text{accept if residual and conditioning tests pass},\\
\text{Householder QR fallback otherwise}.
\end{cases}
\]

For the strongest reliability target, use QR or SVD-based polar retraction as the reference implementation and treat Cayley as an optimized path whose outputs are checked against the reference invariants.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

The retrieved evidence supports the standard publication rule: a writer initializes an object and publishes its pointer with a **release** operation; a reader obtains it with an **acquire** operation. That acquire–release pair creates the required happens-before relationship for writes sequenced before publication.[12] The userspace RCU QSBR implementation is also relevant as an example of grace-period tracking.[7]

An 88-byte size by itself provides **no memory-ordering guarantee**. Alignment, atomicity, cache coherence, and language/compiler rules must be specified independently.

### Correct publication protocol

A safe immutable-snapshot design is:

1. Construct and fully initialize descriptor \(D_{\text{new}}\) privately.
2. Publish its pointer or generation identifier with a release store or release CAS:
   \[
   P.store(D_{\text{new}},\mathrm{release}).
   \]
3. Reader loads \(P\) with acquire:
   \[
   D=P.load(\mathrm{acquire}).
   \]
4. Reader enters or announces its RCU/QSBR read-side critical section before dereferencing \(D\).
5. Writer retires the old descriptor only after a grace period in which every participating reader has passed through a quiescent state.

### Arbitration

- **Acquire/release is sufficient for publication visibility**, assuming the descriptor is immutable after publication.
- It is **not by itself sufficient for reclamation safety**. Reclamation requires RCU/QSBR grace-period accounting.
- Relaxed operations may be used for auxiliary counters only when they do not participate in publication, dependency tracking, or reclamation decisions.
- A descriptor containing concurrently modified fields requires per-field atomics or a different synchronization protocol; acquire/release on the top-level pointer does not make interior mutation safe.

The exact guarantee should be:

> Every reader that acquires a published descriptor observes all descriptor initialization sequenced before the corresponding release publication, and no descriptor is reclaimed until all readers that could have acquired it have passed through a registered QSBR quiescent state.

That guarantee requires:

- a defined lifetime for reader registration;
- no unregistered reader dereferences;
- release publication and acquire consumption;
- a grace-period algorithm proven against the target memory model;
- cache-line and alignment rules for the 88-byte layout;
- an ABI definition for padding, endianness, pointer width, and serialization.

The 88-byte layout should therefore be treated as an **ABI constraint**, not as a synchronization primitive. Cross-language implementations must use explicit offsets and static layout assertions rather than relying on compiler-dependent padding.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

The search results provide only limited evidence: PolyDiM is publicly described as a C++ library, while PyTorch/XLA documents support for Triton kernels.[6][13] They do not establish V1350 conformance across the requested platforms.

More importantly, these environments do not share one universal memory model:

- **C++20 and Rust** provide host-language atomic and synchronization semantics, subject to their respective memory models.
- **CUDA** has device, block, system, and host visibility domains; a host-style acquire/release claim must be mapped to CUDA-supported scopes and synchronization operations.
- **Triton** expresses GPU operations through compiler and backend semantics; host RCU/QSBR cannot simply be assumed to apply inside a GPU kernel.
- **XLA** is graph/compiler based and may reorder, fuse, replicate, or materialize operations unless ordering is represented through supported dependencies and custom-call contracts.

### Required conformance definition

Conformance should be separated into four layers:

| Layer | Required guarantee |
|---|---|
| Numerical | Same mathematical result within a specified tolerance and the same invariant checks |
| ABI/layout | Identical 88-byte descriptor size, alignment, field offsets, encoding, and versioning |
| Memory ordering | Correct publication, observation, and reclamation semantics in each execution domain |
| Compiler/runtime | No transformation may violate declared aliasing, side-effect, ordering, or synchronization contracts |

Bitwise identity across all five environments should **not** be promised unless all arithmetic modes, reduction orders, compiler flags, and math libraries are fixed. The defensible numerical guarantee is instead:

\[
\frac{\|\widehat y-y_{\mathrm{ref}}\|}
{\max(1,\|y_{\mathrm{ref}}\|)}
\le
\tau_{\mathrm{platform}},
\]

with platform-specific tolerances and explicit handling of NaNs, infinities, subnormals, overflow, and reduction nondeterminism.

### Architecture that can legitimately be called SOTA

1. Define one language-neutral descriptor schema with explicit offsets and version fields.
2. Generate C++20 and Rust bindings from that schema.
3. Use host acquire/release plus RCU/QSBR only for host-resident snapshots.
4. For CUDA/Triton, define separate device publication and lifetime rules; do not reuse host QSBR assumptions.
5. Represent XLA side effects and ordering through documented custom-call or graph-token mechanisms.
6. Use a common conformance suite containing:
   - descriptor layout tests;
   - publication-before-read tests;
   - delayed-reader reclamation tests;
   - concurrent writer/reader stress tests;
   - extreme-step retraction tests;
   - orthogonality residual and condition-number checks;
   - CUDA/XLA/Triton numerical tolerance tests;
   - negative tests proving that invalid memory orders or premature reclamation are rejected.

## Definitive arbitration

The strongest synthesis is not “Cayley is always stable,” “88 bytes implies safe barriers,” or “source compatibility implies silicon conformance.” Those are overclaims.

The defensible V1350 contract is:

- **Retraction:** Cayley is an optimized, conditionally accepted path; Householder QR or stable polar projection is the mandatory fallback/reference path. Extreme steps must produce either a verified Stiefel result or an explicit failure.
- **Descriptor synchronization:** release publication plus acquire consumption guarantees initialization visibility; RCU/QSBR grace periods guarantee lifetime safety. Neither property follows from descriptor size alone.
- **Conformance:** CUDA, XLA, Triton, C++20, and Rust require separately specified mappings for arithmetic, ABI, ordering, and lifetime. Conformance is established only by a versioned cross-platform test suite, not by syntactic portability.
- **Exact guarantee:** no silent invariant violation, no read of partially initialized snapshots, no reclamation while a protected reader may still hold a reference, and no claim of bitwise or memory-model equivalence beyond what each backend explicitly supports.