# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 70

The six Tribunal findings cannot be independently compared because their actual reports, definitions of the **V1350 kernels**, and the **88-byte PMTP layout** were not provided. The available evidence supports a conditional arbitration: **no method can be guaranteed stable for arbitrary \(\lvert\text{step}\rvert \ge 10^{10}\) without scaling, conditioning checks, and a fallback; acquire/release is necessary but not sufficient for RCU/QSBR snapshot isolation; and “multi-silicon conformance” must be established by executable conformance tests rather than inferred from source-level similarity.**

## 1. Stiefel retraction under extreme steps

Let \(X \in \mathrm{St}(n,p)\), let \(\Xi\) be a tangent update, and define \(Z=X+\Xi\). The standard candidates are:

\[
R_{\mathrm{polar}}(Z)=Z(Z^\top Z)^{-1/2},
\]

\[
R_{\mathrm{QR}}(Z)=\operatorname{qf}(Z),
\]

and a Cayley update of the form

\[
X_{+}=\left(I-\frac{\alpha}{2}A\right)^{-1}
       \left(I+\frac{\alpha}{2}A\right)X,
\]

where \(A^\top=-A\) is constructed from \(X\) and the tangent direction.

The mathematically defensible arbitration is:

- **Cayley is structurally attractive** because the exact transform is orthogonal in exact arithmetic: if \(A\) is skew-symmetric and the inverse exists, then the Cayley factor preserves orthogonality. It also avoids explicitly forming \(Z^\top Z\).
- **Cayley is not unconditionally stable for extreme steps.** For \(\alpha\) near \(10^{10}\), the linear solve can become badly scaled, the skew-symmetric construction can overflow or lose relative accuracy, and an approximate solve can destroy orthogonality. “Exact orthogonality in exact arithmetic” is not an implementation guarantee.
- **Polar retraction has the strongest geometric projection interpretation.** It is the Frobenius-nearest orthonormal factor when \(Z\) has full column rank. Its numerical quality depends on the conditioning and singular-value separation of \(Z\); it should be computed with a stable SVD or carefully implemented spectral method, not by naïvely forming normal equations.
- **Householder QR is generally the preferred robust fallback** for a badly scaled \(Z\), provided rank deficiency is detected and sign conventions are deterministic. Householder QR avoids the squaring of the condition number caused by \(Z^\top Z\), although it is not immune to overflow, underflow, or rank-revealing failures.

The available Stiefel literature describes polar and QR retractions with the formulas above and compares their computational costs; it does not establish a universal theorem that Cayley dominates either method at arbitrarily large steps.[2] Recent conditioning results likewise indicate that retraction stability depends on conditioning, rather than solely on the retraction label.[15]

### Definitive kernel guarantee

The SOTA design should be a **scaled adaptive retraction**, not an unconditional Cayley kernel:

1. Compute a safe scale \(s\) using a norm estimate, exponent-range checks, and finite-value checks.
2. Apply the Cayley transform to the scaled update only when the associated solve is well-conditioned.
3. Verify
   \[
   \|X_{+}^{\top}X_{+}-I\| \le \tau_{\mathrm{orth}}
   \]
   and verify finite outputs.
4. Fall back to Householder QR, or to a stable polar/SVD path when the application requires the nearest-point property.
5. If \(Z\) is rank deficient or numerically singular, return a defined failure/status code or use a documented rank-revealing policy; do not silently claim a valid Stiefel retraction.

Thus, for \(\lvert\text{step}\rvert \ge 10^{10}\), the exact guarantee is **bounded-output, finite-result, and orthogonality-within-tolerance conditional on successful scaling and validation**—not unconditional bitwise stability or unconditional success.

A useful hierarchy is:

\[
\boxed{\text{scaled Cayley fast path}
\;\rightarrow\;
\text{Householder QR fallback}
\;\rightarrow\;
\text{SVD/polar exceptional path}.}
\]

The implementation should report which path was taken.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering establishes publication ordering only when used on the correct atomic synchronization object. In C++, a release store followed by an acquire load that reads from that release establishes a synchronizes-with relationship.[6] RCU verification work similarly identifies release/acquire ordering as ensuring that object initialization precedes reader access, and that pre-quiescent-state reader operations complete before reclamation.[1]

For an 88-byte descriptor, the architectural rule should be:

- The descriptor itself is **immutable after publication**, or is versioned through an atomic publication mechanism.
- The writer initializes all 88 bytes and associated payload before a **release publication** of the descriptor pointer, index, or generation.
- Readers perform an **acquire load** of that publication field before dereferencing the descriptor.
- Readers enter the RCU read-side critical section before taking the snapshot and leave it only after the final descriptor access.
- Reclamation occurs only after the RCU/QSBR grace-period condition proves that every pre-existing reader has passed through a quiescent state.
- A descriptor update uses copy-publish, not in-place mutation visible to readers.

Acquire/release alone does **not** provide snapshot isolation. It orders initialization and publication; it does not prevent a writer from mutating fields in place while a reader is examining them, nor does it by itself guarantee that reclamation is delayed until all readers are finished. QSBR documentation and implementations explicitly rely on readers reporting quiescent states, while low-level QSBR guidance calls for acquire loads at the relevant observation points.[3][12]

The robust descriptor protocol is therefore:

\[
\text{initialize}
\;\rightarrow\;
\text{release-publish}
\;\rightarrow\;
\text{acquire-observe}
\;\rightarrow\;
\text{read under RCU/QSBR}
\;\rightarrow\;
\text{grace period}
\;\rightarrow\;
\text{reclaim}.
\]

### Exact memory-model guarantee

The guarantee should be stated narrowly:

> If publication is a release operation, the reader observes the corresponding publication through an acquire operation, the descriptor is immutable thereafter, and reclamation waits for a completed RCU/QSBR grace period, then the reader observes a fully initialized, lifetime-valid descriptor snapshot.

It does **not** guarantee:

- atomicity of an arbitrary 88-byte load;
- consistency of an in-place mutable 88-byte object;
- multi-copy atomicity across all devices;
- ordering between unrelated publication variables;
- safe reclamation without reader registration and quiescent-state reporting.

If the descriptor must be mutable, use immutable generations and an atomic pointer/version publication field. A sequence counter can detect concurrent modification, but it must be paired with a lifetime-safe reclamation mechanism; it is not a replacement for RCU/QSBR.

The PMTP ABI should also specify alignment, endianness, padding, ownership, lifetime, versioning, and whether the 88 bytes are host-only, device-visible, or transported across address spaces. “88 bytes” alone is not a sufficient ABI contract.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single common execution or memory model across these environments:

- **C++20 and Rust** provide language-level atomic and aliasing rules, but their guarantees apply to objects and operations expressed within those language models.
- **CUDA** has distinct host/device execution, scopes, synchronization primitives, and compiler restrictions. CUDA’s C++ support is conditional on host and device implementation requirements.[13]
- **Triton** expresses GPU kernels through its own compiler and memory-operation semantics; source-level resemblance to C++ does not establish equivalent ordering or numerical behavior.
- **XLA** is an optimizing compiler and intermediate representation. Operations may be fused, reordered, replicated, or lowered differently unless the relevant side effects and synchronization are explicitly represented.

Consequently, the definitive conformance target must be **behavioral**, not textual. Each backend should satisfy the same abstract contract:

### Numerical conformance

For identical inputs, dimensions, precision mode, and tolerance policy:

\[
\|X^\top X-I\| \le \tau_{\mathrm{orth}},
\]

the output is finite, and the selected retraction path is reported consistently. Exact bitwise equality should not be required across CUDA, XLA, Triton, C++20, and Rust unless all use identical arithmetic, reduction order, compiler settings, and math libraries.

### Memory conformance

For every publication/read test:

1. Initialize a descriptor with a recognizable pattern.
2. Publish it with release semantics.
3. Load it with acquire semantics.
4. Verify that no reader observes a partially initialized descriptor.
5. Retire and reclaim only after the specified QSBR/RCU grace period.
6. Run stress tests with delayed readers, preemption, migration, and concurrent writers.

The test must include negative controls showing that relaxed publication or premature reclamation can fail; otherwise the test does not validate the claimed guarantee.

### ABI conformance

All implementations must agree on:

- exactly 88 bytes;
- alignment;
- field offsets;
- padding;
- integer widths and signedness;
- byte order;
- pointer representation policy;
- version and feature bits;
- serialization/deserialization behavior.

The canonical check is a compile-time and runtime layout manifest. C++ and Rust should assert size and offsets; CUDA and Triton should use an explicitly defined packed logical representation rather than assuming host ABI layout; XLA should receive fields through an explicit tuple or byte-buffer schema.

### Cross-backend conformance matrix

A valid SOTA release should test at least:

- CPU reference implementation;
- C++20 implementation;
- Rust implementation;
- CUDA implementation;
- Triton implementation;
- XLA lowering;
- multiple GPU architectures and driver/toolchain versions;
- extreme-step numerical cases;
- RCU/QSBR publication and reclamation races;
- misalignment, endian, version, and malformed-descriptor cases.

Passing compilation is not conformance. The acceptance criterion is equivalence to the abstract contract under documented tolerances and memory-model assumptions.

## Arbitration outcome

The mathematically strongest synthesis is:

\[
\boxed{
\text{validated scaled Cayley}
+
\text{Householder QR fallback}
+
\text{SVD/polar exceptional path}
+
\text{immutable release/acquire publication}
+
\text{RCU/QSBR grace-period reclamation}
+
\text{executable cross-backend conformance}.
}
\]

The following stronger claims should be rejected unless the six Tribunal reports contain formal proofs and reproducible measurements:

- “Cayley is always more stable than QR or polar for \(\lvert\text{step}\rvert\ge10^{10}\).”
- “Acquire/release alone guarantees 88-byte snapshot isolation.”
- “Identical source code guarantees CUDA/XLA/Triton/C++20/Rust conformance.”
- “An 88-byte descriptor is automatically atomically readable.”
- “A successful kernel launch proves numerical or memory-model correctness.”

The exact architectural guarantees are therefore conditional and compositional: **validated numerical orthogonality, lifetime-safe immutable snapshots, explicitly scoped memory ordering, fixed ABI layout, and test-demonstrated backend equivalence**.