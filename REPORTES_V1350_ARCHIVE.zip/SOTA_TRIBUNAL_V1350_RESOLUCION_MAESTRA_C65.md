# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 65

No verifiable public record of **POLYDIM V1350**, its six kernels, or the six Tribunal-model reports was found in the available material. Therefore, a definitive arbitration of model-specific findings would be fabricated. The technically defensible SOTA synthesis is the following conditional architecture.

## 1. Extreme-step Stiefel retraction

For \(X \in \mathrm{St}(n,p)\), a Cayley update is typically expressed as

\[
Y(\alpha)=(I-\alpha W)^{-1}(I+\alpha W)X,
\qquad W^{T}=-W.
\]

In exact arithmetic, \(I-\alpha W\) is nonsingular for real \(\alpha\), because the eigenvalues of a real skew-symmetric \(W\) are purely imaginary. The resulting transform is orthogonal, so the Cayley map preserves \(Y^{T}Y=I\) mathematically.

That does **not** imply numerical stability for \(|\alpha|\ge 10^{10}\). The solve can become poorly scaled, overflow can occur in forming \(\alpha W\), and finite-precision residuals can dominate. Thus:

- **Cayley:** exact manifold preservation in exact arithmetic; not an unconditional finite-precision guarantee under extreme steps.
- **Polar:** \(Y=(X+\Delta)(I+\Delta^{T}\Delta)^{-1/2}\); usually the strongest choice for orthogonality restoration, provided the Gram computation and matrix inverse square root are stable.
- **Householder QR:** generally the preferred robust implementation for finite precision, especially with blocked Householder reflectors and column sign normalization. It avoids explicitly forming a normal-equation inverse and has strong backward-stability properties.
- **Classical Gram–Schmidt or unpivoted ad hoc QR:** not an acceptable extreme-step baseline.

The mathematically superior arbitration is therefore **not “Cayley always wins.”** It is a two-path design:

1. Use a scaled Cayley step only when a conditioning and overflow test passes.
2. Otherwise compute a Householder QR or high-quality polar retraction.
3. Verify

\[
\|Y^{T}Y-I\| \le \tau_{\mathrm{orth}}
\]

and reject, rescale, or recompute if the condition fails.

A hard guarantee for \(|\alpha|\ge 10^{10}\) requires explicit assumptions on matrix norms, floating-point format, scaling, solver accuracy, and overflow handling. Without those assumptions, no method can honestly promise bounded orthogonality error.

The available literature supports the distinction: QR and polar retractions are standard alternatives, while Cayley is a valid Stiefel retraction but requires care in its implementation and conditioning.[1][2][3]

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An **88-byte size alone provides no memory-ordering guarantee**. Correct snapshot isolation depends on the publication protocol, lifetime reclamation, and the language/runtime memory model.

The minimum sound protocol is:

```text
writer:
    initialize all immutable descriptor fields
    publish descriptor pointer/version with release semantics
    wait for the relevant grace-period condition before reclamation

reader:
    enter RCU/QSBR read-side critical section
    load pointer/version with acquire semantics
    read immutable fields
    leave read-side critical section
```

The guarantees should be stated precisely:

- A **release publication** synchronizes with a matching **acquire observation** of the published pointer or generation.
- The acquire reader observes the descriptor’s prior initialization, subject to the platform memory model.
- QSBR/RCU prevents reclamation only after every pre-existing reader has passed through a quiescent state or otherwise reported completion.
- Acquire/release does **not**, by itself, prevent reclamation races.
- It does **not** make mutable fields safe after publication.
- It does **not** provide a global total order equivalent to sequential consistency.
- It does **not** automatically extend across CUDA device memory, host memory, XLA execution, or foreign-language FFI boundaries.

A robust descriptor should therefore contain or reference:

- an immutable payload;
- an atomically published pointer or generation;
- a version/epoch suitable for validation;
- explicit ownership or reclamation metadata;
- alignment and padding rules;
- a defined endianness and ABI layout.

The exact 88-byte ABI must be specified by offsets, alignment, field widths, and representation—not merely by `sizeof`. In C++20, use atomics and `std::atomic_ref` only where alignment and lifetime requirements are satisfied. In Rust, use atomics, `UnsafeCell`, and lifetime/ownership rules explicitly; `unsafe` code must establish the same publication and reclamation proof.

The architectural guarantee should be:

\[
\text{Acquire(read)} \;\land\; \text{Release(publish)}
\;\Longrightarrow\;
\text{initialized immutable state is visible}
\]

and separately:

\[
\text{all readers quiescent}
\;\Longrightarrow\;
\text{safe reclamation}.
\]

Those are distinct obligations and must not be conflated.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no automatic “multi-silicon conformance” implied by source-level compatibility. The five environments expose materially different execution and memory models:

- **C++20 and Rust:** host-language object, atomic, aliasing, lifetime, and ABI semantics.
- **CUDA:** separate host/device address spaces, CUDA memory scopes, stream ordering, fences, and GPU-specific atomics.
- **Triton:** compiler-managed GPU kernels with constraints on supported atomics, layouts, barriers, and backend lowering.
- **XLA:** an optimizing graph/compiler system whose operation ordering and buffer lifetime may differ from imperative host code.

Consequently, the specification must define a **portable semantic core**, then provide backend-specific implementations. The portable core should require:

1. identical descriptor offsets, widths, alignment, and serialization;
2. identical numerical tolerances and NaN/Inf behavior;
3. explicit synchronization edges;
4. no reliance on undocumented scheduling;
5. no host-pointer dereference from device code;
6. no assumption that a host RCU grace period covers device work;
7. explicit completion signaling before device-visible resources are reclaimed;
8. deterministic fallback behavior for unsupported atomics or barriers.

For cross-device reclamation, the safe sequence is conceptually:

\[
\text{publish}
\rightarrow
\text{launch/use}
\rightarrow
\text{device completion}
\rightarrow
\text{host/device visibility fence}
\rightarrow
\text{RCU/QSBR grace period}
\rightarrow
\text{reclaim}.
\]

A host-side quiescent state occurring before GPU completion is not evidence that the GPU has stopped reading the descriptor.

## Definitive arbitration

The strongest defensible V1350 contract is:

- **Numerics:** Householder QR is the default extreme-step stabilization path; polar is an alternative when its inverse-square-root computation is controlled; Cayley is an optimized path with mandatory scaling, conditioning checks, and postcondition verification.
- **Memory:** the 88-byte descriptor is immutable after release publication; acquire/release establishes initialization visibility, while RCU/QSBR plus device completion establishes reclamation safety.
- **Portability:** conformance is semantic, not implementation-identical. Every backend must pass ABI, numerical, ordering, lifetime, and reclamation litmus tests.
- **Guarantee boundary:** exact orthogonality, race freedom, and cross-silicon equivalence are guaranteed only under explicitly stated precision, atomic-scope, completion, and reclamation assumptions.

Without the six Tribunal reports and the V1350 kernel specifications, no model-by-model winner or exact kernel-specific guarantee can be established. The claims above are the maximal mathematically justified synthesis supported by the available evidence.