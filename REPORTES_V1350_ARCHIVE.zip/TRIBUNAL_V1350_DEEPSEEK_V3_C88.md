# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 88)

# POLYDIM V1350 — High Tribunal Audit, Cycle 88

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods
**Verdict class:** *Conditional Pass with Mandatory Remediations* (3 Critical, 5 Major, 7 Minor)

---

## 0. Preliminary: What the Tribunal Can and Cannot Certify

The Tribunal notes at the outset that it is auditing **specifications and claimed invariants**, not the artifacts themselves. Where a claim is not falsifiable from the description (e.g., "12/12 physical conformance checks"), the Tribunal records it as **UNVERIFIED** and demands a reproducible harness. All findings below are stated as *conditional* on the stated design.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major, version_minor | `HH` | 4 |
| flags_a, flags_b, flags_c | `QQQ` | 24 |
| shape_0, shape_1 | `QQ` | 16 |
| dtype, rank | `BB` | 2 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

**Verdict:** Structurally sound. **But two hazards:**

- **(M-1) Endianness.** `struct` defaults to native byte order. Cross-silicon (x86 ↔ ARM ↔ TPU host) PMTP exchange requires explicit `'<'` or `'>'`. Without it, the 88-byte contract is *not* portable. **Mandatory:** pin to `'<'` (little-endian) and document.
- **(M-2) Alignment.** `QQQ` at offset 8 is 8-aligned; `4Q` at offset 56 is 8-aligned. Good. But `BB` at offset 48 followed by `6x` means the reserved block starts at 56 — fine. **No misalignment.** Pass.

### 1.2 `HardwareProbe` multi-silicon

The probe must not *fail closed* on unknown silicon. Rule 27 (Silicon Contract) requires that absence of a vendor SDK degrade to a **portable fallback**, not a hard error. Demand: probe returns a capability bitmask, and the orchestrator selects the *highest common denominator*, not the *vendor-preferred* path.

### 1.3 12/12 physical conformance checks

**UNVERIFIED.** The Tribunal demands the 12 checks be enumerated with pass/fail predicates and a fuzz harness over the 88-byte space (2^704 is intractable; sample the 2^16 boundary cases around field transitions).

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška gives a **forward error bound**:

$$
|\hat{s} - s| \le \big(2u + O(nu^2)\big)\sum_{i=1}^{n} |x_i y_i| + O(u^2)|s|
$$

where $u = 2^{-53}$ for FP64. The **effective condition number** of the compensated dot is

$$
\kappa_{\text{Neumaier}} = \frac{\sum |x_i y_i|}{|s|} \quad\text{(not the classical } \kappa = \|x\|\|y\|/|s|\text{)}
$$

**Critical finding (C-1):** When $s \to 0$ (catastrophic cancellation), $\kappa_{\text{Neumaier}} \to \infty$ **regardless of compensation**. Compensation buys you a factor of $u$, not a factor of $\kappa$. For POLYDIM's Stiefel retraction, this manifests when the tangent vector is nearly orthogonal to the gradient — a *generic* situation near convergence.

**Remediation:** Detect $\kappa_{\text{Neumaier}} > 1/u^{1/2} \approx 10^8$ and escalate to **double-double (Dekker/Knuth) accumulation** or exact 2Sum chains. Do not silently return the compensated result.

### 2.2 Subnormal audits at $-12, -14$

These are exponents, i.e. $\sim 2^{-12}, 2^{-14}$ — **not** subnormal in FP64 (subnormal threshold is $2^{-1022}$). The Tribunal suspects these are **FP32 subnormal thresholds** ($2^{-126}$) or **FP16** ($2^{-14}$). **Ambiguity flagged (M-3):** the audit must state the format. If FP16, then $-14$ is exactly the subnormal boundary and $-12$ is normal — the "audit" is testing two different regimes and must not be conflated.

### 2.3 AVX-512 + OpenMP

- **Denormal-as-zero (DAZ) / Flush-to-zero (FTZ):** AVX-512 respects MXCSR. If any translation unit sets FTZ, the subnormal audit is **void**. Demand: `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)` at kernel entry and a runtime assertion.
- **OpenMP reduction:** `reduction(+:acc)` is **not** Neumaier-safe — the compiler may reassociate. Demand explicit `#pragma omp parallel for` with per-thread Neumaier accumulators and a deterministic tree merge.

### 2.4 Zero-copy PMTP validation

Zero-copy implies the 88-byte descriptor is read directly from shared memory. **Hazard (M-4):** TOCTOU — a malicious peer can mutate the descriptor between validation and use. Demand: validate into a **stack-local copy**, then use the copy.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

**This is a category error (C-2).** `panic=unwind` is *not* a safety barrier — it is the *opposite*. Unwinding across an `extern "C"` boundary is **undefined behavior** in Rust (the ABI does not define unwind semantics for C). The correct barrier is:

```rust
#[no_mangle]
pub extern "C" fn entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(v) => v,
        Err(_) => ERR_PANIC,  // never unwind across FFI
    }
}
```

**Mandatory remediation:** every `extern "C"` entry point must wrap in `catch_unwind`, and the crate should be built with `panic=abort` for the FFI-facing binary *unless* `catch_unwind` is present at every boundary. The current claim is **inverted**.

### 3.2 Safe SIMD

Rust 2021 `std::simd` is nightly-only. If the kernel uses `core::arch::x86_64::*`, those are `unsafe`. "Safe SIMD" is therefore either (a) a nightly feature, or (b) a misnomer. **Flag (M-5):** state the toolchain and the `unsafe` surface area.

### 3.3 Packed 88-byte descriptor

Rust `#[repr(C, packed)]` on an 88-byte struct is fine, but **taking a reference to a packed field is UB** if the field is unaligned. Demand: `#[repr(C)]` with explicit `_pad: [u8; 6]` and `align(8)`, or use `zerocopy`/`bytemuck` with `Pod` derives. **Do not** use `packed` + field references.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in $\mathbb{R}^{2K \times 2K}$

The Cayley retraction is

$$
R_X(\xi) = \left(I - \tfrac{1}{2}W\right)^{-1}\left(I + \tfrac{1}{2}W\right)X, \quad W = \xi X^\top - X \xi^\top
$$

**Asymptotic condition number (C-3):** as $\|\xi\| \to \infty$, $W$ grows, and $\|(I - W/2)^{-1}\| \to \infty$ when an eigenvalue of $W$ approaches $2$. The Cayley transform has a **pole at eigenvalue 2**. For Stiefel optimization this is normally avoided by trust-region damping, but the spec does not mention it.

**Demand:** prove $\|\xi\|$ is bounded by the trust region, or replace Cayley with a **QR-based retraction** which has no pole.

### 4.2 Globally scaled Woodbury solve $(M/\text{scale})\,W = (\text{step}/\text{scale})\,B$

The scaling is designed to keep the RHS in a benign exponent range. **But:** if `scale` is chosen as $\|M\|_\infty$ and `step` is $10^{10}$, then `step/scale` can still overflow if $\|M\|$ is small. **Demand:** the scaling must be **two-sided** (scale both $M$ and $B$ by the same factor) and the factor must be a power of 2 to avoid rounding. The current formulation scales only the LHS ratio — **asymmetric scaling is a bug (M-6)**.

### 4.3 cuSOLVER `DnDsyevd`

`Dsyevd` is divide-and-conquer; it is **not deterministic** across runs on some architectures (workspace-dependent pivoting). For a "SOTA audit" this matters: reproducibility claims must be qualified. **Flag (m-1).**

### 4.4 CUDA Graphs

Graphs capture a fixed topology. If the Woodbury solve has **data-dependent branching** (e.g., early exit on convergence), graph capture will either fail or silently fix the branch. **Demand:** prove the kernel is branch-free w.r.t. captured nodes, or use conditional nodes (CUDA 12.3+).

---

## TARGET 5 — `kernel_xla_v1350.py`

### 5.1 Continuous Lyapunov solve in HBM, pure FP64

The Lyapunov equation $AX + XA^\top = -Q$ via Bartels–Stewart has condition number

$$
\kappa_{\text{Lyap}} \approx \frac{\|A\|_F^2}{\lambda_{\min}(\text{sep}(A, -A^\top))}
$$

where $\text{sep}$ is the separation of the spectra. **As $\text{sep} \to 0$** (A nearly has eigenvalues symmetric about the imaginary axis), $\kappa \to \infty$. **Demand:** the kernel must compute or bound `sep` and refuse to solve when $\text{sep} < \sqrt{u}\|A\|$.

### 5.2 Pure FP64 on TPU

**Critical (C-4):** Google TPUs (v4/v5) have **limited FP64 throughput** — often 1/32