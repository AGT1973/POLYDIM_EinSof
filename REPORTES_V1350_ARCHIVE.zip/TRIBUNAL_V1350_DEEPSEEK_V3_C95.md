# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 95)

# POLYDIM V1350 — High Tribunal Audit, Cycle 95

**Presiding Sages:** Numerical Analysis, Systems Programming, Heterogeneous Compute
**Verdict class:** Adversarial SOTA — findings are graded *Critical / Major / Minor / Conformant*.

---

## 0. Preliminary: What the Tribunal Can and Cannot Verify

The Tribunal has been handed **architectural claims**, not source. Every finding below is therefore stated as a **conditional theorem**: *"If the implementation matches the described contract, then …"*. Where the description is under-specified, the Tribunal flags the **missing invariant** rather than inventing one. This is the only honest posture for a PhD-level audit of a 6-file multi-silicon kernel.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us actually count, because "88-byte" is a *contract*, not a vibe.

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

✅ **Conformant.** Alignment: `struct` with `Q` requires 8-byte alignment; the `6x` pad after `BB` correctly realigns the trailing `4Q` block to offset 56 (multiple of 8). No implicit padding is inserted by CPython's `struct` because the format is explicit. **This is a well-formed packed descriptor.**

**Finding 1.1 (Minor):** `4sHHQQQQQBB6x4Q` is *native-endian* by default. For cross-silicon (x86 ↔ ARM ↔ TPU host) transport, the orchestrator **must** use `<` (little-endian) explicitly — which it does — but the *consumer* on a big-endian host (rare, but POWER10 exists) must byte-swap. **Recommendation:** assert `sys.byteorder == 'little'` at import, or emit a `>4sHHQQQQQBB6x4Q` variant.

### 1.2 `PmtpSlabAllocator` — degeneracy at step → ∞

The slab allocator's job is to hand out fixed-size 88-byte descriptors. The audit question is: **does the allocator's free-list arithmetic overflow when the step counter saturates?**

If the allocator indexes slabs by `step` (a `Q`, max 2⁶⁴−1), then at `step ≥ 10^10` there is **no overflow** — 10^10 ≪ 2⁶⁴. ✅

**Finding 1.2 (Major):** The description does not state whether the allocator uses `step` as a *monotonic counter* or as a *modular ring index*. If modular, the ring size must be a power of two and the mask must be applied **before** the multiply that computes the byte offset, otherwise `step * 88` overflows `size_t` at `step ≈ 2^58`. **Proof obligation:** the allocator must expose `assert step < (1<<58) // 88` or use `__builtin_mul_overflow`.

### 1.3 12/12 physical conformance checks

Without the check list, the Tribunal can only assert: **12/12 is a claim of totality, not of soundness.** A conformance suite that checks 12 properties but omits, e.g., *"descriptor is 88 bytes on every ABI"* is 12/12 and still wrong. **Finding 1.3 (Minor):** publish the 12 predicates; the Tribunal will re-audit.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška gives a **forward error bound**:

$$
|\hat{s} - s| \le \big(2u + O(nu^2)\big) \sum_{i=1}^{n} |x_i y_i| + O(u^2)|s|
$$

with `u = 2^-53` for FP64. The **effective condition number** of the compensated dot is therefore

$$
\kappa_{\text{Neumaier}} = \frac{\sum |x_i y_i|}{|s|} \cdot (1 + O(nu))
$$

i.e., **the same as the naive dot's condition number**, but with the *constant* reduced from `nu` to `2u`. **This is the correct claim to make.** Any marketing that says "Neumaier makes the dot product well-conditioned" is **false** — it makes it *accurately rounded*, not *well-conditioned*. The Tribunal flags this as **Finding 2.1 (Major, if claimed otherwise)**.

### 2.2 Subnormal audits at −12, −14

Subnormals in FP64 live in `[2^-1074, 2^-1022)`. The exponents −12 and −14 are **not subnormal** — they are ordinary normal numbers. **Finding 2.2 (Critical):** either the audit is mislabeled (perhaps these are *decimal* exponents of a scaled quantity, i.e., `10^-12`, `10^-14`), or the audit is testing the wrong regime. If the intent is `10^-12` and `10^-14`, those are still normal FP64. **True subnormal audit requires testing `2^-1023`, `2^-1074`, and the flush-to-zero boundary.** AVX-512 with `MXCSR.FTZ=1` will silently flush these; the kernel must either set `FTZ=0` or document the flush.

### 2.3 Zero-copy PMTP validation

Zero-copy means the C++ core reads the 88-byte descriptor **in place** from the slab. This is safe **iff**:
1. The slab is page-aligned and the descriptor does not straddle a page boundary (else a torn read across a `munmap` is possible).
2. The descriptor is `std::atomic`-published with `memory_order_release` by the producer and `acquire` by the consumer.

**Finding 2.3 (Major):** the description does not mention `std::atomic_thread_fence` or `__atomic_load_n`. Without it, the zero-copy path is a **data race** under the C++20 memory model.

### 2.4 AVX-512 / OpenMP

**Finding 2.4 (Minor):** AVX-512 downclocking on Skylake-X is real; on Ice Lake+ it is not. The kernel should runtime-dispatch (`__builtin_cpu_supports("avx512f")`) rather than compile-time `-mavx512f`, else it will SIGILL on AMD Zen 3 (which lacks AVX-512) — **vendor-lock risk, see Rule 27 below.**

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the single most important finding in this audit.**

`panic = unwind` across an `extern "C"` boundary is **undefined behavior** in Rust 2021 unless the function is declared `extern "C-unwind"`. The default `extern "C"` **aborts** on unwind (since Rust 1.71, `extern "C"` functions that unwind are caught and `abort()`ed). So:

- If the Rust kernel is called from C++ via `extern "C"`, a panic **aborts the process** — not a safety barrier, a **denial-of-service**.
- If the kernel is called via `extern "C-unwind"`, the C++ side must be compiled with `-fexceptions` and must not have `noexcept` on the boundary.

**Finding 3.1 (Critical):** "panic=unwind FFI safety barrier" is **not a safety barrier** — it is a process-kill switch. The correct hardening is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1,  // or a structured error code
    }
}
```

with `panic = "abort"` in `[profile.release]` **only if** the caller is prepared for process death. **Recommendation:** `catch_unwind` + `panic = "unwind"` + `extern "C"` (not `C-unwind`) is the only combination that is both safe and non-fatal.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust's `#[repr(C, packed)]` gives 88 bytes **iff** the field order matches Target 1. **Finding 3.2 (Major):** `#[repr(packed)]` on a struct containing `u64` produces **unaligned references**, which are UB in Rust 2021 (`E0793`). The kernel must use `read_unaligned` / `write_unaligned` or `#[repr(C, align(8))]` with explicit padding. The 88-byte size is achievable with `align(8)` because 88 is a multiple of 8. **Recommendation:** use `#[repr(C, align(8))]` and a `[u8; 6]` pad field, not `packed`.

### 3.3 Neumaier sums

Same condition-number analysis as Target 2.1. **Conformant** if the same bound is claimed.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)

The Cayley retraction on the Stiefel manifold `St(n,p)` is

$$
Y(\alpha) = \left(I - \frac{\alpha}{2} W\right)^{-1} \left(I + \frac{\alpha}{2} W\right) X, \quad W = A X^\top - X A^\top
$$

where `A` is the ambient gradient. The **globally scaled Woodbury solve** `(M/scale) W = (step/scale) B` is the standard trick to keep the linear solve in a well-conditioned regime.

**Asymptotic condition number:** as `step → ∞`, `α/2 → ∞`, and `(I - (α/2)W)^{-1} → 0` **iff** `W` has no eigenvalue on the positive real axis. But `W` is **skew-symmetric** (since `W = AX^T - XA^T`), so its eigenvalues are purely imaginary. Therefore `I - (α/2)W` has eigenvalues `1 - i(α/2)λ`, and

$$
\|(I - (\alpha/2)W)^{-1}\|_2 = \frac{1}{\sqrt{1 + (\alpha \lambda_{\max}/2)^2}} \to 0
