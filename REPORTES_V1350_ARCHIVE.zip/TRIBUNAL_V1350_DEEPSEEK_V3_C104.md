# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 104)

# POLYDIM V1350 — High Tribunal Audit, Cycle 104

**Presiding Sages:** Numerical Analysis, Systems/FFI, Heterogeneous Compute
**Verdict class:** Adversarial SOTA — findings are graded *Critical / Major / Minor / Conformant*.

A note on scope before we begin: the six artifacts are described to us by their *contracts* (descriptor layouts, retraction formulas, FFI barriers), not by their source. Where a claim is unverifiable from the contract alone, the Tribunal marks it **UNVERIFIED** rather than assuming correctness. This is the honest posture for an adversarial audit.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Layout claimed: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version | `H` | 2 | 4 |
| flags | `H` | 2 | 6 |
| dim0 | `Q` | 8 | 8 |
| dim1 | `Q` | 8 | 16 |
| stride0 | `Q` | 8 | 24 |
| stride1 | `Q` | 8 | 32 |
| nbytes | `Q` | 8 | 40 |
| dtype | `B` | 1 | 48 |
| rank | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| aux[4] | `4Q` | 32 | 56 |
| **total** | | **88** | |

**Arithmetic check:** 4+2+2+8·5+1+1+6+32 = 4+2+2+40+1+1+6+32 = **88**. ✅

**Alignment check (critical):** With `Q` (8-byte) fields, the struct must be 8-byte aligned. Offsets 8,16,24,32,40 are 8-aligned ✅. Offset 56 is 8-aligned ✅. But the *tail* `4Q` at offset 56 ends at 88 — 88 mod 8 = 0 ✅. **However**, the `6x` pad at offset 50–55 is *required* precisely because `dtype`+`rank` at 48–49 would otherwise misalign `aux` at 50. The layout is correct **only if** the compiler does not insert its own padding. In C++/Rust this requires `#[repr(C, align(8))]` / `__attribute__((packed, aligned(8)))` — **not** default `repr(C)` (which would pad to 96). **Finding M-1 (Major):** the descriptor is *not* self-describing about its packing; a single missing attribute silently breaks the 88-byte contract and every FFI boundary.

**Endianness:** `4s` magic + `Q` fields are host-endian. Cross-arch (x86 ↔ ARM ↔ TPU host) FFI will silently corrupt. **Finding M-2 (Major):** no endian tag in `flags`. Recommend reserving bit 15 of `flags` as `BIG_ENDIAN`.

### 0.2 Rule 22 — Zero 1D tokens in inter-agent communication

"Zero 1D tokens" is read here as: **no scalar/1-D payloads cross the agent boundary; all inter-agent messages are the 88-byte PMTP descriptor or a fixed-size batch thereof.** Audit:

- **T1 (orchestrator):** emits descriptors — conformant *if* the `aux[4]` slots are used for shape metadata rather than smuggled scalars. **UNVERIFIED** without source.
- **T2/T3 (C++/Rust):** FFI boundary must pass `*const PmtpTensorDescriptor` (pointer to 88-byte POD), not `(ptr, len)` tuples. A `(ptr, len)` pair is a 1-D token by the rule's spirit. **Finding M-3 (Major):** the contract text says "zero-copy PMTP validation" but does not forbid `(ptr,len)`; require explicit `static_assert(sizeof(...) == 88)` on both sides.
- **T4/T5/T6:** CUDA/XLA/Triton kernels receive descriptors via device pointers; the *host* side must marshal 88-byte structs, not Python tuples. **UNVERIFIED.**

**Rule 22 verdict:** *Conditionally conformant* — contingent on `static_assert`/`const_assert` at every FFI seam and a ban on `(ptr,len)` tuples.

### 0.3 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Lock risk |
|---|---|---|
| T1 orchestrator | none (probe) | **Conformant** if probe is runtime-dispatched |
| T2 C++ AVX-512 | Intel/AMD | **Major** — AVX-512 is not universal (Zen4 yes, Zen3 no, Apple no) |
| T3 Rust SIMD | portable via `std::simd`/`packed_simd` | **Conformant** if `target_feature` gated |
| T4 CUDA | NVIDIA-only | **Critical** — hard vendor lock |
| T5 XLA | Google TPU / AWS Trainium | **Critical** — dual lock, no third path |
| T6 Triton | AMD ROCm + NVIDIA | **Conformant** (dual-vendor) |

**Finding C-1 (Critical):** T4 and T5 individually violate Rule 27. The *architecture* survives only if T1's `HardwareProbe` can route to T2/T3/T6 when T4/T5 are absent. The probe must therefore expose a **capability matrix**, not a vendor enum. If `HardwareProbe` returns `"cuda"` vs `"xla"` as a scalar, Rule 27 is violated at the orchestrator level.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe
**Requirement:** probe must be *total* — for every (arch, driver, runtime) triple it returns a valid dispatch or a typed `Unsupported` error, never a silent fallback.

**Finding M-4 (Major):** "12/12 physical conformance checks" is a *count*, not a *specification*. A count is unfalsifiable. Demand the 12 checks be enumerated as a bitmask in `flags` (bits 0–11) so downstream agents can verify *which* checks passed, not just how many.

### 1.2 PmtpSlabAllocator
**Numerical degeneracy at step → ∞:** The allocator itself is size-driven, not step-driven, so no direct degeneracy. **But** if `aux[0]` encodes `step` as a `Q` (unsigned), then `step ≥ 10^10` is representable (max 2^64−1 ≈ 1.8·10^19) ✅. If `aux[0]` is reinterpreted as `f64` for the Woodbury scale, then `10^10` is fine but `10^308` overflows. **Finding m-1 (Minor):** document the `aux` slot semantics; do not overload.

### 1.3 88-byte descriptor conformance
See §0.1. **Finding M-1** applies.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

Neumaier's variant of Kahan:
```
s = 0; c = 0
for x,y: t = s + x*y
         if |s| >= |x*y|: c += (s - t) + x*y
         else:            c += (x*y - t) + s
         s = t
return s + c
```

**Theorem (Neumaier 1974):** for `n` terms with unit roundoff `u = 2^-53` (FP64),
```
|computed − exact| ≤ (2u + O(n u²)) · Σ|x_i y_i|
```
i.e. **relative error is O(u), independent of n** — the catastrophic cancellation of naive summation is eliminated.

**Degeneracy at step → ∞:** If `step` enters as a *scale* on the dot product, `|step| ≥ 10^10` multiplies every term. Neumaier is scale-invariant in *relative* error, so no degeneracy **provided** no intermediate overflows. With FP64 max ≈ 1.8·10^308, `step·x·y` overflows only if `|x·y| > 10^298`. **Finding M-5 (Major):** the kernel must pre-scale by `1/step` (as T4's Woodbury does) *before* the dot product, not after. Otherwise `step → ∞` is a silent `inf`.

**Degeneracy at step → 0 (subnormals):** The audit mentions subnormal checks at `-12, -14` (presumably exponents `2^-12`, `2^-14` — FP16 subnormal range). In FP64, subnormals begin at `2^-1022`. Neumaier's compensation term `c` can itself become subnormal and lose precision. **Finding M-6 (Major):** the `-12/-14` audit is *FP16-specific*; if the kernel runs FP64, the audit is mis-targeted. If it runs FP16, Neumaier in FP16 is nearly useless (u = 2^-11). **Demand:** state the working precision explicitly.

### 2.2 Zero-copy PMTP validation
**Finding M-7 (Major):** "zero-copy" + "validation" are in tension. Validation requires reading the descriptor; zero-copy requires not copying the payload. The kernel must validate the 88-byte header *in place* and then `mmap`/`cudaHostRegister` the payload. If validation copies the header to a local struct, that's a 88-byte copy — acceptable, but must be documented as *header-copy, payload-zero-copy*.

### 2.3 AVX-512 vendor lock
See §0.3, **Finding C-1**. Additionally: AVX-512 downclocking on Skylake-X is a *performance* degeneracy at high `step` (thermal throttling changes effective `u`? No — `u` is fixed; but throughput collapses). **Finding m-2 (Minor):** document the frequency-throttle regime.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier

**This is the single most dangerous claim in the audit.** `panic=unwind` across an FFI boundary is **undefined behavior** in Rust unless the panic is caught at the boundary. The correct pattern is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(desc: *const PmtpTensorDescriptor) -> i32 {
    let result = std::panic::catch_un