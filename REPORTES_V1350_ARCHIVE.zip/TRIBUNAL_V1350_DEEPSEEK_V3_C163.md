# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 163)

# POLYDIM V1350 — High Tribunal Audit, Cycle 163

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods
**Verdict class:** Adversarial SOTA — findings are graded **CERTIFIED / CONDITIONAL / REJECTED**.

A note on scope before we begin: the six artifacts are presented as *specifications* (descriptor layouts, kernel contracts, retraction formulas). Where source is not in evidence, the Tribunal audits the **stated contract** and flags any claim that cannot be discharged from the contract alone. We do not fabricate line numbers.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout `<4sHHQQQQQBB6x4Q`

Let us count bytes rigorously (native `struct` with `<` little-endian, no alignment padding):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major, version_minor | `HH` | 4 |
| flags, dtype | `BB` | 2 |
| n_rows, n_cols, ld, nnz | `QQQQ` | 32 |
| reserved_a, reserved_b, reserved_c | `QQQ` | 24 |
| pad | `6x` | 6 |
| tail | `4Q` | 32 |
| **Total** | | **104** |

**Finding 1.1 — REJECTED as stated.** The format string `<4sHHQQQQQBB6x4Q` yields **104 bytes**, not 88. To reach 88 the tail must be `2Q` (16 B) with `6x` padding, or the `QQQQQ` block must shrink. The "88-byte PMTP" invariant (Rule 22) is therefore **not discharged** by the declared format string. This is a hard conformance failure — the 12/12 physical checks cannot pass against a 104-byte struct unless the checks are counting something other than `sizeof`.

**Required remediation:** publish `struct.calcsize("<4sHHQQQQQBB6x4Q")` in CI and assert `== 88`. If the intent is 88, the canonical layout is `<4sHHQQQQQBB6x2Q` (4+4+2+32+24+6+16 = 88) — but then two reserved Q's are lost and the "4Q tail" claim in the spec is false.

### 1.2 `HardwareProbe` multi-silicon

- **Degeneracy at step→∞:** the probe itself is integer/bitfield; no FP hazard. But the probe's *reported* `peak_flops` feeds downstream step scaling. If `peak_flops` is queried as `int` and divided into `step`, integer truncation at `step ≥ 10^10` silently floors the effective step. **Recommendation:** carry `peak_flops` as `float64` and clamp `step/peak_flops` with `math.fma`-style compensated division.
- **Vendor-lock (Rule 27):** a probe that *enumerates* CUDA/ROCm/TPU/Trainium is compliant **iff** it exposes a neutral capability tuple (e.g., `(isa, vlen, sram_bytes, fp64_ratio)`) and does not require a vendor SDK to *construct*. If `HardwareProbe.__init__` imports `pynvml` unconditionally, that is a Rule 27 violation. **CONDITIONAL.**

### 1.3 `PmtpSlabAllocator`

- Slab alignment must be ≥ 64 B (AVX-512) and ≥ 128 B (cache-line pair on Zen4). If the allocator returns 88-byte records packed contiguously, **every record after the first is misaligned for SIMD loads**. This is the classic AoS-vs-SoA trap. **Recommendation:** either pad to 128 B (violates 88-byte rule) or store descriptors in a separate SoA array and keep the 88-byte record as a *wire* format only. The spec conflates wire format with in-memory layout — flag.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant is the correct choice over Kahan for non-monotone magnitude sequences. Error bound:

$$
|\hat{s} - s| \le \big(2u + O(u^2)\big)\sum_{i=1}^{n}|x_i y_i|, \quad u = 2^{-53}.
$$

This is **unconditional** (no cancellation assumption). Good.

### 2.2 Subnormal audit at −12, −14

Let `x = 2^{-12}`, `y = 2^{-14}`. Product `xy = 2^{-26}`, comfortably normal. The hazard is **not** the product but the *compensation term* `c` when the running sum is near `2^{-1022}`. If `c` underflows to subnormal, the Neumaier correction loses precision silently. **Required test:** feed `x_i = 2^{-540}`, `y_i = 2^{-540}` (product `2^{-1080}` → subnormal) and assert the compensated result matches `math.fsum` to ≤ 1 ulp of the *subnormal* grid. If the kernel flushes to zero (FTZ/DAZ set by `-ffast-math` or `_MM_SET_FLUSH_ZERO_MODE`), the audit **fails**. **Recommendation:** explicitly clear FTZ/DAZ in the kernel prologue and assert via `_mm_getcsr()`.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the descriptor's `ld` (leading dimension) to match the physical stride. If `ld` is validated only against `n_cols` and not against the *actual* `cudaMallocPitch`/`posix_memalign` stride, a malicious or buggy producer can alias rows. **FFI hardening:** validate `ld ≥ n_cols` **and** `ld % alignof(max_align_t) == 0` **and** `(uintptr_t)ptr % 64 == 0` before any AVX-512 load. Reject otherwise with a typed error, not `abort()`.

### 2.4 step→∞ / step→0

- `step ≥ 10^10`: if `step` is used as a scalar multiplier on `B` before the Woodbury solve, `step * B` can overflow `float64` when `‖B‖_∞ > 10^{298}`. Guard with `frexp`-based scaling.
- `step → 0`: subnormal `step` multiplied into `B` produces subnormal `step*B`; the subsequent `1/scale` division amplifies. **Recommendation:** normalize `step` to `[1, 2)` via `frexp` and carry the exponent separately (this is exactly what Target 4's `M/scale` trick is trying to do — see §4).

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the correct choice** and the Tribunal endorses it. `panic = abort` across an FFI boundary is UB-adjacent (unwinding into C++ is UB unless the C++ side is compiled with matching unwind tables). With `unwind`, the Rust side must still **catch** at the boundary:

```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> i32 {
    match std::panic::catch_unwind(AssertUnwindSafe(|| { /* ... */ })) {
        Ok(()) => 0,
        Err(_) => -1, // typed error, never unwind into C
    }
}
```

Without `catch_unwind`, `panic = unwind` is *worse* than `abort` because it silently unwinds into C++. **CONDITIONAL** pending evidence of `catch_unwind` at every `extern "C"` entry.

### 3.2 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` on an 88-byte struct is fine for wire format but **taking a reference to a packed field is UB** (misaligned reference). Any `&self.n_rows` on a packed struct is a compile error in recent rustc — good — but `unsafe { &raw const self.n_rows }` bypasses it. **Recommendation:** `#[repr(C)]` with explicit `[u8; 6]` padding and `align(8)`, and a separate `#[repr(C, packed)]` wire type with `read_unaligned` accessors. Do not conflate.

### 3.3 Safe SIMD

`std::simd` is still nightly-gated as of the 2021 edition target. If the crate claims "Rust 2021 Safe SIMD," it is either (a) using `core::arch` intrinsics inside `unsafe` blocks (not "safe SIMD"), or (b) requiring nightly (not "2021"). **Flag as marketing-vs-substance.** The safe claim is only defensible via `wide`/`pulp` crates, which are safe wrappers over `unsafe` intrinsics — acceptable, but the audit should record the `unsafe` surface area.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^{2K×2K}

The Cayley retraction is

$$
Y(\xi) = \left(I - \tfrac{1}{2}W(\xi)\right)^{-1}\left(I + \tfrac{1}{2}W(\xi)\right) X, \quad W = \xi X^\top - X \xi^\top,
$$

which is **orthogonality-preserving to machine precision** (it is a rational approximation of the exponential, and `Y^T Y = X^T X` exactly in exact arithmetic). The `cuSOLVER DnDsyevd` call is **wrong for this purpose** — `syevd` is a symmetric eigensolver; the Cayley retraction needs a **linear solve** (`getrf`/`getrs`) or, if you insist on the eigenroute, `gesvd`. Using `syevd` on `W` (which is skew-symmetric, not symmetric) is a **type error**. **REJECTED** unless the spec means `DnDsyevd` is used for a *different* subproblem (e.g., the Stiefel projection via `X(X^TX)^{-1/2}`). Clarify.

### 4.2 Globally scaled Woodbury solve `(M/scale) W = (step/scale) B`

This is the **correct** numerical hygiene. Let `scale = max(|step|, ‖M‖_F, 1)`. Then `M/scale` has unit-ish norm, `step/scale ∈ [-1, 1]`, and the Woodbury identity

$$
(M + \sigma U V^\top)^{-1} = M^{-1} - \sigma M^{-1}U(I + \sigma V^\top M^{-1}U)^{-1}V^\top M^{-