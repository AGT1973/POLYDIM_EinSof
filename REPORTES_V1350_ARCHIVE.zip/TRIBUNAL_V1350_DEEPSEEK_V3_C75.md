# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 75)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 75 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal treats each "TARGET" as a *claimed* artifact. Where the description is internally inconsistent (e.g., "88-byte descriptor" vs. the struct format string `<4sHHQQQQQBB6x4Q`), we flag the discrepancy rather than assume intent. All numerical claims are audited against IEEE-754 binary64, IEEE-754 binary32, and the stated silicon contracts.

---

## 0. Structural Pre-Audit — The 88-Byte Descriptor

The format string `<4sHHQQQQQBB6x4Q` decodes as:

| Field | Type | Bytes |
|---|---|---|
| tag | `4s` | 4 |
| a, b | `HH` | 4 |
| c,d,e,f,g | `QQQQQ` | 40 |
| h,i | `BB` | 2 |
| pad | `6x` | 6 |
| j,k,l,m | `4Q` | 32 |
| **Total** | | **88** |

✅ **Byte count is exactly 88.** Alignment under `<` (little-endian, no padding) is *packed*, so `sizeof == 88` holds on x86-64, aarch64, and CUDA host. **However:**

- **Endianness lock-in.** `<` forces little-endian. On big-endian hosts (IBM POWER, some s390x), the descriptor is *not* wire-compatible. Rule 27 (Silicon Contract) is therefore **violated at the byte level** unless a `>!` variant is specified.
- **`6x` pad is dead weight.** It exists only to hit 88. If the intent is cache-line alignment (64B) or two-line (128B), 88 is neither. **Recommendation:** either drop to 80B (natural) or pad to 128B (cache-line pair). 88 is a *magic number* with no architectural justification — a red flag for Rule 22 compliance.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe
Probing CPU/GPU/TPU/NPU at runtime is fine, but the audit demands:
- **Determinism of dispatch.** If probe order is nondeterministic (e.g., `os.environ` iteration), the same job can land on different silicon across runs → **non-reproducible numerics**. This violates the spirit of Rule 22 (deterministic inter-agent tokens).
- **Fallback semantics.** If AVX-512 is absent, does the orchestrator silently fall back to scalar? Silent fallback is a **numerical degeneracy vector**: scalar Neumaier vs. AVX-512 Neumaier can differ in the last ULP due to FMA contraction. Must be *explicitly* logged as a token.

### 1.2 PmtpSlabAllocator
- **Slab size must be a multiple of 88.** If not, the last descriptor straddles a page boundary → torn reads under concurrent FFI. Demand: `assert slab_bytes % 88 == 0`.
- **Alignment.** For AVX-512 zero-copy, slab base must be 64B-aligned; for CUDA `cudaHostAlloc`, 4KB-aligned. The 88B stride is *not* 64B-aligned, so consecutive descriptors land on misaligned cache lines. **This is a real performance and correctness hazard** for `_mm512_load_ps` (which requires 64B alignment). Either use `_mm512_loadu_ps` (slower) or pad stride to 128B.

### 1.3 12/12 Physical Conformance Checks
Without the checklist we cannot verify, but the Tribunal demands the 12 checks include at minimum:
1. `sizeof(descriptor) == 88` on host and device
2. Endianness match
3. Alignment of slab base
4. Stride divisibility
5. No aliasing between input/output slabs
6. Subnormal preservation flag (FTZ/DAZ off)
7. NaN/Inf propagation policy
8. Rounding mode = RNE
9. FMA contraction policy (explicit)
10. Denormal flush policy per silicon
11. Thread-count determinism
12. Reproducibility hash of dispatch decision

If any of these is missing, **Rule 22 is not satisfied**.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier Compensated Dot Product — Asymptotic Analysis

Neumaier's algorithm:
```
s = 0; c = 0
for i: t = s + x_i*y_i
       if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
       else:                c += (x_i*y_i - t) + s
       s = t
return s + c
```

**Error bound (Ogita–Rump–Oishi):** for `n` terms,
```
|fl(dot) - dot| <= (n-1) * u * |dot| + O(u^2) * Σ|x_i y_i|
```
where `u = 2^-53`. This is **first-order accurate** — a *huge* improvement over naive `O(n·u)`, but **not exact**.

**Degeneracy at step → ∞ (|step| ≥ 10^10):**
- If `step` enters as a *scalar multiplier* on the dot product, `|dot|` scales linearly. The *relative* error is unchanged, but **overflow** becomes the killer: `|step| · |x_i y_i|` can exceed `DBL_MAX ≈ 1.8e308` when `|x_i y_i| > 1.8e298`. For `step = 1e10`, this requires `|x_i y_i| > 1.8e288` — unlikely for normalized inputs, but **not impossible** if inputs are unnormalized.
- **Recommendation:** pre-scale by `1/step` (Woodbury-style, as TARGET 4 does) and post-scale. This is the *only* numerically safe path for `|step| ≥ 1e10`.

**Degeneracy at step → 0 (subnormals):**
- The audit mentions "subnormal audits (-12, -14)". These are likely **exponent thresholds** (2^-12, 2^-14) — but binary64 subnormals begin at `2^-1022`. If the kernel is operating in **binary32** (AVX-512 `_ps`), subnormals begin at `2^-126`, and `2^-12`/`2^-14` are *normal* numbers. **The audit thresholds are mislabeled** unless the kernel is FP16 (subnormals at `2^-14`). This is a **critical inconsistency**.
- If `step → 0`, the compensated sum `s + c` can lose the compensation term to **absorption**: `|c| < u·|s|` → `s + c == s`. Neumaier's guarantee degrades to naive summation. **Demand:** explicit `if |c| < u*|s|: log_degraded()` token.

### 2.2 Zero-Copy PMTP Validation
- Zero-copy requires the descriptor to be **pinned** and **immutable** during kernel execution. If the orchestrator mutates the slab concurrently, the C++ kernel reads torn data. **Demand:** `mprotect(PROT_READ)` on the slab during kernel, or a seqlock.
- **FFI hardening:** the C++ side must validate `tag == expected` and `sizeof == 88` *before* dereferencing. A malformed descriptor from Python (e.g., a `bytes` object of length 87) will cause UB. **Recommendation:** `static_assert(sizeof(Descriptor) == 88)` plus a runtime `memcmp` of the tag.

### 2.3 OpenMP Determinism
`#pragma omp parallel for reduction(+:s,c)` is **not** deterministic across thread counts. Neumaier's compensation is *order-dependent*. **This is a Rule 22 violation** if the orchestrator expects bit-identical results across runs. **Fix:** fixed thread count, or Kahan-Babuška pairwise reduction with deterministic tree.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI Safety Barrier — **This is wrong.**

`panic=unwind` across an FFI boundary is **undefined behavior** unless the panic is caught at the boundary. Rust's `extern "C"` functions **abort** on unwind (since Rust 1.71, `extern "C"` is `nounwind` by default). If the kernel is `extern "C"` and panics, the process aborts — **not** a safety barrier, a **denial-of-service**.

**Correct pattern:**
```rust
#[no_mangle]
pub extern "C" fn kernel(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```
And the C++ caller must check the return code. **Demand:** the audit's claim that `panic=unwind` is a "safety barrier" is **rejected**.

### 3.2 Safe SIMD
Rust's `std::simd` is still nightly. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. **"Safe SIMD" is a misnomer** unless the kernel uses `wide` or `pulp` crates. Demand clarification.

### 3.3 Packed 88-byte Descriptor
Rust's `#[repr(C, packed)]` gives 88 bytes, but **packed structs cannot be referenced by reference** (`&packed.field` is UB for unaligned fields). The kernel must copy fields out. **Demand:** `#[repr(C)]` with explicit `_pad: [u8; 6]` and `#[repr(align(8))]` — this gives 88 bytes *and* safe field access.

### 3.4 Neumaier in Rust
Same asymptotic analysis as C++. Rust's `f64::mul_add` is **not** guaranteed to be fused unless `target_feature = "fma"` is enabled. **Demand:** explicit `#[target_feature(enable = "fma")]` or use `mul_add` with the `fma` feature.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley Retraction

For `Y ∈ St(n,p) = {Y : YᵀY = I_p}`, the Cayley retraction is:
```
Y(t) = (I - (t/2) A)^{-1} (I + (t/2) A) Y,   A = G Yᵀ - Y Gᵀ  (skew)
```
where `G` is the gradient. In `R^(2K × 2K)`, `A` is `2K × 2K` skew