# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 114)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 114 · Multi-File Adversarial SOTA Review

**Preliminary note on evidentiary basis.** The six artifacts are described by specification, not by source. I will audit the *stated* architecture with the rigor the Tribunal demands, but I must flag up front: several claims (12/12 physical conformance, "pure FP64" on TPU, "88-byte" descriptor with the given struct format) are **internally inconsistent** and I will call them out rather than launder them. Where I cannot verify, I will say so explicitly rather than fabricate line-level findings.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Struct layout audit: `<4sHHQQQQQBB6x4Q`

Let me actually compute this.

| Field | Type | Size (bytes) |
|---|---|---|
| `4s` | char[4] | 4 |
| `H` | uint16 | 2 |
| `H` | uint16 | 2 |
| `Q` | uint64 | 8 |
| `Q` | uint64 | 8 |
| `Q` | uint64 | 8 |
| `Q` | uint64 | 8 |
| `Q` | uint64 | 8 |
| `B` | uint8 | 1 |
| `B` | uint8 | 1 |
| `6x` | pad | 6 |
| `4Q` | uint64[4] | 32 |

**Sum:** 4+2+2+8·5+1+1+6+32 = **88 bytes**. ✅

**Alignment check (native, no `<`):** With `<` (little-endian, standard size, no alignment), the struct is packed. Without `<`, `Q` would force 8-byte alignment and the struct would be 96 bytes. **The `<` prefix is load-bearing.** Any FFI boundary that re-declares this struct in C/Rust/CUDA *must* use `#pragma pack(1)` / `#[repr(C, packed)]` / `__attribute__((packed))`. This is the single most likely source of silent corruption in the whole stack.

**Recommendation:** Add a static assertion in every language:
```c
_Static_assert(sizeof(pmtp_desc_t) == 88, "PMTP descriptor drift");
```
```rust
const _: () = assert!(std::mem::size_of::<PmtpTensorDescriptor>() == 88);
```

### 1.2 Numerical degeneracy at step → ∞ / step → 0

The orchestrator itself is a dispatcher, but it owns the **step-scaling policy**. Two failure modes:

**(a) step → ∞ (|step| ≥ 10¹⁰).** If the orchestrator passes raw `step` into the Woodbury solve `(M/scale) W = (step/scale) B`, then `step/scale` must be computed in FP64 *before* any FP32 cast. If any backend receives `step` as FP32, `10¹⁰` is representable but `step²` (used in Cayley denominators `(I + (θ/2)A)⁻¹(I − (θ/2)A)`) overflows at `θ > ~1.8×10¹⁹`. **Hard requirement:** the orchestrator must clamp `θ = step · lr` to `|θ| ≤ θ_max` where `θ_max` is derived from the Stiefel tangent norm, not a magic constant.

**(b) step → 0 (subnormal).** FP64 subnormals begin at `2⁻¹⁰²² ≈ 2.2×10⁻³⁰⁸`. If `step` is legitimately that small (e.g., late-stage fine-tuning), then `step/scale` may underflow to zero, silently zeroing the update. The orchestrator must detect `|step| < 2⁻¹⁰⁰⁰` and either promote to a compensated representation or refuse the step.

### 1.3 Rule 22 compliance (Zero 1D tokens)

The 88-byte descriptor is a **fixed-width, self-describing token** — this is exactly what Rule 22 demands. ✅ **Provided** the orchestrator never emits variable-length JSON/msgpack between agents. If any inter-agent path serializes a Python `dict`, Rule 22 is violated. **Audit action:** grep for `json.dumps`, `pickle`, `msgpack` on the inter-agent bus.

### 1.4 Rule 27 (Silicon Contract)

`HardwareProbe` with multi-silicon dispatch is compliant **iff** the probe result is a *capability bitmask*, not a vendor string. If the orchestrator branches on `"cuda" in device_name`, that is vendor-lock. It must branch on `has_avx512`, `has_tensor_core_fp64`, `has_lyapunov_hw`, etc.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — condition number

Neumaier's algorithm gives a **faithfully rounded** result: relative error `≤ u + O(u²)` where `u = 2⁻⁵³`. For a dot product of length `n` with condition number `κ = Σ|xᵢyᵢ| / |Σxᵢyᵢ|`, the *uncompensated* error is `O(n·u·κ)`. Neumaier reduces this to `O(u·κ)` — **independent of n**. This is the correct choice for the PMTP inner products.

**Asymptotic condition number for the Stiefel projection:** For `X ∈ St(n,p)`, the projection `P_X = I − XXᵀ` has `κ₂(P_X) = 1` (it's an orthogonal projector). The *tangent-space* solve, however, involves `(I − XXᵀ) A`, whose condition number is `κ(A)`. **The compensated dot product does not help if `κ(A) > 1/u`.** The kernel must expose `κ(A)` estimate and refuse steps when `κ(A) · u > 10⁻³`.

### 2.2 Subnormal audits at −12, −14

These are almost certainly **exponent thresholds** (i.e., `2⁻¹²`, `2⁻¹⁴` as *scaling* exponents, not subnormal boundaries). If they are literal subnormal thresholds, they are wrong: FP64 subnormals start at `2⁻¹⁰²²`. **Clarification demanded.** If the intent is "flush-to-zero below 2⁻¹²", that is a *deliberate* precision loss and must be documented as such — it will break Neumaier's compensation guarantee.

### 2.3 AVX-512 + OpenMP

- **AVX-512 downclocking** on Skylake-X: the kernel must measure and report effective FLOPs/W, not peak. On Ice Lake / Sapphire Rapids this is mitigated.
- **OpenMP `#pragma omp simd reduction(+:sum)`** does **not** preserve Neumaier compensation order. The compensated sum must be done with an explicit two-accumulator pattern and `reduction` on *both* accumulators, or with a tree-reduction that preserves the compensation invariant. **This is a real bug class.**

### 2.4 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be **cache-line aligned** (64B) or at least 8B-aligned. 88 is not a multiple of 64. **Recommendation:** pad to 128 bytes for cache-line isolation, or accept false sharing. The "88-byte" constraint is a *wire format* constraint, not a *memory layout* constraint — these should be decoupled.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

**This is a serious concern.** `panic=unwind` across an FFI boundary is **undefined behavior** in Rust unless the panic is caught at the boundary. The correct pattern is:

```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1,  // signal error to C caller
    }
}
```

`panic=unwind` alone is **not** a safety barrier — it is a *precondition* for `catch_unwind` to work. If the C++ caller does not expect a longjmp-style unwind, this is a crash. **Recommendation:** use `panic=abort` at the FFI boundary and `catch_unwind` only in the Rust-internal orchestration layer, OR wrap every `extern "C"` function in `catch_unwind`.

### 3.2 Safe SIMD

Rust's `std::simd` is still nightly. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" is aspirational unless using `wide` or `pulp` crates. **Audit action:** count `unsafe` blocks; each must have a `// SAFETY:` comment justifying the invariant.

### 3.3 Packed 88-byte descriptor

```rust
#[repr(C, packed)]
pub struct PmtpTensorDescriptor { /* ... */ }
```

**Warning:** `#[repr(C, packed)]` makes field access generate unaligned loads. On x86 this is fine; on ARM (Trainium host) it can fault or be slow. **Recommendation:** use `#[repr(C)]` with explicit padding to 88 bytes, and `bytemuck::Pod` for zero-copy.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction

The Cayley retraction is:
```
Y(θ) = (I − (θ/2)A)⁻¹ (I + (θ/2)A) X,   A = XᵀG − GᵀX  (skew)
```
For `X ∈ R^{2K×2K}` (square Stiefel = orthogonal group O(2K)), this is exact. For `X ∈ St(n,p)` with `n > p`, the retraction is on the *embedded* manifold and the Cayley transform must be applied in the tangent space, not the ambient space. **The spec says `R^{2K×2K}` — this is the orthogonal group case, which is fine, but it means the kernel is specialized to square Stiefel.** If the caller passes `n ≠ p`, silent wrong answers.

### 4.2 cuSOLVER `DnDsyevd` — wrong routine?

`DnDsyevd` is the **divide-and-conquer symmetric eigensolver**. The Cayley retraction requires a **linear solve** `(I − (θ/2)A)⁻¹`, not an eigendecomposition. If the kernel is using `syevd` to invert via eigendecomposition, that is `O(n³)` with a large constant vs. `O(n³)` LU — but more importantly, **eigendecomposition of a non-symmetric `(I