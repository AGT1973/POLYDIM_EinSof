# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 120

A definitive arbitration is **not possible from the supplied record**: no specifications, implementations, benchmarks, proofs, or the eight models’ actual findings were provided, and the public search results do not identify a verifiable “POLYDIM V1350” or “PMTP 88-byte Descriptor” standard. The evidence supports only a conditional architectural synthesis, not exact guarantees.

### 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For a Stiefel point \(X\) and skew-symmetric update operator \(W\), the Cayley map is typically

\[
X^{+}
=
\left(I-\frac{1}{2}W\right)^{-1}
\left(I+\frac{1}{2}W\right)X .
\]

When the inverse exists and is computed stably, the Cayley transform preserves orthonormality in exact arithmetic because it is induced by an orthogonal transformation. Published Stiefel-manifold work describes Cayley retractions and establishes local retraction properties; iterative variants require a contraction condition involving the update magnitude, such as \(\alpha < 2/\lVert W\rVert\).[1][9]

That does **not** imply unconditional stability for a raw step of \(10^{10}\). In finite precision:

- A large step can make the linear solve ill-conditioned or cause severe cancellation.
- Iterative Cayley schemes may fail their contraction condition.
- A mathematically orthogonal result can still lose orthogonality through solver error and rounding.
- Householder QR is generally the safest default for robust re-orthogonalization.
- Polar retraction has strong geometric properties but requires a potentially expensive and numerically delicate factorization, especially near rank deficiency.
- Cayley is attractive when the update is structured and bounded, but should be paired with step scaling, norm-based safeguards, residual checks, and fallback QR/polar repair.

**Arbitration:** no method deserves an unconditional “stable for every \(|\mathrm{step}|\ge10^{10}\)” guarantee. The strongest defensible design is:

1. Scale or clip the tangent update before applying Cayley.
2. Use a backward-stable solve or structured factorization.
3. Check
   \[
   \left\|(X^{+})^{T}X^{+}-I\right\|
   \]
   against a declared tolerance.
4. Fall back to Householder QR when the check fails.
5. Optionally use a polar correction when the application requires the closest orthonormal factor.

Thus, **Householder QR should be the hard-failure fallback; Cayley should not be advertised as unconditionally superior under extreme steps**.

### 2. PMTP 88-byte descriptor and RCU/QSBR isolation

The search results provide general QSBR evidence, not a PMTP descriptor specification. QSBR implementations require readers to register, report quiescent states, and allow a writer to wait until all readers have passed through a grace period before reclaiming or publishing state.[5][15]

The correct memory-ordering rule is:

- **Publisher:** initialize the complete immutable descriptor, then publish its pointer or generation with **release** semantics.
- **Reader:** load the pointer or generation with **acquire** semantics before dereferencing descriptor fields.
- **Retirement:** remove or replace the old pointer only after publication of the new snapshot.
- **Reclamation:** free the old descriptor only after an RCU grace period or equivalent QSBR epoch confirmation.
- **Reader critical section:** must begin before the protected pointer is loaded and end after the final field access.

Acquire/release ordering alone does **not** provide reclamation safety. It orders visibility; it does not ensure that an object remains allocated while a reader uses it. Conversely, QSBR alone does not necessarily establish initialization visibility unless the publication operation uses suitable release/acquire synchronization.

**Arbitration:** the exact guarantee should be stated as:

> A reader that enters a valid QSBR read-side critical section and performs an acquire load observes either a fully initialized old descriptor or a fully initialized new descriptor; no descriptor is reclaimed until every pre-publication reader has reported a quiescent state.

This requires all of the following:

- Immutable-after-publication descriptor contents, or separately synchronized mutation.
- One release publication point.
- One acquire reader load.
- Correct QSBR registration and quiescent-state reporting.
- Grace-period completion before reclamation.
- No reliance on descriptor size, including the fact that it is 88 bytes, as a substitute for synchronization.
- Explicit handling of cache-line crossing, alignment, tearing, and ABI layout.

An 88-byte object may cross cache-line boundaries, and a multiword descriptor cannot be assumed atomically replaceable merely because individual machine-word operations are atomic. If the descriptor is copied directly, readers need a versioning protocol, pointer indirection, seqlock-like validation, or immutable snapshot replacement.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no basis for claiming exact multi-silicon conformance without:

- A normative ABI and layout specification.
- Defined scalar types, alignment, padding, endianness, and ownership rules.
- Reference tests and numerical tolerances.
- Device-specific implementations.
- Compiler and runtime version matrices.
- Memory-model mappings for each backend.
- Failure-injection and race-detection tests.

The ecosystems also do not share one identical execution or memory model:

- C++20 and Rust provide language-level atomic semantics, but their guarantees depend on the target platform and implementation.
- CUDA adds host/device visibility, stream ordering, fences, and scoped atomics.
- Triton exposes compiler- and hardware-dependent memory operations and barriers.
- XLA may fuse, reorder, or replicate operations according to its IR and backend semantics; host-language acquire/release assumptions cannot simply be projected onto arbitrary device code.

**Arbitration:** conformance can be claimed only at a specified contract boundary. A sound contract would separate:

1. **Numerical conformance:** orthogonality, residual, and update-error tolerances.
2. **Memory conformance:** acquire/release publication and QSBR grace-period guarantees.
3. **ABI conformance:** exact 88-byte layout only where the target ABI explicitly supports it.
4. **Execution conformance:** defined behavior under streams, asynchronous launches, replication, and compiler reordering.
5. **Failure conformance:** deterministic fallback or explicit error when stability predicates fail.

### Definitive synthesis

The mathematically and architecturally defensible SOTA position is:

- **Retraction:** Cayley is an orthogonality-preserving map in exact arithmetic, but not an unconditional extreme-step stability mechanism. Use adaptive scaling plus residual validation and Householder QR fallback.
- **Snapshot isolation:** release publication plus acquire consumption provides visibility; QSBR/RCU grace periods provide lifetime safety. Both are required.
- **Portability:** preserve the abstract contract across CUDA, XLA, Triton, C++20, and Rust, but do not claim bitwise, ABI, or memory-model equivalence without backend-specific proofs and tests.
- **Guarantees:** state only conditional guarantees tied to explicit preconditions. No exact “SOTA” guarantee follows from model consensus alone, and the eight tribunal findings cannot be compared until their actual reports and the six kernel specifications are supplied.