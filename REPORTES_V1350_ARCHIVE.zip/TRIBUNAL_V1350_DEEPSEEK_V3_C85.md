# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 85)

# POLYDIM V1350 — High Tribunal Audit, Cycle 85

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute
**Verdict class:** *Conditional Pass with Mandatory Remediations* (3 Critical, 4 High, 5 Medium)

Below is a component-by-component audit. Where the artifact is not literally in front of us, I audit the *specification as stated* and flag every claim that is not self-evidently provable from the stated invariants. I refuse to certify anything I cannot derive.

---

## 0. Cross-cutting invariants (apply to all 6 targets)

### 0.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let me actually lay out the struct and check the arithmetic, because "88 bytes" is a load-bearing claim under Rule 22.

```
4s   :  4 bytes   (magic)
H    :  2 bytes   (version_major)
H    :  2 bytes   (version_minor)
Q    :  8 bytes   (n_rows)
Q    :  8 bytes   (n_cols)
Q    :  8 bytes   (ld)
Q    :  8 bytes   (stride_bytes)
Q    :  8 bytes   (data_ptr)
B    :  1 byte    (dtype)
B    :  1 byte    (layout)
6x   :  6 bytes   (explicit pad)
4Q   : 32 bytes   (aux[4]: e.g. scale, seed, flags, checksum)
----
Total: 4+2+2+8+8+8+8+8+1+1+6+32 = 88 bytes  ✓
```

**Finding 0.1 (PASS, with caveat).** The layout is 88 bytes *only if* the compiler honors the explicit `6x` pad and the struct is not re-aligned. Under C++20 with `alignas(8)` on the `Q` members, the natural alignment of the struct is 8, and the trailing `4Q` (32 bytes) is already 8-aligned, so no trailing pad is inserted. **However**, if any member is declared `alignas(16)` (e.g., for AVX-512 loads of `aux`), the struct silently becomes 96 bytes. **Remediation R-0.1:** add `static_assert(sizeof(PmtpTensorDescriptor) == 88, "PMTP ABI drift");` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` in Rust, and a runtime `assert(desc.__sizeof__() == 88)` in Python. Without these, Rule 22 is *unverifiable*.

**Finding 0.2 (CRITICAL — Rule 22 violation risk).** Rule 22 forbids "1D tokens" in inter-agent communication. The descriptor is a *flat byte string*, which is fine — but the `4Q aux` field is under-specified. If any agent packs a variable-length payload (e.g., a checksum over a variable tensor) into `aux`, the descriptor ceases to be a fixed-size token and becomes a *pointer into a 1D stream*. **Remediation R-0.2:** freeze the semantics of `aux[0..4]` in a versioned spec; forbid any interpretation as offset/length into an external buffer.

### 0.2 Rule 27 — Silicon Contract / vendor lock

I audit each target for vendor lock below. Summary: **Targets 4 and 5 are the only true vendor-lock risks**; Targets 1, 2, 3, 6 are portable *if* the dispatch layer is honest.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe

**Finding 1.1 (HIGH).** A Python-level `HardwareProbe` that enumerates CPU/GPU/TPU/NPU is inherently a *trust boundary*. If it shells out to `nvidia-smi`, `rocm-smi`, `lspci`, or reads `/sys/class/...`, it is vulnerable to:
- **TOCTOU**: device hot-unplug between probe and dispatch.
- **Spoofing**: a container can bind-mount a fake `nvidia-smi`.
- **Silent fallback**: probe returns "CPU" and the orchestrator silently runs a numerically different kernel.

**Remediation R-1.1:** HardwareProbe must return a *capability token* (signed by the runtime, e.g., CUDA's `cuDeviceGetUuid` + driver version), not a boolean. Dispatch must be *fail-closed*: unknown device → refuse, not fallback.

### 1.2 PmtpSlabAllocator

**Finding 1.2 (MEDIUM).** Slab allocation of 88-byte descriptors is fine, but:
- If the slab is page-aligned and descriptors are packed contiguously, **false sharing** across cores is guaranteed at 88 bytes (not a multiple of 64). Two adjacent descriptors share a cache line.
- **Remediation R-1.2:** pad slab slots to 128 bytes (2 cache lines) *internally*, while keeping the wire format at 88 bytes. The 88-byte invariant is a *wire* invariant, not an *in-memory* invariant.

### 1.3 12/12 physical conformance checks

**Finding 1.3 (MEDIUM).** "12/12" is a claim, not a proof. Without the list of 12 checks, I cannot certify. **Demand:** publish the 12 predicates as a machine-checkable spec (e.g., a `conformance.yaml` with `assert` expressions). A conformance suite that is not itself versioned and hash-pinned is theater.

### 1.4 Numerical degeneracy at step → ∞ / step → 0

The orchestrator itself does not do arithmetic, but it *routes* `step`. **Finding 1.4 (HIGH):** if `step` is passed as a Python `float` and the orchestrator does any `step * scale` before dispatch, it can overflow to `inf` at `step ≥ 1e10` with `scale ≥ 1e298`, or flush to `0.0` at `step ≤ 1e-308`. **Remediation R-1.4:** orchestrator must pass `step` as a *raw IEEE-754 bit pattern* (or as a `(mantissa, exponent)` pair) and never touch it arithmetically.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan–Babuška:

```
s = 0; c = 0
for i: t = s + x_i*y_i
       if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
       else:                c += (x_i*y_i - t) + s
       s = t
return s + c
```

**Finding 2.1 (PASS, with bound).** Neumaier gives a *forward* error bound of roughly `2u * Σ|x_i y_i|` (u = unit roundoff ≈ 1.1e-16 for FP64), independent of n. This is the correct choice for ill-conditioned Gram matrices.

**Finding 2.2 (HIGH — degeneracy at step → ∞).** The compensated sum is *not* immune to overflow. If `step ≥ 1e10` and the kernel forms `step * B` with `B` having entries near `1e300`, the product overflows to `inf`, and Neumaier's compensation term becomes `inf - inf = NaN`. **Proof sketch:** let `t = s + x_i y_i` with `x_i y_i = +inf`. Then `s - t = -inf`, `(s-t) + x_i y_i = -inf + inf = NaN`. The compensation poisons the result. **Remediation R-2.2:** pre-scale by `1/scale` *before* the dot product (see Target 4's Woodbury trick), or use `fma` with explicit exponent tracking. A `std::isfinite` guard on every accumulation is *not* sufficient — it must be a *pre-condition* on inputs.

**Finding 2.3 (HIGH — degeneracy at step → 0 / subnormals).** The audit mentions subnormal audits at `-12, -14` (presumably exponents). For FP64, subnormals begin at `2^-1022 ≈ 2.2e-308`. If `step ≤ 1e-308`, `step * B` flushes to zero on hardware with FTZ/DAZ enabled (which AVX-512 kernels often enable for speed). **This silently changes the mathematical result.** **Remediation R-2.3:** explicitly clear FTZ/DAZ in MXCSR for the duration of the kernel, or document that subnormal inputs are *rejected* (fail-closed). The `-12, -14` audit points suggest the authors are aware; demand the exact MXCSR mask used.

### 2.2 Zero-copy PMTP validation

**Finding 2.4 (MEDIUM).** "Zero-copy" + "validation" is a contradiction unless validation is done on the *descriptor only* (88 bytes), not the payload. If the kernel validates the payload by reading it, it's not zero-copy. **Remediation R-2.4:** validation must be a *descriptor-level* check (magic, version, alignment, `data_ptr` non-null, `stride_bytes` consistent with `n_cols * dtype_size`). Payload integrity is the caller's responsibility, enforced by a checksum in `aux[3]`.

### 2.3 Rule 27 — vendor lock

**Finding 2.5 (PASS).** AVX-512 + OpenMP is portable across Intel/AMD (with `-march=native` caveats). **Caveat:** AVX-512 on Zen 4 is double-pumped; on Zen 5 it's full-width. If the kernel assumes full-width, it will be *correct* but *slow* on Zen 4. Not a lock, but a performance cliff. **Remediation R-2.5:** runtime dispatch on `__builtin_cpu_supports("avx512f")` and a fallback AVX2 path.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier

**Finding 3.1 (CRITICAL — this is backwards).** The standard FFI hardening rule is **`panic=abort` at the FFI boundary**, or `catch_unwind` at every `extern "C"` entry point. `panic=unwind` *across* an FFI boundary is **undefined behavior** in Rust (the C++ side has no landing pad). If the audit claims `panic=unwind` is the "safety barrier," that is a **misstatement of the rule**.

**Remediation R-3.1 (mandatory):**
```rust
#[no_mangle]
pub extern "C" fn pmtp_kernel(...) -> c_int {
    match std::panic::