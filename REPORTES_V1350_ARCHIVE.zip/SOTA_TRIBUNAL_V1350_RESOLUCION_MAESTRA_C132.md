# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 132

The available evidence does **not** contain the eight Tribunal reports, the six V1350 kernel specifications, benchmark traces, or conformance artifacts. The search results identify a public **PolyDiM** numerical library, but do not substantiate “POLYDIM V1350,” “PMTP 88-byte Descriptor,” or the claimed Tribunal findings.[3][7][10] Therefore, a definitive arbitration of those specific implementations would be unsupported. The following is the strongest standards-based synthesis that can be stated conditionally.

## 1. Extreme-step Stiefel retraction

For \(Y\in\mathrm{St}(n,p)\), a Cayley update generally has the form

\[
Y_{+}=\left(I-\frac{\tau}{2}A\right)^{-1}
       \left(I+\frac{\tau}{2}A\right)Y,
\qquad A^{T}=-A .
\]

In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists. However, that does **not** imply numerical stability for \(|\tau|\ge 10^{10}\). The implementation must handle:

- formation of \(A\) without overflow or catastrophic cancellation;
- solution of the shifted system without explicitly forming an inverse;
- preservation of skew symmetry;
- conditioning of the linear solve;
- finite-precision loss of \(Y_{+}^{T}Y_{+}=I\).

A correctly implemented Householder QR or polar factorization has a stronger practical stability basis for producing an orthonormal representative. Householder QR is backward stable under standard floating-point assumptions; polar retraction is geometrically attractive but requires a stable factorization of \(Y+\tau\Delta\), such as SVD or a carefully implemented inverse square root.

**Arbitration:** no unconditional claim that Cayley is superior at extreme step sizes is mathematically defensible. The architectural guarantee should instead be:

\[
\|Y_{+}^{T}Y_{+}-I\| \le C(n,p)\,u\,\kappa_{\mathrm{alg}}+\varepsilon_{\mathrm{guard}},
\]

subject to finite, nonsingular intermediate operations. If the bound cannot be demonstrated, the kernel must reject, rescale, or damp the step. For \(|\tau|\ge10^{10}\), the preferred policy is:

1. scale the tangent/update before evaluating the transform;
2. use a backward-stable solve or factorization;
3. verify the orthogonality residual;
4. fall back to Householder QR or polar retraction if the residual exceeds tolerance.

Thus, **Cayley may preserve the manifold analytically, but QR/polar provides the stronger unconditional numerical fallback guarantee**. No implementation can guarantee stable output for arbitrary extreme inputs merely from the Cayley formula.

## 2. PMTP descriptor and RCU/QSBR isolation

Acquire/release operations can establish ordering, but they do not by themselves guarantee complete snapshot isolation.

A sound publication protocol requires:

- the writer initializes the immutable snapshot;
- the writer performs a **release** publication of the descriptor or generation pointer;
- the reader performs an **acquire** load before dereferencing the snapshot;
- readers announce quiescent-state participation before accessing the object;
- reclamation occurs only after every preexisting reader has passed through a quiescent state;
- descriptor fields used concurrently are either immutable after publication or independently atomic.

The essential happens-before relation is:

\[
\text{initialize snapshot}
\;\xrightarrow{\text{release}}\;
\text{publish descriptor}
\;\xrightarrow{\text{acquire}}\;
\text{reader dereference}.
\]

For reclamation, the required relation is:

\[
\text{reader exit/quiescence}
\;\xrightarrow{}\;
\text{reclaimer observes all required quiescent states}
\;\xrightarrow{}\;
\text{free old snapshot}.
\]

An 88-byte size is an ABI/layout property, not a memory-model guarantee. It cannot establish atomicity, alignment, lifetime safety, or cross-device visibility. The descriptor must specify:

- exact field offsets and alignment;
- ownership and lifetime rules;
- which fields are atomic;
- the publication variable;
- generation or epoch semantics;
- the reader-entry and reader-exit protocol;
- reclamation conditions;
- host/device visibility requirements.

**Arbitration:** “Acquire/Release is sufficient” is valid only for the publication edge under a correctly specified RCU/QSBR protocol. It is **not** sufficient as a blanket guarantee of snapshot isolation or safe reclamation. The strongest defensible guarantee is:

> A reader that acquires a published descriptor observes a fully initialized immutable snapshot, and that snapshot remains alive until the reader’s announced critical section has ended and the reclamation grace-period condition has been met.

Sequential consistency is not required for this guarantee, but relaxed operations require a separately proven protocol and are not interchangeable with acquire/release.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or execution model shared identically by all five environments. “Multi-silicon conformance” therefore cannot mean bitwise-identical behavior or identical synchronization primitives.

A valid portability contract must define a common semantic subset:

- fixed-width integer and floating-point representations;
- explicit endianness and descriptor layout;
- no reliance on compiler-specific padding;
- explicit alignment;
- no data races;
- no undefined behavior;
- explicit synchronization scope;
- deterministic handling of NaNs, overflow, and denormals where required;
- tolerance-based numerical equivalence rather than exact equality;
- separate host, device, block/workgroup, and system visibility domains.

The implementation mappings differ:

- **C++20:** use the C++ memory model and atomics, while avoiding assumptions about nonstandard lock-free widths.
- **Rust:** use atomics and synchronization primitives with explicit ownership/lifetime rules; `unsafe` code requires a documented memory-model proof.
- **CUDA:** distinguish thread-block, device, and system scopes; a block barrier is not automatically a system-wide publication barrier.
- **Triton:** express synchronization only through operations supported by the target backend; compiler lowering and launch topology must be part of the contract.
- **XLA:** treat operations as graph-level computations; side effects and ordering require explicit supported mechanisms, and arbitrary C++-style atomic assumptions cannot be imported.

**Arbitration:** conformance should be certified by a behavioral test suite, not by source-level similarity. A kernel conforms only if every target satisfies:

\[
\text{layout}
\land
\text{lifetime}
\land
\text{ordering}
\land
\text{numerical tolerance}
\land
\text{failure behavior}.
\]

## Definitive conditional synthesis

The mathematically strongest architecture is a **guarded, verified pipeline**:

1. Construct the manifold update using a numerically stable method.
2. For extreme steps, scale or reject the update before evaluating a Cayley transform.
3. Use Householder QR or a stable polar factorization as the certified fallback.
4. Publish immutable snapshots through release/acquire edges.
5. Protect reclamation with a complete RCU/QSBR grace-period protocol.
6. Treat the 88-byte descriptor as a versioned ABI object with explicit alignment and offsets.
7. Define a portability subset and provide backend-specific synchronization mappings.
8. Verify postconditions at runtime in debug/certification modes:
   \[
   \|Y^{T}Y-I\| \le \tau_{\mathrm{orth}},
   \qquad
   \text{descriptor generation is coherent},
   \qquad
   \text{no reader observes reclaimed storage}.
   \]

The exact guarantees that can legitimately be claimed are therefore **conditional guarantees under stated preconditions**, not unconditional SOTA claims:

- orthogonality up to a specified floating-point residual;
- initialized-snapshot visibility after acquire;
- reclamation safety after a completed grace period;
- ABI compatibility under an explicitly frozen layout;
- behavioral equivalence within declared numerical and memory-order tolerances across supported backends.

Without the actual eight Tribunal outputs and implementation artifacts, ranking Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, and Perplexity—or declaring one of their findings definitive—would amount to inventing evidence.