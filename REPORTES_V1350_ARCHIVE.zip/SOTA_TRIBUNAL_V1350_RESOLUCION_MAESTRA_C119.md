# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 119

A definitive arbitration is **not possible from the supplied record**: the eight model reports, the six kernel specifications, and the V1350 implementation or test artifacts are absent. Public search results also do not establish a recognized “POLYDIM V1350” kernel suite or “PMTP 88-byte Descriptor”; the identifiable PolyDiM project concerns numerical methods for PDEs, not this architecture.[2][5][7] The results do support the general QSBR principle that reclamation is safe only after all readers holding references have passed through quiescent states.[3][9][12]

The strongest technically defensible synthesis is therefore a **conditional architecture**, not a claimed benchmark result.

## 1. Extreme-step Stiefel retraction

For an orthonormal-frame state \(X\) and tangent update \(\Delta\), the retraction must first define the effective step

\[
Y = X + \alpha \Delta,\qquad |\alpha|\ge 10^{10},
\]

and then compute an orthonormal factor \(Q\) satisfying

\[
Q^{\mathsf T}Q = I
\]

within a specified floating-point tolerance.

### Arbitration

- **Naïve Cayley retraction is not unconditionally stable** at extreme step sizes. A Cayley map generally has the form

\[
Q(\alpha) =
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right),
\qquad A^{\mathsf T}=-A,
\]

and requires a well-conditioned solve. Large \(\alpha\) does not by itself make the map unstable, but it magnifies conditioning, overflow, cancellation, and solver-residual problems.
- **Householder QR** is the preferable baseline for robust orthogonalization. With blocked or compact WY Householders, it avoids explicitly forming normal equations and is backward stable under standard assumptions.
- **Polar retraction** is the mathematically cleanest projection onto the Stiefel manifold:

\[
\operatorname{polar}(Y)=Y(Y^{\mathsf T}Y)^{-1/2},
\]

but computing \(Y^{\mathsf T}Y\) can square the condition number. A stable SVD-based or carefully scaled Newton–Schulz/polar-decomposition implementation is required; an unscaled Gram-matrix implementation is not an extreme-step guarantee.

### Definitive guarantee

The only valid unconditional guarantee is:

> For \(|\alpha|\ge 10^{10}\), the kernel shall use norm scaling, finite-value checks, rank/conditioning detection, and a backward-stable orthogonalization path—preferably Householder QR or SVD-based polar decomposition—with a documented residual bound
> \[
> \|Q^{\mathsf T}Q-I\|\le \varepsilon_{\mathrm{orth}}
> \]
> and no silent acceptance of overflow, NaN, rank loss, or failed linear solves.

A Cayley implementation may be accepted only if it proves a condition-dependent bound for its solve and has a deterministic fallback. No architecture can honestly promise stability merely from the Cayley formula or from the magnitude threshold \(10^{10}\).

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte size is an ABI/layout fact, not a memory-ordering guarantee. Correct snapshot isolation requires a publication protocol.

A sound release/acquire protocol is:

1. Writer constructs the entire immutable descriptor payload.
2. Writer publishes the pointer or generation token with **release** semantics.
3. Reader loads that publication with **acquire** semantics.
4. Reader enters or announces its RCU/QSBR read-side critical section before dereferencing the object.
5. Writer retires the old object and reclaims it only after every relevant reader has passed a quiescent state.

The essential ordering is:

\[
\text{initialize payload}
\;\xrightarrow{\text{release}}\;
\text{publish pointer/version}
\;\xrightarrow{\text{acquire}}\;
\text{reader dereference}.
\]

### Arbitration

- **Acquire/release is sufficient for publication visibility**, assuming the descriptor is immutable after publication and the publication variable is atomic.
- **Acquire/release alone is insufficient for reclamation safety.** It does not prevent a reader from dereferencing memory that a writer has already freed.
- **RCU/QSBR supplies the lifetime guarantee**, not descriptor width and not ordinary release stores. QSBR specifically requires readers to report quiescent states; reclamation is safe only after all participating readers have done so.[3][9][12]
- A 16-byte atomic publication field may be required if the design publishes a pointer plus generation/version atomically. The full 88-byte descriptor need not itself be atomically copied.

### Exact guarantee

The descriptor contract should state:

> A reader that acquires generation \(g\) while inside a registered read-side epoch observes a fully initialized, internally consistent descriptor for \(g\). The descriptor remains allocated until every reader that could have observed \(g\) has reported a quiescent state. No reader may mutate the published payload. Reclamation before that grace period is a use-after-free bug.

For C++20, this can be expressed using `std::atomic` publication and an explicit RCU/QSBR library. Rust requires an ownership/epoch mechanism or carefully encapsulated atomics; `Ordering::Acquire` and `Ordering::Release` do not independently implement RCU. CUDA, Triton, and XLA require separate treatment because host-language atomics, device atomics, compiler barriers, and stream/event ordering are not interchangeable.

## 3. Multi-silicon and multi-backend conformance

A single source-level statement cannot automatically guarantee identical semantics across CUDA, XLA, Triton, C++20, and Rust. These systems differ in:

- memory scopes and coherence domains;
- compiler reordering rules;
- host/device visibility;
- supported atomic widths and alignments;
- floating-point contraction, flush-to-zero, and fast-math behavior;
- legality of dynamic control flow and aliasing;
- collective and asynchronous execution semantics.

### Definitive conformance model

Conformance should be defined as a layered contract:

| Layer | Required guarantee |
|---|---|
| Numerical | Same mathematical result within a declared tolerance, not bitwise identity unless explicitly required |
| Structural | Orthogonality, descriptor size/alignment, field offsets, and version invariants |
| Memory | Acquire/release publication plus an explicit grace-period/reclamation protocol |
| Execution | No data race, use-after-free, invalid synchronization scope, or hidden stream dependency |
| Backend | Every backend has a native implementation or a formally specified lowered equivalent |
| Failure | Overflow, rank deficiency, unsupported atomics, and failed synchronization are reported deterministically |

For numerical kernels, the specification should require tests over:

- \(|\alpha| \in \{10^{10},10^{12},10^{16}\}\);
- ill-conditioned and rank-deficient inputs;
- NaN and infinity injection;
- varying matrix shapes and batch sizes;
- all target devices and compiler optimization levels;
- concurrent readers, publication, retirement, and reclamation;
- host/device and multi-stream visibility.

## Arbitration outcome

The mathematically superior SOTA position is:

1. **Use scaled, residual-checked Householder QR or SVD-based polar projection as the mandatory extreme-step fallback.** Cayley is an optional optimized path, not the universal stability primitive.
2. **Treat the 88-byte PMTP descriptor as an ABI object only.** Snapshot isolation requires atomic release publication, acquire consumption, immutable payloads, registered readers, and QSBR/RCU grace-period reclamation.
3. **Define cross-silicon conformance by explicit contracts and differential tests**, not by assuming CUDA, XLA, Triton, C++20, and Rust share one memory or floating-point model.
4. **Reject any stronger claim**—for example, unconditional Cayley stability, acquire/release-only reclamation safety, or bitwise cross-backend identity—unless the missing kernel specifications, model reports, formal proofs, and device test logs establish it.