# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 97

The requested arbitration cannot be validated as stated: the public search results do not contain the six Tribunal models’ reports, the six V1350 kernel specifications, or evidence that “POLYDIM V1350,” “PMTP 88-byte Descriptor,” and the associated terminology are publicly documented. The results instead identify PolyDiM as a C++ library for polytopal discretization methods[2][11][15] and provide general QSBR/RCU references[1][6][10][12][13]. Therefore, no defensible model-by-model vote or “definitive” conformance claim can be derived.

## Provisional technical arbitration

### 1. Extreme-step Stiefel retraction

For a point \(X\) on the Stiefel manifold \(\mathrm{St}(n,p)\), a Cayley update typically has the form

\[
X_{+}
=
\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)X,
\qquad
A^{\mathsf T}=-A.
\]

In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists. However, that does **not** imply numerical stability for \(|\tau|\ge 10^{10}\). The implementation must address:

- conditioning of the shifted solve;
- overflow or underflow in forming \(\tau A\);
- loss of skew-symmetry through rounding;
- residual orthogonality;
- rank deficiency or ill-conditioning in the tangent representation;
- backward-error growth in the linear solve.

A Householder or properly implemented polar-QR retraction is generally the safer reference method for extreme steps because it explicitly restores orthogonality through orthogonal transformations or a matrix factorization. It is not correct to guarantee that an unscaled Cayley implementation is superior merely because it preserves orthogonality algebraically.

The strongest defensible guarantee is conditional:

\[
\|X_{+}^{\mathsf T}X_{+}-I\|
\le
C\,u\,\kappa_{\mathrm{solve}}\,\Phi(n,p,\tau A)
+
\varepsilon_{\mathrm{fallback}},
\]

where \(u\) is machine precision and \(\varepsilon_{\mathrm{fallback}}\) is the explicitly configured repair tolerance. A production design should use:

1. norm scaling or a parameterization that avoids constructing enormous \(\tau A\);
2. a stable solve rather than explicit inversion;
3. iterative refinement or residual checking;
4. orthogonality verification;
5. automatic fallback to polar or Householder-QR when the residual or estimated conditioning exceeds a threshold.

Thus, the architectural guarantee should be **bounded residual plus fallback**, not unconditional stability for every \(|\tau|\ge 10^{10}\).

### 2. PMTP descriptor barriers and RCU/QSBR isolation

Acquire/release operations are necessary but not sufficient to define snapshot isolation.

For a publication path, the minimum correct pattern is conceptually:

\[
\text{initialize payload}
\;\prec_{\mathrm{sb}}\;
\text{release-store descriptor pointer/version}
\]

and on the reader:

\[
\text{acquire-load descriptor pointer/version}
\;\prec_{\mathrm{hb}}\;
\text{read payload}.
\]

Here, \(\prec_{\mathrm{sb}}\) is sequenced-before and \(\prec_{\mathrm{hb}}\) is the resulting happens-before relation. This ensures that a reader acquiring a published descriptor observes the initialization that preceded publication.

For reclamation, however, acquire/release publication does not by itself prevent use-after-free. The writer must defer reclamation until every reader that could have observed the old snapshot has passed through a grace period. In QSBR terms, readers must report quiescent states, and reclamation occurs only after all relevant readers have advanced beyond the publication epoch. The QSBR references found describe precisely this principle: a quiescent state is a point at which a reader no longer holds a reference, after which a writer can safely reclaim the object[10].

A robust descriptor protocol therefore needs:

- release publication of the immutable snapshot;
- acquire observation by readers;
- immutable payload after publication, or separately synchronized mutation;
- reader registration and liveness rules;
- explicit grace-period completion;
- protection against reader deregistration, stalled readers, ABA, wraparound, and descriptor reuse;
- correct treatment of device memory and host/device visibility if accelerators participate.

The **88-byte size is not a memory-model guarantee**. It can be an ABI/layout guarantee only if the specification fixes field sizes, alignment, endian policy, atomic representation, padding, and versioning. A mathematically valid guarantee is:

\[
\text{reader observes either a fully initialized snapshot } S_i
\text{ or a fully initialized snapshot } S_{i+1},
\]

provided the reader follows the protocol and reclamation is delayed until the applicable grace period completes. Acquire/release alone cannot guarantee that property for mutable, reused, or prematurely reclaimed storage.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared uniformly by these environments. Host C++20 and Rust atomics have language-level semantics; CUDA adds host/device scopes and synchronization domains; Triton exposes compiler- and backend-dependent atomic behavior; XLA is an optimizing computation graph/compiler system whose effective ordering guarantees depend on the operation and backend.

Consequently, “multi-silicon conformance” must be defined as a layered contract:

- **Numerical conformance:** bounded error relative to a specified reference computation.
- **Layout conformance:** exact descriptor size, offsets, alignment, and serialization.
- **Host memory conformance:** C++20/Rust happens-before and lifetime rules.
- **Device memory conformance:** explicit CUDA or backend-supported scope and synchronization.
- **Compiler conformance:** no reliance on undocumented reordering, aliasing, or atomic behavior.
- **Progress conformance:** specified guarantees under stalled, preempted, or absent readers.
- **Cross-silicon conformance:** tested behavior across named architectures, compiler versions, and optimization levels.

The exact guarantee should be conditional on a declared capability profile, for example:

\[
\mathrm{Conforms}(P,A,C,V)
\iff
\begin{cases}
\text{layout}(P)=\text{specified ABI},\\
\text{ordering}(P)\supseteq\text{required ordering},\\
\text{numerical residual}\le \epsilon,\\
\text{reclamation safety holds},\\
\text{all required litmus and stress tests pass}.
\end{cases}
\]

Without such a profile, a claim of universal conformance across CUDA, XLA, Triton, C++20, and Rust is too strong.

## Definitive synthesis

The technically superior SOTA architecture is a **verified hybrid**:

1. Use a scaled Cayley update only in a numerically certified regime.
2. Check conditioning, solve residual, and Stiefel orthogonality after the update.
3. Fall back deterministically to polar decomposition or Householder-QR outside that regime.
4. Publish immutable 88-byte descriptors with release semantics.
5. Read them with acquire semantics.
6. Reclaim old snapshots only after a formally defined RCU/QSBR grace period.
7. Treat host, device, compiler, and ABI guarantees as separate conformance layers.
8. Require litmus tests, randomized stress tests, numerical residual tests, and cross-compiler/cross-silicon certification before claiming support.

The exact unconditional guarantees that can be made from the available information are limited to these conditional forms:

- **Retraction:** orthogonality is guaranteed mathematically by the exact Cayley transform, but finite-precision stability for \(|\text{step}|\ge 10^{10}\) requires scaling, residual checks, and a certified fallback.
- **Snapshot isolation:** acquire/release establishes publication visibility; RCU/QSBR grace periods establish reclamation safety.
- **Portability:** conformance is guaranteed only for explicitly specified backends, memory scopes, ABI rules, compiler versions, and tested silicon.

No evidence currently supports assigning a winning Tribunal model, certifying all six kernels, or asserting unconditional architectural guarantees.