# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 127)

# POLYDIM V1350 — High Tribunal Audit, Cycle 127

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods
**Verdict class:** *Conditional Admissibility* — 4 of 6 targets pass with remediation; 2 require mandatory patches before production.

---

## 0. Preliminary: What the 88-byte descriptor actually encodes

Struct layout `<4sHHQQQQQBB6x4Q`:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | 4s | 4 | 0 |
| version | H | 2 | 4 |
| flags | H | 2 | 6 |
| n_rows | Q | 8 | 8 |
| n_cols | Q | 8 | 16 |
| stride | Q | 8 | 24 |
| dtype | Q | 8 | 32 |
| device | Q | 8 | 40 |
| rank | B | 1 | 48 |
| layout | B | 1 | 49 |
| pad | 6x | 6 | 50 |
| reserved | 4Q | 32 | 56 |
| **Total** | | **88** | |

`struct.calcsize('<4sHHQQQQQBB6x4Q') = 88` ✓ — **alignment is not guaranteed** by `struct` (it is packed), so any C/Rust/CUDA mirror must be `#pragma pack(1)` / `#[repr(C, packed)]`. **This is the first FFI hazard** and it recurs in Targets 2, 3, 4.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator
- Multi-silicon probe is fine as a *capability* query, but the allocator must return **device-tagged** slabs. If `device` field in the descriptor is a `Q` (u64) enum, ensure the enum is **closed** (no vendor-specific magic numbers leaking into the ABI). Otherwise Rule 27 is violated at the descriptor level.
- **Rule 22 check:** the orchestrator must never emit a 1-D token stream to peers. Confirm that every inter-agent message is a *packed 88-byte header + payload*, never a bare `bytes`/`str`. If `HardwareProbe` returns a Python `list[str]` of device names, that is a **Rule 22 violation** — wrap it in a descriptor.

### 1.2 12/12 physical conformance checks
Without the check list we cannot certify, but the *pattern* of "12/12" is a red flag for **tautological conformance** (checks that re-assert the descriptor's own fields). Demand:
- At least 3 checks must be **independent** (e.g., `cudaPointerGetAttributes` on a slab, `munmap` round-trip, `sizeof` cross-language assertion).
- At least 1 check must be **adversarial** (feed a corrupted descriptor, expect rejection).

### 1.3 Numerical degeneracy at `step → ∞` / `step → 0`
The orchestrator itself is not numerical, but it *routes* `step`. If it clamps `step` to `[1e-300, 1e10]` silently, downstream kernels see a **discontinuous** input. **Recommendation:** orchestrator must reject `|step| ≥ 1e10` with `E_RANGE` and `|step| < 2^-1022` with `E_SUBNORMAL`, not clamp.

**Verdict T1:** *Admissible with descriptor-ABI patch and Rule 22 audit of probe output.*

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product
Neumaier's variant is **correct** for the standard case, but the compensation term `c` is itself a sum of rounding errors and can **overflow** if partial sums are near `DBL_MAX`. For `step → ∞` with `|step| ≥ 1e10`, the products `step * B` can reach `1e10 * 1e308 = inf`. **Proof obligation:** show `‖B‖_F · |step| < DBL_MAX / 2` is enforced *before* the dot product, or the compensation is meaningless.

### 2.2 Subnormal audits at `-12, -14`
These are almost certainly **exponent thresholds** (2^-12, 2^-14) for flushing. Two issues:
- **FTZ/DAZ interaction:** AVX-512 with `_MM_FROUND` and MXCSR FTZ=1 will silently flush subnormals *before* your audit sees them. The audit must run with FTZ=0/DAZ=0, or it is measuring the wrong thing.
- **Neumaier + subnormals:** the compensation term `c` is *exactly* where subnormals live. If you flush `c`, you lose the compensation. **This is a correctness bug, not a performance knob.**

### 2.3 Zero-copy PMTP validation
Zero-copy means the C++ kernel reads the 88-byte header **directly from the peer's buffer**. This requires:
- `#pragma pack(1)` on the mirror struct (see §0).
- Endianness assertion (little-endian assumed; add `static_assert`).
- **TOCTOU:** validate the descriptor *after* `mmap`/`cudaHostRegister`, not before. Otherwise a malicious peer can swap the header between validation and use.

### 2.4 Rule 27 (vendor lock)
AVX-512 is Intel-specific. If the kernel *requires* AVX-512 with no scalar fallback, that is a **soft vendor lock**. Provide a `-march=x86-64-v3` fallback path and a runtime `__builtin_cpu_supports("avx512f")` dispatch.

**Verdict T2:** *Admissible only after FTZ/DAZ audit fix and overflow precondition proof.*

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier
This is **the single most dangerous design choice in the entire stack.** `panic=unwind` across an FFI boundary is **UB** unless every `extern "C"` function is wrapped in `catch_unwind` and the panic payload is converted to an error code. Rust's own docs are explicit: unwinding across `extern "C"` is undefined behavior.

**Mandatory hardening:**
```rust
#[no_mangle]
pub extern "C" fn pmtp_dot(...) -> i32 {
    match std::panic::catch_unwind(|| inner(...)) {
        Ok(Ok(_)) => 0,
        Ok(Err(e)) => e.code(),
        Err(_) => E_PANIC,
    }
}
```
And the C++ side must **not** call back into Rust during unwinding.

### 3.2 Safe SIMD + Neumaier
Rust's `std::simd` is still nightly. If this is stable Rust, "Safe SIMD" is a misnomer — you're using `core::arch` intrinsics, which are `unsafe`. **Demand:** the `unsafe` blocks must be audited for alignment (`#[repr(align(64))]`) and bounds.

### 3.3 Packed 88-byte descriptor
`#[repr(C, packed)]` on a struct containing `u64` fields will generate **unaligned loads** on some targets. On x86 this is fine; on ARM (Trainium host) it can trap. Use `#[repr(C, packed(1))]` and access via `read_unaligned`.

### 3.4 Numerical degeneracy
Same as T2: Neumaier compensation underflows to subnormal when `step → 0`. Rust does **not** flush subnormals by default (good), but `f64::mul_add` may use FMA which changes the rounding profile. **Proof obligation:** show the FMA path preserves Neumaier's error bound `|err| ≤ ε|Σ| + O(ε²)`.

**Verdict T3:** *Admissible only after `catch_unwind` wrapper is mandatory and `packed(1)` + `read_unaligned` is enforced.*

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)
Cayley: `Y = (I - (α/2)W)^{-1} (I + (α/2)W) X`, where `W = A X^T - X A^T` (skew). For `step → ∞`, `α → ∞`, and the Cayley transform approaches `-I` — **the retraction degenerates to a reflection**, which is not a retraction onto the Stiefel manifold in the limit. **Proof obligation:** show `α` is bounded by `1/‖W‖_2` (or a safe fraction thereof) before the solve.

### 4.2 cuSOLVER `DnDsyevd` for the Woodbury solve
`DnDsyevd` is a **symmetric** eigensolver. The Woodbury matrix `(M/scale) W` is **not symmetric** in general. If you symmetrize it, you change the problem. **This is a mathematical error, not a numerical one.** Either:
- Use `DnDsyevd` on the *symmetric* part and prove the skew part is negligible (unlikely), or
- Use `DnDsyevd` on `W^T W` (normal equations) — but then condition number squares, and for `step → ∞` the condition number is `κ²`, which is catastrophic.

### 4.3 Globally scaled Woodbury `(M/scale) W = (step/scale) B`
The scaling is a **preconditioner**, not a solution. If `scale` is chosen as `‖B‖_F`, then `step/scale` is `O(1)` — good. But if `step → 0`, `step/scale → 0`, and the RHS underflows to subnormal. **Demand:** `scale = max(‖B‖_F, 2^-1000)` and a post-solve rescale with Neumaier compensation.

### 4.4 CUDA Graphs
Graphs are fine, but **graph capture cannot include `cudaMalloc`**. If the Woodbury solve allocates workspace inside the graph, capture will fail or silently fall back. **Demand:** pre-allocate all workspace before capture.

### 4.5 Rule 27
cuSOLVER is NVIDIA-only. The kernel must expose a **ROCm/HIP** path (see T6) or declare itself NVIDIA-exclusive. If the orchestrator (T1) routes to it unconditionally, that is a vendor lock.

**Verdict T4:** *Not admissible.* The `DnDsyevd` on a non-symmetric matrix is a correctness defect. Requires redesign of the Woodbury solve.

---

## TARGET 5 — `kernel_xla_v1350.py`

### 5.1 `@jax.jit` + continuous Lyapunov in HBM
Lyapunov `A