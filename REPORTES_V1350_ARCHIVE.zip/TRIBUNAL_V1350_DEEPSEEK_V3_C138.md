# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 138)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 138 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has examined the six artifacts as *specifications*, not as source (no line-level source was supplied). Findings below are therefore stated as **conditional theorems**: each is a proof obligation that the artifact must satisfy, with the failure mode that triggers if the obligation is unmet. Where the spec is silent, we flag it as a **defect of specification**, not of implementation.

---

## 0. Notation and Standing Assumptions

- Step size `h ∈ ℝ`, scale `s > 0`, dimension `D`, rank `K`, `M = 2K`.
- PMTP descriptor: `<4sHHQQQQQBB6x4Q` → 4 + 2 + 2 + 8·5 + 1 + 1 + 6 + 8·4 = **88 bytes**. ✔
- Neumaier compensated summation: `s = s + t` with `t = (|a| ≥ |s|) ? (s − (s + a)) + a : (a − (s + a)) + s`.
- Subnormal audit points: `−12`, `−14` (presumably `2^−12`, `2^−14` in FP64 exponent space).

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor conformance

Layout `<4sHHQQQQQBB6x4Q`:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version | `H` | 2 | 4 |
| flags | `H` | 2 | 6 |
| dim | `Q` | 8 | 8 |
| rank | `Q` | 8 | 16 |
| stride | `Q` | 8 | 24 |
| offset | `Q` | 8 | 32 |
| nbytes | `Q` | 8 | 40 |
| dtype | `B` | 1 | 48 |
| layout | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| reserved | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict:** Structurally sound. **But** `struct` in CPython uses *native* alignment unless `=` prefix is used. The format string as written (`<`) forces little-endian **and** standard sizes with no padding — good. **However**, the C++/Rust/CUDA sides must declare the struct with `#pragma pack(1)` / `#[repr(C, packed)]` / `__attribute__((packed))` respectively. If any side uses natural alignment, the `Q` fields at offsets 8, 16, 24, 32, 40 are already 8-aligned, and `B` at 48/49 followed by `6x` pad then `4Q` at 56 is also 8-aligned — so **natural alignment happens to coincide with packed layout here**. This is a *fragile coincidence*: any future field insertion breaks ABI silently.

**Recommendation (Rule 22 hardening):** Add a static assertion on every side:
```
static_assert(sizeof(PmtpDescriptor) == 88, "PMTP ABI drift");
static_assert(offsetof(PmtpDescriptor, reserved) == 56, "PMTP ABI drift");
```
and a runtime `ctypes.sizeof` check in the orchestrator before any FFI call.

### 1.2 Multi-silicon HardwareProbe

The probe must return a **capability bitmask**, not a vendor string. If it returns `"nvidia"` / `"amd"` / `"tpu"` as a string and the orchestrator branches on it, that is a **Rule 27 violation** (vendor-lock by dispatch). The correct pattern is:

```
caps = probe()  # bitmask: HAS_AVX512 | HAS_OPENMP | HAS_CUDA | HAS_ROCM | HAS_XLA | HAS_TRITON
```

with the orchestrator selecting the *highest-throughput kernel whose caps are satisfied*, not the *vendor-preferred kernel*.

### 1.3 12/12 physical conformance checks

Without the list we cannot verify, but the Tribunal demands the checks be **orthogonal** (no check implies another) and **falsifiable**. A check like "descriptor size == 88" is falsifiable; "kernel is fast" is not. If any of the 12 is a tautology, the count is inflated.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier dot product — asymptotic condition number

For a dot product `Σ aᵢbᵢ` with Neumaier compensation, the forward error bound is:

```
|fl(Σ aᵢbᵢ) − Σ aᵢbᵢ| ≤ (2u + O(u²)) · Σ |aᵢbᵢ| + O(u²) · |Σ aᵢbᵢ|
```

where `u = 2⁻⁵³`. This is **independent of n** (unlike naive summation, whose bound is `n·u·Σ|aᵢbᵢ|`). The **condition number** of the dot product is:

```
κ = Σ|aᵢbᵢ| / |Σ aᵢbᵢ|
```

**Degeneracy at h → ∞:** If `h ≥ 10¹⁰` and the operands scale with `h`, then `Σ|aᵢbᵢ| ~ h²` while `Σ aᵢbᵢ` may cancel to `O(1)`. Then `κ ~ h² ~ 10²⁰`, and even Neumaier's `2u·Σ|aᵢbᵢ|` term becomes `~10²⁰ · 10⁻¹⁶ = 10⁴` — **catastrophic**. Neumaier does **not** save you from ill-conditioning; it only removes the `n` factor.

**Required mitigation:** Pre-scale by `1/h` before the dot product, or use **double-double** (Dekker/Knuth two-sum + two-product) if `κ > 10¹²`. The spec does not mention this — **defect**.

### 2.2 Subnormal audit at `−12`, `−14`

If these are `2⁻¹²` and `2⁻¹⁴`, they are **normal** in FP64 (min normal exponent is `−1022`). If they are *exponents* `−12`, `−14` applied to a mantissa, still normal. **The audit is testing the wrong regime.** True subnormal FP64 lives at `2⁻¹⁰²²` down to `2⁻¹⁰⁷⁴`. If the audit points are `−12`/`−14` in *decimal* exponent (`10⁻¹²`, `10⁻¹⁴`), those are also normal.

**Verdict:** Either the audit is mislabeled, or it is testing **denormalized intermediate products** (e.g., `a·b` underflows to subnormal before accumulation). The latter is real: if `|aᵢbᵢ| < 2⁻¹⁰²²`, the product loses precision. Neumaier's compensation term `(a − (s+a)) + s` can itself underflow. **Recommendation:** flush-to-zero (FTZ) must be **disabled** on the AVX-512 path, or the audit must explicitly test `2⁻¹⁰⁵⁰`-scale operands.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the descriptor's `offset` and `stride` to be validated against the actual buffer bounds **before** the kernel dereferences. If validation is done *after* the first load, it is not zero-copy-safe. The spec must state: validation is a **precondition** on the descriptor, checked in `O(1)`, with `nbytes` and `offset + nbytes ≤ buffer_size`.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier

**This is the most dangerous item in the audit.** `panic=unwind` across an FFI boundary is **undefined behavior** unless the panic is caught at the boundary. Rust's `extern "C"` functions **abort** on unwind (since Rust 1.71, `extern "C"` is `nounwind` by default). If the spec claims `panic=unwind` provides a "safety barrier," that is **false** — it provides a *crash*, not a barrier.

**Correct pattern:**
```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```
with `extern "C"` (not `extern "C-unwind"` unless the C side is prepared to unwind).

**Verdict:** If the spec relies on `panic=unwind` alone, it is **non-compliant with FFI hardening**. Demand `catch_unwind` at every `#[no_mangle]` boundary.

### 3.2 Packed 88-byte descriptor

`#[repr(C, packed)]` on a struct containing `u64` fields causes **unaligned loads** on every field access. On x86 this is a performance hit; on ARM (Trainium host) it can be a **SIGBUS**. The correct pattern is `#[repr(C)]` with explicit `#[repr(align(8))]` and manual padding, or `#[repr(C, packed(8))]` (Rust 1.33+) which packs to 8-byte alignment.

**Recommendation:** Use `#[repr(C, packed(8))]` and verify `size_of::<PmtpTensorDescriptor>() == 88` with a `const _: () = assert!(...)`.

### 3.3 Safe SIMD

Rust's `std::simd` is still nightly. If the spec uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" is therefore either (a) a wrapper with `unsafe` inside, or (b) `std::simd` on nightly. The spec must declare which. If (a), the safety invariant must be documented: **alignment, no aliasing, no NaN propagation across lanes**.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in `ℝ^(2K × 2K)`

The Cayley retraction on the Stiefel manifold `St(n,p)` is:
```
Y(h) = (I − (h/2) A)⁻¹ (I + (h/2) A) Y₀,   A = Y₀ᵀ∇F − ∇FᵀY₀  (sk