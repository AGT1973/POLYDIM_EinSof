# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 106

No public, verifiable specification or tribunal reports for **POLYDIM V1350**, its six kernels, or the **PMTP 88-byte Descriptor** were found in the available evidence. Therefore, a definitive arbitration among Claude, Qwen, Kimi, Gemini, DeepSeek, and Perplexity cannot honestly be presented as an empirical adjudication. The strongest defensible synthesis is a set of **conditional architectural guarantees** grounded in numerical linear algebra and language memory models.

## 1. Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

Let \(X\in\mathbb{R}^{m\times n}\) satisfy \(X^\mathsf{T}X=I\), and let \(Z=X+\alpha D\) be the trial point.

| Method | Guarantee under extreme step | Main failure mode | Arbitration |
|---|---|---|---|
| Cayley retraction | Orthogonality in exact arithmetic if the Cayley system is nonsingular; the canonical form requires that the relevant transformed operator not have eigenvalue \(-1\). Its conditioning is favorable locally, but not an unconditional large-step guarantee.[10] | Singular or badly conditioned linear solve; overflow, cancellation, loss of orthogonality, and breakdown when the transform approaches its excluded eigenvalue | Not sufficient as the sole extreme-step path |
| Householder QR | Produces an orthogonal \(Q\) in exact arithmetic and is generally backward stable when implemented with standard blocked Householder reflectors | Factorization of an overflowed or nonfinite input; sign conventions and rank deficiency must be handled explicitly | Best default robust fallback |
| Polar factor | Gives the closest orthogonal factor to a full-rank matrix and has strong geometric meaning; the cited analysis reports a bounded local condition number for polar-light retraction, but also an eigenvalue exclusion condition.[10] | Singular or nearly rank-deficient \(Z\); iterative polar methods can stagnate or overflow without scaling | Strong alternative, especially with scaling and rank checks |

The mathematically superior policy is therefore **not “Cayley always wins.”** Use a **scaled, guarded hybrid**:

1. Compute a norm or exponent estimate for \(Z\) and rescale before forming products.
2. Reject nonfinite inputs immediately.
3. Attempt Cayley only when a conditioning estimate and denominator/spectral guard pass.
4. Otherwise use Householder QR, preferably with column pivoting if rank deficiency is possible.
5. Optionally refine with a polar iteration if the application requires the closest orthogonal factor.
6. Verify
   \[
   \|Q^\mathsf{T}Q-I\| \le \tau_{\mathrm{orth}}
   \]
   and verify finite residuals before publishing the result.
7. On failure, return an explicit status and do not publish a partially formed matrix.

For \(|\alpha|\ge 10^{10}\), no floating-point implementation can promise stability merely from the mathematical identity of a retraction. The guarantee must be stated in terms of **scaled inputs, finite arithmetic, solver status, backward error, and postcondition checks**. QR is the appropriate unconditional *algorithmic fallback*, not an unconditional guarantee for already-overflowed data.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release semantics provide a happens-before edge only when the acquire operation observes the value, or an appropriate release sequence, from the corresponding release operation on the **same atomic synchronization object**.[1][3] They do not make an entire descriptor automatically atomic, nor do they make unrelated payload accesses safe.

The correct publication protocol is:

```text
writer:
    construct immutable payload
    construct descriptor fields
    release-store descriptor pointer/version

reader:
    acquire-load descriptor pointer/version
    read descriptor and immutable payload
    enter/confirm RCU or QSBR read-side protection
    use the snapshot
    leave/advance read-side state

reclaimer:
    retire old snapshot
    wait for the grace-period condition
    reclaim only after every pre-existing reader is quiescent
```

The exact guarantee is:

- A reader that successfully acquires the published generation sees all writes sequenced before the release publication.
- The snapshot remains immutable while that reader uses it.
- Reclamation is safe only after the RCU/QSBR grace-period protocol proves that no reader can still hold a reference.
- Acquire/release alone does **not** prevent use-after-free, ABA, torn multiword updates, or races on mutable payload fields.
- If the 88-byte descriptor is larger than the platform’s lock-free atomic width, it must be published through an atomic pointer, indirection, seqlock-style protocol, or another explicitly validated mechanism; copying the 88 bytes nonatomically is not a portable atomic snapshot.

The descriptor should therefore be treated as an **immutable object identified by an atomically published pointer or generation token**, rather than as one presumed-atomic 88-byte value. The release/acquire ordering model is consistent between C++20 and Rust; Rust documents that its orderings correspond to the C++20 model, including release publication and acquire observation.[1][3][4]

A portable PMTP guarantee should require:

\[
\text{publish}_{\mathrm{release}}(p,g)
\;\;\text{ synchronizes with }\;\;
\text{observe}_{\mathrm{acquire}}(p,g),
\]

followed by:

\[
\text{reclaim}(p)
\quad\text{only after}\quad
\forall r,\; \text{quiescent}(r,g).
\]

For QSBR specifically, “quiescent” must mean that the reader has reported a post-publication quiescent state according to the implementation’s documented protocol. Merely reading the generation counter is not enough.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single source-level claim of identical memory and numerical behavior across these environments is too strong. They have different execution and compilation models:

- **C++20/Rust:** define language-level atomic ordering, but only for operations expressed through their respective atomic APIs and supported target mappings.[1][3][4]
- **CUDA:** requires CUDA atomics, scopes, fences, and explicit stream/device visibility rules. Host-language acquire/release semantics cannot simply be assumed to cover device memory or all agents.
- **Triton:** abstracts GPU kernels and may reorder or vectorize operations according to its compiler and target semantics; synchronization must use supported Triton primitives and target-specific guarantees.
- **XLA:** is graph/compiler based. A custom kernel’s internal protocol is not automatically equivalent to a general host-memory RCU protocol; token dependencies, custom calls, buffer donation, and stream ordering must be specified.
- **Multi-silicon execution:** requires separate validation for alignment, endianness, atomic widths, cache coherence, address spaces, floating-point modes, and compiler lowering.

The defensible conformance contract is therefore layered:

### Numerical contract

For every backend:

\[
\|Q^\mathsf{T}Q-I\| \le \tau_{\mathrm{backend}},
\]

with explicitly documented tolerances, scaling rules, NaN/Inf behavior, rank-deficiency behavior, and deterministic or nondeterministic reduction policy.

### Publication contract

For every backend that participates in snapshot publication:

- descriptor storage is correctly aligned;
- publication uses a supported atomic pointer/version operation;
- the release and acquire operations address the same synchronization location;
- payload is immutable after publication;
- reclamation is performed only by a host/device protocol that actually spans all participating agents.

### Execution contract

For each target, document:

- memory scope: thread, block, device, host, or system;
- synchronization primitive;
- stream or graph dependency;
- ownership of allocation and reclamation;
- supported atomic widths;
- whether the descriptor is host-visible, device-visible, or mirrored.

Without these per-backend definitions, “conformance” means only that the code compiles, not that it has equivalent semantics.

## Definitive arbitration

The strongest SOTA synthesis is:

1. **Retraction:** use a scaled Cayley implementation for ordinary, well-conditioned steps; use guarded Householder QR as the extreme-step correctness path; optionally use a scaled polar refinement when nearest-orthogonal projection is required. Cayley has no unconditional superiority at \(|\mathrm{step}|\ge10^{10}\).
2. **Descriptor publication:** publish an immutable descriptor through an atomic pointer or generation—not as an assumed atomic 88-byte blob. Pair release publication with acquire observation on the same atomic location.
3. **RCU/QSBR:** acquire/release orders initialization, while the grace-period mechanism provides lifetime safety. Neither mechanism substitutes for the other.
4. **Portability:** define a semantic ABI and implement backend-specific synchronization adapters. C++20 and Rust can share the abstract memory-order contract, but CUDA, Triton, and XLA require explicit device-, scope-, and graph-level mappings.
5. **Guarantee boundary:** the system may guarantee postcondition-checked orthogonality, publication visibility, and reclamation safety only under stated preconditions. It cannot guarantee mathematical stability, atomicity of an 88-byte object, or cross-silicon equivalence from names or source compatibility alone.

Thus, any tribunal finding that declares **Cayley unconditionally stable at extreme step**, **Acquire/Release alone sufficient for RCU reclamation**, or **source-level equivalence across all five execution ecosystems** is mathematically and architecturally overstated.