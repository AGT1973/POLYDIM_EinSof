# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 108)

# POLYDIM V1350 — High Tribunal Audit, Cycle 108

**Presiding note.** The Tribunal treats the six artifacts as *claimed* implementations. Where source is not in evidence, we audit the *specification* and flag every claim that requires a witness (source line, test vector, or CI artifact) before it can be certified. Verdicts are issued per target, then consolidated.

---

## 0. Cross-cutting invariants (applied to all six targets)

### 0.1 Rule 22 — Zero 1D tokens, 88-byte PMTP

The descriptor layout `<4sHHQQQQQBB6x4Q` decodes as:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | 4s | 4 | 0 |
| version | H | 2 | 4 |
| flags | H | 2 | 6 |
| n_rows | Q | 8 | 8 |
| n_cols | Q | 8 | 16 |
| stride | Q | 8 | 24 |
| dtype | Q | 8 | 32 |
| scale_bits | Q | 8 | 40 |
| rank | B | 1 | 48 |
| pad0 | B | 1 | 49 |
| pad1 | 6x | 6 | 50 |
| reserved | 4Q | 32 | 56 |
| **Total** | | **88** | |

**Finding 0.1.1 (structural).** 4+2+2+8·5+1+1+6+32 = 88. ✅ Layout is byte-exact and naturally aligned to 8 (all Q fields at 8-aligned offsets: 8,16,24,32,40,56). No `#pragma pack` required on x86-64/aarch64; on 32-bit ARM the `Q` fields would misalign — **require `alignas(8)` on the struct in C++/Rust and `__attribute__((aligned(8)))` in CUDA**.

**Finding 0.1.2 (Rule 22 semantic).** "Zero 1D tokens" means no scalar/vector payload may cross the FFI boundary outside the 88-byte descriptor. Audit:
- T1 (Python): must serialize via `struct.pack('<4sHHQQQQQBB6x4Q', ...)`. Any `ctypes.Structure` with implicit padding is a **violation**.
- T2 (C++): `static_assert(sizeof(PmtpDescriptor)==88)` and `static_assert(alignof(...)==8)` are **mandatory**; absence is a Rule 22 breach.
- T3 (Rust): `#[repr(C, align(8))]` + `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` — the const-assert is the only acceptable proof.
- T4 (CUDA): descriptor must be passed by value in `__grid_constant__` or via `cudaMemcpyAsync` of exactly 88 bytes; **no `cudaMalloc` of a padded struct**.
- T5 (XLA): JAX `ShapeDtypeStruct` cannot carry the descriptor; it must be a `jnp.uint8[88]` buffer with `jax.lax.bitcast` on the host side. Any Python-side `dict` crossing the PJRT boundary is a **1D-token leak**.
- T6 (Triton): the descriptor must be a `tl.constexpr`-free runtime argument passed as `tl.uint8` pointer; Triton's default `int64` scalar args are **1D tokens** and violate Rule 22.

**Verdict 0.1:** Layout ✅. Compliance is **conditional** on the per-target assertions above; T5 and T6 are the highest-risk.

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor surface | Lock risk |
|---|---|---|
| T1 | none (pure Python) | ✅ |
| T2 | AVX-512 (Intel/AMD), OpenMP | ⚠️ AVX-512 absent on Zen4 mobile, Apple, ARM |
| T3 | portable SIMD | ✅ (if `std::simd` or `wide` crate) |
| T4 | CUDA + cuSOLVER | ❌ hard lock |
| T5 | XLA/PJRT (TPU **or** Trainium) | ⚠️ dual-vendor is acceptable *if* both backends are exercised in CI |
| T6 | ROCm **and** NVIDIA | ⚠️ dual-vendor, but Triton-on-ROCm is a moving target |

**Finding 0.2.1.** T4 is the only **hard** Rule 27 violation unless a CPU fallback path (T2) is registered under the same `PmtpSlabAllocator` ABI. **Recommendation:** mandate a `PmtpBackend` vtable with `{probe, alloc, dispatch, free}` and require T4 to register as one of ≥2 backends.

**Finding 0.2.2.** T2's AVX-512 must be gated by `__builtin_cpu_supports("avx512f")` with a scalar/AVX2 fallback; otherwise Rule 27 is breached on non-AVX-512 silicon.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy

**step → ∞ (|step| ≥ 10¹⁰).** The orchestrator itself is control-plane; degeneracy enters via the `scale_bits` field. If `scale = 2^e` with `e` near `Q`-range, `step/scale` underflows to 0 in FP64 when `e > 1074 + log2|step|`. **Proof obligation:** the orchestrator must clamp `e ∈ [-1022, 1023]` before packing, else the Woodbury solve in T4 receives a zero RHS.

**step → 0 (subnormal).** `scale_bits` as a raw `Q` reinterpreted to `f64` can land in `[2^-1074, 2^-1022)`. The orchestrator must **flush-to-zero or reject** subnormal scales; otherwise T2's Neumaier compensation will *preserve* the subnormal and T4's cuSOLVER will silently denormalize.

**Recommendation 1.1.** Add a `validate_scale()` gate: reject `|scale| < 2^-1022` or `|scale| > 2^1023`, and emit a `PMTP_ERR_SUBNORMAL_SCALE` code in the `flags` field.

### 1.2 Rule 22

The 12/12 physical conformance checks are the right shape, but the Tribunal demands the **check list** be enumerated in the audit artifact. Without it, "12/12" is unfalsifiable. **Demand:** publish the 12 predicates (magic, version, flags, alignment, size, endianness, reserved-zero, rank≤255, stride≥cols, dtype∈enum, scale finite, checksum).

### 1.3 Rule 27

✅ No vendor lock. **But** `HardwareProbe` must not *require* any specific silicon to import the module; probe failures must degrade, not raise.

### 1.4 FFI hardening

- Use `struct.Struct('<4sHHQQQQQBB6x4Q')` (precompiled) — never `ctypes` with implicit padding.
- Pin `sys.byteorder == 'little'` at import; big-endian hosts must byte-swap.
- Add `assert s.size == 88` at module load.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Numerical degeneracy

**Neumaier compensated dot.** For `x·y` with `|x_i y_i|` spanning > 2⁵³, the compensation term `c` can itself lose bits. The **asymptotic condition number** of the compensated sum is

κ_Neumaier ≈ 1 + n·u / (1 − n·u),  u = 2⁻⁵³,

so for `n = 2^20` (a 1M-element dot), κ ≈ 1 + 2^20·2^-53 ≈ 1 + 2^-33 — **safe**. But if `step → ∞` drives `x_i` into overflow (`|x_i| > 2^1023`), Neumaier's `t = s + x_i` produces `inf`, and `c` becomes `NaN`. **Proof obligation:** the kernel must pre-scale by `1/‖x‖_∞` and post-scale, or reject `‖x‖_∞ > 2^1000`.

**Subnormal audits (−12, −14).** These are exponents; `2^-12` and `2^-14` are *normal* in FP64 (min normal exponent is −1022). The audit is therefore **trivially passing** and does not exercise the subnormal regime. **Demand:** re-run with exponents −1022, −1023, −1074 (min subnormal) and assert FTZ/DAZ behavior matches the declared `MXCSR` policy.

### 2.2 Rule 22

`static_assert(sizeof(PmtpDescriptor)==88)` and `static_assert(alignof(PmtpDescriptor)==8)` are **mandatory**. Zero-copy PMTP validation must check `reinterpret_cast<uintptr_t>(ptr) % 64 == 0` for AVX-512 alignment.

### 2.3 Rule 27

AVX-512 is a **soft lock**. **Recommendation:** compile-time dispatch via `__attribute__((target_clones("avx512f","avx2","default")))` on the hot dot-product, and runtime `__builtin_cpu_supports` gate. OpenMP must not assume `OMP_NUM_THREADS` — use `omp_get_max_threads()`.

### 2.4 FFI hardening

- `extern "C"` with `noexcept` on every boundary function.
- `-fno-exceptions` at the FFI TU, or wrap in `try/catch(...)` and return `PMTP_ERR_CPP_EXCEPTION`.
- `-fno-strict-aliasing` is **not** needed if you use `std::memcpy` for descriptor marshalling; prefer that over `reinterpret_cast`.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 Numerical degeneracy

Same Neumaier analysis as T2. Rust's `f64::mul_add` (FMA) is **not** a substitute for Neumaier — FMA gives correctly-rounded `a*b+c` but does not accumulate compensation. **Demand:** the Neumaier loop must be `let t = s + x; if s.abs() >= x.abs() { c += (s - t) + x } else { c += (x - t) + s }`.

**Subnormal:** Rust does not set FTZ by default; `f64::MIN_POSITIVE` is `2^-1022`. Subnormal inputs are preserved. If the C++ side sets FTZ, the two kernels **disagree** on subnormal inputs —