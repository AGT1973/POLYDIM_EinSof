# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 112

The public evidence available here does **not contain the six Tribunal models’ reports or a verifiable V1350 specification**. The search results identify PolyDiM as a C++ library for polytopal discretization methods, but do not document “V1350,” six kernels, or an “88-byte PMTP descriptor.”[2][7] Therefore, no defensible arbitration can declare one model’s empirical findings superior. The following is the strongest standards-based synthesis that can be made from the stated design goals.

## 1. Extreme-step Stiefel retraction

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), \(X^\top X=I\), a tangent update \(\Delta\), and extreme step \(t\), the central issue is not merely the retraction formula but **overflow, conditioning, and loss of orthogonality**.

### Arbitration

| Method | Mathematical behavior for \(|t|\ge 10^{10}\) | SOTA judgment |
|---|---|---|
| Cayley retraction | Can preserve orthogonality in exact arithmetic because it applies an orthogonal transform, typically through a solve involving \(I\pm A\), where \(A^\top=-A\). Numerical failure occurs if scaling, factorization, or solve accuracy is inadequate. | Preferred as the primary kernel if implemented with norm scaling, stable factorization, and residual checks. |
| Householder QR | Orthogonality is generally backward stable and Householder transformations avoid the explicit formation of normal equations. However, QR of a matrix dominated by an enormous step can produce a numerically valid orthogonal basis that is poorly related to the intended geodesic/retraction path. | Strong fallback and validation method; often the best robustness reference. |
| Polar retraction | The polar factor is the closest orthogonal/Stiefel factor in the Frobenius norm and is geometrically attractive. Its computation requires a stable SVD or symmetric eigensolver; direct \(Y(Y^\top Y)^{-1/2}\) is unsafe for extreme scaling. | Best geometric projection, but expensive and implementation-sensitive. |

The correct conclusion is **not** that Cayley is unconditionally more stable than Householder or polar QR. In finite precision, a Cayley kernel can be superior for preserving the intended orthogonal flow, while Householder QR is usually the safer generic orthogonalization fallback. Polar retraction is preferable when nearest-point geometry matters more than throughput.

A mathematically defensible implementation should compute a scaled update,

\[
\widehat{\Delta}=\frac{t\Delta}{s},
\qquad
s=\max\!\left(1,\|t\Delta\|_{\mathrm{scale}}\right),
\]

apply the Cayley transform to the scaled representation, and avoid forming quantities whose magnitude is \(O(t^2)\). It should then verify

\[
\|Q^\top Q-I\| \le c\,u\,\kappa_{\mathrm{op}},
\]

where \(u\) is machine epsilon and \(\kappa_{\mathrm{op}}\) captures the conditioning of the solve and matrix representation.

### Architectural guarantee

A valid guarantee is:

> For finite, representable inputs and a successful backward-stable factorization, the kernel returns a matrix whose orthogonality defect is bounded by the implementation’s stated floating-point error bound. It does **not** guarantee accuracy relative to the unscaled mathematical update when \(t\Delta\) overflows, underflows, or is ill-conditioned.

For production use, the exact fallback policy should be:

1. Attempt scaled Cayley.
2. Check solve residual and orthogonality defect.
3. Fall back to Householder QR if either threshold fails.
4. Use polar/SVD only when nearest orthogonal projection is explicitly required.

That is stronger than claiming unconditional Cayley stability.

## 2. PMTP 88-byte descriptor and RCU/QSBR

No public result establishes the PMTP layout or its field alignment. The available RCU/QSBR evidence supports the standard publication rule: initialize the object, publish its pointer with a release operation, and read it with an acquire operation; the acquire load then observes writes sequenced before the release.[8][12]

### Required memory-order protocol

For immutable snapshot publication:

```text
writer:
    initialize all descriptor fields
    store-release(published_snapshot, new_descriptor)

reader:
    enter RCU/QSBR read-side critical section
    snapshot = load-acquire(published_snapshot)
    read descriptor fields
    leave read-side critical section

reclaimer:
    remove or replace published pointer
    wait for a complete grace period
    reclaim old descriptor
```

The exact guarantees are:

- **Release publication** orders descriptor initialization before publication.
- **Acquire consumption** prevents the reader from observing the pointer without the initialized state that it publishes.
- **RCU/QSBR grace-period completion** prevents reclamation while a registered reader may still hold the descriptor.
- Acquire/release operations alone do **not** provide reclamation safety.
- QSBR is correct only if every participating reader reports quiescent states according to the protocol; stalled, unregistered, or incorrectly instrumented readers can indefinitely delay reclamation.
- If descriptor fields are mutable after publication, they require their own synchronization; snapshot publication does not make later mutation safe.

An 88-byte size is an ABI/layout constraint, not a memory-model guarantee. The descriptor must specify:

- field offsets and alignment;
- atomic versus non-atomic fields;
- ownership and lifetime rules;
- endianness and representation;
- cache-line placement or false-sharing policy;
- whether a pointer is protected by RCU before dereference;
- release/acquire requirements for every publication path.

### Architectural guarantee

The strongest valid guarantee is:

> Any reader that enters the read-side critical section before acquiring the published pointer, and any writer that performs release publication followed by a completed QSBR/RCU grace period before reclamation, observes a fully initialized immutable snapshot and cannot dereference reclaimed storage.

It is not valid to guarantee snapshot isolation merely because the descriptor is 88 bytes or because a single atomic pointer exists.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

The search results show that Triton kernels can be integrated into PyTorch/XLA execution graphs, but they do not establish conformance for the claimed V1350 kernels across all five targets.[13] Cross-silicon conformance therefore requires an explicit semantic contract rather than source-level similarity.

### Portable semantic core

The common contract should define:

- tensor shapes, strides, layouts, and aliasing;
- scalar types and accumulation precision;
- NaN, infinity, signed-zero, and overflow behavior;
- deterministic versus nondeterministic reductions;
- permitted error bounds;
- alignment requirements;
- synchronization scope;
- descriptor ownership and lifetime;
- failure behavior for unsupported dimensions or extreme values.

### Backend-specific limitations

- **CUDA:** A kernel’s memory ordering is scoped; device-wide visibility and host visibility are distinct. CUDA atomics and fences must be selected according to the publication domain.
- **Triton:** Compilation and supported atomic/barrier behavior depend on backend and compiler version. The semantic contract must not assume arbitrary C++-style memory orders unless the generated backend provides them.
- **XLA:** Operations may be reordered, fused, replicated, or lowered differently. Side effects and synchronization must be represented through supported XLA mechanisms rather than inferred from source order.
- **C++20:** The abstract machine provides portable atomic ordering, but it does not define GPU execution behavior. Host and device implementations need separate conformance tests.
- **Rust:** Rust’s type and ownership guarantees do not automatically make foreign GPU memory, atomics, or FFI descriptors safe. `unsafe` boundaries must encode layout, lifetime, alignment, and synchronization invariants.

### Conformance levels

A rigorous arbitration should distinguish:

1. **Bitwise conformance:** identical output bits; usually unrealistic across CUDA, XLA, Triton, C++20, and Rust for floating-point kernels.
2. **Numerical conformance:** outputs satisfy a specified normwise or componentwise error bound.
3. **Structural conformance:** identical shape, layout, aliasing, and failure semantics.
4. **Memory-model conformance:** all publication, visibility, and reclamation obligations are met.
5. **Performance conformance:** throughput or latency targets under a fixed benchmark protocol.

Only levels 2–4 should be treated as portable correctness guarantees unless deterministic arithmetic has been deliberately engineered.

## Definitive synthesis

The mathematically strongest architecture is a **layered design**:

- **Numerical layer:** scaled Cayley retraction as the fast path, with residual validation and Householder QR fallback; stable polar/SVD only for nearest-point projection requirements.
- **State-publication layer:** immutable descriptors, release publication, acquire consumption, explicit RCU/QSBR read-side entry and grace-period reclamation.
- **ABI layer:** a versioned, statically asserted 88-byte layout with declared offsets, alignment, endianness, and atomic fields.
- **Backend layer:** separate CUDA, Triton, XLA, C++20, and Rust implementations conforming to one semantic specification, not one assumed execution model.
- **Verification layer:** adversarial tests for \(|t|\ge 10^{10}\), overflow and underflow, ill-conditioned solves, delayed readers, stalled QSBR participants, descriptor reuse, NaNs, noncontiguous layouts, and cross-device reductions.

Accordingly, the defensible arbitration is:

> **Cayley is the preferred extreme-step fast path only with scaling and postcondition checks; Householder QR is the robustness fallback; polar is the geometric reference. Acquire/release establishes publication visibility, while RCU/QSBR establishes lifetime safety. Cross-silicon conformance is achievable for explicitly defined numerical, structural, and memory-model contracts, but not guaranteed by common source code, descriptor size, or model consensus alone.**

Claims of unconditional stability, automatic snapshot isolation, or exact five-backend conformance would require the missing Tribunal reports, source code, ABI specification, numerical bounds, and reproducible cross-silicon test results.