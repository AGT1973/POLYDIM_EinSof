# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 103)

# POLYDIM V1350 — High Tribunal Audit, Cycle 103

**Verdict posture:** The architecture is *plausible* but the audit brief contains several claims that cannot be verified from the artifact names alone. I will separate **what is provable from the stated invariants**, **what is conditionally sound**, and **what is a red flag requiring source-level evidence**. I will not fabricate line numbers or benchmark numbers.

---

## 0. Preliminary: what the brief actually asserts

The six targets share a common contract:

- **88-byte PMTP descriptor** with layout `<4sHHQQQQQBB6x4Q` (Python `struct`).
- **Rule 22:** zero 1D tokens in inter-agent communication; 88-byte PMTP only.
- **Rule 27:** no vendor lock.
- Numerical core: Neumaier compensated summation, Stiefel Cayley retraction, Lyapunov solve, Clifford bivector rotations.

Let me first audit the **descriptor** because every other claim depends on it.

### 0.1 Struct layout arithmetic

`<4sHHQQQQQBB6x4Q` under `struct` (little-endian, no alignment padding because `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | 4s | 4 |
| f1 | H | 2 |
| f2 | H | 2 |
| q1..q5 | 5×Q | 40 |
| b1,b2 | 2×B | 2 |
| pad | 6x | 6 |
| q6..q9 | 4×Q | 32 |
| **Total** | | **88** |

✅ **88 bytes confirmed.** This is the one hard, checkable claim in the brief and it holds.

**Tribunal note:** `6x` is *explicit* padding, so the struct is endian-stable and ABI-stable across C++/Rust/CUDA/XLA/Triton **only if** every binding uses the same `<` (little-endian) format. On big-endian hosts (POWER9, s390x) this silently mis-parses. **Recommendation:** assert `sys.byteorder == 'little'` at import, or emit a `>4sHHQQQQQBB6x4Q` variant. This is a Rule 27 (portability) concern, not a vendor-lock concern.

---

## 1. Numerical degeneracy: step → ∞ and step → 0

### 1.1 Neumaier compensated dot product (Targets 2, 3)

Neumaier's algorithm:

```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
    else:                c += (x_i*y_i - t) + s
    s = t
return s + c
```

**Error bound (Neumaier 1974, Rump 2009):** for `n` terms with unit roundoff `u`,

```
|fl(Σ x_i y_i) − Σ x_i y_i|  ≤  (n u + O(n²u²)) · Σ |x_i y_i|
```

i.e. **relative error is bounded by `n·u` regardless of cancellation**, provided no overflow/underflow in the intermediate `t`.

**Degeneracy at step → ∞ (|step| ≥ 10¹⁰):**

- If `step` enters as a *scalar multiplier* on the dot product, the compensated sum is still accurate *relative to the scaled magnitude*, but the **absolute** error scales with `|step|`. For a Stiefel retraction `Y = (I − (step/2)W)⁻¹(I + (step/2)W)X`, the Woodbury form `(M/scale)W = (step/scale)B` is the correct mitigation — **provided `scale` is chosen as `max(|step|, ‖B‖_F, ε_min)`**. If `scale` is a compile-time constant, you get overflow at `step ≈ 10¹⁵⁴` (FP64) and catastrophic cancellation well before that.
- **Required proof obligation:** show `scale = Θ(max(|step|, ‖B‖_F))` and that the compensated sum is applied to the *scaled* quantities. Without the source, I cannot certify this.

**Degeneracy at step → 0 (subnormals, −12, −14 exponents):**

- The brief cites "subnormal audits (−12, −14)". These are **decimal exponents**, i.e. `10⁻¹²` and `10⁻¹⁴`, *not* FP64 subnormals (which begin at `2⁻¹⁰²² ≈ 2.2×10⁻³⁰⁸`). If the audit is checking `10⁻¹²`/`10⁻¹⁴` magnitudes, that is **normal-range FP64** and Neumaier is fine.
- **If** the code actually probes FP64 subnormals, then:
  - Neumaier's `c` term can itself underflow to subnormal, and the final `s + c` loses the compensation. **Error bound degrades to absolute, not relative.**
  - AVX-512 `vfmadd` with FTZ/DAZ set (common in `-ffast-math` builds) will **flush subnormals to zero**, silently breaking the audit. **Recommendation:** compile with `-fno-fast-math` and explicitly clear FTZ/DAZ in MXCSR before the audit kernel, or use `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`.
  - Rust: `f64` arithmetic is IEEE-754 by default, but `core::intrinsics::fadd_fast` (unstable) or `-C target-feature=+fma` with `fast-math`-style flags can change this. **Rust 2021 safe SIMD does not enable FTZ by default** — good.

**Tribunal ruling:** The subnormal claim is **ambiguous** and must be disambiguated. If "−12/−14" means decimal exponents, the audit is trivial. If it means FP64 subnormals, the audit is **not** satisfied by Neumaier alone.

### 1.2 Stiefel Cayley retraction (Target 4)

Cayley: `Y(step) = (I − (step/2)W)⁻¹ (I + (step/2)W) X`, `W = A Xᵀ − X Aᵀ` skew.

- **step → 0:** `Y → X + step·W X + O(step²)`. Condition number of `(I − (step/2)W)` → 1. **Stable.**
- **step → ∞:** `(I − (step/2)W)⁻¹ → −(2/step)W⁻¹` (if `W` invertible). The retraction **does not converge to a limit point on the Stiefel manifold**; it oscillates. The Woodbury scaling `(M/scale)W = (step/scale)B` is the right fix **only if** `M` is the *shifted* matrix `I − (step/2)W` and `scale` absorbs `step`. The brief's notation `(M/scale)W = (step/scale)B` is dimensionally suspicious: `W` on the left, `B` on the right, `M` a matrix — this looks like a **Sylvester/Lyapunov** form, not a Cayley form. **Flag: the brief may be conflating two different solvers.**
- **cuSOLVER `DnDsyevd`:** this is a *symmetric* eigensolver. `W` is skew-symmetric. `DnDsyevd` on a skew matrix is **mathematically wrong** unless the code symmetrizes `iW` (which is Hermitian). **This is the single most serious red flag in the brief.** If the code passes `W` directly to `DnDsyevd`, the eigenvalues are garbage. If it passes `iW` as a complex Hermitian matrix, then `DnDsyevd` is the wrong routine — you want `zheevd`. **Demand source evidence.**

### 1.3 Continuous Lyapunov solve (Target 5)

`A X + X Aᵀ + Q = 0`. Condition number:

```
κ(X) ≤ κ(A)² · κ(Q) · (1 + ‖A‖·‖X‖/‖Q‖)
```

For `A` with eigenvalues near the imaginary axis, `κ → ∞`. **Pure FP64 in HBM does not save you** — the Bartels–Stewart algorithm's backward error is `O(u·‖A‖²)`, and the *forward* error can be `O(u·κ(A)²)`. **Recommendation:** require `min_i Re(λ_i(A)) < −δ` for some `δ > 0` and report `δ` in the descriptor. If the descriptor has no field for `δ`, Rule 22 is being violated in spirit (the 88 bytes are not carrying the conditioning metadata needed for safe inter-agent use).

### 1.4 Clifford bivector rotations (Target 6)

Streaming bivector rotations `R = exp(θ B)` with `B² = −1`:

- **step → 0:** `R ≈ I + θB`, fine.
- **step → ∞:** `exp(θB)` is **bounded** (it's a rotation), so no overflow. But the *streaming* implementation accumulates products `R_1 R_2 … R_n`; each product is orthogonal, so `‖R‖ = 1` exactly in exact arithmetic, but in FP the error grows as `O(n·u)`. For `n = 10⁹` streaming steps, `u = 2⁻⁵³`, error `≈ 10⁻⁷` — acceptable. **No degeneracy.**

---

## 2. Rule 22 compliance (zero 1D tokens, 88-byte PMTP)

**What is checkable:**

- The 88-byte struct is confirmed (§0.1).
- "Zero 1D tokens" means no variable-length arrays, no JSON, no strings in the inter-agent channel. The struct has `4s` (magic) and `6x` (pad) — **no variable-length fields**. ✅

**What is NOT checkable from the brief:**

- Whether the *runtime* actually enforces 88 bytes. A Python `struct.pack` will happily produce 88 bytes, but a C++ `reinterpret_cast` of a `struct` with different alignment will produce 96 or 104 bytes. **The `6x` pad only works if the C++ struct is declared `#pragma pack(1)` or `__attribute__((packed))`.** If not, the C++ side has implicit padding and the FFI is broken.
- **Recommendation:** add a `static_assert(sizeof(PmtpTensorDescriptor) == 88)` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` in Rust, and a `struct.calcsize('<4sHHQQQQQBB