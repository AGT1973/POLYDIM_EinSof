# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 79

The six Tribunal findings cannot be independently compared because their actual reports and the V1350 kernel specifications were not provided. The defensible SOTA arbitration is therefore a **conditional architecture**, not a claim that any unverified kernel already satisfies these guarantees.

## 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

**Arbitration:** no mathematically sound implementation can guarantee stability merely because it uses a Cayley transform. A direct Cayley solve, Householder QR, or polar decomposition must all be analyzed with scaling, conditioning, finite-precision error, and failure handling.

For a Stiefel point \(X\) with \(X^\top X=I\), a typical Cayley update has the form

\[
Y=(I-\tfrac{\alpha}{2}\Omega)^{-1}(I+\tfrac{\alpha}{2}\Omega)X,
\qquad \Omega^\top=-\Omega .
\]

In exact arithmetic, the Cayley factor is orthogonal whenever the inverse exists. In floating-point arithmetic, however:

- the expression \(I-\frac{\alpha}{2}\Omega\) can be badly scaled for \(\alpha\ge 10^{10}\);
- direct inversion or an unscaled solve can lose relative accuracy;
- iterative Cayley schemes have convergence conditions tied to the norm of the scaled generator, so an extreme step cannot be accepted without normalization or damping;
- orthogonality must be measured and repaired, not assumed.

Householder QR is generally the strongest **robust baseline** for producing an orthonormal basis, provided it uses blocked, pivot-free or appropriately controlled QR and stable sign conventions. Polar retraction has attractive conditioning properties, but its quality depends on the SVD or matrix-square-root implementation and on handling rank deficiency. A recent analysis reports bounded absolute condition numbers for canonical Cayley and polar-light retractions, but those local bounds do not imply stability for an unscaled step of \(10^{10}\).[3]

The definitive policy should therefore be:

\[
\alpha_{\mathrm{eff}}
=
\min\!\left(\alpha,\,
\frac{\eta}{\|\Omega\|}\right),
\]

with a prescribed \(\eta\) below the solver’s stability threshold, followed by a stable solve and an explicit orthogonality check

\[
\|Y^\top Y-I\| \le \tau_{\mathrm{orth}}.
\]

If the check fails, the kernel must fall back to Householder QR or a polar retraction. The guarantee is then:

> **For every finite input and any requested step, the kernel either returns a finite matrix satisfying the specified orthogonality tolerance, or returns a deterministic failure/status code; it must never silently claim a valid Stiefel point.**

Thus, Cayley is preferable for efficient low-rank updates, but **Householder QR should be the conformance oracle and emergency fallback**. No unconditional claim that Cayley is superior to QR or polar at \(|\mathrm{step}|\ge10^{10}\) is justified.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release semantics are necessary but not sufficient for reclamation. A release publication followed by an acquire load synchronizes only when the acquire observes the corresponding release sequence on the same atomic object.[1] Rust states the same rule: writes before a release become ordered before operations following an acquire that reads the released value.[5]

The descriptor should separate:

- immutable configuration and payload metadata;
- an atomic publication/version field;
- ownership or reclamation metadata;
- padding or reserved bytes for ABI stability.

The publication protocol should be conceptually:

```cpp
// Writer:
write_payload(new_descriptor);
published_version.store(v, std::memory_order_release);

// Reader:
enter_qsbr_read_section();
auto v = published_version.load(std::memory_order_acquire);
read_payload_consistent_with(v);
exit_qsbr_read_section();
```

The required guarantee is:

\[
\text{payload writes}
\;\xrightarrow{\mathrm{sb}}\;
\text{release publication}
\;\xrightarrow{\mathrm{sw}}\;
\text{acquire observation}
\;\xrightarrow{\mathrm{sb}}\;
\text{reader payload reads}.
\]

Here `sb` denotes sequenced-before and `sw` denotes synchronizes-with.

However, this does **not** by itself provide snapshot isolation. The design also needs:

- a reader announcement or QSBR epoch protocol;
- a writer-side grace-period wait;
- immutable published snapshots, or a seqlock/version validation loop;
- protection against ABA and descriptor reuse;
- reclamation only after every pre-existing reader has passed a quiescent state.

RCU verification work explicitly treats release/acquire ordering and quiescent-state reporting as jointly necessary before reclamation.[4] QSBR separates logical removal from physical reclamation: removal may be published immediately, but memory cannot be freed until all readers from the prior epoch have quiesced.

The exact architectural guarantee should be:

> A reader that successfully acquires version \(v\) observes one immutable, self-consistent snapshot associated with \(v\), and that snapshot remains allocated until the reader leaves its read-side critical section. No writer may mutate or reclaim that snapshot while such a reader can still access it.

An 88-byte size alone guarantees nothing. The ABI must additionally specify alignment, atomic-field representation, endianness, padding, cache-line behavior, and whether the descriptor is copied by value. If the descriptor contains an atomic object, its layout must be validated separately on every target; a byte-size assertion is not an atomicity proof.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or execution model shared identically by all five environments. C++20 and Rust define language-level atomic semantics; CUDA adds device and scope-specific memory behavior; XLA is an optimizing graph/compiler IR whose operation ordering depends on explicit data dependencies and supported synchronization primitives; Triton exposes a lower-level GPU programming model whose guarantees depend on the generated backend and memory scopes.

Therefore, “multi-silicon conformance” must mean **semantic conformance to a portable contract**, not bit-identical implementation behavior.

The portable contract should define:

- descriptor ABI and alignment;
- ownership and lifetime rules;
- publication and snapshot protocol;
- permitted atomic orders and scopes;
- numerical tolerances;
- deterministic status/error behavior;
- supported layouts, dtypes, and dimensions;
- explicit synchronization boundaries;
- no reliance on undefined races, undocumented compiler behavior, or implicit stream ordering.

The implementation mapping should be:

| Layer | Required conformance rule |
|---|---|
| C++20 | Use standard atomics and establish release/acquire on the same atomic publication variable. |
| Rust | Use `std::sync::atomic` orderings matching the C++ protocol; do not weaken them during FFI translation. |
| CUDA | Use the narrowest correct device/system scope and explicit fences or atomics appropriate to the producer and consumer locations. |
| Triton | Express publication and visibility using operations supported by the target backend; otherwise place the protocol outside the Triton kernel. |
| XLA | Treat snapshots as immutable values and encode dependencies through graph dataflow or a supported collective/barrier primitive; do not assume C++-style shared mutable memory inside an XLA computation. |

The test suite must include:

- CPU and GPU litmus tests for publication ordering;
- delayed readers spanning reclamation epochs;
- ABA and descriptor-reuse tests;
- randomized snapshot/version validation;
- numerical stress at steps through and beyond \(10^{10}\);
- NaN, overflow, singularity, rank-deficiency, and allocation-failure cases;
- cross-backend ABI and layout checks;
- orthogonality residual and reproducibility checks.

## Definitive arbitration

The mathematically strongest synthesis is a **verified hybrid**:

1. **Cayley path** for efficient ordinary updates, with norm scaling, stable linear solves, and explicit residual checks.
2. **Householder QR fallback** as the universal orthonormalization and conformance oracle.
3. **Polar/SVD fallback** where the required metric or closest-point property makes polar retraction preferable.
4. **Release publication plus acquire observation** for descriptor visibility.
5. **QSBR/RCU grace periods** for lifetime safety; acquire/release alone is not reclamation.
6. **Immutable versioned snapshots** to obtain actual snapshot isolation.
7. **A language- and backend-neutral contract** tested independently on CUDA, XLA, Triton, C++20, and Rust.

Accordingly, the exact guarantees that can legitimately be claimed are conditional:

- **Numerical safety:** no silent invalid Stiefel output; either a result meeting tolerance or an explicit failure/fallback.
- **Memory visibility:** readers acquiring a published version observe all writes sequenced before its release publication.
- **Lifetime safety:** reclamation occurs only after the corresponding QSBR/RCU grace period.
- **Snapshot consistency:** each protected reader observes one immutable version, not a mixture of versions.
- **Portability:** behavior is conformant only where the backend implements the specified synchronization, ABI, and numerical contract; portability cannot be inferred from source-level similarity alone.

No stronger unconditional claim—especially that an unscaled Cayley update is stable at \(|\mathrm{step}|\ge10^{10}\), or that acquire/release alone provides RCU isolation—follows from the available evidence.