# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 68)

# POLYDIM V1350 — High Tribunal Audit, Cycle 68

**Presiding note.** The Tribunal will not accept marketing prose. Every claim below is either (a) a theorem with a proof sketch, (b) a counterexample, or (c) an explicit "unverifiable from the artifact as described." Where the artifact is described only by name (e.g., "12/12 physical conformance checks"), the Tribunal treats the claim as **unproven** and flags it.

---

## 0. Preliminary: what the Tribunal can and cannot see

You have given me *descriptions* of six kernels, not their source. Therefore:

- **Numerical claims** (Neumaier, Cayley, Lyapunov, Woodbury) can be audited *as mathematics* — I can state the exact conditions under which they degenerate.
- **Binary-layout claims** (88-byte descriptor, `<4sHHQQQQQBB6x4Q`) can be audited *as struct arithmetic*.
- **Silicon-contract claims** (Rule 27) can be audited *as interface design*.
- **"12/12 conformance"** cannot be audited without the 12 predicates. I will state what they *must* be for the claim to be meaningful.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor

Format string: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `H H` | 4 |
| five `Q` | `Q Q Q Q Q` | 40 |
| two `B` | `B B` | 2 |
| pad | `6x` | 6 |
| four `Q` | `Q Q Q Q` | 32 |
| **Total** | | **88** |

**Arithmetic check:** 4+4+40+2+6+32 = 88. ✅

**Alignment hazard (Rule 22 compliance).** `struct.calcsize('<4sHHQQQQQBB6x4Q')` = 88 **only because `<` forces no alignment**. If any consumer re-declares this as a C `struct` without `__attribute__((packed))`, the compiler will insert padding to align the `Q`s to 8 bytes, and the size will silently become **96 or 104 bytes**. This is the single most common Rule-22 violation in polyglot kernels.

**Recommendation (FFI hardening):**
```c
_Static_assert(sizeof(pmtp_desc_t) == 88, "PMTP descriptor must be 88 bytes");
_Static_assert(offsetof(pmtp_desc_t, field_after_pad) == 56, "...");
```
and in Rust:
```rust
#[repr(C, packed)]
struct PmtpDesc { ... }
const _: () = assert!(core::mem::size_of::<PmtpDesc>() == 88);
```
and in Python:
```python
assert struct.calcsize(FMT) == 88
```

### 1.2 "12/12 physical conformance checks"

Without the list, the Tribunal demands the following **minimum** set for the claim to be non-vacuous:

1. `calcsize == 88` on CPython 3.11+ and 3.12+.
2. Endianness round-trip on little-endian host.
3. `magic` matches a fixed constant (e.g., `b'PMTP'`).
4. All `Q` fields survive `pack→unpack` for values `{0, 1, 2^63-1, 2^64-1}`.
5. `H` fields survive `{0, 65535}`.
6. `B` fields survive `{0, 255}`.
7. `6x` padding is zero on emit (not garbage).
8. Descriptor is byte-identical when re-emitted from a parsed struct (idempotence).
9. Cross-language: C++ `memcpy` of the same struct yields identical bytes.
10. Rust `#[repr(C, packed)]` yields identical bytes.
11. CUDA `__align__(1)` host-side mirror yields identical bytes.
12. No uninitialized bytes leak (valgrind / MSan clean).

If any of these is missing, "12/12" is a **tautology over a weaker set**.

### 1.3 `PmtpSlabAllocator` — degeneracy at step extremes

A slab allocator is size-class based. The degeneracy risk is **not** in `step` but in **descriptor churn**: if `step → ∞` triggers a new descriptor per iteration, the slab pool fragments. The Tribunal requires:

- **Invariant:** descriptor count is `O(1)` in `step`, i.e., the allocator reuses a fixed ring of 88-byte slots.
- **Proof obligation:** show `alloc_count(step) ≤ C` for all `step`, with `C` independent of `step`.

If the allocator is `mmap`-backed with `MAP_HUGETLB`, then at `step ≥ 10^10` the risk is **TLB shootdown storms** across NUMA nodes. Mitigation: pin to a single NUMA node and use `mbind(MPOL_BIND)`.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's algorithm computes `s = Σ xᵢyᵢ` with a running compensation `c`. The **forward error bound** is:

$$
|\hat{s} - s| \le \big(2u + O(nu^2)\big) \sum_i |x_i y_i| + O(u^2)|s|
$$

where `u = 2^{-53}` for FP64. This is **independent of the condition number of the dot product itself** — that is the whole point of compensated summation. However:

**Degeneracy at `step → ∞`.** If `step ≥ 10^10` and the kernel forms `step · B` (as in Target 4's Woodbury), then `|xᵢyᵢ|` grows like `step`, and the *absolute* error grows like `u · step · Σ|Bᵢ|`. The *relative* error stays `O(u)`, but if downstream code compares against an absolute tolerance `ε = 1e-12`, the comparison **fails spuriously**. This is a **tolerance-scaling bug**, not a Neumaier bug.

**Recommendation:** all tolerance checks must be **relative** (`|a-b| ≤ ε·max(|a|,|b|)`) or **scaled** by `step`.

### 2.2 Subnormal audits at `-12, -14`

You cite exponents `-12` and `-14`. For FP64, the subnormal range begins at `2^{-1022} ≈ 2.2e-308`. Exponents `-12` and `-14` are **nowhere near subnormal** — they are ordinary normal numbers. The Tribunal suspects these are **FP32** exponents (FP32 subnormals begin at `2^{-126} ≈ 1.2e-38`), or they are **log-magnitudes** in a different base.

**If they are FP32 exponents:** `2^{-12} ≈ 2.4e-4` and `2^{-14} ≈ 6.1e-5` are still normal. The audit is testing **near-zero but not subnormal** behavior. That is fine, but the label "subnormal audit" is **misleading**.

**If they are log10 magnitudes:** `10^{-12}` and `10^{-14}` are also normal in FP64.

**Verdict:** the Tribunal demands the actual bit patterns tested. A real subnormal audit must include `0x0000000000000001` (smallest FP64 subnormal) and `0x000FFFFFFFFFFFFF` (largest FP64 subnormal).

### 2.3 Zero-copy PMTP validation

"Zero-copy" means the 88-byte descriptor is `mmap`'d or `memcpy`'d once and then read in place. The hazard:

- **Torn reads** if the descriptor is written by another thread while being read. Mitigation: `std::atomic<__int128>` pairs, or a seqlock.
- **Cache-line straddling:** 88 bytes is not a multiple of 64. A descriptor at offset `56 mod 64` straddles two cache lines. Under `-O3 -march=native`, the compiler may emit two loads; under `volatile`, this is a **data race** if the producer writes non-atomically.

**Recommendation:** align descriptors to 128 bytes (`alignas(128)`), wasting 40 bytes per descriptor but eliminating straddle.

### 2.4 AVX-512 / OpenMP

- **AVX-512 downclocking** on Skylake-X: heavy 512-bit FMA can drop the core to 1.4 GHz. For a `step → ∞` loop, this is a **throughput cliff**. Mitigation: use `_mm512_mask_` sparingly, or fall back to AVX2 for short vectors.
- **OpenMP `reduction(+:s)`** does **not** use Neumaier compensation. If you rely on `#pragma omp parallel for reduction(+:s)` for the dot product, you have **silently discarded** the compensation. This is a **correctness bug** if the audit claims Neumaier.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the wrong choice** for an FFI boundary. `panic = unwind` across an `extern "C"` boundary is **undefined behavior** in Rust 2021 unless the function is declared `extern "C-unwind"`. The correct pattern is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```

**Verdict:** `panic = unwind` is **not** a safety barrier; it is a **safety hazard** unless every FFI entry point wraps in `catch_unwind`. The Tribunal demands proof that every `extern "C"` function is either `extern "C-unwind"` or wrapped.

### 3.2 Packed 88-byte descriptor

`#[repr(C, packed)]` on a struct containing `u64` fields causes **unaligned loads**. On x86-64 this is a minor perf hit; on ARM64 (AWS Graviton, Apple Silicon) it can be a **SIGBUS** if the compiler emits `ldp` (load pair) on an unaligned address. Rust's `packed` attribute forces the compiler to use `read_unaligned`, which is safe but slow.

**Recommendation:** use `#[repr(C)]` with explicit `[u8; 6]` padding instead of `packed`, and `_Static_assert` the size. This preserves alignment and size.

