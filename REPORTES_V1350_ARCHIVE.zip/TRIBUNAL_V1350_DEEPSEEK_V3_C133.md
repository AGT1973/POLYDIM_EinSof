# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 133)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 133 · Multi-File Adversarial SOTA Review

**Presiding note:** The Tribunal treats every claim as *unproven until demonstrated*. Where a file is not physically in front of us, we audit the *specification as stated* and flag every place where the spec is under-determined. We do not grant "SOTA" status on assertion.

---

## 0. Cross-Cutting Findings (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Format claimed: `<4sHHQQQQQBB6x4Q`

Let us actually sum the bytes:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

✅ **Byte count is correct.** Alignment: `struct` with `<` is little-endian, no native padding, so 88 is exact and portable across x86-64 / aarch64 / RISC-V. Good.

**But:** the Tribunal flags three latent issues:

1. **Magic `4s` is only 32 bits.** For a multi-silicon contract spanning CPU/GPU/TPU/Trainium/ROCm, 32 bits of magic is a *collision surface* if any vendor ever reinterprets the buffer. Recommend `8s` magic + drop one `Q` (net zero bytes) or move to a 96-byte descriptor with a CRC-32C trailer.
2. **No version field distinct from magic.** `HH` is claimed as two `uint16`. If one is "version" and one is "flags", the spec must say so; otherwise forward-compat is undefined.
3. **`6x` padding is a smuggling channel.** Rule 22 says "zero 1D tokens." Padding bytes MUST be asserted `== 0` on both producer and consumer, or an adversary can encode a side-channel in the pad. **This is a Rule 22 violation risk in every one of the six files unless explicitly zeroed.**

### 0.2 Rule 22 compliance — the real test

Rule 22 ("zero 1D tokens in inter-agent communication") is only satisfied if:
- The descriptor is the *only* wire format (no JSON, no pickle, no `str`).
- All 88 bytes are canonicalized (endianness, pad-zeroed, magic-checked).
- No variable-length tail is appended.

**Verdict:** The spec *claims* compliance but does not *prove* it. Every file must ship a `assert_descriptor_canonical(buf: &[u8; 88])` that:
```
magic == EXPECTED
pad[0..6] == [0;6]
len(buf) == 88
```
Without this, Rule 22 is aspirational.

### 0.3 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor lock risk | Verdict |
|---|---|---|
| 1 orchestrator | none if probe is table-driven | ✅ if probe is data, ❌ if `#ifdef NVIDIA` |
| 2 C++ AVX-512 | **HIGH** — AVX-512 is Intel-only on many SKUs | ⚠️ needs runtime dispatch |
| 3 Rust SIMD | portable if `std::simd` or `wide` crate | ✅ |
| 4 CUDA | **TOTAL LOCK** — cuSOLVER `DnDsyevd` is NVIDIA-only | ❌ Rule 27 violation as written |
| 5 XLA | **DUAL LOCK** — TPU *and* Trainium are two incompatible vendors | ❌ unless HLO is vendor-neutral |
| 6 Triton | ROCm + CUDA is *two* backends — good — but Triton itself is a lock | ⚠️ |

**Tribunal ruling:** Targets 4 and 5 as specified **violate Rule 27**. A "Silicon Contract" that names `cuSOLVER` and `@jax.jit`-on-TPU is a vendor contract, not a silicon contract. Remediation below.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy

The orchestrator itself does no math, but it *dispatches* on `step`. Two failure modes:

**(a) step → ∞ (|step| ≥ 10¹⁰).** If the orchestrator computes any `step * scale` or `step / norm` before dispatch, FP64 overflow occurs at `step > ~1.8e308`. At 10¹⁰ you are safe in FP64 but **not** if any intermediate is `step²` (overflow at ~1.3e154). The orchestrator must **never** square the step. Enforce: `assert abs(step) < 1e150` at the boundary, or better, pass `log(step)` and let kernels exponentiate.

**(b) step → 0 (subnormal).** FP64 subnormals begin at `2.2e-308`. If the orchestrator normalizes `step / max_step`, and `max_step` is huge, the ratio underflows to 0 and the kernel sees a *zero step* — silently a no-op. **This is the most dangerous degeneracy in the whole stack** because it fails *silently*.

**Proof obligation:** The orchestrator must publish an invariant:
```
step ∈ [2^-1022, 2^1023)  ∪  {0 exactly}
```
and reject anything in the subnormal band `(0, 2^-1022)` unless the kernel explicitly opts into subnormal handling.

### 1.2 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe:** must be *data-driven* (a table of `(vendor_id, device_id, capability_bits)`), not `if/elif` on vendor strings. Otherwise Rule 27 is violated by construction.
- **Slab allocator:** 88-byte descriptors imply slab alignment should be 64 (cache line) or 128 (AVX-512). If slabs are packed at 88 bytes with no padding, **every descriptor straddles a cache line** → false sharing across cores. Recommend 128-byte stride with 40 bytes of *zeroed* pad (still Rule 22 compliant because pad is zero).

### 1.3 12/12 physical conformance checks

The Tribunal demands the *list*. "12/12" is a marketing number until the 12 predicates are enumerated. Minimum acceptable set:
1. magic match
2. pad zeroed
3. endianness
4. length == 88
5. version supported
6. flags subset of known
7. Q-fields monotone (if they encode offsets)
8. offsets within slab
9. no overlap between descriptors
10. alignment ≥ 64
11. checksum (if present)
12. no NaN in any float-reinterpreted field

If any of these is missing, "12/12" is a claim, not a proof.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic analysis

Neumaier's variant of Kahan:
```
s = 0; c = 0
for x,y:
    t = s + x*y
    if |s| >= |x*y|: c += (s - t) + x*y
    else:            c += (x*y - t) + s
    s = t
return s + c
```

**Error bound (Neumaier 1974):** for `n` terms with unit roundoff `u = 2^-53`,
```
|computed - exact| ≤ (2u + O(n u²)) · Σ|x_i y_i|
```
i.e. **the error is independent of cancellation** to first order. This is the correct choice for the Stiefel/Woodbury inner products.

**Degeneracy at step → ∞:** if `x_i y_i` overflows to `±inf`, then `t = s + inf = inf`, and `c += (s - inf) + inf = NaN`. **Neumaier is NOT overflow-safe.** The kernel must pre-scale: compute `dot(x/scale, y/scale) * scale²` with `scale = max(|x|,|y|)`. This is exactly what Target 4 claims to do ("globally scaled Woodbury") — Target 2 must do the same or it will diverge from Target 4 at large step.

**Degeneracy at step → 0:** if `x_i y_i` underflows to subnormal, Neumaier's compensation term `(s - t) + x*y` is itself subnormal and the compensation is lost. The audit at `-12, -14` (presumably `2^-12`, `2^-14` scaling exponents) is *insufficient* — subnormals start at `2^-1022`. **The claimed subnormal audit at -12/-14 is auditing the wrong regime.** Demand: audit at `2^-1020`, `2^-1022`, `2^-1023` (first subnormal), and `2^-1074` (smallest).

### 2.2 AVX-512 vendor lock

AVX-512 is **not** on AMD Zen 1–3 (Zen 4 has it), not on Intel Alder Lake E-cores, not on ARM. A "Silicon Contract" kernel that hard-requires AVX-512 violates Rule 27. **Required:** runtime dispatch via `__builtin_cpu_supports("avx512f")` with a scalar/AVX2 fallback that produces *bit-identical* results (or documents the divergence).

### 2.3 Zero-copy PMTP validation

"Zero-copy" + "validation" is a contradiction unless validation is done *in place* on the 88-byte header before the payload is touched. The C++ kernel must:
1. `static_assert(sizeof(PmtpDescriptor) == 88)`
2. `static_assert(alignof(PmtpDescriptor) <= 8)` (or document the alignment)
3. Validate magic/pad *before* `reinterpret_cast` to payload.

If validation happens after the cast, a malformed descriptor can cause UB. **This is a memory-safety finding, not a style nit.**

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI barrier — **this is wrong**

`panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is `extern "C-unwind"` (Rust 1.71+) *and* the other side is prepared. The correct hardening is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1,  // or a defined error code
    }
}
```

**`panic = abort` is safer for FFI** than `panic = unwind` unless you explicitly catch