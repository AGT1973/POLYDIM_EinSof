# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 155)

# **High Tribunal of Mathematical and Systems Sages**  
### **POLYDIM V1350 – Multi‑File Adversarial SOTA Audit – Cycle 155**  

**Prepared for:**  PolyDim Inc. – Security & Performance Review Board  
**Date:** 2026‑10‑05  

---  

## 1. Executive Summary  

| Target | Numerical Degeneracy (‖step‖→∞) | Numerical Degeneracy (‖step‖→0) | Rule 22 (88‑byte PMTP) | Rule 27 (Silicon‑Lock) | Overall Verdict |
|--------|----------------------------------|----------------------------------|------------------------|------------------------|-----------------|
| **kernel_orchestrator_v1350.py** | **Potential overflow** in the 64‑bit “scale” field when `step ≥ 2⁶³`; also division‑by‑zero in `scale = step / M` if `M = 0`. | **Under‑flow** in the 32‑bit “subnormal” flag; loss of significance when `step < 2⁻⁷⁴` (sub‑normal region of IEEE‑754 binary64). | **Compliant** – descriptor fields 10‑12 are zero‑initialized and validated at runtime. | **No vendor lock** – pure‑Python orchestration; only depends on the binary descriptor. | **Pass** with mitigation. |
| **kernel_cpp_v1350.cpp** | **Catastrophic cancellation** in Neumaier dot‑product when `|step| ≥ 10¹⁰` due to `float64` mantissa (53 bits) → loss of ~17 bits. AVX‑512 fused‑multiply‑add (FMA) reduces but does not eliminate error. | **Sub‑normal flush‑to‑zero** (FTZ) default on many x86 CPUs may silently drop contributions < 2⁻¹⁰⁷⁴, breaking compensated sums. | **Compliant** – static_assert on descriptor size; runtime guard checks that token count = 0. | **Potential lock**: use of Intel‑specific AVX‑512 intrinsics; compilation on non‑Intel silicon forces an emulation path that is not performance‑guaranteed. | **Conditional Pass** – vendor‑agnostic fallback required. |
| **kernel_rust_v1350.rs** | **Overflow** in the 64‑bit `scale` field of `PmtpTensorDescriptor` when `step` is cast to `u128` before truncation; Rust’s checked conversion aborts. | **Under‑flow** when `step` is represented as `f64::MIN_POSITIVE * 2⁻⁶⁴`; the `Neumaier` implementation uses `f64` and will produce sub‑normals that are *not* flushed. | **Compliant** – `#[repr(C, packed(1))]` guarantees 88‑byte layout; zero‑token invariant enforced by `static_assert_eq!`. | **No lock** – code is pure‑Rust, only dependent on `std::simd` which is portable across AMD/NVIDIA/ARM. | **Pass** – ensure `panic = "abort"` for hardened FFI. |
| **kernel_cuda_v1350.cu** | **Ill‑conditioned eigenproblem**: `DnDsyevd` on `2K×2K` Stiefel matrices suffers ‑log κ ≈ O(K · log ‖step‖) → exponential growth for `|step|≥10¹⁰`. Also `step/scale` can overflow 32‑bit integer kernel launches. | **Sub‑normal** entries in the descriptor are flushed to zero by the default `cudaDeviceProp.flushDenormsToZero = 1`; this silently discards the smallest components of the Woodbury solve, biasing the result. | **Compliant** – a device‑side kernel validates that the 88‑byte descriptor’s 1‑D token field = 0 before any compute. | **Potential lock** – reliance on `cuSOLVER` (NVIDIA‑only) and CUDA Graphs forces execution on NVIDIA GPUs; AMD ROCm path is absent. | **Conditional Pass** – must provide an ROCm‑compatible alternative. |
| **kernel_xla_v1350.py** | **Scaling blow‑up** in the Lyapunov solve: `AᵀX + XA = -C` with `C ∝ step`; condition number κ(A) ≈ O(exp(|step|)) for `|step|≥10¹⁰`. XLA’s FP64 lowering may insert `convert`‐to‑FP32 for TPU, losing precision. | **Sub‑normal** suppression on TPU: `XLA` implicitly enables `flush_denormals_to_zero` on Cloud TPU, removing contributions ≈ 2⁻¹⁰⁷⁴. | **Compliant** – the HLO fusion pipeline includes a “ZeroTokenCheck” pass that aborts if any 1‑D token ≠ 0. | **No lock** – code runs on both Google Cloud TPU and AWS Trainium (via XLA’s device‑agnostic backend). | **Pass** – watch for automatic FP32 down‑cast on TPU; enforce FP64 flag. |
| **kernel_triton_v1350.py** | **Projection overflow** on `S^{D‑1}` when `step` scales the norm: `‖v‖ = step·‖v₀‖`; for `|step| ≥ 10¹⁰` the squared norm exceeds 2⁵³, causing rounding to multiples of 2ⁿ. | **Sub‑normal** handling: Triton’s default `float32` tiling flushes denormals to zero; the bivector rotation kernels use `float64` for accumulation, but intermediate `float32` loads may lose them. | **Compliant** – the Triton scripts embed a `static_assert(sizeof(PmtpTensorDescriptor) == 88)` and runtime zero‑token guard. | **Potential lock** – the code explicitly calls `torch.cuda` and `torch.amd` APIs; if only one vendor library is available the other path aborts, effectively forcing a vendor choice. | **Conditional Pass** – supply a vendor‑agnostic “generic” kernel (e.g., OpenCL) or fallback to CPU. |

**Bottom‑line:** All six modules meet **Rule 22** (zero‑token, 88‑byte PMTP) but **Rule 27** is violated in three of them (C++, CUDA, Triton) by embedding vendor‑exclusive libraries without fallback implementations. Numerical degeneracy is present in all modules for extreme step magnitudes; mitigations are recommended below.

---

## 2. Detailed Component Audits  

### 2.1. `kernel_orchestrator_v1350.py`  

#### 2.1.1. Architectural Overview  
* **HardwareProbe** – abstracts silicon‑level capabilities via a JSON manifest.  
* **PmtpSlabAllocator** – reserves a contiguous 88‑byte slab for each tensor; alignment = 8 bytes.  
* **Binary descriptor layout** (`<4sHHQQQQQBB6x4Q`):  

| Offset (bytes) | Field | Size (bytes) | Semantic |
|----------------|-------|--------------|----------|
| 0 | `magic` | 4 | “PMTP” signature |
| 4 | `version` | 2 | 0x0135 |
| 6 | `flags` | 2 | bit‑field (zero‑token flag = bit 0) |
| 8 | `scale` | 8 (uint64) | `step / M` |
| 16 | `step` | 8 (uint64) | current integration step |
| 24 | `M` | 8 (uint64) | physical constant |
| 32 | `N` | 8 (uint64) | dimensionality |
| 40 | `token_1D` | 1 (uint8) | **must be 0** (Rule 22) |
| 41 | `reserved` | 1 (uint8) | – |
| 42–47 | *padding* | 6 | – |
| 48 | `checksum` | 8 (uint64) | XOR of previous fields |

The descriptor is *checked* at every inter‑process hand‑off (`assert descriptor.token_1D == 0`).

#### 2.1.2. Numerical Degeneracy  

| Regime | Failure Mode | Analysis |
|--------|--------------|----------|
| **|step| → ∞** (≥ 10¹⁰) | **Overflow** of `scale = step / M` if `M` is small (`M < 2⁵⁴`). In Python `int` is unbounded, but the subsequent C‑FFI cast to `uint64` truncates modulo 2⁶⁴, producing wrap‑around and loss of monotonicity. |
| **|step| → 0** (sub‑normals) | `step` may become smaller than `2⁻¹⁰⁷⁴` (binary64 sub‑normal). The descriptor stores it as `uint64` via `float.as_integer_ratio()`, which over‑flows to `0` for sub‑normals, violating the “no‑loss” guarantee of the orchestrator. |

**Proof of overflow** – let `M = 1`. Then `scale = step`. When `step = 2⁶⁴ + 1`, `scale` modulo 2⁶⁴ = 1, breaking the invariant `scale ≥ step`. By the definition of modular arithmetic, `scale` wraps after `2⁶⁴`.  

**Condition number** for the map `step ↦ scale` is simply `|∂scale/∂step| = 1/M`. When `M → 0` the map becomes ill‑conditioned (`κ → ∞`).  

#### 2.1.3. Rule 22 Verification  

* **Static Layout** – `struct.pack` enforces field order; `token_1D` is explicitly set to `0` during allocation.  
* **Runtime Guard** – `if descriptor['token_1D'] != 0: raise PMTPTokenError`.  

Both compile‑time and runtime checks ensure **zero 1‑D tokens**; no deviation found.

#### 2.1.4. Rule 27 (Silicon Contract)  

Pure