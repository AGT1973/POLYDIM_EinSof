# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 87)

# POLYDIM V1350 — High Tribunal Audit, Cycle 87

**Presiding Sages:** Numerical Analysis, Systems/FFI, Heterogeneous Compute
**Verdict posture:** Adversarial. Claims of "12/12 conformance" and "SOTA" are treated as *hypotheses*, not facts. Below, each target is dissected for degeneracy, Rule 22/27 compliance, and FFI hardening. Where the spec is under-determined, I state the assumption explicitly and flag it as an audit gap.

---

## 0. Cross-cutting invariants (apply to all 6 targets)

### 0.1 The 88-byte descriptor — structural audit

Layout claimed: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | 4s | 4 | 0 |
| ver_major, ver_minor | HH | 4 | 4 |
| flags, dtype, rank, _pad | (packed) | — | 8 |
| Q×5 (dims/strides) | QQQQQ | 40 | 16 |
| BB | 2 | 56 |
| 6x pad | 6 | 58 |
| 4Q | 32 | 64 |
| **Total** | | **96** | |

**Finding 0.1 (BLOCKER).** `4 + 2 + 2 + 40 + 2 + 6 + 32 = 88` only if the `HH` pair is *not* followed by two more `H` (flags/dtype/rank). The literal format string `<4sHHQQQQQBB6x4Q` computes to **96 bytes**, not 88. Either:
- (a) the format string is wrong (should be `<4sHHQQQQQBB6x4Q` → drop one `Q` → 88), or
- (b) the "88-byte" claim is a documentation error.

**Action:** Re-derive with `struct.calcsize`. If the wire format is 96 B, every "88-byte PMTP" claim in Targets 1–6 is **Rule 22 non-compliant** by 8 bytes. This is the single highest-severity finding in the audit.

### 0.2 Rule 22 — "Zero 1D tokens"

Interpretation: inter-agent messages must be *structured tensors/descriptors*, never flat 1-D token streams. Audit criterion: every IPC/FFI boundary must carry a descriptor with `rank ≥ 2` and explicit strides.

### 0.3 Rule 27 — Silicon Contract (no vendor lock)

Criterion: each kernel must have a *documented fallback path* to a vendor-neutral reference (CPU scalar or OpenMP) that produces bit-identical or ULP-bounded results.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe** is fine *if* it returns a capability bitmask, not a vendor enum. If it returns `"cuda"|"rocm"|"xla"|"cpu"` as a string, that is a **Rule 27 soft violation** (orchestrator becomes vendor-aware). Recommend: probe returns `{isa: bitset, mem_model: enum, ffi_abi: enum}`.
- **PmtpSlabAllocator**: slab allocation of 88/96-byte descriptors is cache-hostile. 88 B is not a power of two; a slab of N descriptors has stride 88, causing 4-way set conflicts on 64 B cache lines every 8 descriptors. **Recommendation:** pad to 128 B (one cache line) and *document the padding as part of the ABI*, or use SoA layout (separate arrays for magic, dims, strides).

### 1.2 Degeneracy at step → ∞ / step → 0

The orchestrator itself does not do math, but it *routes* `step`. If it clamps or scales `step` before dispatch, the clamp must be **log-symmetric**:

```
step_eff = sign(step) * exp(clamp(log|step|, log ε, log S_max))
```

A linear clamp `min(max(step, ε), S_max)` destroys the asymptotic behavior the CUDA/XLA kernels rely on (see §4, §5). **Audit gap:** the spec does not state the clamp policy. Demand it.

### 1.3 12/12 physical conformance checks

Without the check list, "12/12" is unfalsifiable. Demand the 12 predicates as executable assertions with named tolerances. A conformance suite that cannot fail is not a conformance suite.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

For vectors `x, y ∈ R^n`, Neumaier summation gives

```
|fl(Σ xᵢyᵢ) − Σ xᵢyᵢ| ≤ (n·u + O(n²u²)) · Σ|xᵢyᵢ| + O(u)·|Σ xᵢyᵢ|
```

with `u = 2⁻⁵³`. This is **not** the same as Kahan; Neumaier is *unconditionally* better for the running-sum correction. **However**, the *products* `xᵢyᵢ` are still rounded once. For `|step| ≥ 10¹⁰`, if `xᵢ ~ step`, then `xᵢyᵢ` can overflow to `+inf` before compensation. **Finding 2.1:** Neumaier does not protect against overflow in the *product* stage. Require a pre-scale: compute `dot(x/scale, y)` and multiply by `scale` afterward, with `scale = max|x|·max|y|` (or `2^⌈log₂ max⌉`).

### 2.2 Subnormal audits at −12, −14

Subnormals in IEEE-754 binary64 live in `[2⁻¹⁰⁷⁴, 2⁻¹⁰²²)`. "−12, −14" almost certainly refers to **decimal exponents** (`10⁻¹²`, `10⁻¹⁴`), which are *normal* doubles. If the audit means `2⁻¹²` and `2⁻¹⁴`, those are also normal. **Finding 2.2:** the subnormal audit as stated is mislabeled. True subnormal stress requires inputs near `1e-308`. Demand the actual test vectors.

### 2.3 AVX-512 + OpenMP

- **FMA contraction**: `-ffast-math` or `-ffp-contract=fast` will fuse `a*b+c` and *break* Neumaier's error bound (the correction term assumes separate rounding). **Mandate `-ffp-contract=off`** for the compensated path.
- **OpenMP reduction**: `reduction(+:acc)` is *not* deterministic across thread counts. For a "SOTA" kernel claiming bit-reproducibility, this is a **Rule 27-adjacent violation** (results depend on core count). Use a fixed tree reduction or `omp simd reduction` with deterministic ordering.

### 2.4 Zero-copy PMTP validation

Zero-copy requires the descriptor's `dims`/`strides` to match the actual buffer. **Finding 2.3:** if the 88/96-byte descriptor is passed by value across the FFI boundary, the C++ side must `static_assert(sizeof(PmtpDescriptor) == 88)` (or 96). If the Python side uses `struct.pack` with the wrong format (see §0.1), the C++ `reinterpret_cast` reads garbage. **This is a memory-safety bug, not just a numerical one.**

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

**Finding 3.1 (CRITICAL).** `panic=unwind` across an FFI boundary is **undefined behavior** unless every `extern "C"` function is wrapped in `catch_unwind`. The Rust reference is explicit: unwinding past a non-Rust frame is UB. If the C++/CUDA caller does not have a matching personality routine, the process aborts or corrupts.

**Hardening:**
```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1, // or set a thread-local error code
    }
}
```
Additionally, `panic=unwind` bloats the binary and disables some optimizations. For a *safety barrier*, `panic=abort` + explicit error codes is often preferable. The claim that `panic=unwind` *is* the safety barrier is backwards — it is the *hazard* the barrier must contain.

### 3.2 Safe SIMD

Rust's `std::simd` is still nightly. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" is therefore aspirational unless wrapped in a `#[target_feature]` + runtime dispatch. **Audit gap:** demand the dispatch mechanism (e.g., `is_x86_feature_detected!`).

### 3.3 Packed 88-byte descriptor

Rust `#[repr(C, packed)]` on a struct containing `u64` fields produces **unaligned loads**, which on some architectures (ARM64 with strict alignment, or when the compiler emits `movaps`) trap. **Finding 3.2:** use `#[repr(C)]` with explicit `[u8; 6]` padding and `align(8)`, or `#[repr(C, align(8))]` with a `[u8; 6]` tail. Packed + u64 is a footgun.

### 3.4 Neumaier in Rust

Same overflow caveat as §2.1. Rust's `f64::mul_add` maps to FMA and will *break* the compensation unless the algorithm is written to avoid contraction (Rust does not contract by default, which is actually safer here — but `-C target-feature=+fma` plus LLVM can still contract in some cases; verify with `cargo asm`).

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K×2K)

Cayley: `Y = (I − ½W)⁻¹(I + ½W) X`, `W = A Xᵀ − X Aᵀ` (skew). For `W` with `‖W‖ → ∞` (i.e., `step → ∞`), `(I − ½W)` becomes ill-conditioned and the solve loses accuracy. **Asymptotic condition number:**

```
κ(I − ½W) ≈ ½‖W‖₂ · (1 + O(1/‖W‖))
```

So `κ ~ ‖step‖`. At `step