# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 135

There is not enough verifiable evidence to issue a definitive arbitration of the eight purported Tribunal findings or the six V1350 kernels. I found no authoritative public specification, benchmark corpus, or model-by-model reports for “POLYDIM V1350,” “Cycle 135,” or the “PMTP 88-byte Descriptor”; therefore, any claim that one Tribunal model prevailed would be fabricated.

What can be established from standard mathematics and systems principles is the following.

## 1. Cayley retraction under extreme steps

For \(X\in\mathrm{St}(n,p)\), common retractions include

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)(I+\Xi^\top\Xi)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

where \(W^\top=-W\) and \(W\) is constructed from \(X\) and \(\Xi\). These are recognized Stiefel-manifold retractions, but they have different numerical and implementation properties.[1][2]

No unconditional theorem supports the claim that Cayley is universally more stable than Householder QR or polar retraction for \(|\mathrm{step}|\ge 10^{10}\). At such magnitudes:

- **Cayley:** orthogonality is structurally preserved in exact arithmetic because the Cayley transform of a skew-symmetric matrix is orthogonal, but finite-precision stability depends on solving the shifted system accurately. A poorly scaled or nearly singular implementation can lose accuracy.
- **Householder QR:** avoids explicitly forming normal equations and is generally the robust baseline for orthogonalization, but it requires rank-revealing safeguards when \(X+\Xi\) is ill-conditioned.
- **Polar:** gives the nearest orthogonal factor in Frobenius norm when the matrix is sufficiently well behaved, but computing \((I+\Xi^\top\Xi)^{-1/2}\) can overflow, underflow, or become inaccurate unless scaling and a stable SVD/iterative scheme are used.

The defensible SOTA guarantee is therefore conditional:

\[
\boxed{
\text{Use scaled, backward-stable QR or SVD-based polar fallback; use Cayley only with a certified stable solve.}
}
\]

A valid extreme-step implementation should:

1. scale \(\Xi\) before forming products;
2. avoid forming \(\Xi^\top\Xi\) when it risks overflow;
3. use Householder QR or SVD fallback when conditioning checks fail;
4. verify
   \[
   \|Y^\top Y-I\| \le c\,u\,\kappa_{\mathrm{alg}},
   \]
   where \(u\) is unit roundoff;
5. reject or flag any result for which the residual exceeds the specified tolerance.

Thus, “Cayley is always stable for extreme steps” is not an architectural guarantee.

## 2. PMTP 88-byte descriptor and RCU/QSBR

The byte size of a descriptor does not determine its memory-ordering correctness. An 88-byte layout can be useful for alignment and cache behavior, but **Acquire/Release semantics alone do not automatically guarantee complete RCU or QSBR snapshot isolation**.

A correct publication protocol requires, at minimum:

- descriptor initialization before publication;
- a **Release** store of the publication pointer or generation;
- an **Acquire** load by readers before consuming descriptor fields;
- reader registration or quiescent-state tracking;
- deferred reclamation only after every pre-existing reader has passed through a quiescent state;
- protection against ABA, typically through generations, epochs, hazard pointers, or equivalent tagging.

The abstract ordering requirement is:

\[
\text{initialize fields}
\;\xrightarrow{\text{Release publish}}\;
\text{Acquire read}
\;\xrightarrow{}\;
\text{consume fields}.
\]

For reclamation, the stronger condition is:

\[
\text{retire}(d)
\;\prec\;
\text{all readers that could have observed }d\text{ becoming quiescent}.
\]

Therefore the strongest defensible guarantee is:

\[
\boxed{
\text{Acquire/Release provides publication visibility; RCU/QSBR provides reclamation safety only when its grace-period protocol is correctly implemented.}
}
\]

It is not possible to certify snapshot isolation from the descriptor size or from memory barriers without the exact state machine, atomic fields, alignment rules, reader protocol, reclamation algorithm, and target memory model.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single “multi-silicon conformance” guarantee across these environments merely because they implement equivalent source-level logic. Their execution and memory models differ:

- **C++20:** defines language-level atomic and synchronization semantics, subject to the implementation and target platform.
- **Rust:** provides language-level ownership and atomic APIs, but unsafe code, FFI, device code, and compiler/target behavior remain relevant.
- **CUDA:** has host/device and device-scope memory-ordering mechanisms, with synchronization semantics tied to scope and GPU architecture.
- **Triton:** compiles kernels through compiler-specific lowering; supported atomics, barriers, layouts, and ordering guarantees must be validated per backend.
- **XLA:** uses an optimizing compiler and may fuse, reorder, replicate, or lower operations differently across hardware backends.

A mathematically equivalent algorithm is not automatically memory-model equivalent. Exact conformance requires a testable contract covering:

\[
\text{layout}
+\text{endianness}
+\text{alignment}
+\text{atomic width}
+\text{scope}
+\text{ordering}
+\text{barrier participation}
+\text{progress}
+\text{numerical tolerance}.
\]

The appropriate guarantee is observational rather than implementation-identical:

\[
\boxed{
\forall b\in\{\text{CUDA, XLA, Triton, C++20, Rust}\},\quad
\operatorname{Obs}_b(\text{kernel})
\in \mathcal{C},
}
\]

where \(\mathcal{C}\) is a formally specified set of permitted outputs, ordering observations, and failure modes.

That requires:

- a canonical descriptor ABI;
- explicit serialization and padding rules;
- backend-specific lowering tests;
- litmus tests for publication, reclamation, and stale reads;
- differential numerical tests;
- race detection and sanitizer coverage where available;
- stress testing across supported GPU/CPU architectures;
- negative tests proving that unsupported memory scopes are rejected rather than silently weakened.

## Arbitration

Based on the available evidence, the only technically supportable arbitration is:

| Claim | Arbitration |
|---|---|
| Cayley dominates QR and polar for all \(|\mathrm{step}|\ge10^{10}\) | **Rejected as unconditional** |
| A Cayley implementation can preserve orthogonality structurally | **Accepted in exact arithmetic; conditional in floating point** |
| An 88-byte descriptor plus Acquire/Release guarantees RCU/QSBR isolation | **Rejected** |
| Acquire/Release can provide publication visibility | **Accepted, if applied to the correct atomic publication protocol** |
| The same implementation is automatically conformant across CUDA, XLA, Triton, C++20, and Rust | **Rejected** |
| Cross-backend observational conformance can be guaranteed by a formal ABI and litmus-test suite | **Accepted in principle, pending evidence** |

The mathematically superior synthesis is consequently a **certified hybrid architecture**:

1. scaled Cayley update for well-conditioned moderate updates;
2. Householder QR or SVD-based polar fallback for extreme or ill-conditioned updates;
3. explicit orthogonality and residual certification;
4. Release publication and Acquire consumption of immutable snapshots;
5. epoch/QSBR grace-period reclamation with ABA protection;
6. a canonical ABI plus backend-specific memory-scope mappings;
7. conformance defined by formal observational tests, not source-code similarity.

Without the eight Tribunal reports, the six kernel definitions, and the PMTP memory-layout/protocol specification, stronger “exact architectural guarantees” cannot be derived.