# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 68

The six-model findings cannot be definitively compared from the material provided: no actual Claude, Qwen, Kimi, Gemini, DeepSeek, or Perplexity tribunal reports, nor a public specification for “POLYDIM V1350,” “PMTP,” or its six kernels, were supplied. The defensible SOTA result is therefore a **conditional architecture and proof obligation**, not a claim that a particular implementation already satisfies these guarantees.

## 1. Cayley–Stiefel retraction at \(|\mathrm{step}|\ge 10^{10}\)

A Cayley retraction is not automatically stable merely because the Cayley transform preserves orthogonality in exact arithmetic. For a skew-symmetric generator \(\Omega\),

\[
Q(\alpha)=(I-\alpha\Omega)^{-1}(I+\alpha\Omega),
\]

and, in exact arithmetic, \(Q(\alpha)^{T}Q(\alpha)=I\) whenever the inverse exists. However, at extreme \(\alpha\), the implementation is dominated by conditioning, overflow/underflow, cancellation, and the quality of the linear solve—not by the formal orthogonality identity.

The strongest arbitration is:

| Method | Extreme-step assessment | Required qualification |
|---|---|---|
| Direct Cayley solve | **Not unconditionally stable** for \(|\alpha|\ge 10^{10}\) | Must use scaling, stable factorization, finite-value checks, and residual monitoring |
| Householder QR | Generally the safest baseline for producing an orthonormal factor | Requires a stable QR implementation and careful handling of highly scaled inputs |
| Polar retraction | Geometrically attractive and closest in Frobenius norm | Newton–Schulz or iterative variants require scaling and convergence checks; an unscaled iteration is not guaranteed |
| Scaled Cayley / compact WY-style implementation | Potentially the best specialized kernel | Stability must be demonstrated by backward-error and orthogonality-residual bounds |

Recent mathematical results support the view that Cayley and polar retractions can have favorable conditioning in appropriate formulations, but those local conditioning results do **not** establish safe execution for an arbitrary floating-point step of \(10^{10}\).[1] QR and polar retractions are established alternatives on the Stiefel manifold, while Cayley methods are attractive because they can avoid a full decomposition in some structured cases.[7][12]

### Definitive guarantee

The V1350 kernel should claim the following, and no stronger statement:

\[
\widehat X^T\widehat X=I+E,\qquad
\|E\| \le c\,u\,\kappa_{\mathrm{scaled}}(\Omega,X)+\tau_{\mathrm{iter}},
\]

provided that:

- the input is finite;
- scaling prevents intermediate overflow and underflow;
- the shifted Cayley system is nonsingular and its solve residual is below a specified threshold;
- the kernel rejects or falls back when the residual, condition estimate, or orthogonality defect exceeds its contract.

For \(|\alpha|\ge 10^{10}\), the **architecturally superior policy is adaptive**:

1. Normalize the step and generator by a power-of-two scale.
2. Form the retraction using a stable solve, not an explicit inverse.
3. Check the solve residual and \(X^TX-I\).
4. Fall back to Householder QR or a scaled polar method on failure.
5. Report the selected path and numerical status deterministically.

Thus, a claim that “Cayley is always more stable than Householder or polar QR at extreme steps” is unsupported. The correct conclusion is that **scaled, residual-checked Cayley may be faster while QR remains the mandatory correctness fallback**.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte layout is only an ABI/layout fact. It does not itself provide memory safety, snapshot isolation, or inter-thread ordering.

For a publication protocol, the essential pattern is:

\[
\text{initialize descriptor fields}
\;\prec\;
\text{release-publish pointer/version}
\]

and on the reader:

\[
\text{acquire-load pointer/version}
\;\prec\;
\text{read descriptor fields}.
\]

In C++20, a release store synchronizes with an acquire load of the **same atomic object** when the load observes the released value.[13] Rust uses the same acquire/release model: release orders prior operations before publication, and acquire orders subsequent operations after the observed publication.[5][6]

The exact guarantee is therefore:

\[
\text{writer initialization}
\;\xrightarrow{\text{release/acquire}}
\text{reader descriptor observation}.
\]

That guarantee does **not** by itself provide:

- reclamation safety;
- protection against ABA;
- a complete RCU grace period;
- ordering for unrelated atomics;
- GPU/CPU coherence across an arbitrary device boundary;
- isolation if readers access a descriptor after its reclamation.

A valid PMTP protocol requires:

- an atomic publication pointer or generation;
- release publication by the writer;
- acquire observation by readers;
- reader-side QSBR/RCU quiescent-state reporting;
- reclamation only after all readers that could have observed the old generation pass through a grace period;
- immutable descriptor contents after publication, or separately synchronized mutation;
- explicit alignment and atomic-width guarantees for every atomic field;
- version, generation, or hazard protection against ABA.

The descriptor may be 88 bytes, but **the synchronization contract must be attached to the publication and reclamation protocol, not to the descriptor size**. Kernel-style RCU documentation similarly distinguishes release publication operations from acquire observation operations.[9] The userspace QSBR implementation also explicitly uses release-group annotations in its grace-period machinery.[3]

### Definitive guarantee

The strongest defensible statement is:

> A reader that acquire-loads a PMTP publication token and then enters the specified RCU/QSBR read-side critical section observes a fully initialized, immutable descriptor corresponding to that token; the descriptor remains alive until the required grace period completes.

This is conditional on the implementation using the same atomic publication object and on correct grace-period accounting. “Acquire/release semantics alone guarantee snapshot isolation” is too broad and should be rejected.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model or execution model shared identically by these five environments. C++20 and Rust provide language-level atomic ordering; CUDA adds host/device and scope-specific synchronization; Triton exposes compiler- and backend-dependent GPU behavior; XLA is an optimizing graph compiler whose transformations and aliasing decisions must be constrained by its documented effects and runtime semantics.

Consequently, **source-level conformance is insufficient**. V1350 needs a semantic intermediate contract with backend-specific lowering rules.

| Requirement | C++20 / Rust | CUDA | Triton | XLA |
|---|---|---|---|---|
| Acquire/release publication | Native language atomics | Scope and operation dependent | Must be expressed through supported atomic/fence primitives | Must be represented through supported side-effect/ordering mechanisms |
| RCU/QSBR | Possible with a complete protocol | Requires explicit host/device domain design | Not automatically supplied by kernel launch semantics | Not automatically supplied by graph execution |
| Descriptor layout | `static_assert` / compile-time layout checks | Host/device ABI checks | Explicit offsets, alignment, and masks | Layout is compiler-managed unless constrained |
| Deterministic fallback | Ordinary control flow | Device-compatible fallback | Backend-dependent | Must be representable in the compiled graph |
| Cross-device visibility | Language model only | Requires explicit synchronization and coherence assumptions | Backend/runtime dependent | Runtime ordering and side effects must be specified |

The architecture should define a small backend-neutral contract:

```text
publish(ptr, generation, release)
observe(generation, acquire)
enter_read_section()
exit_read_section()
retire(ptr, generation)
reclaim_after_grace_period()
```

Each backend must then provide a proof or conformance test for:

1. publication visibility;
2. descriptor lifetime;
3. generation/ABA behavior;
4. alignment and layout;
5. numerical retraction residuals;
6. behavior under concurrent readers and writers;
7. behavior across host/device boundaries;
8. compiler optimization and fusion boundaries.

### Exact conformance guarantee

The V1350 implementation can claim cross-silicon conformance only if all supported backends pass the same observable tests:

\[
\begin{aligned}
&\|\widehat X^T\widehat X-I\|\le \varepsilon_{\mathrm{orth}},\\
&\|A\widehat x-b\|\le \varepsilon_{\mathrm{solve}},\\
&\text{reader never observes partially initialized fields},\\
&\text{retired descriptors are not reclaimed before grace completion},\\
&\text{descriptor offsets and size match the ABI},\\
&\text{fallback decisions are deterministic under the declared tolerance}.
\end{aligned}
\]

The tolerances must be parameterized by datatype, backend, matrix dimensions, and hardware—not asserted as one universal epsilon.

## Arbitration of the six-model claims

Without the six reports, the appropriate arbitration rules are:

- Reject any claim of unconditional Cayley stability at \(10^{10}\).
- Prefer claims backed by backward-error analysis, residual checks, and fallback behavior over benchmark-only claims.
- Reject the assertion that an 88-byte descriptor creates memory ordering or reclamation guarantees.
- Accept acquire/release visibility only when the acquire observes the corresponding release on the same atomic publication object.
- Reject “CUDA/XLA/Triton/C++20/Rust identical semantics” unless the implementation defines explicit backend scopes and tests.
- Prefer a hybrid design: **scaled Cayley for the fast path, Householder QR for correctness fallback, release/acquire publication, QSBR/RCU reclamation, and backend-specific conformance proofs**.

That hybrid is the mathematically and architecturally strongest SOTA synthesis supported by the available evidence. It provides conditional numerical stability, publication visibility, and reclamation safety—not unconditional guarantees independent of conditioning, memory scope, compiler behavior, or reclamation correctness.