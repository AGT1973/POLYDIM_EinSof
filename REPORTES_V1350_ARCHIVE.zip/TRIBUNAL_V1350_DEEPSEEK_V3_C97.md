# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 97)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 97 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been asked to audit six artifacts whose *source text was not actually attached to the docket*. What follows is therefore a **structural audit against the declared contract** (the 88-byte descriptor, the Rule 22 / Rule 27 invariants, the Neumaier/Stiefel/Woodbury/Lyapunov numerics, and the FFI surface), not a line-by-line reading. Where a claim is unverifiable from the docket, the Tribunal says so explicitly rather than fabricating a verdict. This is itself a Rule 22 discipline: **no 1-D token of praise or condemnation without a 2-D evidence matrix.**

---

## 0. The 88-byte descriptor — first-principles check

Declared format: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Cumulative |
|---|---|---|---|
| magic | `4s` | 4 | 4 |
| version, flags | `HH` | 4 | 8 |
| 5× `Q` (dims/strides/offsets) | `QQQQQ` | 40 | 48 |
| 2× `B` (rank, dtype) | `BB` | 2 | 50 |
| pad | `6x` | 6 | 56 |
| 4× `Q` (checksums / handles) | `4Q` | 32 | **88** |

**Verdict:** the struct format is *arithmetically* 88 bytes **only if** the compiler honors `#pragma pack(1)` / `__attribute__((packed))` / Rust `#[repr(C, packed)]` / CUDA `__align__(8)` consistently. The Tribunal flags three concrete hazards:

1. **Alignment trap.** `Q` fields at offsets 8, 16, 24, 32, 40 are 8-aligned; the trailing `4Q` block begins at offset 56 (8-aligned) — good. But the `BB6x` block at offset 48–55 means the *second* `Q` group starts at 56, which is fine. **However**, if any language inserts natural alignment (C++ without `packed`, Rust without `repr(packed)`), the struct silently becomes 96 bytes and every cross-language `memcpy` corrupts. This is the single most likely Rule 22 violation in the whole stack.
2. **Endianness.** `<` is little-endian. TPU/Trainium HLO and some ARM64 big-endian test rigs will silently byte-swap. The descriptor must carry an explicit endianness byte or the magic must be endian-tagged.
3. **`4s` magic is only 32 bits.** For a multi-vendor ABI you want ≥64 bits of magic to make accidental collision with a foreign 88-byte struct (e.g., a `cudaIpcMemHandle_t`-adjacent blob) cryptographically improbable.

**Recommendation:** add a `static_assert(sizeof(...) == 88)` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` in Rust, and a Python `struct.calcsize("<4sHHQQQQQBB6x4Q") == 88` assertion at import time. Without these, Rule 22 is *aspirational*, not enforced.

---

## 1. Numerical degeneracy: `step → ∞` and `step → 0`

### 1a. `|step| ≥ 10^10` — the Woodbury / Cayley regime

The CUDA kernel declares a **globally scaled Woodbury solve** `(M/scale) W = (step/scale) B`. Let `M = I + U C Uᵀ` with `U ∈ R^{n×k}`, `k ≪ n`. The Woodbury identity gives

```
M⁻¹ = I − U (C⁻¹ + UᵀU)⁻¹ Uᵀ.
```

The scaled form `M/scale` has condition number

```
κ(M/scale) = κ(M) = κ(I + UCUᵀ).
```

**Asymptotic bound.** If `‖UCUᵀ‖ = ρ`, then `κ(M) ≤ (1+ρ)/(1−ρ)` for `ρ < 1`, and `κ(M) ≈ ρ` for `ρ ≫ 1`. The *scale* factor cancels exactly in exact arithmetic — **but not in floating point**. The relative error of the scaled solve is

```
‖δW‖/‖W‖ ≲ κ(M) · u + |step/scale| · u,
```

where `u = 2⁻⁵³` (FP64) or `2⁻²⁴` (FP32). For `step = 10^10` and `scale = 1`, the second term is `10^10 · 2⁻⁵³ ≈ 1.1 × 10⁻⁶` — **six orders of magnitude worse than the FP64 unit roundoff**. The scaling is therefore *not* a cosmetic normalization; it is load-bearing. **The Tribunal demands a proof that `scale` is chosen as `scale = max(‖step‖, ‖M‖_F, 1)` and that the ratio `step/scale` is bounded by `O(1)` before the solve.** If `scale` is a compile-time constant, the kernel is numerically degenerate at `step ≥ 10^10`.

**Cayley retraction.** The Stiefel Cayley retraction `Y = (I − ½W)(I + ½W)⁻¹ X` requires `(I + ½W)` to be well-conditioned. With `W = step · B` and `step = 10^10`, `‖½W‖ ≈ 5×10^9`, so `κ(I + ½W) ≈ 10^10` and the retraction loses ~10 digits. **The Cayley form is only stable for `‖step·B‖ ≲ 1`.** For large steps the correct retraction is the *QR-based* or *polar* retraction, or a line-search that caps `step`. The Tribunal flags this as a **hard numerical degeneracy**, not a soft one.

### 1b. `step → 0` — subnormal regime

The C++ kernel declares subnormal audits at `-12` and `-14` (presumably `std::fpclassify` codes or exponent thresholds). Two hazards:

1. **Neumaier compensated summation does not rescue subnormals.** Neumaier's correction term `c` is itself computed in the same format; once `|x| < 2⁻¹⁰²²` (FP64) the correction `(t − sum) − x` underflows to zero and the compensation silently degrades to naive summation. The audit at `-12`/`-14` must therefore **flush to zero or promote to a wider accumulator**, not merely *detect*.
2. **AVX-512 DAZ/FTZ.** If the CPU core runs with `MXCSR.DAZ=1, FTZ=1` (common in HPC builds), the subnormal audit is a no-op because subnormals never reach the audit. The Tribunal demands an explicit `_mm_getcsr()` / `_mm_setcsr()` guard around the audit region, and a documented policy: **either FTZ everywhere (and the audit is meaningless) or FTZ nowhere (and the audit is meaningful).** Mixing is a Rule 22 violation at the numerical layer.

**Asymptotic condition number for the Lyapunov solve (XLA kernel).** For `A X + X Aᵀ = −Q`, the sensitivity is

```
κ_Lyap = ‖A‖_F · ‖A⁻¹‖_F · (‖A‖_F + ‖A⁻¹‖_F) / (2 · sep(A, −Aᵀ)),
```

where `sep` is the separation of the spectra. As `step → 0`, `A → I`, `sep → 2`, `κ_Lyap → O(1)` — **benign**. As `step → ∞`, `A` becomes stiff and `sep → 0`; the Lyapunov solve is then **exponentially ill-conditioned**. The XLA kernel must therefore **not** be the one handling large steps; the CUDA Cayley path must, and only with the scaling proof above.

---

## 2. Rule 22 compliance — zero 1-D tokens, 88-byte PMTP

Rule 22 as stated: *inter-agent communication carries no 1-D tokens; all payloads are 88-byte PMTP descriptors.*

**Structural verdict.** The six kernels each declare an 88-byte descriptor, which is necessary but **not sufficient**. Rule 22 is violated the moment any of the following occurs:

- A kernel returns a **scalar status code** (`int rc`) across the FFI boundary instead of packing it into the descriptor's `flags` field. The Rust `panic=unwind` barrier is the classic offender: a caught panic that returns `-1` is a 1-D token.
- A kernel logs a **string** to a shared channel. Strings are 1-D token streams by definition.
- A kernel passes a **pointer + length** pair as two separate arguments. The pointer and length must be *inside* the 88-byte descriptor (the `4Q` checksum/handle block is the natural home).
- The Python XLA kernel uses `jax.jit` with a **Python scalar** argument. JAX will trace it as a 0-D array, which is a 1-D token in disguise.

**Recommendation.** Add a `pmtp_validate(const uint8_t[88])` function in each language that asserts: (a) magic matches, (b) `version` is in the accepted set, (c) the `4Q` checksum block verifies against a BLAKE3 of the payload, (d) `rank ≤ 8` and `dtype` is in the enum. Any kernel that cannot produce a valid 88-byte descriptor must **refuse to emit** rather than fall back to a scalar.

---

## 3. Rule 27 — Silicon Contract / vendor lock

The Tribunal's finding: **the stack as declared is vendor-neutral at the descriptor layer and vendor-locked at the execution layer.** This is the correct architecture, but it must be *explicit*.

| Kernel | Vendor surface | Lock risk |
|---|---|---|
| `kernel_orchestrator_v1350.py` | Multi-silicon `HardwareProbe` | **None** if probe is capability-based (AVX-512, SVE, ROCm, CUDA, TPU) rather than SKU-based. |
| `kernel_cpp_v1350.cpp` | AVX-512 + OpenMP | **Medium.** AVX-512 is Intel-specific; AMD Zen 4 supports it but Zen 3 does not. Must fall back to AVX2/NEON. |
| `kernel_rust_v1350.rs` | Safe SIMD | **Low.** `std::simd` is portable; `core::arch` intrinsics are not. |
| `kernel_cuda_v1350.cu` | cuSOLVER `DnDsyevd`, CUDA Graphs | **High.** cuSOLVER is NVIDIA-only. The Stief