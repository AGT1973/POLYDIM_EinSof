# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 76

No verifiable six-model Tribunal reports or V1350 kernel specifications were provided, so a literal arbitration of Claude, Qwen, Kimi, Gemini, DeepSeek, and Perplexity would be fabricated. The defensible SOTA synthesis is therefore a **conditional architectural ruling** based on numerical linear algebra and weak-memory guarantees—not a claim about undocumented V1350 implementations.

## Arbitration

| Issue | Definitive ruling | Architectural guarantee |
|---|---|---|
| Extreme-step Stiefel retraction | **Householder QR is the default robust implementation; polar retraction is the strongest geometric reference; naive Cayley is not certified for \(\lvert\text{step}\rvert\ge 10^{10}\).** | Orthogonality must be measured and enforced with a residual bound; no method may claim unconditional stability from the retraction formula alone. |
| PMTP 88-byte descriptor | **Acquire/release is necessary but not, by itself, sufficient to specify RCU/QSBR snapshot isolation.** | Publication, reader entry, validation, grace-period detection, and reclamation must be explicitly ordered and defined. |
| Multi-silicon conformance | **Source-level portability is not semantic portability.** | Each backend requires a conformance layer and litmus, numerical, compiler, and race tests; CUDA/XLA/Triton/C++20/Rust cannot inherit identical guarantees automatically. |

## 1. Cayley versus Householder QR and polar retraction

For \(X\in\mathrm{St}(n,r)\), the Stiefel constraint is

\[
X^{\mathsf T}X=I_r.
\]

The polar retraction is

\[
R_{\mathrm{polar}}(X,\xi)
=(X+\xi)\left(I_r+\xi^{\mathsf T}\xi\right)^{-1/2},
\]

while QR uses

\[
R_{\mathrm{QR}}(X,\xi)=\operatorname{qf}(X+\xi),
\]

with a sign convention such as positive diagonal in the triangular factor. These are established Stiefel retractions; the polar form is the closest-point orthogonalization in the Frobenius metric, whereas QR is generally cheaper and is naturally implemented with Householder transformations.[12]

A Cayley update has the schematic form

\[
Y=(I-\tfrac{\alpha}{2}\Omega)^{-1}
(I+\tfrac{\alpha}{2}\Omega)X,
\qquad \Omega^{\mathsf T}=-\Omega.
\]

In exact arithmetic, the Cayley transform is orthogonal when the inverse exists. That does **not** imply numerical stability for an extreme step. Large \(\alpha\|\Omega\|\) can produce badly scaled linear systems, cancellation, overflow in intermediate expressions, or convergence failure in iterative Cayley approximations. The cited iterative scheme is contractive only under a restriction of the form

\[
\alpha < \min\left\{1,\frac{2}{\|W\|}\right\},
\]

which directly excludes treating arbitrary \(10^{10}\)-scale steps as unconditionally safe.[15]

### Ruling

- **Householder QR wins as the production fallback** for extreme steps because it reduces the problem to orthogonal transformations and avoids explicitly forming a potentially ill-conditioned inverse.
- **Polar retraction wins as the geometric reference** when the small \(r\times r\) inverse square root can be computed robustly, preferably through a symmetric eigendecomposition or a carefully scaled iterative method.
- **Cayley is acceptable only with guarded scaling or fallback.** A Cayley kernel may be fast for moderate steps, but it must detect denominator conditioning, iteration nonconvergence, nonfinite values, and orthogonality loss.

The correct guarantee is therefore:

\[
\|Q^{\mathsf T}Q-I\| \le \tau_{\mathrm{orth}}
\]

for a declared tolerance \(\tau_{\mathrm{orth}}\) tied to precision, matrix dimensions, and backend. If this test fails, the kernel must retry using scaled polar/QR or return an explicit failure status. “Stable for \(\lvert\text{step}\rvert\ge10^{10}\)” is not a mathematically meaningful guarantee without specifying scaling, norm bounds, floating-point format, conditioning, and fallback behavior.

A superior design is:

1. Scale the tangent/update operator before forming the Cayley system.
2. Use a bounded iterative solve only within a proven convergence region.
3. Monitor residual and orthogonality.
4. Fall back to Householder QR.
5. Optionally compare against polar retraction in validation mode.
6. Never silently return a non-Stiefel result.

The canonical Cayley construction also has domain restrictions: formulations involving \((I+\cdot)^{-1}\) require the relevant matrix to remain nonsingular; an eigenvalue at \(-1\) is a known obstruction for canonical Cayley forms.[9]

## 2. PMTP 88-byte descriptor and RCU/QSBR

A descriptor size of 88 bytes is an ABI/layout fact, not a memory-ordering proof. The descriptor must specify:

- field offsets and alignment;
- which fields are immutable after publication;
- which fields are atomic;
- ownership and lifetime;
- generation/version semantics;
- publication and retirement protocol;
- cache-line and device-visibility requirements.

In C++20, a release store followed by an acquire load on the same atomic object synchronizes when the load observes the value written by the release store. This orders initialization before the reader’s subsequent accesses.[6] Verification work on RCU likewise identifies release/acquire ordering on link/publication fields as what orders node initialization before reader access.[1]

That yields **safe publication**, not complete snapshot isolation.

### Required protocol

A defensible descriptor protocol should be:

1. Writer constructs the descriptor and all reachable immutable payload.
2. Writer performs a release publication of the pointer/version.
3. Reader enters the RCU/QSBR read-side critical section before loading the pointer.
4. Reader performs an acquire load of the publication pointer/version.
5. Reader validates the generation or sequence if writers can replace multiple related objects.
6. Writer retires the old object, but does not reclaim it until a grace period confirms that all preexisting readers have quiesced.
7. Reader exits its read-side section with the ordering required by the selected RCU/QSBR implementation.
8. Reclamation occurs only after the grace-period condition is satisfied.

The acquire load must be on the publication or validation variable that participates in the release/acquire chain. An acquire operation on an unrelated field does not establish the required ordering. Likewise, relaxed atomics may be sufficient for counters or some QSBR bookkeeping, but they do not automatically publish initialized object state.

### Snapshot guarantee

The strongest safe claim is:

> A reader that successfully enters the read-side critical section and observes a published generation sees a fully initialized, unreclaimed object corresponding to that generation.

A stronger claim—“the reader sees a globally coherent multi-object snapshot”—requires a versioned publication protocol, seqlock-style validation, immutable object graphs, or an equivalent atomic root pointer. Acquire/release alone does not make several independently updated fields appear as one transaction.

For QSBR, reclamation additionally depends on every participating reader reporting quiescent states correctly. A stalled, crashed, or non-cooperating reader can delay reclamation indefinitely; premature reclamation is a correctness failure, not merely a performance issue. DPDK’s QSBR documentation explicitly uses acquire loads in relevant grace-period logic, illustrating that the exact ordering must be attached to the protocol’s state transitions rather than inferred from descriptor layout.[5]

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or numerical model shared identically by these environments:

- **C++20** defines the host-language atomic model, but not GPU execution semantics.
- **Rust** provides language-level ownership and atomic abstractions, but unsafe FFI and accelerator backends still require target-specific guarantees.
- **CUDA** has distinct host/device, stream, kernel, and system-scope ordering rules.
- **Triton** exposes compiler-managed GPU programs whose legal barriers and visibility properties depend on its supported memory operations and target.
- **XLA** is an optimizing graph/compiler IR; operation ordering and aliasing are constrained by its compiler contract, not by C++ atomics.

Therefore, a V1350 conformance claim must distinguish:

1. **ABI conformance** — descriptor size, alignment, offsets, endianness, and calling convention.
2. **Numerical conformance** — output residuals, tolerances, NaN/Inf policy, and deterministic tie-breaking.
3. **Memory conformance** — publication, visibility, reader entry, retirement, and reclamation.
4. **Progress conformance** — bounded retries, fallback behavior, and deadlock freedom.
5. **Compiler conformance** — preservation of barriers, aliasing assumptions, and synchronization through lowering.
6. **Concurrency conformance** — litmus tests under the target’s actual memory scope and scheduling model.

The kernels should expose a common semantic contract, not pretend that the implementations are identical:

```text
Input:
  descriptor, X, tangent/update, step, execution context

Success:
  finite output Y
  ||YᵀY - I|| ≤ τorth
  declared generation remains valid
  no read-after-retire or use-after-reclaim

Failure:
  explicit status
  no partially published descriptor
  no reclamation before the required grace period
```

Each backend then maps that contract to its own primitives. Cross-silicon certification should include:

- descriptor layout `static_assert`/compile-time checks;
- acquire/release and grace-period litmus tests;
- randomized extreme-step tests, including \(\lvert\text{step}\rvert\ge10^{10}\);
- adversarial ill-conditioned matrices;
- NaN, Inf, overflow, and underflow tests;
- orthogonality and residual checks;
- race detection and sanitizer runs where supported;
- repeated runs across GPU architectures and compiler optimization levels;
- differential comparison against a high-precision polar/QR reference.

## Definitive architecture

The mathematically strongest and operationally defensible V1350 architecture is:

- **Primary retraction:** scaled Cayley for the well-conditioned moderate-step region.
- **Certified fallback:** Householder QR for failed conditioning, excessive step magnitude, nonconvergence, or residual violation.
- **Reference path:** polar retraction for validation and selected high-accuracy modes.
- **Descriptor publication:** immutable construction followed by release publication of a single versioned root.
- **Reader protocol:** acquire root load inside an RCU/QSBR read-side critical section, with generation validation when a coherent snapshot is required.
- **Reclamation:** only after a verified grace period; no descriptor-size or acquire/release shortcut may replace this requirement.
- **Portability:** one semantic specification, separate backend mappings, and mandatory numerical and memory-model conformance tests.
- **Guarantee form:** conditional and measurable—bounded residuals, explicit failure statuses, defined lifetime safety, and backend-specific synchronization—not an unconditional claim that every implementation is stable or equivalent at every step size.