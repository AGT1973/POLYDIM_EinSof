# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 79)

# POLYDIM V1350 — High Tribunal Audit, Cycle 79

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods
**Verdict posture:** Adversarial. Claims are treated as unproven until shown.

---

## 0. Preliminary: what the audit can and cannot certify

The Tribunal notes at the outset that **no source files were attached to this docket**. The audit below is therefore conducted against the *architectural claims as stated* in the six TARGET descriptions. Where a claim is mathematically decidable from the description alone (e.g. Neumaier error bounds, Cayley retraction orthogonality, Woodbury conditioning), we prove or refute it. Where a claim requires the actual bytes (e.g. the exact `struct` layout of the 88-byte descriptor, the FFI `extern "C"` signatures), we issue a **conditional certification** and demand the artifact.

Any component that fails to produce its artifact within one cycle is **struck from the SOTA register**.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor: `struct` format `<4sHHQQQQQBB6x4Q`

Let us count bytes under the standard `struct` module rules (little-endian, no alignment padding because `<` is used):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `H H` | 4 |
| five `Q` | `Q Q Q Q Q` | 40 |
| two `B` | `B B` | 2 |
| pad | `6x` | 6 |
| four `Q` | `Q Q Q Q` | 32 |
| **Total** | | **88** |

**Arithmetic check:** 4 + 4 + 40 + 2 + 6 + 32 = **88**. ✅

**Tribunal finding:** The byte count is *arithmetically* correct. However, three adversarial objections stand:

1. **`<` disables alignment.** This is fine for wire format but means the Python struct and the C++ `#pragma pack(1)` struct must agree *exactly*. If the C++ side uses `alignas(64)` for cache-line isolation (which a "12/12 physical conformance" claim implies), the layouts diverge. **Demand:** a `static_assert(sizeof(PmtpDescriptor) == 88)` in C++ and a `struct.calcsize("<4sHHQQQQQBB6x4Q") == 88` assertion in Python, both executed at import time.
2. **`6x` padding is a landmine.** Six bytes of explicit padding is a *semantic* choice, not an alignment artifact. If any future field is added, the padding must be re-derived. Recommend replacing with a named `_reserved: [u8; 6]` and a `#[repr(C, packed)]` Rust mirror.
3. **Endianness.** `<` forces little-endian. On a big-endian POWER10 or s390x node (both still in HPC fleets), the descriptor will be silently misread. **Rule 27 violation risk** if the orchestrator claims portability.

### 1.2 Multi-silicon HardwareProbe

The claim of "multi-silicon" probing is only meaningful if the probe is **fail-closed**. Adversarial scenario: a node reports `avx512f` in `/proc/cpuinfo` but the kernel has disabled AVX-512 via `clearcpuid` (a real CVE-2022-40982 mitigation). The probe must execute an actual `_mm512_add_ps` in a signal-handled trampoline, not parse flags.

**Demand:** `HardwareProbe` must include a `SIGILL`-guarded execution test for every ISA it claims to support. Flag-parsing alone is **struck**.

### 1.3 PmtpSlabAllocator

"Slab" implies fixed-size object pooling. For 88-byte objects, the natural slab is 4096/88 ≈ 46 objects per page with 48 bytes wasted. **Asymptotic fragmentation:** for N descriptors, waste is O(N) but with constant 48/4096 ≈ 1.17%. Acceptable. **But:** if the allocator is lock-free (implied by "orchestrator"), ABA on the free-list head is a classic bug. **Demand:** tagged pointers or a hazard-pointer scheme.

### 1.4 12/12 physical conformance checks

Without the checklist, this is **unfalsifiable**. The Tribunal requires the 12 checks to be enumerated and each mapped to a falsifiable predicate. A "12/12" claim with no published rubric is **struck as marketing**.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

Neumaier's variant of Kahan summation achieves, for a dot product of length n with unit roundoff u = 2⁻⁵³ (FP64):

$$
|\hat{s} - s| \le (2u + O(nu^2)) \sum_{i=1}^{n} |x_i y_i|
$$

This is **independent of n to first order** — the key advantage over naive summation (whose bound is $nu \sum |x_i y_i|$). ✅

**Adversarial edge case:** Neumaier's compensation term `c` is itself accumulated in FP64. If the true sum is ~0 but the partial sums are ~10¹⁰, catastrophic cancellation in `c` can still occur. The bound above is *relative to Σ|xᵢyᵢ|*, not to |s|. **If the caller needs relative accuracy on a near-zero result, Neumaier is insufficient.** Demand: a documented `condition_number = Σ|xᵢyᵢ| / |s|` returned alongside the result, with a warning if > 10¹².

### 2.2 Subnormal audits at -12 and -14

The exponents -12 and -14 are **not** the FP64 subnormal boundary (that is -1022, with the smallest subnormal at 2⁻¹⁰⁷⁴). They are presumably **decimal** exponents: 10⁻¹² and 10⁻¹⁴. These are *normal* FP64 values. So the "subnormal audit" is misnamed — it is a **small-magnitude audit**.

**Finding:** If the intent is to test true FP64 subnormals, the audit must probe near 2⁻¹⁰²². If the intent is to test small-but-normal values (e.g. physical constants at 10⁻¹²), the naming is misleading and the audit is trivially passed by any IEEE-754-compliant unit. **Demand:** clarify. If true subnormals are intended, note that **AVX-512 DAZ/FTZ flags** (Denormals-Are-Zero, Flush-To-Zero) are set by some BLAS libraries and will silently destroy the audit. The kernel must explicitly clear MXCSR bits 6 and 15.

### 2.3 Zero-copy PMTP validation

"Zero-copy" means the 88-byte descriptor is read directly from shared memory without a memcpy. **Adversarial scenario:** if the producer (Python orchestrator) writes the descriptor while the consumer (C++ kernel) reads it, and the descriptor straddles a cache line (88 bytes is not a multiple of 64), a torn read is possible on some architectures. **Demand:** either (a) align descriptors to 128 bytes, or (b) use a seqlock with a version counter in the descriptor.

### 2.4 `step → ∞` degeneracy

If `step` is a scalar multiplier in the kernel, then for `|step| ≥ 10¹⁰`:
- Any product `step * x` with `|x| > 10²⁹⁸` overflows to `+inf`.
- Neumaier's compensation term `c` becomes `inf - inf = NaN`.
- **The kernel must clamp `step` before the first multiply**, not after. Demand: `step = std::clamp(step, -1e10, 1e10)` at the FFI boundary, with a logged warning.

### 2.5 `step → 0` degeneracy

For `|step| < 2⁻¹⁰²²`, `step * x` may underflow to a subnormal or to zero. If the kernel then divides by `step` (e.g. in a normalization), it produces `inf` or `NaN`. **Demand:** a `step == 0` fast path that returns the identity, and a subnormal-preserving multiply (no FTZ).

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier — **REFUTED**

This is the most serious finding in the audit.

**Claim:** `panic = unwind` provides an FFI safety barrier.
**Reality:** Unwinding across an `extern "C"` boundary is **undefined behavior** in Rust (pre-1.81) and **aborts** in Rust 1.81+ with `extern "C"` (the `C-unwind` ABI is required for unwinding). If the Rust kernel is called from C++ via `extern "C"`, a panic will either:
- (pre-1.81) unwind into C++ frames → UB, or
- (1.81+) abort the process.

**Neither is a "safety barrier."** A safety barrier is `catch_unwind` at the FFI boundary, converting the panic into an error code. **Demand:** every `extern "C"` function must be wrapped:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> i32 {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(()) => 0,
        Err(_) => -1,
    }
}
```

And `panic = "abort"` is actually *safer* for FFI because it makes the failure mode deterministic. The claim that `unwind` is a barrier is **struck**.

### 3.2 Safe SIMD

Rust's `std::simd` is still nightly-only as of 2024. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe` intrinsics. "Safe SIMD" is therefore either (a) a nightly feature, or (b) a misnomer. **Demand:** specify the toolchain and the exact safety argument.

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` on a struct containing `u64` fields will generate **unaligned loads** on some targets, which are slow or faulting on strict-alignment architectures (SPARC, some ARM). **Demand:** `#[repr(C)]` with explicit `_pad: [u8; 6]` and a `static_assert` equivalent (`const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`).

### 3.4 Neumaier sums

Same analysis as Target 2. The Rust implementation must use `f64::mul_add