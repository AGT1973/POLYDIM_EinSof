# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 115)

# POLYDIM V1350 — HIGH TRIBUNAL AUDIT
## Cycle 115 · Six-Component Adversarial Review

**Presiding note.** The Tribunal treats every claim as falsifiable. Where a component's source is not in evidence, we audit the *stated contract* and flag unverifiable assertions as **UNPROVEN** rather than passing them. Numerical claims are checked against IEEE-754 binary64 (and binary32 where noted), the Kahan–Neumaier error bound, and standard Stiefel/Cayley literature (Edelman–Arias–Smith 1998; Wen–Yin 2013; Hairer–Lubich–Wanner).

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Struct size audit (native alignment assumed, `=` little-endian, no padding):

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| a, b | `HH` | 4 | 4 |
| q1..q5 | `QQQQQ` | 40 | 8 |
| c, d | `BB` | 2 | 48 |
| pad | `6x` | 6 | 50 |
| tail | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict: 88 bytes confirmed.** But two hazards:

- **H1 (alignment).** `Q` requires 8-byte alignment. Offset 8 ✓, offset 56 ✓. However, if the struct is embedded in a packed container or a `bytearray` slice at an odd offset, `struct.unpack` is fine but a C++ `reinterpret_cast` to a struct with `alignas(8)` will fault on ARM64 (SVE) and misalign on x86 (slow path). **Recommendation:** declare `alignas(8)` in C++/Rust and assert `(uintptr_t)ptr % 8 == 0` at every FFI boundary.
- **H2 (endianness).** `<` is little-endian. TPU/Trainium HLO and some POWER9 hosts are big-endian. **Recommendation:** canonicalize to LE on the wire and byte-swap at the host boundary; do not rely on `<` matching host order.

### 1.2 12/12 physical conformance checks

Without the check list we cannot certify. The Tribunal requires the 12 checks to include at minimum: (i) magic match, (ii) version match, (iii) `a,b` in range, (iv) `q1..q5` monotone where required, (v) `c,d` enum-valid, (vi) pad bytes zero, (vii) tail checksum, (viii) size == 88, (ix) alignment, (x) endianness, (xi) reserved-bit zero, (xii) cross-field invariant (e.g., `q3 == q1*q2`). **UNPROVEN** until enumerated.

### 1.3 Numerical degeneracy at `|step| ≥ 10^10`

The orchestrator itself is integer/descriptor logic; degeneracy propagates from downstream kernels. The orchestrator **must** clamp `step` before dispatch. See §7.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant (improved Kahan) gives, for `n` terms with unit roundoff `u = 2^-53`:

```
|error| ≤ (2u + O(nu²)) · Σ|x_i y_i|
```

**Asymptotic condition number:** `κ_dot = Σ|x_i y_i| / |Σ x_i y_i|`. For catastrophic cancellation (`κ_dot → ∞`), Neumaier recovers the *exact* sum to within `2u·Σ|x_i y_i|`, i.e., the compensated result is as accurate as if computed in ~2× precision. **This is the correct choice**; naive Kahan fails when the running sum is smaller than the next addend.

**Degeneracy at `step → ∞`:** if `step` scales the operands, `Σ|x_i y_i| ~ step²`, and the *absolute* error grows as `step²·u`. For `step = 10^10`, `step² = 10^20`, and `u·10^20 ≈ 10^-16·10^20 = 10^4` — **absolute error of order 10^4**. If the true dot product is O(1), the result is garbage. **Mitigation:** pre-scale by `1/step` (see §4 Woodbury trick) so the compensated sum operates on O(1) magnitudes.

### 2.2 Subnormal audits at `-12, -14`

Subnormals in binary64 live in `[2^-1074, 2^-1022)`. The exponents `-12, -14` are **not** subnormal — they are ordinary normals. Two readings:

- If these are **decimal exponents** (`10^-12`, `10^-14`), still normal.
- If these are **binary exponents of a scaled quantity** (e.g., `2^-12`), still normal.

**Verdict: the "subnormal audit" labels are misnomers.** True subnormal audit points are `-1022` and `-1074`. **Recommendation:** rename to "small-magnitude audit" or move the probes to `2^-1022` and `2^-1074`. On AVX-512, subnormal inputs trigger a **microcode assist** (~100–200 cycle penalty per instruction) unless `FTZ/DAZ` is set in MXCSR — but FTZ/DAZ **destroys** the audit. **Recommendation:** run subnormal audits on a dedicated thread with FTZ/DAZ cleared, and restore MXCSR after.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be **immutable** for the kernel's lifetime. If the orchestrator mutates `q1..q5` concurrently, the C++ kernel reads torn state. **Recommendation:** `const PmtpDescriptor* __restrict__` + a seqlock or RCU epoch; assert `magic` before and after the kernel.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` FFI safety barrier

**This is a serious hazard.** `panic = unwind` across an `extern "C"` boundary is **undefined behavior** in Rust (the C ABI has no unwind tables). The correct pattern is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```

**Recommendation:** either (a) set `panic = abort` for the FFI crate, or (b) wrap every `extern "C"` entry in `catch_unwind`. The stated "panic=unwind FFI safety barrier" is **not a barrier** — it is a UB vector. **FAIL.**

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust `#[repr(C, packed)]` removes padding but **also removes alignment guarantees**. Reading a `u64` field from a packed struct generates unaligned loads — legal on x86/ARM64 but **not** on some RISC-V and older ARM. **Recommendation:** use `#[repr(C)]` with explicit `alignas(8)` and a `[u8; 6]` pad field, matching the Python layout exactly. Verify with `std::mem::size_of::<PmtpTensorDescriptor>() == 88` and `align_of == 8` in a `const _: () = assert!(...)`.

### 3.3 Neumaier in Rust

Rust's `f64::mul_add` (FMA) is **not** the same as Neumaier compensation. If the kernel uses `mul_add` and calls it "Neumaier," that is a **mislabel**. Neumaier requires explicit `t = sum + x; if |sum| >= |x| { c += (sum - t) + x } else { c += (x - t) + sum }`. **UNPROVEN** without source.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in `R^(2K × 2K)`

Cayley retraction: `Y = (I - ½W)^{-1}(I + ½W) X`, where `W = A X^T - X A^T` is skew-symmetric. For `X ∈ St(2K, 2K)` (i.e., `X` orthogonal), `W` is `2K × 2K` skew.

**Condition number of `(I - ½W)`:** eigenvalues of `W` are purely imaginary, `±iλ_j`. Then `I - ½W` has eigenvalues `1 ∓ iλ_j/2`, so

```
κ₂(I - ½W) = max_j |1 + iλ_j/2| / min_j |1 + iλ_j/2|
           = sqrt(1 + λ_max²/4) / sqrt(1 + λ_min²/4)
```

For `step → ∞`, `λ_max ~ step`, so `κ₂ ~ step/2`. At `step = 10^10`, `κ₂ ~ 5×10^9` — **the linear solve loses ~9.7 decimal digits**. In FP64 (16 digits), you retain ~6 digits. **Marginal but survivable**; in FP32 it is catastrophic.

**Recommendation:** use the **Woodbury/scaled form** (see §4.2) to keep `κ₂` bounded, or switch to a **QR-based retraction** (`qr(X + step·A)`) whose condition number is `O(1)` in `step`.

### 4.2 Globally scaled Woodbury solve `(M/scale) W = (step/scale) B`

This is the correct stabilization. If `M = I - ½W` and `B = I + ½W`, then solving `M W = step·B` with `scale = max(1, |step|)` gives

```
(M/scale) W = (step/scale) B
```

Both sides are O(1) in `step`. **But:** `M/scale` is no longer `I - ½W`; it is `I/scale - ½W/scale`. For `scale = step`, `M/scale → -½W/step`, which is **singular** as `step → ∞` (since `W/step` is O(1) but `I/step → 0`). **The scaling is only valid if `M` is dominated by `I`, i.e., `|step| ≲ 1`.** For `|step| ≥ 10^10`, the scaled system is **ill-posed**. **Recommendation:** cap `step` at `O(1)` and use multiple