# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 78

The requested arbitration cannot be validated as a comparison of six model reports: no public, authoritative record of the **POLYDIM V1350**, its six kernels, or the Claude/Qwen/Kimi/Gemini/DeepSeek/Perplexity findings was located. The available evidence supports only general conclusions about Stiefel retractions, C++ memory ordering, RCU/QSBR, and portability—not exact V1350 guarantees.

## Arbitration

### 1. Cayley–Stiefel retraction under \(\lvert\mathrm{step}\rvert \ge 10^{10}\)

A Cayley update can preserve orthogonality in exact arithmetic when formed correctly, but it is **not unconditionally stable for arbitrarily large steps**. Large parameters can cause:

- ill-conditioned linear solves;
- overflow or loss of significance in forming the skew-symmetric generator;
- amplification of conditioning errors;
- failure of convergence or loss of numerical feasibility in finite precision.

Householder and polar-based methods provide stronger orthogonality control, but they have different trade-offs:

| Method | Extreme-step behavior | Orthogonality guarantee |
|---|---|---|
| Cayley retraction | Requires bounded/scaled generator and stable solve | Conditional, finite-precision |
| Householder QR | Generally robust, but needs scaling and careful blocked implementation | Strong numerical orthogonalization |
| Polar retraction | Often the best geometric projection when the matrix is nonsingular and the polar factor is computed stably | Strong, but SVD/iteration conditioning applies |

**Definitive arbitration:** no method should claim unconditional stability at \(\lvert\mathrm{step}\rvert \ge 10^{10}\). The mathematically defensible design is an adaptive retraction:

\[
\Delta \leftarrow \frac{\Delta}{\max(1,\|\Delta\|/\tau)},
\]

followed by a Cayley step only when its linear system is adequately conditioned; otherwise fall back to a Householder or polar-based retraction. The implementation must verify

\[
\|X^\top X-I\| \le \varepsilon_{\mathrm{orth}}
\]

and reject, rescale, or recompute failed updates.

Thus, claims that Cayley is categorically superior to Householder or polar QR under extreme steps are unsupported. A **guarded hybrid** is superior to any unconditional single-method claim.

### 2. PMTP 88-byte descriptors and RCU/QSBR snapshot isolation

An 88-byte layout, by itself, provides no memory-safety or snapshot-isolation guarantee. Correctness depends on:

- atomicity and alignment of every concurrently accessed field;
- a clearly defined publication protocol;
- acquire/release or stronger ordering on the publication path;
- reader registration and quiescent-state participation;
- reclamation only after a grace period;
- avoidance of non-atomic concurrent access to mutable descriptor fields.

The relevant RCU/QSBR evidence indicates that readers must observe the published generation before accessing the pointed-to structure, and that reclamation must wait until readers have either reported quiescence or observed the relevant grace-period state.[1] QSBR also requires participating reader threads to be registered before entering read-side critical sections.[2]

A sound protocol is:

**Writer**

1. Construct an entirely immutable descriptor \(D_{n+1}\).
2. Publish its pointer or generation with **release** semantics.
3. Retire \(D_n\).
4. Reclaim \(D_n\) only after an RCU/QSBR grace period.

**Reader**

1. Enter the read-side critical section.
2. Load the pointer or generation with **acquire** semantics.
3. Read only immutable contents of that descriptor.
4. Exit and report quiescence according to the selected RCU/QSBR implementation.

The guarantee is:

\[
\text{Acquire(reader)} \;\leadsto\; \text{Release(writer)}
\]

for initialization visibility, plus a completed grace period before reclamation. Acquire/release alone does **not** guarantee reclamation safety if readers fail to register, fail to report quiescence, access retired objects after leaving the read-side section, or mutate descriptor fields concurrently.

**Definitive arbitration:** the 88-byte size is an ABI/storage constraint, not a synchronization proof. The exact guarantee should be stated as:

> A reader that is correctly registered, inside a read-side critical section, and that acquires the published descriptor observes a fully initialized immutable snapshot. The descriptor remains alive until the applicable grace period completes.

No stronger guarantee follows from “Acquire/Release” alone.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or execution model shared identically by these environments. Conformance must therefore be defined at an explicit abstraction boundary.

Important distinctions include:

- **C++20:** language-level atomics and memory ordering apply only to objects accessed through the C++ abstract machine.
- **Rust:** ownership and borrowing provide strong aliasing discipline, but cross-thread publication still requires appropriate atomic primitives or synchronization; `unsafe` code can invalidate those guarantees.
- **CUDA:** host and device memory, scopes, fences, atomics, streams, and kernel launches have distinct ordering rules.
- **Triton:** compiler lowering and backend-specific atomic/fence support must be verified rather than assumed from C++ or Rust semantics.
- **XLA:** operations may be fused, reordered, replicated, or lowered differently; ordinary host-language acquire/release assumptions do not automatically describe device execution.

Accordingly, “multi-silicon conformance” cannot mean bit-identical behavior or identical memory ordering on every backend. The strongest defensible definition is **observational conformance**:

1. Every backend implements the same descriptor state machine.
2. Publication is represented by an explicit release-capable operation.
3. Snapshot acquisition is represented by an explicit acquire-capable operation.
4. Descriptor contents are immutable after publication.
5. Reclamation is performed only by a host/runtime mechanism with a proven grace-period protocol.
6. Numerical kernels use bounded inputs, defined rounding/error tolerances, and explicit NaN/overflow behavior.
7. A litmus-test suite validates visibility, no-use-after-reclaim, generation consistency, and numerical invariants on each target.

## Definitive SOTA synthesis

The mathematically and architecturally strongest synthesis is:

- Use a **guarded hybrid Stiefel retraction**: Cayley for well-conditioned moderate updates; Householder or polar fallback for extreme or ill-conditioned updates.
- Treat the PMTP descriptor as an **immutable, versioned snapshot**, not as a merely packed 88-byte record.
- Publish snapshots with release semantics and consume them with acquire semantics.
- Use RCU/QSBR grace periods for reclamation; do not rely on acquire/release alone.
- Define CUDA/XLA/Triton/C++20/Rust compatibility through a small, explicit abstract protocol and backend-specific implementations.
- Require runtime invariant checks for orthogonality, generation consistency, descriptor lifetime, and backend-visible ordering.

The exact guarantees that can legitimately be claimed are therefore:

\[
\boxed{
\begin{aligned}
&\text{Numerical: } \|X^\top X-I\|\le\varepsilon_{\mathrm{orth}}
\text{ only when the guarded update succeeds;}\\
&\text{Memory: acquire observes release-published immutable initialization;}\\
&\text{Lifetime: reclamation occurs only after a completed grace period;}\\
&\text{Portability: observational conformance holds only for tested backend mappings;}\\
&\text{Failure mode: extreme steps, unsupported atomics, failed fences, or invalid}\\
&\text{quiescence are detected and rejected—not silently treated as correct.}
\end{aligned}
}
\]

The public search evidence does not establish any stronger V1350-specific result, nor does it provide the six tribunal reports needed to rank or reconcile the individual models.