# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 134

The requested arbitration cannot be made definitively from the available evidence: **POLYDIM V1350, “Cycle 134,” the six kernels, and the eight Tribunal reports are not publicly documented in the retrieved sources**. The available material supports only general conclusions about Stiefel retractions and RCU/QSBR—not claims about this specific architecture or cross-silicon conformance.

## 1. Cayley/Stiefel stability versus Householder/Polar QR

For \(X\in\mathrm{St}(n,p)\) and tangent update \(\Xi\), a Cayley-style update has the form

\[
X_{+}
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\qquad W^{T}=-W.
\]

In exact arithmetic, the Cayley transform is orthogonal, so it preserves the Stiefel constraint. The retrieved mathematical source confirms this formulation and identifies Cayley retraction as a recognized Stiefel retraction.[1][4]

However, **orthogonality in exact arithmetic does not imply numerical stability for \(\lvert\mathrm{step}\rvert\ge 10^{10}\)**. At such scales:

- forming \(W\) can overflow or lose relative accuracy;
- solving \(I-\frac12W\) can become poorly scaled;
- iterative Cayley approximations require a contraction condition involving \(\|W\|\); the retrieved literature states a sufficient condition of the form \(\alpha<2/\|W\|\).[8]
- a naïve implementation cannot receive a blanket “stable for all extreme steps” guarantee.

A QR or polar retraction is therefore preferable as a **fallback or normalization path**:

\[
X_{+}=\operatorname{qf}(X+\Xi)
\]

for QR, or

\[
X_{+}=(X+\Xi)\bigl((X+\Xi)^T(X+\Xi)\bigr)^{-1/2}
\]

for the polar factor. QR is generally cheaper; the polar factor is often a stronger nearest-point projection but can be more expensive and sensitive to conditioning in its Gram/eigendecomposition route. Householder QR is usually preferable to classical Gram–Schmidt because it provides backward stability under standard floating-point assumptions.

**Arbitrated result:** no unconditional superiority claim is justified. The strongest defensible architecture is:

1. scale or damp the step before constructing the Cayley transform;
2. use a stable solve rather than an explicit inverse;
3. verify \(\|X_+^TX_+-I\|\);
4. fall back to Householder QR or a robust polar implementation when the bound or residual test fails;
5. specify a finite-precision error tolerance rather than claiming exact preservation.

Thus, the exact guarantee is conditional:

\[
X_+^T X_+ = I
\]

only in exact arithmetic; in floating point, the guarantee should be stated as

\[
\|X_+^T X_+-I\| \le \tau_{\mathrm{orth}}
\]

provided the conditioning, overflow, and residual checks pass.

## 2. PMTP 88-byte descriptors and RCU/QSBR

The retrieved QSBR implementation supports the general principle that readers must observe the relevant generation/parity before dereferencing a newly published pointer, and that memory barriers are part of the protocol.[5] It also describes waiting for readers to report quiescence or observe the current grace-period counter.[5]

That does **not** establish that an 88-byte descriptor is sufficient, nor that its layout automatically provides snapshot isolation. Descriptor size is a representation constraint; correctness depends on:

- atomicity of each published field;
- alignment and permitted atomic widths on every target;
- a clearly defined immutable-versus-mutable split;
- publication ordering;
- reader entry/exit protocol;
- grace-period completion before reclamation;
- avoidance of torn multiword snapshots.

Acquire/release semantics can provide the necessary publication ordering only when used in a complete protocol. A typical safe pattern is:

```text
writer:
    initialize immutable payload
    publish descriptor pointer with release
    wait for grace period before reclaiming old payload

reader:
    enter RCU/QSBR read-side critical section
    load descriptor pointer with acquire
    read immutable payload
    exit read-side critical section
```

If the descriptor itself is updated in multiple words, a single acquire load does not make those fields an atomic snapshot. The design must use one of:

- immutable descriptors with atomic pointer replacement;
- a seqlock/version protocol;
- a double-width or otherwise supported atomic publication mechanism;
- transactional or platform-specific atomic facilities.

**Arbitrated result:** acquire/release is necessary in many implementations but is not, by itself, a proof of RCU snapshot isolation. The exact guarantee should be:

> A reader that successfully acquires a published immutable descriptor and remains inside the read-side critical section observes a fully initialized descriptor; reclamation of the prior descriptor is forbidden until the applicable grace period completes.

That guarantee requires the stated RCU/QSBR protocol and cannot be inferred from “88 bytes” alone.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

No retrieved evidence demonstrates implementation or conformance of the V1350 kernels across these ecosystems. Consequently, a claim of universal multi-silicon conformance would be unsupported.

The systems also do not share one uniform memory model:

- **C++20** provides language-level atomic and memory-order semantics, subject to the target implementation.
- **Rust** exposes comparable atomic ordering concepts, but unsafe pointer reclamation and FFI boundaries require explicit proofs.
- **CUDA** has device, block, system, and host interaction scopes with platform-specific ordering rules.
- **Triton** lowers through compiler and backend-specific mechanisms; source-level intent is not automatically an inter-backend proof.
- **XLA** uses compiler-level ordering and buffer semantics, and may transform or fuse operations unless synchronization and aliasing constraints are explicitly represented.

The correct conformance criterion is therefore observational, not source-level identity. Each backend must pass tests for:

- orthogonality residual and rank preservation;
- extreme-step behavior and fallback activation;
- descriptor publication and absence of torn reads;
- delayed reclamation under stalled readers;
- concurrent writer/reader stress;
- NaN, infinity, overflow, and cancellation behavior;
- deterministic ABI/layout validation;
- target-specific atomic-width and alignment checks.

## Definitive arbitration

Based on the available evidence, the mathematically and architecturally defensible synthesis is:

1. **Cayley retraction:** structure-preserving in exact arithmetic, but not unconditionally stable for extreme steps. Use scaling, stable solves, residual validation, and Householder-QR or polar fallback.
2. **PMTP descriptor:** 88 bytes is not a correctness guarantee. Acquire/release establishes ordering only within a complete immutable-publication plus RCU/QSBR grace-period protocol.
3. **Cross-platform conformance:** cannot be asserted without backend-specific implementations, memory-model mappings, and conformance tests. A single “universal” guarantee across CUDA, XLA, Triton, C++20, and Rust would be overstated.

The retrieved sources substantiate the general Cayley/Stiefel formulas and QSBR barrier principles,[1][4][5][8] but they do not substantiate the named V1350 kernels, the eight Tribunal findings, or any claimed SOTA architectural guarantees for them.