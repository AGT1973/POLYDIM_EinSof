# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 150

The requested arbitration cannot be validated as stated: the eight Tribunal reports, the six V1350 kernel specifications, and a reproducible benchmark corpus were not provided, and no authoritative public record for “POLYDIM V1350,” “PMTP 88-byte Descriptor,” or “Cycle 150” was found. The available search results identify **PolyDiM** as a C++ library for polytopal discretization methods, not this kernel suite.[7][10] Consequently, no defensible model-by-model vote or “definitive” empirical SOTA claim can be issued.

What can be established mathematically is the following.

## 1. Extreme-step Stiefel retraction

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), a retraction must preserve—or numerically restore—the constraint

\[
X^\top X=I_p.
\]

For an update \(Y=X+\alpha \Delta\), where \(|\alpha|\ge 10^{10}\), the dominant issue is conditioning and floating-point range, not merely the choice of orthogonalization label.

- **Householder QR** is generally the strongest default for rank-revealing orthonormalization. It is backward stable, avoids explicitly forming normal equations, and is usually preferable to classical Gram–Schmidt.
- **Polar retraction**, typically computed through an SVD or a stable polar-decomposition algorithm,

\[
R_{\mathrm{polar}}(Y)=Y(Y^\top Y)^{-1/2},
\]

is geometrically canonical, but forming \(Y^\top Y\) squares the condition number and is unsafe if done naively.
- **Cayley retraction** is attractive because it uses an implicit orthogonal transform. For a skew-symmetric generator \(A^\top=-A\),

\[
Q=(I-\tfrac12 A)^{-1}(I+\tfrac12 A),
\]

\(Q\) is exactly orthogonal in exact arithmetic whenever the inverse exists. In floating-point arithmetic, however, stability depends on solving the linear system stably and on how the generator is constructed. A large step can make the solve ill-conditioned or cause overflow before the Cayley transform is evaluated.

Therefore, the strongest unconditional claim is **not** that Cayley is universally more stable than Householder or polar QR. The defensible guarantee is:

> For extreme steps, use scaled arithmetic, finite-value checks, a stable QR or SVD/polar fallback, and an explicit residual test  
> \[
> \|R^\top R-I\| \le \tau_{\mathrm{orth}}.
> \]

If the required guarantee is constraint preservation under arbitrary finite input, no ordinary floating-point implementation can provide it without assumptions on conditioning, representability, and nonoverflow. A Cayley implementation may be selected as the primary path, but it requires a certified fallback.

## 2. PMTP descriptor barriers and RCU/QSBR

An 88-byte size alone says nothing about synchronization correctness. Correct snapshot isolation requires a published immutable state together with a reclamation protocol.

The writer-side publication pattern must be conceptually equivalent to:

```cpp
state->initialize_completely();
descriptor->published.store(state, std::memory_order_release);
```

A reader must pair this with:

```cpp
auto* s = descriptor->published.load(std::memory_order_acquire);
```

The acquire load ensures that initialization sequenced before the release publication becomes visible to the reader. However, **Acquire/Release alone does not provide memory reclamation safety**. The reader must also enter a read-side critical section before loading the pointer, and the writer must defer reclamation until an RCU grace period or QSBR condition has completed.

The required ordering is therefore:

1. Reader enters RCU/QSBR read-side protection.
2. Reader performs an acquire load of the published pointer or generation.
3. Reader accesses the immutable snapshot.
4. Reader exits the read-side critical section.
5. Writer publishes a replacement with release semantics.
6. Writer waits for the applicable grace period.
7. Writer reclaims the old snapshot.

The QSBR implementation searched describes precisely this distinction: readers must observe the relevant generation/parity, and grace-period completion must precede committing the next generation; compiler ordering and barriers are required to prevent missed observations.[2]

Thus the architectural guarantee should be stated narrowly:

> Release publication plus acquire observation guarantees visibility of initialized snapshot contents; RCU/QSBR grace-period completion guarantees that the observed snapshot remains alive. Neither guarantee follows from descriptor packing, alignment, or atomicity alone.

The 88-byte layout must also specify field offsets, alignment, atomic widths, cache-line behavior, endian assumptions, and whether atomics are lock-free on every target. A packed or misaligned atomic field can invalidate the portability claim even if the abstract C++ memory orders are correct.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single universal guarantee across these ecosystems is not available without defining an explicit contract. Their memory models and lowering paths are not identical:

- **C++20** can specify host-language atomic ordering and object-lifetime rules.
- **Rust** can express ownership and atomic ordering, but unsafe device interoperability still depends on the backend and ABI.
- **CUDA** has distinct host, device, block, grid, and system scopes; a C++ acquire/release statement does not automatically imply system-wide GPU visibility.
- **Triton** exposes compiler- and architecture-dependent memory operations and synchronization primitives.
- **XLA** may fuse, reorder, replicate, or lower operations according to its intermediate representation and backend semantics; source-level barriers are not automatically preserved as hardware fences.

A sound conformance specification must define:

- a canonical data layout and ABI;
- supported scalar types and alignment;
- memory scope for every atomic operation;
- publication and reclamation protocol;
- synchronization points and allowed compiler transformations;
- numerical tolerances;
- NaN, infinity, overflow, and denormal behavior;
- deterministic behavior requirements;
- a litmus-test suite and stress tests;
- target-specific feature gates and fallback paths.

The correct claim is therefore **conditional conformance**:

> The kernels conform across CUDA, XLA, Triton, C++20, and Rust only when each backend implements the same abstract state-machine contract and passes the same litmus, lifetime, numerical, and layout tests. Source-level similarity is not evidence of semantic equivalence.

## Arbitration outcome

Absent the actual eight reports, the mathematically strongest synthesis is:

1. **Retraction:** Cayley is acceptable as a primary orthogonal-update method, but not as an unconditional extreme-step stability winner. Stable QR/SVD fallback, scaling, and residual certification are mandatory.
2. **Descriptor synchronization:** Release/acquire is necessary for snapshot publication and observation, but RCU/QSBR grace periods are independently necessary for lifetime safety. The 88-byte format is an ABI constraint, not a correctness proof.
3. **Portability:** Cross-silicon conformance is a contract-and-test result, not a property inferred from C++20 or Rust source. CUDA, XLA, and Triton require explicit memory scopes and backend-specific validation.
4. **Exact guarantees:** The only defensible guarantees are conditional guarantees parameterized by bounded inputs, representable values, conditioning thresholds, atomic alignment/lock-freedom, supported memory scopes, and successful conformance tests.

Any Tribunal model claiming unconditional stability for \(|\mathrm{step}|\ge 10^{10}\), automatic RCU safety from Acquire/Release alone, or semantic equivalence across all five compilation ecosystems would be overstating what the stated premises establish.