# AUDITORÍA TRIBUNAL DE SABIOS — Claude_Sonnet_5_5 (CICLO 149)

I don't actually have access to the six files being referenced in this audit, so I shouldn't fabricate specific findings about code I haven't seen. What I can offer is substantive value independent of that: analysis of the Cayley retraction math, Woodbury scaling, condition numbers, the 88-byte descriptor struct layout, general FFI hardening recommendations, and an audit checklist—while flagging the references to "Rule 22" and "Rule 27" that I should address honestly.

Working through the struct format, I verify the field sizes add up correctly to 88 bytes with little-endian standard sizing and no implicit alignment padding. Checking natural C alignment instead, I find it also lands on 88 bytes without needing packed representation, meaning explicit packing attributes would actually be unnecessary and could introduce unaligned-reference undefined behavior in Rust—a useful concrete finding. There's also a subtlety about buffer alignment if the bytes originate from Python, which would require unaligned reads.

I also note a possible semantic tension: a rule about zero 1D tokens versus treating the descriptor itself as a byte stream, which I should flag as an ambiguity worth clarifying rather than resolving unilaterally.

Now I'm working through the Cayley retraction on the Stiefel manifold, setting up the skew-symmetric matrix from the gradient and expressing it in low-rank factored form to analyze the retraction's computational structure.

Alternatively, forming iKx via the skew structure and using a complex Hermitian eigensolver or real Schur decomposition would make more sense, since eigendecomposing once lets you reuse it across steps for the Cayley transform.

For a skew-symmetric K, its eigenvalues are purely imaginary ±iσ, so the Cayley map produces unit-modulus eigenvalues that tend to −1 for all nonzero modes as t→∞, meaning the orthogonal matrix stays bounded — it converges to a reflection that's −I on the range of K and I on its null space, so no blow-up occurs there. The real issue is that the Woodbury correction term grows like t, so its conditioning scales with the step size even though the orthogonal matrix itself stays well-behaved.

Working through the normalized form, as the step size goes to infinity the scaled matrix approaches V^TU plus a vanishing identity term; if V^TU is singular — which happens when A has rank below 2k, say when G is rank-deficient — the limit becomes singular and the tiny regularization term has to carry the conditioning on those null directions. That means the condition number grows linearly with the step size on those degenerate directions, so at extremely large steps like 1e10 the conditioning becomes enormous.

I check the special case where the gradient G equals X times a symmetric matrix S (gradient confined to the normal space), which forces A to vanish entirely. In that scenario V^TU takes a block form built from S and its square, and squaring that block matrix gives exactly zero — it's nilpotent. That nilpotency lets me invert the resulting matrix exactly as a simple linear correction rather than needing a full matrix inverse.

Working through the condition number of this nilpotent correction, I find it scales quadratically with t, so at t=1e10 the condition number blows up past 1/eps — meaning the Woodbury 2k-system can become catastrophically ill-conditioned even though the true underlying Cayley transform problem is perfectly stable (since A=0 implies Q=I trivially). I also note that rescaling by 1/scale doesn't fix this, since scalar multiplication alone doesn't change the condition number.

By contrast, when I examine the full n×n system directly, with A skew-symmetric, the singular values come out as sqrt(1+(tσ/2)²), giving a condition number that grows only linearly in t — so the full-dimension formulation is actually much better conditioned than the low-rank Woodbury reduction in this regime.

For the true normal skew case, I realize the Cayley transform via spectral decomposition of A (using the Hermitian eigenvalues of iA) stays backward stable for all t, since the resulting Q(t) has entries of unit modulus.

