# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 140)

# POLYDIM V1350 — High Tribunal Audit, Cycle 140

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods
**Verdict class:** Adversarial SOTA — findings are graded **C (Critical)**, **M (Major)**, **m (minor)**, **P (Pass)**.

---

## 0. Preliminary: what we can and cannot audit

The Tribunal notes that the six artifacts were submitted as **architectural specifications**, not as source. Every claim below is therefore evaluated against the *stated* contract (88-byte descriptor, Neumaier sums, Cayley retraction, etc.). Where a claim is unfalsifiable without source (e.g., "12/12 physical conformance checks"), we mark it **P-conditional** and demand the conformance harness be produced under seal in Cycle 141.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly (little-endian, standard `struct` alignment disabled by `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major, version_minor | `HH` | 4 |
| flags, dtype, rank, reserved16 | `HHBB`? — **see below** | — |
| Q×5 | `QQQQQ` | 40 |
| B×2 | `BB` | 2 |
| pad | `6x` | 6 |
| Q×4 | `QQQQ` | 32 |
| **Total** | | **88** |

**Finding 1.1 (M):** The format string `<4sHHQQQQQBB6x4Q` contains **only two `H`** but the prose claims "12/12 physical conformance checks" including *rank* and *dtype*. If rank/dtype are packed into the two `B` fields, then `flags` is a single `H` and the second `H` is `version_minor` — meaning **there is no room for a `reserved16`**. Either the prose is wrong or the format string is wrong. **Demand:** byte-offset table signed by the author.

**Finding 1.2 (C):** `6x` padding is **not** a conformance check — it is a *hole*. A malicious peer can write arbitrary bytes into offsets 52–57 and they will round-trip through `struct.pack/unpack` without detection. Under Rule 22 (zero 1D tokens), the descriptor is the *only* inter-agent token; a 6-byte uncontrolled channel is a **covert-channel violation**. **Recommendation:** replace `6x` with `6s` nonce and require HMAC over the 88 bytes, or zero it and assert `== b'\x00'*6` on unpack.

### 1.2 `PmtpSlabAllocator` under step → ∞ / step → 0

The allocator is described as slab-based. Two degeneracies:

- **step → ∞ (|step| ≥ 10¹⁰):** if slab size is computed as `ceil(step * K * sizeof(T))`, the product overflows `size_t` on 32-bit hosts and silently wraps on 64-bit when `step * K * sizeof(T) > 2⁶⁴`. **Proof obligation:** show `K * sizeof(T) < 2⁵⁴ / 10¹⁰ ≈ 1.8×10⁶`. If K is the Stiefel dimension 2K from Target 4, this fails for K > 9×10⁵.
- **step → 0 (subnormal):** if slab size is `max(1, floor(step * ...))`, the allocator degenerates to 1-element slabs → **allocator thrash**, O(step⁻¹) syscalls. This is a **denial-of-service vector** in a multi-agent loop.

**Finding 1.3 (M):** No stated clamp. **Recommendation:** `step_eff = clamp(step, 2⁻²⁰, 2⁴⁰)` before any size arithmetic, with a logged warning.

### 1.3 HardwareProbe multi-silicon

**Finding 1.4 (P-conditional):** Probing is fine, but the probe result must be **cached and signed**; otherwise a compromised agent can spoof `cuda_available=True` and force the orchestrator into a code path that then fails open. **Recommendation:** probe once at boot, hash the result into the 88-byte descriptor's `flags` field.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's algorithm is *conditionally* accurate: it is exact for the sum of two floats, but the **compensation term itself accumulates rounding** over N terms. The classical bound (Higham, *Accuracy and Stability*, Thm 4.3) gives

$$
|\hat{s} - s| \le \gamma_{n-1} \sum |x_i y_i| + O(u^2)
$$

with $\gamma_k = ku/(1-ku)$. For N = 10⁶ and u = 2⁻⁵³, $\gamma \approx 1.1\times10^{-10}$ — fine. But:

**Finding 2.1 (M):** Neumaier does **not** protect against **catastrophic cancellation in the products themselves**. If `x_i * y_i` underflows to subnormal, the compensation term `(t - s) + (x_i*y_i - t)` is computed with **reduced precision** (subnormals have fewer significand bits). The audit claim "subnormal audits (-12, -14)" suggests the authors know this — but the *fix* must be **scaling**, not auditing. **Recommendation:** pre-scale by `2^⌈log2(max|x||y|)⌉` and post-scale, or use `fma`-based TwoProd (Dekker) which is subnormal-safe on AVX-512.

### 2.2 step → ∞ / step → 0

- **step → ∞:** if the kernel computes `step * A` for a matrix A, the product overflows to `+inf`; Neumaier then produces `inf - inf = NaN`. **Finding 2.2 (C):** no stated overflow guard. **Proof obligation:** show `‖A‖∞ · step < FLT_MAX ≈ 3.4×10³⁸`. For step = 10¹⁰ this requires `‖A‖∞ < 3.4×10²⁸` — plausible but unverified.
- **step → 0:** subnormal products. AVX-512 with `MXCSR.DAZ=1` (denormals-are-zero) will **silently flush** subnormals to zero, breaking Neumaier's compensation. **Finding 2.3 (C):** the kernel must explicitly clear DAZ/FTZ or document that it does not. **Recommendation:** `_mm_setcsr(_mm_getcsr() & ~0x8040)` at kernel entry, restore at exit.

### 2.3 Zero-copy PMTP validation

**Finding 2.4 (M):** "Zero-copy" + "validation" is a contradiction unless validation is done on a **read-only mapped view** with a checksum. If validation reads the same memory the compute kernel writes, you have a TOCTOU. **Recommendation:** validate the 88-byte descriptor, then `mprotect(PROT_READ)` the slab before compute.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

**Finding 3.1 (C):** This is **backwards**. `panic=unwind` across an FFI boundary is **undefined behavior** unless every `extern "C"` function is wrapped in `catch_unwind`. The correct barrier is `panic=abort` for the FFI crate, or `#[no_mangle] extern "C" fn` wrappers that call `std::panic::catch_unwind` and return an error code. The audit claim "panic=unwind FFI safety barrier" is **inverted**. **Recommendation:** either (a) `panic=abort` + `abort()` on the C++ side, or (b) `catch_unwind` at every boundary with `AssertUnwindSafe`.

### 3.2 Packed 88-byte descriptor

**Finding 3.2 (M):** Rust's `#[repr(C, packed)]` on a struct containing `u64` fields produces **unaligned loads** on some targets (ARMv7, RISC-V without Zicclsm). The compiler will emit byte-wise loads — correct but ~4× slower. **Recommendation:** `#[repr(C)]` with explicit `[u8; 6]` padding and a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` compile-time check.

### 3.3 Neumaier in Safe SIMD

**Finding 3.3 (m):** Rust's `std::simd` (portable SIMD) does not expose `fma` in stable; the `fma` intrinsic is `unsafe`. If the kernel uses `core::arch::x86_64::_mm512_fmadd_pd`, it is **not** "Safe SIMD" — it is `unsafe` with a safety comment. **Recommendation:** rename the claim to "SIMD with audited unsafe blocks" and enumerate them.

### 3.4 step → ∞ / step → 0

Same as Target 2. **Finding 3.4 (M):** Rust's `f64::mul_add` is subnormal-safe on x86-64 but **not** guaranteed on all targets; the `fma` feature is target-dependent. Document the target matrix.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)

The Cayley retraction is
$$
Y(\alpha) = (I - \tfrac{\alpha}{2} A)^{-1} (I + \tfrac{\alpha}{2} A) Y_0, \quad A = Y_0^\top \nabla f - \nabla f^\top Y_0 \text{ (skew)}.
$$

**Finding 4.1 (C):** The stated use of `cuSOLVER DnDsyevd` (symmetric eigensolver) is **mathematically wrong** for the Cayley retraction. The Cayley transform requires a **linear solve** `(I - αA/2) X = (I + αA/2) Y_0`, not an eigendecomposition. `DnDsyevd` computes eigenvalues of a symmetric matrix — A is skew-symmetric, so its eigenvalues are purely imaginary and `Dsyevd` will either fail or return garbage. **This is a fatal architectural error.** The correct primitive is `cusolverDnDgetrf` + `cusolverDnDgetrs` (LU), or `cusolverDnDpotrf` if you symmetrize.

**Proof obligation:** show that