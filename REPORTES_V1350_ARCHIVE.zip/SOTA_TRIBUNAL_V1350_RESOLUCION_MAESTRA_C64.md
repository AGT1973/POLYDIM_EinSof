# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 64

No publicly verifiable record of **“POLYDIM V1350,” “PMTP 88-byte Descriptor,” Cycle 64, or the six cited Tribunal reports** was found in the available search results. Therefore, a definitive arbitration of those proprietary findings would be unjustified. The following is the strongest technically defensible synthesis from established numerical linear algebra and memory-model principles.

## 1. Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For \(X\in\mathrm{St}(n,p)\), the relevant candidates are:

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)\left(I+\Xi^\top\Xi\right)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley update of the form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

where \(W^\top=-W\) is constructed from \(X\) and the tangent direction. These are recognized Stiefel retractions, but they have different conditioning and implementation requirements.[1][3][6]

### Arbitration

A claim that Cayley is unconditionally more stable than Householder QR or polar retraction at steps of \(10^{10}\) is **not mathematically supportable**.

- **Householder QR** is generally the preferred robust fallback for arbitrary large updates because it avoids explicitly forming \((X+\Xi)^\top(X+\Xi)\), and Householder transformations are backward stable in standard floating-point implementations.
- **Polar retraction** has a favorable geometric property—it is the closest orthonormal factor in the Frobenius norm—but the Gram matrix can have a condition number roughly proportional to \(\kappa(X+\Xi)^2\). Forming \(\Xi^\top\Xi\) at extreme scale can overflow, lose relative accuracy, or amplify conditioning problems.
- **Cayley retraction** preserves orthogonality algebraically when the solve is performed accurately and \(W\) is genuinely skew-symmetric. However, its stability depends on constructing \(W\), solving the shifted system, scaling the operator, and avoiding overflow. Large \(\|W\|\) does not by itself establish numerical stability.

The relevant invariant is not the raw step magnitude but the **scaled condition of the actual update and linear solve**. For a robust implementation, the definitive guarantee should therefore be:

\[
\| \widehat X^\top \widehat X-I\|
\le
C\,u\,\operatorname{poly}(n,p,\kappa_{\mathrm{solve}})
+\text{reduction error},
\]

provided finite inputs, no overflow/underflow, stable factorizations, and correctly rounded or bounded-error reductions. Here \(u\) is unit roundoff.

### Recommended architecture

Use a **tiered policy**:

1. Scale the tangent/update before evaluating any formula.
2. Use Cayley only when its skew operator and shifted solve pass conditioning and overflow checks.
3. Use Householder QR as the deterministic robust fallback.
4. Use polar retraction when high-quality orthogonal projection is required and a stable SVD or scaled polar algorithm is available.
5. Re-orthogonalize or validate with
   \[
   \|X^\top X-I\| \le \tau_{\mathrm{orth}}.
   \]

Thus, the mathematically superior synthesis is **not “Cayley always wins.”** It is **Cayley when certified well-conditioned, Householder QR as the broad-domain safety path, and stable polar decomposition for projection quality**. Cayley methods have documented advantages for certain vector-transport and optimization properties, but that does not imply universal floating-point superiority over QR or polar methods.[13]

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

The descriptor size—88 bytes—has no inherent bearing on memory-order correctness. Correctness depends on:

- publication of the fully initialized descriptor,
- atomic ownership or pointer publication,
- reader acquisition before dereference,
- release of retired objects only after a valid grace-period condition,
- and the reclamation protocol’s treatment of readers that begin concurrently with retirement.

A sound publication pattern is conceptually:

```cpp
// Writer
initialize_descriptor(d);
descriptor_ptr.store(d, std::memory_order_release);

// Reader
auto* p = descriptor_ptr.load(std::memory_order_acquire);
use_descriptor(p);
```

The release/acquire pair guarantees that descriptor initialization sequenced before publication becomes visible to a reader whose acquire observes that publication. It does **not**, by itself, guarantee safe reclamation.

For RCU/QSBR, the architectural guarantee must be separated into two claims:

1. **Snapshot visibility:** readers observe either the old complete descriptor or the new complete descriptor, not partially initialized fields.
2. **Lifetime safety:** a retired descriptor is not freed until every reader that could have acquired it has passed through a quiescent state or otherwise exited its read-side critical section.

Acquire/release operations alone do not provide the second guarantee. A QSBR implementation needs explicit reader registration/state tracking, a writer grace-period algorithm, and ordering rules preventing compiler or hardware reordering around read-side entry and exit.

### Definitive memory guarantee

For every reader \(r\), if \(r\) acquires pointer \(p\) before retirement, then:

\[
\operatorname{free}(p)
\quad\text{occurs only after}\quad
r\text{ has reported a post-acquisition quiescent state}.
\]

The 88-byte layout must additionally specify:

- alignment,
- padding and cache-line placement,
- atomic versus non-atomic fields,
- ownership of each field,
- version or generation counter semantics,
- and whether descriptors may straddle cache lines.

If fields are independently mutable, release/acquire publication of the pointer does not make later field mutations atomic or race-free. The strongest defensible result is therefore:

> **Release publication plus acquire observation provides initialization visibility; RCU/QSBR grace-period tracking provides reclamation safety. Neither replaces the other.**

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared identically by all five environments. “Multi-silicon conformance” must be defined as a contract over a common subset, not assumed from source-level similarity.

| Layer | Required conformance condition |
|---|---|
| C++20 | Atomic operations, happens-before relations, object lifetime, and alignment obey the C++ memory model |
| Rust | The implementation preserves Rust aliasing, ownership, and atomic-ordering rules; unsafe code must justify lifetime and synchronization invariants |
| CUDA | Device/global/shared-memory scopes, CUDA atomics, fences, streams, and host-device synchronization are explicitly specified |
| Triton | Generated kernel ordering, program-instance independence, masking, and atomic behavior are validated for the target backend |
| XLA | HLO-level ordering, buffer aliasing, asynchronous execution, and backend lowering preserve the declared semantics |
| Silicon | The target GPU/CPU memory hierarchy and atomic instructions satisfy the assumptions of the backend runtime |

The portable subset should require:

- naturally aligned atomic pointer/version fields;
- no reliance on implicit coherence;
- no reliance on sequential consistency unless explicitly requested;
- explicit release/acquire publication;
- explicit read-side critical-section entry and exit;
- explicit grace-period completion before reclamation;
- deterministic handling of ABA/version wraparound;
- bounded-width serialization for descriptor fields;
- and validation on every supported backend.

CUDA, XLA, and Triton may execute operations asynchronously or lower them differently from C++20 and Rust. Consequently, a host-language acquire/release statement cannot automatically be treated as a device-wide synchronization primitive. A correct implementation needs backend-specific lowering and tests for:

- publication-before-read visibility,
- no partial descriptor observation,
- no use-after-reclamation,
- update linearizability,
- descriptor version monotonicity,
- and orthogonality residuals for the numerical kernels.

## Final arbitration

The strongest technically justified SOTA specification is:

1. **Retraction:** no unconditional Cayley victory at extreme steps. Use scaled Cayley with a certified solve, Householder QR fallback, and stable polar computation where projection quality is primary.
2. **Descriptor synchronization:** release/acquire guarantees publication visibility only. RCU/QSBR grace periods guarantee lifetime safety. Both are mandatory.
3. **Cross-platform conformance:** define a portable semantic contract and provide backend-specific implementations; source-level equivalence is insufficient.
4. **Exact guarantees:** state residual, overflow, ordering, and reclamation bounds explicitly. Claims of exact orthogonality, universal extreme-step stability, or automatic cross-silicon memory equivalence are not valid without additional assumptions and test evidence.

The available sources establish the standard Cayley, QR, and polar formulas and their differing properties, but they do not substantiate the existence or findings of the six named V1350 tribunal models.[1][3][6][13]