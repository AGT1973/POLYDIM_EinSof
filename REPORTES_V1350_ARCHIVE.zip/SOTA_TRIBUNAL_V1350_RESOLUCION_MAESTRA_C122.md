# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 122

The requested arbitration is **not verifiable from the available evidence**. The search results do not identify a public POLYDIM V1350 specification, the six kernels, the Cycle 122 reports, or reproducible findings from the eight named models. The only clearly matching public result is **PolyDiM**, a C++ library for polytopal discretization methods, which does not establish a connection to the described V1350 system.[1][2]

Accordingly, no mathematically defensible “definitive” synthesis or exact architectural guarantee can be attributed to the eight tribunals. Any such conclusion would be fabricated unless the underlying reports, source code, formal specification, and test logs are supplied.

## What can be established conditionally

### 1. Cayley–Stiefel retraction under extreme steps

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\) satisfying \(X^\top X=I\), a Cayley-style update typically has the form

\[
X_{+}=\left(I-\frac{\alpha}{2}A\right)^{-1}
       \left(I+\frac{\alpha}{2}A\right)X,
\]

where \(A^\top=-A\). In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists, so it preserves the Stiefel constraint:

\[
X_{+}^{\top}X_{+}=I.
\]

That is a **mathematical invariance**, not an unconditional numerical-stability guarantee. For \(|\alpha|\ge 10^{10}\), stability depends on:

- conditioning of \(I-\frac{\alpha}{2}A\);
- the linear-system solver and pivoting policy;
- floating-point precision;
- scaling of \(A\);
- overflow, underflow, and loss of significance;
- whether the implementation forms products explicitly or uses a stable solve.

A Householder or polar/QR retraction generally provides stronger practical orthogonality control because it explicitly reorthogonalizes the result. However, it is not automatically stable under arbitrarily large steps either. A defensible guarantee would therefore be:

> **Conditional guarantee:** the Cayley implementation preserves the Stiefel manifold in exact arithmetic and remains numerically acceptable only under a stated conditioning, precision, and solver bound.

It would be incorrect to claim unconditional superiority of Cayley over Householder or polar QR for extreme steps without backward-error measurements and failure thresholds.

### 2. PMTP descriptor barriers and RCU/QSBR isolation

Acquire/release operations can establish ordering, but they do not by themselves define a complete RCU or QSBR protocol. Correct snapshot isolation requires at least:

1. a publication operation using release semantics;
2. a reader snapshot or pointer acquisition using acquire semantics;
3. immutable or versioned data after publication;
4. reader quiescent-state reporting;
5. a grace-period mechanism;
6. deferred reclamation only after all preexisting readers have passed through a quiescent state.

QSBR systems commonly wait until each participating reader reports quiescence or observes the current grace-period counter.[3] Thus the exact guarantee must distinguish:

- **visibility:** acquire observes data published by release;
- **ordering:** prior writes happen-before the corresponding acquire;
- **lifetime safety:** reclamation does not occur while a reader may still dereference the object;
- **snapshot consistency:** all fields belong to one descriptor generation.

An 88-byte size is not itself an architectural guarantee. The descriptor also needs an explicitly specified alignment, field layout, atomic widths, generation or sequence number, publication state, and reclamation protocol. On heterogeneous devices, host-language memory orders do not automatically imply equivalent device-level behavior.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

Cross-silicon conformance cannot be established merely by implementing equivalent source-level kernels. The environments differ in:

- memory models and synchronization scopes;
- atomic availability and ordering;
- compiler transformations;
- floating-point contraction and reassociation;
- tensor-layout and aliasing rules;
- device-specific execution and visibility semantics;
- supported integer widths and alignment requirements.

A valid conformance claim requires a normative specification plus a test matrix covering every target backend and silicon family. At minimum, it should include:

- bitwise or tolerance-based numerical equivalence;
- Stiefel residuals such as \(\lVert X^\top X-I\rVert\);
- descriptor publication and reclamation litmus tests;
- race detection and sanitizer results;
- randomized stress tests;
- extreme-step and ill-conditioned cases;
- compiler and optimization-level variation;
- negative tests proving that invalid synchronization is rejected or detected.

The result should be stated as a bounded claim, for example:

> “For the listed compiler versions, hardware revisions, precisions, tensor shapes, and synchronization scopes, the implementation satisfies the specified numerical and memory-ordering tests.”

It should not be stated as universal conformance across CUDA, XLA, Triton, C++20, and Rust without those bounds.

## Arbitration outcome

The only supportable arbitration is:

- **Cayley retraction:** exact-manifold preservation is plausible under a skew-symmetric generator, but extreme-step numerical stability is implementation- and conditioning-dependent.
- **Householder/polar QR:** generally the safer baseline for explicit orthogonality restoration, but no unconditional extreme-step guarantee follows without measurements.
- **PMTP barriers:** acquire/release can provide publication ordering; RCU/QSBR snapshot isolation additionally requires a complete grace-period and reclamation protocol.
- **Multi-silicon conformance:** unproven absent the V1350 specification, backend implementations, target list, and reproducible test evidence.
- **Eight-model consensus:** unavailable because the cited Cycle 122 findings were not provided or located in authoritative public sources.

Therefore, the exact architectural guarantees requested cannot honestly be formulated from the gathered information. Any stronger “SOTA” verdict would be speculation rather than arbitration.