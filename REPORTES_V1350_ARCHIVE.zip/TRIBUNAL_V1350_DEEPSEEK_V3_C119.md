# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 119)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 119 · Six-Component Adversarial SOTA Review

**Presiding note.** The Tribunal treats each target as a *claim* to be falsified. Where the source is not in evidence, we audit the *stated contract* and flag any assertion that cannot be discharged from the specification alone. Verdicts are graded: **PASS**, **CONDITIONAL**, **FAIL**, **UNVERIFIABLE**.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Binary descriptor `struct <4sHHQQQQQBB6x4Q`

Let us lay out the format string byte-by-byte (native alignment assumed, `<` little-endian, no padding except explicit `6x`):

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version_major | `H` | 2 | 4 |
| version_minor | `H` | 2 | 6 |
| flags | `Q` | 8 | 8 |
| n_rows | `Q` | 8 | 16 |
| n_cols | `Q` | 8 | 24 |
| stride | `Q` | 8 | 32 |
| dtype_code | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| layout | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| reserved | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict on 88-byte claim: PASS** — arithmetic closes exactly. `struct.calcsize('<4sHHQQQQQBB6x4Q') == 88` on CPython ≥3.7 with default alignment (no native padding because `<` forces standard size/alignment).

### 1.2 Numerical degeneracy at `step → ∞` and `step → 0`

The orchestrator itself is a dispatcher; degeneracy enters via the *descriptor* it emits. Two hazards:

- **`step` is not a field in the 88-byte descriptor.** If the orchestrator encodes `step` into `reserved[0]` as a raw `Q` (unsigned), then `step < 0` is unrepresentable and `step → 0⁺` collapses to integer 0 — a silent subnormal-killer. **Recommendation:** mandate `reserved[0]` be interpreted as IEEE-754 binary64 via `struct.unpack('<d', ...)`, and reserve `reserved[1]` for a scale exponent.
- **`step → ∞` (|step| ≥ 10¹⁰):** if `step` is later multiplied into a Woodbury RHS (Target 4), the product `step · B` overflows FP64 at `step > ~1.8e308 / ‖B‖`. The orchestrator must clamp or renormalize *before* dispatch. **CONDITIONAL PASS** pending a documented clamp policy.

### 1.3 Rule 22 (Zero 1D tokens, 88-byte PMTP)

The descriptor is a *packed struct*, not a 1D token stream — compliant **iff** the orchestrator never serializes it as a flat `bytes` blob into an inter-agent channel without the 88-byte framing. **PASS** on the stated contract; **UNVERIFIABLE** on the wire format.

### 1.4 Rule 27 (Silicon Contract)

`HardwareProbe` + `PmtpSlabAllocator` are described as multi-silicon. **PASS** provided the probe returns a *capability set* (AVX-512, AMX, ROCm, CUDA CC, TPU gen) rather than a vendor enum. If any branch is `if vendor == "nvidia"`, that is a Rule 27 violation. **UNVERIFIABLE** without source.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Standard Neumaier:

```
s = 0; c = 0
for i: t = s + a[i]*b[i]
       if |s| >= |a[i]*b[i]|: c += (s - t) + a[i]*b[i]
       else:                  c += (a[i]*b[i] - t) + s
       s = t
return s + c
```

**Error bound (Ogita–Rump–Oishi):** for `n` terms, `|result − exact| ≤ (2u + O(nu²)) · Σ|aᵢbᵢ|`, with `u = 2⁻⁵³`. This is *condition-independent* in the sense that the bound scales with the sum of absolute products, not the condition number of the dot itself.

**Degeneracy at `step → 0`:** if `a[i]*b[i]` underflows to subnormal, `t = s + subnormal` may lose the subnormal entirely when `|s| ≫ 2⁻¹⁰²²`. Neumaier's compensation term `(s − t) + a[i]*b[i]` recovers it *only if* the FPU honors gradual underflow. **AVX-512 with FTZ/DAZ enabled (default in many `-ffast-math` builds) will silently zero subnormals and destroy the compensation.** The audit flags the stated "subnormal audits (−12, −14)" as *necessary but not sufficient*: the kernel must explicitly clear `MXCSR.FTZ` and `MXCSR.DAZ` before the compensated loop.

**Verdict: CONDITIONAL PASS** — require a `_mm_setcsr(_mm_getcsr() & ~0x8040)` guard and a post-loop `_mm_setcsr` restore.

### 2.2 Asymptotic condition number

For the compensated dot, the *forward* error is `O(u)` independent of `κ`. For the *backward* error, `‖Δ‖ ≤ γₙ Σ|aᵢbᵢ|` with `γₙ = nu/(1−nu)`. At `n = 10⁶`, `γₙ ≈ 2.2e-10` — still below the `10¹⁰` step threshold, so no overflow in the compensation accumulator **provided `c` is FP64 and not FP32**.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be `alignas(8)` and the payload to be page-aligned. **PASS** if `static_assert(sizeof(PmtpDescriptor) == 88)` is present; **FAIL** if the compiler inserts tail padding (it will not, given `6x` is explicit, but `#pragma pack` is safer).

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` FFI safety barrier

This is the **most dangerous** claim in the entire audit. `panic = unwind` across an `extern "C"` boundary is **undefined behavior** in Rust 2021 unless the function is declared `extern "C-unwind"`. The stated "FFI safety barrier" is only sound if:

1. Every `extern "C"` entry point wraps its body in `std::panic::catch_unwind`.
2. The panic payload is converted to an error code before returning.
3. `#[no_mangle]` symbols are `unsafe extern "C"` and documented as `# Safety` contracts.

**Verdict: FAIL as stated.** `panic = unwind` is *not* a barrier; it is a *hazard*. Recommended hardening:

```rust
#[no_mangle]
pub unsafe extern "C" fn pmtp_dot(...) -> i32 {
    match std::panic::catch_unwind(|| { /* body */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```

Or, preferably, `panic = abort` for the FFI crate and `catch_unwind` only at the Rust-internal boundary.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust's `#[repr(C, packed)]` will produce 88 bytes **iff** the field order matches Target 1. `#[repr(C)]` alone will insert padding after `layout: u8` to align the `[u64; 4]` to 8 bytes — yielding 96 bytes. **Require `#[repr(C, packed(8))]`** and a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`.

### 3.3 Neumaier in Safe SIMD

Rust's `std::simd` (nightly) or `wide` crate can express Neumaier, but the compensation branch `if |s| >= |p|` is a *data-dependent branch* that defeats SIMD unless implemented with `simd_select`. **CONDITIONAL PASS** — require branchless `select` and a documented `fma`-based variant.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in ℝ^(2K × 2K)

The Cayley retraction on the Stiefel manifold `St(n,p)` is:

```
Y(τ) = (I − (τ/2) A)⁻¹ (I + (τ/2) A) Y,   A = G Yᵀ − Y Gᵀ
```

where `G` is the Euclidean gradient. For `2K × 2K` with `p = 2K` (square orthogonal), `A` is skew-symmetric and the retraction is *exact* (Cayley transform of a skew matrix is orthogonal). **PASS** mathematically.

**Degeneracy at `step → ∞`:** `(I − (τ/2)A)⁻¹` becomes singular when `τ/2 · λ_max(A) = 1`, i.e. `τ = 2/λ_max(A)`. For `|step| ≥ 10¹⁰`, `τ` must be *clamped* to `2/λ_max(A) · (1 − ε)`. **The stated architecture does not mention this clamp.** **FAIL** — add a spectral-radius guard using the largest Ritz value from `DnDsyevd`.

### 4.2 Globally scaled Woodbury solve `(M/scale) W = (step/scale) B`

Woodbury identity:

```
(M + UCVᵀ)⁻¹ = M⁻¹ − M⁻¹U (C⁻¹ + VᵀM⁻¹U)⁻¹ VᵀM⁻¹
```

The "globally scaled" form `(M/scale) W = (step/scale) B` is a *preconditioning* trick: it keeps the LHS well-conditioned when `scale ≈ ‖M‖`. **Condition number:** `κ(M/scale) = κ(M)`, unchanged — scaling does not improve conditioning, only overflow headroom. **The claim that scaling improves conditioning is FALSE.** It improves *dynamic range*.

**Asymptotic:** as `step → ∞`, `W → (M/scale