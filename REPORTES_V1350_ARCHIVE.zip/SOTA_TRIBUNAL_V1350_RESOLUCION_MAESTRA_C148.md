# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 148

The requested arbitration cannot be made definitively from the available evidence: the eight Tribunal reports and the six V1350 kernel specifications were not provided, and no authoritative public specification for “POLYDIM V1350,” “PMTP,” or its 88-byte descriptor was found. The following is therefore a **standards-based synthesis**, not a verified vote among the eight models.

## 1. Stiefel retraction under \(\lvert\mathrm{step}\rvert \ge 10^{10}\)

No retraction is unconditionally stable merely because it is Cayley-based. For a tangent update \(A\) at \(X\in\mathrm{St}(n,p)\), a Cayley map typically has the form

\[
X_{+}=\left(I-\frac{\alpha}{2}A\right)^{-1}
       \left(I+\frac{\alpha}{2}A\right)X,
\qquad A^\mathsf{T}=-A.
\]

In exact arithmetic, the transformation is orthogonal whenever the inverse exists. That does **not** imply numerical stability for arbitrarily large \(\alpha\). At extreme scale, direct formation of \(I\pm \alpha A/2\) can suffer overflow, cancellation, loss of rank information, and inaccurate solves. A mathematically valid Cayley formula therefore requires a **scaled implementation**, stable linear solves, and residual checks.

| Method | Extreme-step assessment | Required guarantee |
|---|---|---|
| Cayley/Stiefel | Potentially excellent orthogonality preservation, but not automatically safe for \(10^{10}\)-scale parameters | Scaling, factored/skew-symmetric representation, stable solve, residual and orthogonality tests |
| Householder QR | Usually robust for orthogonalization and avoids explicit normal equations | Stable blocked Householder implementation; rank/conditioning policy must be specified |
| Polar decomposition | Strong geometric projection and often high-quality orthogonality | Stable SVD/eigendecomposition or iterative polar algorithm; handling of nearly rank-deficient factors |

The defensible SOTA decision is **not “Cayley always wins.”** It is:

1. Use Cayley when the update is represented in a structure-preserving, scaled form and the solve is demonstrably backward stable.
2. Fall back to Householder QR or polar projection when the Cayley solve is ill-conditioned, overflows, or fails residual checks.
3. Define correctness by explicit bounds such as

\[
\|X_{+}^{\mathsf T}X_{+}-I\| \le c\,u\,\kappa_{\mathrm{eff}},
\]

where \(u\) is machine unit roundoff and \(\kappa_{\mathrm{eff}}\) includes the conditioning of the update and solve.

An unconditional guarantee for every finite floating-point input with \(\lvert\mathrm{step}\rvert\ge 10^{10}\) is impossible without specifying precision, scaling, matrix dimensions, conditioning limits, overflow behavior, and fallback semantics.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering is sufficient for **publication visibility**, but it is not by itself a complete RCU or QSBR reclamation protocol.

A valid publication sequence is:

```text
writer:
    initialize immutable descriptor and payload
    release-store published pointer/version

reader:
    acquire-load published pointer/version
    read descriptor and payload
```

If the acquire operation reads from the corresponding release sequence, the initialization happens-before the reader’s subsequent accesses. C++ atomic semantics establish this only for the same synchronization object; unrelated atomics or ordinary fields do not automatically create the required ordering.[15]

The exact architectural guarantee should be:

- The descriptor’s **publication word** is atomic and suitably aligned.
- The writer fully initializes the descriptor and its referenced immutable payload before a release publication.
- Readers acquire the publication value before dereferencing the descriptor.
- Descriptor fields are immutable after publication, or each mutation uses its own atomic protocol.
- Reclamation occurs only after a completed RCU grace period or QSBR epoch proving that no pre-publication reader can still hold the object.
- The 88-byte size is an ABI/layout property, not a memory-ordering guarantee.
- If the descriptor crosses devices, processes, or non-coherent address spaces, ordinary C++ acquire/release semantics are insufficient; an explicit platform-supported inter-device protocol is required.

The key distinction is:

\[
\text{Acquire/release} \Rightarrow \text{visibility and ordering}
\]

but

\[
\text{Acquire/release} \not\Rightarrow \text{safe reclamation}.
\]

QSBR additionally requires correct reader registration, quiescent-state reporting, epoch advancement, and a reclaimer that waits for every reader that could have observed the old generation. A missing reader announcement, premature quiescent report, or relaxed publication load invalidates snapshot isolation.

For a descriptor carrying a generation \(g\), a strong design is:

\[
\text{snapshot}=(p,g),
\]

where \(p\) is the immutable descriptor pointer and \(g\) is the publication generation. Readers retain that snapshot for the entire read-side critical section. Writers publish a new immutable generation and reclaim generation \(g\) only after the grace-period condition proves that no reader can still access it.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single portable memory model spanning all five environments. C++20 and Rust provide language-level atomic semantics; CUDA provides host/device and device-scope primitives with scope-specific rules; XLA is an optimizing compiler IR whose execution and aliasing guarantees depend on the backend; Triton exposes compiler- and hardware-dependent synchronization mechanisms.

Consequently, “multi-silicon conformance” must be defined as a **contract plus a test matrix**, not inferred from source-level similarity.

The portable core should require:

- Identical descriptor byte layout, alignment, endianness, field offsets, and versioning.
- Explicit serialization/deserialization at host-device boundaries.
- No reliance on implicit structure padding.
- A specified atomic publication field and atomic width supported by every target.
- Immutable published payloads.
- Explicit reader critical-section and reclamation protocol.
- No assumption that a host release automatically synchronizes with a device acquire, or vice versa.
- Capability-based fallbacks where a target lacks the required atomic width, scope, or fence.

For C++20, the publication atomic should use at least release store and acquire load, with lifetime and data-race rules satisfying the C++ abstract machine. For Rust, the equivalent `Ordering::Release`/`Ordering::Acquire` pair gives the corresponding ordering when applied to the same atomic object.[6] Rust’s type and ownership guarantees do not, by themselves, establish correctness for externally managed device memory or FFI descriptors.

For CUDA, the implementation must specify whether ordering is thread-, block-, device-, or system-scoped. A device-only fence cannot be promoted into a host/device guarantee without the appropriate system-scope mechanism and allocation/interconnect support.

For XLA and Triton, the compiler must be prevented from treating the descriptor as freely mutable or from eliminating/reordering accesses across the intended synchronization boundary. If the framework cannot express the required acquire/release and reclamation semantics, the safe conformance claim is limited to **single-launch immutable snapshots** or host-managed epoch boundaries.

## Definitive arbitration

The strongest supportable synthesis is:

1. **Retraction:** adopt a hybrid Cayley–Householder/polar design. Cayley is the fast structure-preserving path; scaled Householder QR or polar projection is the certified fallback. Do not claim unconditional stability at \(\lvert\mathrm{step}\rvert\ge10^{10}\).
2. **Descriptor isolation:** use release publication and acquire observation of the same atomic publication object, plus immutable generations and a separately proven RCU/QSBR grace period. The 88-byte layout alone guarantees nothing about synchronization.
3. **Portability:** define conformance at the ABI, memory-scope, lifetime, and numerical-error levels. C++20/Rust semantics cannot automatically be projected onto CUDA, XLA, or Triton.
4. **Certification:** require adversarial tests for overflow, ill-conditioned tangent updates, ABA/version wraparound, delayed readers, premature QSBR quiescence, descriptor reuse, host-device races, compiler reordering, and every supported silicon/backend combination.

Thus the mathematically superior claim is a **conditional, checked, fallback-based architecture** with explicit numerical and memory-model contracts—not an unconditional assertion that one retraction, one 88-byte layout, or one source implementation is universally stable and conformant.