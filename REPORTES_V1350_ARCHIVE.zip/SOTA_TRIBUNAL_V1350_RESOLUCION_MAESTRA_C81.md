# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 81

The requested six-model tribunal record and the POLYDIM V1350 kernel specifications are not publicly verifiable in the available evidence. The search results identify an unrelated PolyDiM PDE library and general RCU/QSBR material, but they do **not** establish the existence, implementation, benchmarks, or findings of “POLYDIM V1350,” “PMTP,” or the six named tribunal reports. Therefore, no evidence-based arbitration can legitimately declare one model’s findings definitive.

What can be stated rigorously from established numerical-analysis and memory-model principles is:

## 1. Cayley–Stiefel retraction versus Householder/Polar QR

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), \(X^\top X=I\), an unconstrained tangent step \(\Delta\) generally has a norm that grows with the step magnitude. A Cayley update of the form

\[
X_{+}
=
\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)X,
\]

with \(A^\top=-A\), preserves orthogonality in exact arithmetic whenever the inverse exists. However, this does **not** imply unconditional numerical stability for \(|\tau|\ge 10^{10}\). In floating-point arithmetic, the following remain possible:

- ill-conditioning of the shifted system \(I-\frac{\tau}{2}A\);
- overflow or loss of significance in forming \(\tau A\);
- inaccurate linear solves;
- amplification of perturbations when the skew operator has unfavorable spectral scales;
- loss of feasibility after finite-precision rounding.

A Cayley retraction is therefore **structure-preserving in exact arithmetic**, not automatically stable for arbitrary extreme steps.

Householder QR is typically the strongest general-purpose orthogonalization primitive for numerical robustness: blocked Householder transformations avoid the severe loss of orthogonality associated with classical Gram–Schmidt and are usually more reliable than explicitly forming a polar factor. Polar retraction can offer attractive geometric properties, but its practical stability depends on the method used to compute the polar decomposition—typically an SVD, Newton iteration, or carefully scaled QR-based algorithm.

The defensible arbitration is:

| Claim | Mathematical status |
|---|---|
| Cayley preserves orthogonality exactly under its assumptions | Valid in exact arithmetic |
| Cayley is unconditionally stable for \(|\text{step}|\ge 10^{10}\) | Unsupported and generally false |
| Householder QR is a robust fallback for extreme steps | Generally justified |
| Polar retraction is always superior to QR | Not justified |
| A Cayley-first, scaled, condition-checked method with QR/SVD fallback is SOTA | Defensible architectural synthesis |

A mathematically sound extreme-step policy is therefore:

1. Scale or normalize the tangent direction before forming the update.
2. Evaluate a conditioning or residual criterion for the Cayley solve.
3. Reject or damp the step if the solve is ill-conditioned or overflows.
4. Reproject with Householder QR or a backward-stable polar/SVD routine.
5. Verify

\[
\|X_{+}^{\top}X_{+}-I\|
\le
c\,u\,\operatorname{poly}(n,p,\kappa),
\]

where \(u\) is unit roundoff and \(c\) depends on the implementation.

The exact guarantee should be stated as **conditional backward stability**, not unconditional stability at \(10^{10}\).

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

An 88-byte layout alone provides no memory-ordering guarantee. Correct snapshot isolation requires a protocol, not merely a descriptor size.

For a writer publishing a fully initialized immutable descriptor \(D\), the minimum publication pattern is conceptually:

```cpp
payload_initialize(D);
publication.store(new_version, std::memory_order_release);
```

A reader must acquire the publication value before dereferencing the associated payload:

```cpp
v = publication.load(std::memory_order_acquire);
read_descriptor_for(v);
```

This establishes a happens-before relation for the initialization visible through that publication mechanism. In an RCU/QSBR design, reclamation additionally requires that the writer wait until every reader that could have observed the old version has passed through a quiescent state. Acquire/release ordering alone does **not** make reclamation safe.

The exact guarantee should distinguish:

- **Publication safety:** release by the publisher and acquire by the reader expose initialized state.
- **Snapshot consistency:** all fields belonging to one immutable version are read from that version.
- **Reclamation safety:** the old version is not freed until the RCU/QSBR grace-period condition is satisfied.
- **Atomicity:** fields wider than the machine’s naturally atomic width require an indirection, seqlock, lock, or platform-supported atomic representation.
- **Layout safety:** 88 bytes must be accompanied by explicit alignment, padding, endian, ABI, and version rules.

A descriptor containing mutable multiword state cannot obtain atomic snapshot semantics simply by placing acquire/release operations around individual fields. The superior design is:

- immutable, versioned descriptor bodies;
- one atomic publication pointer or version token;
- release publication;
- acquire reader load;
- reader-side RCU/QSBR protection;
- grace-period-based reclamation;
- optional checksum, generation, or sequence validation.

For a seqlock-style design, readers must validate that the sequence is unchanged and even after copying the descriptor. That is a different protocol from ordinary RCU and should not be conflated with it.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared identically by all five environments. A claim of universal conformance requires an explicit semantic subset and a per-backend proof or test mapping.

The main portability boundary is:

- **C++20/Rust:** host-language memory models govern CPU-side atomics and data races.
- **CUDA:** device and host visibility additionally depend on CUDA’s memory scopes, synchronization operations, stream behavior, and the relevant hardware.
- **Triton:** compiler and GPU execution semantics constrain what barriers and atomic operations are expressible and how they are lowered.
- **XLA:** operations are represented through an optimizing compiler IR; ordering and aliasing guarantees depend on the specified HLO/StableHLO operation and backend lowering, not merely on source-language intent.

Consequently, the strongest defensible conformance guarantee is not “identical behavior everywhere,” but:

> Every backend implements the same abstract protocol: immutable snapshot construction, one release-equivalent publication event, acquire-equivalent observation, reader protection through the complete access interval, and deferred reclamation after a proven grace period.

That requires backend-specific mechanisms:

| Backend | Required proof obligation |
|---|---|
| C++20 | No data races; atomic publication and reclamation obey the C++ memory model |
| Rust | Safe ownership/borrowing or carefully isolated unsafe code; atomics and reclamation are explicitly validated |
| CUDA | Correct device/system scope, fences, atomics, stream/event synchronization, and lifetime management |
| Triton | Supported atomic/barrier operations lower to the intended GPU ordering and scope |
| XLA | The graph expresses the required dependency and lifetime semantics; compiler transformations cannot invalidate the protocol |
| Cross-backend | Identical descriptor schema, versioning, visibility, and reclamation state machine |

## Definitive synthesis

The strongest SOTA architecture supported by the stated requirements is a **layered, fail-safe design**:

1. **Numerics:** use a Cayley retraction as an efficient structure-preserving proposal only when scaling and conditioning checks pass.
2. **Fallback:** use Householder QR, or a backward-stable polar/SVD routine, to restore the Stiefel constraint when the step is extreme or the Cayley solve is unsafe.
3. **Descriptor publication:** treat the 88-byte object as an immutable versioned record, not as an independently mutable atomic blob.
4. **Synchronization:** use release publication, acquire observation, explicit reader protection, and grace-period reclamation.
5. **Portability:** define one abstract memory protocol and provide backend-specific implementations and litmus tests.
6. **Validation:** require numerical residual tests, race/dynamic-sanitizer tests where applicable, GPU litmus tests, compiler-lowering tests, and repeated cross-silicon conformance runs.

The exact architectural guarantees should therefore be phrased narrowly:

- **Orthogonality:** guaranteed in exact arithmetic by the Cayley transform; in floating point, bounded only conditionally and verified by residual checks.
- **Extreme-step behavior:** no unconditional guarantee for \(|\text{step}|\ge10^{10}\); the implementation must scale, damp, reject, or fall back.
- **Snapshot publication:** guaranteed only when release/acquire operations are attached to a valid publication object.
- **Snapshot isolation:** guaranteed for immutable versioned records while readers hold the required RCU/QSBR protection.
- **Reclamation:** guaranteed only after a completed grace period covering all potentially observing readers.
- **Cross-silicon conformance:** guaranteed only for the explicitly defined abstract protocol and only after backend-specific verification.

Any tribunal conclusion stronger than these—particularly claims of unconditional Cayley stability at extreme step sizes, descriptor atomicity merely from an 88-byte layout, or automatic equivalence across CUDA, XLA, Triton, C++20, and Rust—would be an architectural assertion rather than a mathematically established guarantee.