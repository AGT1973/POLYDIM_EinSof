# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 162

No public, verifiable record of the **POLYDIM V1350**, its six kernels, the **PMTP 88-byte descriptor**, or the eight purported Tribunal-model reports was found in the available evidence. Therefore, I cannot honestly arbitrate those model-specific findings or claim a definitive implementation-level SOTA guarantee. The available sources support only the following conditional synthesis.

## 1. Extreme-step Stiefel retraction

For \(X^\top X=I\) and tangent step \(\Xi\), the standard retractions include

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)\bigl(I+\Xi^\top\Xi\bigr)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley transform based on a skew-symmetric update. These formulas and their differing computational costs are documented in the Stiefel-retraction literature.[1]

The mathematically defensible arbitration is:

- **No method is unconditionally stable for arbitrary \(\lvert\text{step}\rvert\ge 10^{10}\)** in finite precision.
- A Cayley retraction preserves orthogonality structurally when its linear solve is well-defined and accurately executed, but it can become ill-conditioned when the associated system approaches singularity.
- Polar retraction has a particularly clean geometric formulation, but forming \(I+\Xi^\top\Xi\), its inverse square root, and \(X+\Xi\) can cause overflow, underflow, loss of scale, or cancellation for extreme steps.
- Householder-based QR is generally the preferred *orthogonalization primitive* for numerical robustness, but it does not make the input \(X+\Xi\) safe when that matrix is badly scaled or nearly rank deficient.
- QR and polar methods have been observed to become unstable in some large-step numerical experiments; this rules out an unconditional claim that either dominates for every extreme-step regime.[10]

**Recommended guarantee:** use norm-scaled steps, finite-value checks, rank/conditioning checks, and a fallback sequence such as

\[
\Xi \leftarrow
\frac{\tau}{\max(1,\|\Xi\|)}\Xi,
\]

followed by Householder QR or a carefully scaled polar factorization. If exact Cayley structure is required, solve the Cayley system with pivoting or iterative refinement and reject updates whose residual or orthogonality defect exceeds tolerance.

The strongest valid guarantee is therefore **conditional backward stability under bounded scaling and nonsingularity**, not stability for every raw step of magnitude \(10^{10}\) or greater.

## 2. PMTP descriptor barriers and RCU/QSBR

Acquire/release semantics provide an ordering relationship only when the acquire reads from the relevant release sequence or otherwise participates in the same synchronization protocol. An acquire prevents later operations from being reordered before it; a release prevents earlier operations from being reordered after it.[9]

Consequently, an 88-byte descriptor is not made safe merely by placing acquire and release operations somewhere in its access path. Snapshot isolation requires a complete protocol:

1. The writer initializes the descriptor and all reachable immutable payload.
2. The writer publishes the descriptor pointer or generation using a **release** operation.
3. The reader loads the publication point with **acquire** semantics.
4. The reader announces an RCU/QSBR read-side critical section before dereferencing the snapshot.
5. Retired descriptors and their reachable storage are reclaimed only after every reader that could have observed the old generation has passed a quiescent state.
6. Descriptor fields that can change concurrently must either be immutable after publication, independently atomic, or protected by a documented lock/protocol.

A release store on one field does **not** automatically make unsynchronized writes to unrelated mutable fields safe. Likewise, acquire/release alone does not provide reclamation safety; that requires the RCU/QSBR grace-period rule.

**Architectural guarantee:** with immutable-after-publication descriptors, release publication, acquire consumption, correct reader registration, and grace-period reclamation, readers observe a fully initialized snapshot and never access reclaimed storage. Without all of those conditions, snapshot isolation is not guaranteed.

The descriptor’s size—88 bytes—has no inherent memory-ordering significance. Alignment, cache-line placement, atomic field widths, ABI layout, and lifetime rules must be specified independently.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

The available evidence does not establish a common POLYDIM ABI or an official conformance suite across these five environments. Thus, **cross-silicon conformance cannot be asserted** from the model names alone.

A credible conformance contract must separately define:

- numerical precision and permitted error bounds;
- NaN, infinity, signed-zero, and overflow behavior;
- matrix layout, alignment, padding, and endianness;
- synchronization scope and visibility domain;
- descriptor ownership and reclamation;
- supported atomic widths and memory orders;
- deterministic versus nondeterministic reduction behavior;
- device-specific math-library allowances;
- conversion rules between host and device representations.

C++20 and Rust can express acquire/release ordering, but the guarantee applies only to operations participating in the same defined atomic protocol. CUDA and Triton additionally require explicit treatment of GPU memory scopes, kernel launch ordering, stream/event synchronization, and host/device visibility. XLA may legally fuse, reorder, or lower operations according to its compiler and backend semantics unless the contract introduces an explicit ordering primitive.

Therefore, a valid portability claim should be stated as:

> **Conforming implementations preserve the specified abstract snapshot and numerical contract under the declared memory scope, precision, and synchronization model; they are not required to produce bit-identical results across CUDA, XLA, Triton, C++20, and Rust unless deterministic arithmetic and reduction order are explicitly mandated.**

## Arbitration outcome

The strongest defensible synthesis is:

- **Cayley:** structurally attractive and potentially second-order accurate, but not universally stable under unscaled extreme steps.
- **Householder QR:** preferred robust fallback for re-orthogonalization, subject to scaling and rank checks.
- **Polar:** geometrically canonical and useful when conditioning is controlled, but not an unconditional extreme-step solution.
- **PMTP barriers:** acquire/release are necessary publication tools, not a complete RCU/QSBR reclamation protocol.
- **Multi-silicon support:** possible only through an explicit abstract-machine contract and conformance tests; no evidence supports an unconditional exact guarantee across all five toolchains and silicon targets.

Accordingly, claims such as **“guaranteed stability for every \(\lvert\text{step}\rvert\ge10^{10}\),” “snapshot isolation from acquire/release alone,”** or **“bit-exact universal conformance”** should be rejected unless the missing V1350 specifications, implementations, proofs, and test results are supplied.