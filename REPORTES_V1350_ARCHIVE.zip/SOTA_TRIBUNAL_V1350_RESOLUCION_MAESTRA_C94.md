# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 94

The requested **Cycle 94 arbitration cannot be made definitively** from the information available: the six Tribunal reports, the six V1350 kernel specifications, and any conformance test artifacts were not provided, and no publicly verifiable POLYDIM V1350 specification was found. The available literature supports general mathematical and memory-model conclusions, but not product-specific guarantees.

## 1. Cayley–Stiefel retraction under extreme steps

For \(X\in\mathrm{St}(n,p)\), common retractions include

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)(I+\Xi^\top\Xi)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley map of the form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

where \(W^\top=-W\) is constructed from the tangent update.[1][2]

The mathematically defensible arbitration is:

| Criterion | Cayley | Polar | Householder/QR |
|---|---|---|---|
| Exact orthogonality in exact arithmetic | Yes, when the inverse exists | Yes | Yes |
| Behavior as \(\lvert\text{step}\rvert\to\infty\) | Not intrinsically bounded; conditioning depends on \(I-\frac12W\) | Defined for finite full-rank \(X+\Xi\), but can overflow or lose rank numerically | QR remains algebraically applicable, but numerical scaling is essential |
| Numerical stability | Strong for well-conditioned solves; requires a stable linear solver | Often highly accurate; inverse square root is expensive | Householder QR is generally the standard robust factorization |
| Cost | Low-rank or structured implementations can be efficient | Typically more expensive | Typically robust and broadly available |
| Unconditional guarantee at \(\lvert\text{step}\rvert\ge10^{10}\) | None without scaling, conditioning, and finite-precision bounds | None without scaling and rank/overflow controls | None without scaling and rank/overflow controls |

Cayley should therefore **not** be declared universally more stable than Householder QR or polar retraction at extreme step magnitudes. Its exact orthogonality is a structural advantage, but the computation requires solving a system involving \(I-\frac12W\); finite-precision stability depends on the conditioning of that system, the construction of \(W\), and whether the update is rescaled. The literature describes Cayley, QR, and polar methods as alternative retractions rather than establishing unconditional dominance of one method.[1][2]

A defensible V1350 guarantee would require all of the following:

- **Step normalization or trust-region scaling** before forming large products.
- **Overflow-safe norm computation**, such as scaled BLAS-style norm evaluation.
- **Stable factorization**, preferably Householder QR or a backward-stable symmetric eigensolver/SVD for the polar path.
- **Condition monitoring** for \(I-\frac12W\).
- **Residual certification**, for example
  \[
  \|Y^\top Y-I\|\le \tau_{\mathrm{orth}}
  \]
  and an update residual bound.
- A specified failure result when the requested step cannot be represented or the solve is ill-conditioned.

Thus, the strongest mathematically justified synthesis is a **hybrid policy**: use Cayley for bounded, well-conditioned, often low-rank updates; fall back to scaled Householder QR or a stabilized polar computation when the step is extreme or the Cayley solve is poorly conditioned. No exact guarantee is possible for arbitrary \(\lvert\text{step}\rvert\ge10^{10}\) in finite precision merely from the choice of retraction.

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

An 88-byte descriptor size by itself provides **no memory-ordering guarantee**. Snapshot isolation depends on the publication protocol, object lifetime rules, atomicity of the fields used for publication, and the participating platform memory model.

The required publication pattern is conceptually:

1. Writer fully initializes the immutable descriptor or versioned payload.
2. Writer publishes its pointer/version with **release** semantics.
3. Reader loads the published pointer/version with **acquire** semantics.
4. Reader enters an RCU read-side critical section before dereferencing.
5. Writer retires the old object only after a grace period.
6. QSBR readers report quiescent states according to the implementation’s protocol.

Acquire/release establishes a *happens-before* relationship for initialization and publication, but it does not by itself provide reclamation safety. In particular:

- **Release publication + acquire observation** protects visibility of prior initialization.
- **RCU/QSBR grace periods** protect object lifetime after replacement.
- **Atomic pointer/version publication** prevents data races on the publication variable.
- **Immutable-after-publication payloads** avoid races on descriptor contents.
- **Seqlock-style validation** may be needed if readers observe mutable multiword state.
- An 88-byte descriptor may require padding, alignment, or split-field handling; it must not be assumed to be atomically transferable as one unit across all targets.

A correct guarantee can therefore be stated as:

> If the publication word is atomic, the writer initializes the descriptor before a release store, readers perform an acquire load inside a valid RCU/QSBR read-side section, and reclamation occurs only after the corresponding grace period, readers observe either a fully initialized old snapshot or a fully initialized new snapshot, and no reclaimed descriptor is dereferenced.

That guarantee is conditional. **Acquire/release alone is insufficient** for RCU/QSBR snapshot isolation, and descriptor byte length does not strengthen it. The exact semantics must be mapped separately to C++20 atomics, Rust atomics/ownership discipline, CUDA memory scopes, and the relevant XLA/Triton lowering behavior.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single “multi-silicon conformance” guarantee across these ecosystems cannot be inferred from source-level similarity. They expose different execution, synchronization, compilation, and memory models:

- **C++20** provides a language memory model and atomic ordering rules, but hardware-specific lock-free and alignment properties remain implementation-dependent.
- **Rust** largely inherits the target platform’s atomic and memory semantics through its atomic types; ownership and borrowing help with ordinary aliasing but do not automatically implement RCU reclamation.
- **CUDA** has device-, block-, and system-scope synchronization and atomics; host/device visibility and scope must be specified explicitly.
- **Triton** is a kernel DSL whose compiler and target backend determine supported synchronization and memory behavior; C++20-style object lifetime assumptions do not transfer automatically.
- **XLA** is an optimizing compiler IR/runtime ecosystem; buffer aliasing, ordering, and visibility must be established through its documented operations and backend contracts, not assumed from source-language acquire/release syntax.

The proper conformance criterion is not bitwise identity across all backends. It should be a layered contract:

1. **Representation conformance**  
   Field offsets, widths, alignment, endianness, and version tags are identical or explicitly translated.

2. **Algebraic conformance**  
   Each backend implements the same retraction equations and returns an orthogonality residual within a stated tolerance.

3. **Memory-order conformance**  
   Publication, acquisition, reader critical sections, and reclamation satisfy the same happens-before and grace-period contract.

4. **Numerical conformance**  
   Results satisfy bounded error criteria relative to a reference implementation, with tolerances parameterized by datatype, backend, and reduction order.

5. **Failure conformance**  
   Overflow, rank deficiency, ill-conditioned Cayley solves, unsupported atomic widths, and timeout/stalled-QSBR conditions produce specified status codes rather than silent degradation.

6. **Adversarial testing**  
   Tests must include extreme steps, NaN/Inf inputs, rank-deficient updates, descriptor reuse, delayed readers, preemption, mixed host/device access, divergent GPU control flow, and compiler optimization barriers.

## Definitive arbitration

The strongest supportable SOTA synthesis is:

- **Retraction:** no universal winner at \(\lvert\text{step}\rvert\ge10^{10}\). Use scaled Cayley when its linear system is certified well-conditioned; otherwise use a stabilized Householder-QR or polar fallback. Guarantee orthogonality only through explicit residual checks and finite-precision bounds.
- **PMTP:** use release publication and acquire observation, but require immutable snapshots, atomic publication metadata, valid RCU/QSBR read-side participation, and grace-period reclamation. The 88-byte layout is not itself a synchronization guarantee.
- **Portability:** claim conformance only through a formal representation, algebraic, memory-order, numerical, and failure contract, separately validated on CUDA, XLA, Triton, C++20, and Rust.
- **Exact architectural guarantee:** without the missing V1350 definitions and six Tribunal findings, the only valid guarantee is conditional—not an unconditional claim of extreme-step stability, cross-silicon memory isolation, or universal language/backend equivalence.