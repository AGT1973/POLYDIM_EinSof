# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 71

The six “V1350 kernels” and the six Tribunal-model reports are not included in the available material, so no literal vote-by-vote arbitration is possible. The defensible SOTA synthesis is therefore a **conditional architectural specification**, not a claim that any particular model’s undocumented result is correct.

## 1. Stiefel retraction under \(\lvert\mathrm{step}\rvert \ge 10^{10}\)

No retraction method can honestly guarantee finite, accurate output for an unrestricted step of that magnitude. The correct guarantee is conditional on finite arithmetic, conditioning, overflow handling, and a bounded accepted step.

A Cayley retraction has the form

\[
Y=(I-\tfrac{\alpha}{2}\Omega)^{-1}
   (I+\tfrac{\alpha}{2}\Omega)X,
\qquad \Omega^\top=-\Omega .
\]

When computed exactly, the Cayley map preserves orthogonality because it is a rational orthogonal transformation. Iterative Cayley schemes are valid retractions and can avoid a large matrix inverse, but their convergence requires a step-dependent contraction condition; one cited formulation requires a bound of the form

\[
\alpha < \frac{2}{\lVert \Omega\rVert}.
\]

Thus, a raw step of \(10^{10}\) is **not** itself a stability guarantee. It can make the linear system ill-conditioned, overflow intermediate products, or invalidate fixed-point convergence.

| Method | Mathematical property | Extreme-step verdict |
|---|---|---|
| Cayley | Orthogonality-preserving when the solve is accurate; efficient for structured or low-rank updates | Best as an adaptive method, not as an unrestricted huge-step operation |
| Polar | Produces the nearest orthogonal factor in the Frobenius norm; generally robust when the input has adequate singular-value separation | Strong fallback, but requires stable polar/SVD-like computation |
| Householder QR | Backward stable in standard implementations and avoids forming normal equations | Preferred general-purpose fallback, with sign/pivot conventions fixed |

The mathematically superior design is therefore **not “Cayley always wins.”** It is a guarded hierarchy:

1. Scale or clip the proposed step before forming \(\Omega\).
2. Use Cayley only when a certified bound such as \(\alpha\|\Omega\|<2-\varepsilon\) holds and the small solve is well-conditioned.
3. Otherwise use Householder QR or a stable polar factorization.
4. Verify the result using
   \[
   \|Y^\top Y-I\| \le \tau_{\mathrm{orth}}
   \]
   and a residual/backward-error test.
5. Reject, recompute at higher precision, or fall back if the test fails.

The exact guarantee should be stated as:

> For every accepted finite step, the kernel returns a matrix satisfying the requested orthogonality tolerance, or returns an explicit failure/status code. It must never silently claim a valid Stiefel point after overflow, nonconvergence, or a failed residual check.

Claims that Cayley is unconditionally more stable than Householder QR or polar retraction at \(\lvert\mathrm{step}\rvert\ge10^{10}\) are not mathematically supportable.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release operations are necessary but are not, by themselves, a complete RCU or QSBR protocol.

The essential publication pattern is:

1. Fully initialize the immutable descriptor and the object graph it references.
2. Publish the descriptor pointer with a **release** store or exchange.
3. Readers load the pointer with an **acquire** operation.
4. Readers announce entry into the read-side critical section before dereferencing the object.
5. Retiring writers wait for the relevant grace period or QSBR epoch.
6. Reclaim memory only after every pre-existing reader has passed a quiescent state.

A release store synchronizes with an acquire load that reads its value; this makes prior initialization visible to the reader. The corresponding RCU principle is that release/acquire ordering protects publication, while the grace-period mechanism protects reclamation.

The exact guarantee is:

> A reader that successfully acquires a published PMTP descriptor observes a fully initialized descriptor and all release-before-publication data. No retired descriptor or transitively referenced object is reclaimed until every reader that could have acquired the old pointer has passed the required grace period.

The following are **not sufficient** on their own:

- An acquire load without a release publication.
- A release store without a reader-side critical-section protocol.
- A compiler barrier alone.
- An 88-byte size or alignment assertion alone.
- QSBR epoch increments without proof that every participating reader reports quiescence.
- Relaxed atomics used for pointer publication or reclamation decisions.

The 88-byte layout must additionally be treated as an ABI contract:

- `static_assert(sizeof(Descriptor) == 88);`
- Explicit alignment and offset assertions.
- No unintentional padding dependence across languages.
- Defined ownership and lifetime of every pointer, handle, and embedded scalar.
- Atomic fields must use representations and alignment supported by every target.
- Serialization, endian, and version fields must be explicit if descriptors cross process or device boundaries.

A crucial distinction is that acquire/release gives **happens-before publication**, not a universal snapshot transaction. If a snapshot contains multiple independently mutable objects, the implementation needs immutable versions, a sequence counter, RCU replacement of the complete root, or another validation protocol. Otherwise readers can observe a mixture of generations even though each individual pointer load is correctly ordered.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

“Conformance” must be split into separate claims:

- **Numerical conformance:** same mathematical result within a declared tolerance.
- **Memory-model conformance:** equivalent publication, visibility, and reclamation guarantees.
- **ABI/layout conformance:** identical size, alignment, offsets, and representation.
- **Compilation conformance:** all implementations accept and lower the specified operations.
- **Performance conformance:** throughput or latency targets, which are not implied by the others.

C++20 and Rust can express host-side atomic ordering, but CUDA device memory ordering and synchronization are governed by CUDA’s own memory model and scope rules. XLA and Triton are compiler/intermediate-representation systems; they do not automatically provide arbitrary host-style RCU/QSBR semantics for device-resident data structures. A host RCU guarantee cannot simply be transferred to a GPU kernel without an explicit device protocol.

The portable architecture should therefore use:

- A language-neutral descriptor schema.
- Generated layout manifests for C++20, Rust, CUDA, and any host/device ABI.
- Compile-time size, alignment, and offset checks.
- Explicit scalar types and endianness.
- A canonical reference implementation.
- Backend-specific kernels with declared precision and accumulation modes.
- Golden-vector tests, randomized tests, adversarial-condition tests, and differential tests.
- Separate host and device synchronization protocols.
- Capability checks for atomics, memory scopes, and supported floating-point operations.

For numerical kernels, the strongest realistic statement is:

\[
\|f_{\text{backend}}(x)-f_{\text{reference}}(x)\|
\le
\tau_{\text{abs}}+\tau_{\text{rel}}\|f_{\text{reference}}(x)\|,
\]

with tolerances parameterized by dtype, reduction order, backend, and matrix conditioning. Bitwise identity across CUDA, XLA, Triton, C++20, and Rust should not be promised unless deterministic arithmetic, operation ordering, compiler settings, and hardware are all fixed.

For the memory subsystem, the portable guarantee should instead be stated in terms of a protocol:

> All backends implement the same abstract state machine: release publication, acquire observation, reader registration, quiescent-state reporting, grace-period completion, and deferred reclamation. Backend-specific primitives may differ, but an implementation is conformant only if it refines that state machine and passes litmus tests for publication, stale reads, reader entry races, and reclamation safety.

## Definitive arbitration

The strongest defensible synthesis is:

1. **Retraction:** guarded Cayley for admissible steps; Householder QR or polar fallback for extreme or ill-conditioned steps; residual verification is mandatory.
2. **Descriptor:** 88 bytes is an ABI invariant, not a synchronization proof. Publication requires release/acquire; reclamation requires a correct RCU/QSBR grace-period protocol.
3. **Portability:** define conformance at the schema, protocol, and tolerance levels. Do not claim identical floating-point results or host-style RCU semantics on GPU backends without explicit implementation and tests.
4. **Architectural guarantee:** every kernel must either return a result satisfying its declared numerical and memory-safety contract or return a detectable failure. Silent degradation, unchecked overflow, unverified orthogonality, and premature reclamation are outside the specification.

Accordingly, any Tribunal finding asserting unconditional Cayley superiority at \(10^{10}\)-scale steps, snapshot isolation from acquire/release alone, or automatic cross-silicon equivalence should be rejected as overstated.