# TRIBUNAL DE SABIOS — DEEPSEEK V3 (V1350 AUDIT)

# POLYDIM V1350 — Cold Technical Audit

## 1. Cayley Retraction on St(D,K): Backward Error Under Extreme Steps

### 1.1 Setup and the actual problem

You are computing a retraction $R_X(\xi)$ on the Stiefel manifold $\mathrm{St}(D,K)$, $D\ge 10^5$, $K\le 64$. The Cayley transform is
$$
R_X(\xi) = \left(I - \tfrac{1}{2}W\right)^{-1}\left(I + \tfrac{1}{2}W\right)X,\qquad W = \xi X^\top - X\xi^\top \in \mathfrak{so}(D).
$$
The "two Lyapunov + Woodbury" pipeline is a *specific factorization* of this map. Let me be precise about what is actually being solved, because the framing hides the real conditioning.

Write $X = [Z/s,\; U_2]$ with $Z\in\mathbb{R}^{D\times K}$ the active block and $U_2$ an orthonormal complement. The Lyapunov equations
$$
GC + CG = S + S^\top,\qquad GB + BG = -S_t
$$
are the standard Bartels–Stewart reduction for the Sylvester/Lyapunov system $G Y + Y G = R$. **The critical fact**: the conditioning of this solve is governed by $\mathrm{sep}(G,-G) = 2\sigma_{\min}(G)$, not by $\kappa(G)$ alone. For $G$ symmetric positive definite with eigenvalues in $[\lambda_{\min},\lambda_{\max}]$,
$$
\|Y\|_F \le \frac{\|R\|_F}{2\lambda_{\min}(G)},\qquad \kappa_{\text{Lyap}} = \frac{\lambda_{\max}(G)}{2\lambda_{\min}(G)}.
$$
If $G$ is the projected Hessian $H = U^\top U$ (or its active restriction), then $\lambda_{\min}(H)$ collapses as the iterate approaches a degenerate critical point. **This is the failure mode.**

### 1.2 Backward error comparison

Let $\tau$ be the step size, $\rho = 2/\tau$ the spectral limit you cite. Define the *effective* condition number of each route:

| Route | Dominant cost | Backward error bound (FP64, unit roundoff $u\approx 1.1\times10^{-16}$) |
|---|---|---|
| (a) Eigendecomposition of $H=U^\top U$ | $O(K^3)$ + $O(DK^2)$ | $\hat\gamma \lesssim u\cdot\kappa(V)\cdot\kappa(H)\cdot\|H\|/\rho$ |
| (b) Householder/CholQR polar | $O(DK^2)$ | $\hat\gamma \lesssim u\cdot\kappa(X)\cdot(1+\tau\|W\|/2)$ |
| **Your Lyapunov+Woodbury** | $O(DK^2)$ | $\hat\gamma \lesssim u\cdot\kappa_{\text{Lyap}}\cdot\kappa_{\text{Wood}}\cdot(\|S\|+\|S_t\|)/\rho$ |

**Key asymptotic claim (provable):**

> For $|\tau| \ge 10^{10}$ and $\|S\|_F = O(1)$, the Lyapunov route has backward error $\hat\gamma_{\text{Lyap}} = \Theta(u\cdot \tau \cdot \lambda_{\min}(G)^{-1})$, whereas the polar route has $\hat\gamma_{\text{polar}} = \Theta(u\cdot\tau\cdot\|W\|_2)$ with $\|W\|_2 \le 2\|X\|_2\|\xi\|_2$.

The Lyapunov route is **strictly worse** by a factor $\|W\|_2 / \lambda_{\min}(G)$ whenever $\lambda_{\min}(G) \ll \|W\|_2$. Under extreme steps, $\|W\|_2 \sim \tau\|\xi\|$, so the ratio is $\sim \tau\|\xi\|/\lambda_{\min}(G)$ — **unbounded**.

### 1.3 The Woodbury scaling is a band-aid, not a fix

The scaling `scale = max(1.0, |step|)` followed by $(M/\text{scale})W = (\text{step}/\text{scale})B$ is a *norm-balancing* trick. It controls the *magnitude* of the RHS but does **not** change $\kappa(M)$. Specifically:

- If $M = I + \tfrac{1}{2}G^{-1}S$ (the Woodbury form), then $\kappa(M) \le (1+\tfrac12\|G^{-1}S\|)/(1-\tfrac12\|G^{-1}S\|)$.
- As $\tau\to\infty$, $\|G^{-1}S\| \to \|G^{-1}\|\cdot\|S\|$, which is **independent of $\tau$** only if $S$ is $\tau$-independent. But in your pipeline $S$ is built from $\xi$, so $\|S\|\sim\tau\|\xi\|$ and $\|G^{-1}S\|\sim\tau\|\xi\|/\lambda_{\min}(G)$.

**Conclusion**: scaling does not save you. The backward error grows linearly in $\tau$ until $\|G^{-1}S\| \gtrsim 1$, at which point the Woodbury inverse loses all accuracy and the retraction leaves the manifold by $O(1)$.

### 1.4 Provable recommendation

For $|\tau|\ge 10^{10}$:

1. **Do not use the Lyapunov route.** Use the **polar retraction via CholQR** (route b). Its backward error is bounded by $u\cdot\kappa(X)\cdot(1+\tau\|W\|/2)$ and, crucially, the *manifold distance* $\mathrm{dist}(R_X(\xi),\mathrm{St})$ is $O(u\cdot\kappa(X))$ **independent of $\tau$** because the polar factor is computed by a QR whose conditioning depends only on $X$, not on $\xi$.
2. If you must keep the Cayley form, replace the Lyapunov solve with a **direct Householder application**: $R_X(\xi) = X + \tau\,W\,(I - \tfrac{\tau}{2}W)^{-1}X$ computed via $K$ Householder reflectors. Cost $O(DK^2)$, backward error $O(u\cdot\tau\|W\|)$ but with **no $\lambda_{\min}(G)^{-1}$ blowup**.
3. The eigendecomposition route (a) is only competitive when $K$ is small and $H$ is well-conditioned; for $D=10^5$, $K=64$, the $O(DK^2)$ matmul dominates and the $\kappa(V)$ factor is the killer near degenerate spectra.

**Verdict**: Your architecture is **not** provably lower backward error under extreme steps. It is provably *higher* by a factor $\|W\|_2/\lambda_{\min}(G)$.

---

## 2. Rule 22 (Ghost Protocol) — 88-Byte PMTP Descriptor

### 2.1 Struct layout audit

Format `<4sHHQQQQQBB6x4Q`:

| Offset | Field | Size | Notes |
|---|---|---|---|
| 0 | magic `"PDM4"` | 4 | OK |
| 4 | version=1350 | 2 | OK |
| 6 | encoded_size=88 | 2 | OK |
| 8 | segment_id | 8 | OK |
| 16 | buffer_id | 8 | OK |
| 24 | generation | 8 | OK |
| 32 | byte_offset | 8 | OK |
| 40 | byte_length | 8 | OK |
| 48 | dtype_code=1 | 1 | OK |
| 49 | ndim | 1 | OK |
| 50 | reserved[6] | 6 | OK |
| 56 | shape[4] | 32 | OK |
| **Total** | | **88** | ✓ |

Struct is **packed correctly**, no padding, alignment is 8-byte for the Q fields. Good.

### 2.2 Does it resolve ASLR pointer relocation?

**No — and this is the central flaw.** The descriptor contains **no pointer field**. It contains `segment_id`, `buffer_id`, `byte_offset`, `byte_length`. This is a *handle-based* design, which is the correct approach for ASLR, **but only if**:

1. There is a **process-local translation table** mapping `(segment_id, buffer_id) → base_va`. The descriptor alone is meaningless without it.
2. The translation table is itself in shared memory and must be **versioned** (hence `generation`).
3. `generation` must be **monotonic** and **atomically updated** on every remap. A 64-bit generation is sufficient for ABA avoidance only if you also have a **hazard pointer** or **epoch** mechanism.

**Failure mode**: If process A reads `(segment_id=5, buffer_id=7, generation=42)`, then process B remaps segment 5 and bumps generation to 43, process A's subsequent dereference via its stale translation table entry is a **use-after-free**. The descriptor does not prevent this; only the RCU/QSBR protocol does.

### 2.3 Lockless RCU/QSBR snapshot isolation

For lockless RCU/QSBR across multi-process shared memory, you need:

- **Per-thread epoch counters** in shared memory (one cache line each, padded to avoid false sharing).
- **Grace period detection**: a writer must wait until all readers have advanced past the epoch in which the old mapping was published.
- **Memory ordering**: `std::atomic_thread_fence(std::memory_order_acquire)` on the reader side after reading the descriptor, and `release` on the writer side after publishing.

Your 88-byte descriptor **does not contain**:
- A pointer to the epoch counter.
- A sequence number for the RCU update (the `generation` field is a *version*, not a *sequence*).
- A checksum or CRC to detect torn reads.

**Torn read risk**: The descriptor is 88 bytes, which spans **two cache lines** on x86-64 (64-byte lines). A concurrent writer updating `generation` and `byte_offset` can produce a **torn descriptor** where the reader sees new generation with old offset. You need either:
- A **seqlock** (even/odd counter) around the descriptor, or
- A **128-byte aligned** descriptor with a single atomic 16-byte CAS on the first 16 bytes (magic+version+size+segment_id+buffer_id) as a commit flag.

**Verdict**: The descriptor is a **necessary but not sufficient** component. It resolves ASLR *only* in conjunction with a versioned translation table and a proper QSBR protocol. As specified, it is **not** lockless-safe across processes.

---

## 3. Rule 27 (Silicon Contract) — Numerical Divergence: XLA HLO `eigh` vs cuSOLVER `DnDsyevd`

### 3.1 Algorithmic divergence

- **cuSOLVER `DnDsyevd`**: Divide-and-conquer (D&C) for the tridiagonal eigenproblem, with **secular equation** solved by **Newton + rational interpolation** (Gu–Eisenstat). Backward error: $\|A - V\Lambda V^\top\|_F \le c\cdot u\cdot\|A\|_F$ with $c$ small (typically $c\lesssim 10$). Forward error on eigenvalues: $O(u\cdot\|A\|_2)$ for well-separated, $O(u\cdot\|A\|_2/\mathrm{gap})$ for clustered.

- **XLA HLO `eigh`**: Lowers to **LAPACK `syevd`** on CPU (same D&C) but on **TPU** it lowers to a **custom HLO fusion** that typically uses **QR iteration** or **Jacobi** depending on the XLA version. On GPU (via XLA:GPU), it lowers to **cuSOLVER** as well, but the **HLO fusion** may reorder operations, changing the **accumulation order** in the tridiagonalization (Householder) step.

### 3.2 Concrete divergence bound

Let $A\in\mathbb{R}^{n\times n}$ symmetric. The two implementations produce $\hat\Lambda_1, \hat\Lambda_2$. Then:
$$
|\hat\lambda_i^{(1)} - \hat\lambda_i^{(2)}| \le |\hat\lambda_i^{(1)} - \lambda_i| + |\lambda_i - \hat\lambda_i^{(2)}| \le 2c\,u\,\|A\|_2\,\kappa_{\text{eig}},
$$
where $\kappa_{\text{eig}} = \max_i \|A\|_2/\mathrm{gap}_i$ and $\mathrm{gap}_i = \min_{j\ne i}|\lambda_i-\lambda_j|$.

**For clustered spectra** ($\mathrm{gap}\sim u\|A\|$), the divergence can be $O(\|A\|_2)$, i.e., **complete loss of agreement** on individual eigenvalues, though the **invariant subspace** is still accurate to $O(u\|A\|/\mathrm{gap})$.

### 3.3 FP64-specific concerns

- **cuSOLVER DnDsyevd** uses **FP64 throughout** but the secular equation solver uses **extended precision** (double-double) internally for the **twisted factorization**. This is a **non-reproducible** optimization: the result depends on the **number of threads** and the **block size** chosen by cuSOLVER's heuristic.
- **XLA HLO** on TPU uses **bfloat16 accumulation** in some fusion paths unless `--xla_cpu_enable_fast_math=false` and `--xla_gpu_enable_fast_math=false` are set. **This is a silent FP64→BF16 downgrade** that will produce $O(10^{-2})$ divergence, not $O(10^{-16})$.
- **XLA on GPU** may use **TF32** for the tridiagonalization matmuls unless `XLA_FLAGS=--xla_gpu_enable_tf32=false`. Again, silent precision loss.

### 3.4 Verdict

**Yes, there are numerical divergences.** For well-separated spectra, divergence is $O(u\|A\|_2)\sim 10^{-16}\|A\|_2$. For clustered spectra, divergence can be $O(\|A\|_2)$. The **dominant risk** is not algorithmic but **configuration**: XLA's default fast-math and TF32/BF16 paths will silently degrade FP64 accuracy. You must pin:
```
XLA_FLAGS=--xla_gpu_enable_tf32=false --xla_cpu_enable_fast_math=false
```
and verify with a **reproducibility test** on a known clustered matrix (e.g., Wilkinson $W_{21}^+$).

---

## Summary of Provable Failures

| Component | Claim | Reality |
|---|---|---|
| Cayley Lyapunov | Lower backward error at $\tau\ge10^{10}$ | **False** — error $\propto \tau/\lambda_{\min}(G)$, unbounded |
| Woodbury scaling | Stabilizes extreme steps | **False** — controls magnitude, not conditioning |
| 88-byte descriptor | Resolves ASLR + lockless RCU | **Insufficient** — no translation table, no seqlock, torn reads across cache lines |
| XLA vs cuSOLVER | FP64 agreement | **False** — $O(\|A\|)$ divergence on clustered spectra; silent TF32/BF16 downgrade |

**Recommendation**: Replace the Lyapunov route with CholQR polar; add a seqlock + 128-byte alignment to the descriptor; pin XLA fast-math flags and add a reproducibility gate.