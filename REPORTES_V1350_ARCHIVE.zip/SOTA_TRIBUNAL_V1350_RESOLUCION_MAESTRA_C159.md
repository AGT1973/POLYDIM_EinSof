# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 159

There is not enough verifiable evidence to perform the requested **eight-model arbitration** or to assert definitive architectural guarantees for “POLYDIM V1350.” The available public results do not identify a V1350 specification, six-kernel definition, PMTP descriptor layout, Tribunal transcripts, or conformance test artifacts. The only relevant material supports general mathematical and systems principles, not claims about this purported implementation.[1][2][3]

## Provisional arbitration of the three technical questions

### 1. Cayley–Stiefel retraction versus Householder/Polar QR at \(|\mathrm{step}| \ge 10^{10}\)

A Cayley retraction has the form

\[
Y=\left(I-\frac12 W\right)^{-1}\left(I+\frac12 W\right)X,
\]

where \(W^\ast=-W\). Its key mathematical property is that the exact transform is orthogonal/unitary, so it preserves the Stiefel constraint in exact arithmetic.[2][3]

That does **not** imply numerical stability for an extreme step:

- A large step can make the tangent generator \(W\) very large.
- The Cayley solve may become ill-conditioned or suffer overflow, loss of significance, and inaccurate iterative convergence.
- The published iterative Cayley method itself requires a step-size restriction for contraction; therefore it cannot justify an unconditional guarantee at \(10^{10}\).[2]
- QR and polar retractions explicitly re-orthogonalize the result. Their stability still depends on the chosen algorithm, scaling, precision, rank behavior, and exceptional-case handling.
- Householder QR with a stable implementation is generally the strongest default for robust orthogonalization; polar decomposition is attractive when the closest-point interpretation matters but can be more expensive.

**Arbitration:** no method should be declared unconditionally stable at \(|\mathrm{step}| \ge 10^{10}\). A defensible architecture must either:

1. reject or rescale such steps;
2. use a bounded trust-region or geodesic parameter;
3. fall back to Householder QR or a carefully implemented polar factorization;
4. verify the postcondition
   \[
   \|Y^\ast Y-I\|\le \tau
   \]
   and return an explicit failure status if it is not met.

The strongest guarantee available is therefore **conditional constraint preservation after verified re-orthogonalization**, not “Cayley is stable for arbitrary extreme steps.”

### 2. PMTP 88-byte descriptors and RCU/QSBR snapshot isolation

Acquire/release operations alone do not establish a complete RCU or QSBR protocol. They can order publication and observation, but safe reclamation additionally requires:

- immutable or versioned descriptor contents after publication;
- release publication of the new pointer/version;
- acquire observation by readers;
- reader announcement or quiescent-state tracking;
- a grace-period proof showing that every reader that could have held the old snapshot has passed a quiescent state;
- reclamation only after that proof;
- correct alignment, lifetime, and atomicity for every concurrently accessed field.

A useful abstract protocol is:

\[
\text{initialize snapshot}
\;\xrightarrow{\text{release}}\;
\text{publish pointer/version}
\;\xrightarrow{\text{acquire}}\;
\text{reader uses immutable snapshot}
\]

followed by:

\[
\text{retire old snapshot}
\;\xrightarrow{\text{QSBR grace period}}\;
\text{reclaim}.
\]

**Arbitration:** the exact 88-byte size is not itself a correctness property. The descriptor can guarantee snapshot isolation only if its ABI specifies field offsets, alignment, ownership, atomic widths, publication ordering, and reclamation protocol. “Acquire/release semantics” without a grace-period mechanism is insufficient and must not be advertised as memory-safe RCU.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

Cross-silicon conformance cannot be inferred from source-level similarity. These environments have different execution and memory models:

- CUDA and Triton expose GPU-specific synchronization and scope rules.
- XLA may fuse, reorder, or lower operations under compiler-controlled semantics.
- C++20 defines language-level atomics but does not automatically provide GPU-device visibility or host/device lifetime guarantees.
- Rust provides type and ownership safety within its model, but `unsafe`, FFI, atomics, kernels, and device memory remain dependent on the target backend.

A genuine conformance claim requires a normative semantic contract plus differential tests covering:

- numerical postconditions and tolerances;
- NaN, infinity, overflow, underflow, and rank-deficient inputs;
- extreme steps;
- concurrent publication, readers, quiescent states, and reclamation;
- alignment and endian/ABI checks for the 88-byte descriptor;
- synchronization scopes and stream/event behavior;
- deterministic failure codes;
- every supported compiler, architecture, precision mode, and optimization level.

**Arbitration:** conformance should be stated as a tested implementation matrix, not as a universal property of the five ecosystems. Absent such artifacts, the strongest valid status is **unverified portability**, not multi-silicon conformance.

## Definitive guarantee set that can responsibly be claimed

For a production-quality V1350-like design, the architectural guarantees should be limited to the following:

1. **Manifold invariant:** successful kernels return \(Y\) satisfying \(Y^\ast Y=I\) within a specified, measured tolerance; failures are explicit.
2. **Extreme-step behavior:** steps outside a defined safe range are scaled, rejected, or sent to a verified QR/polar fallback; no unconditional \(10^{10}\) stability claim.
3. **Snapshot safety:** readers observe either the old or new immutable snapshot, never a partially initialized one.
4. **Reclamation safety:** retired storage is reclaimed only after a formally defined RCU/QSBR grace period.
5. **Descriptor ABI:** the 88-byte layout is fixed by versioned offsets, alignment, atomicity, and lifetime rules; size alone carries no guarantee.
6. **Portability:** each backend is conformant only for the operations and memory scopes covered by its conformance suite.
7. **Observability:** numerical residuals, version mismatches, synchronization failures, and unsupported configurations are surfaced rather than silently repaired.

The searched material establishes only the general Cayley-retraction formulation, its computational tradeoffs, and standard Stiefel retraction properties.[2][3] It does not substantiate the named V1350 kernels or the eight Tribunal models’ purported findings, so a stronger “definitive SOTA” verdict would be fabricated rather than an evidence-based arbitration.