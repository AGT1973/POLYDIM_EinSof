# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 141

The requested **definitive arbitration cannot be performed from the available evidence**. No transcripts, benchmark data, formal specifications, or outputs from the eight named Tribunal models were provided, and the available search results do not identify a public “POLYDIM V1350,” its six kernels, or the “PMTP 88-byte Descriptor.” The only relevant public material concerns general Cayley/Stiefel optimization, not this architecture.[11][13]

What can be stated rigorously is the following.

### 1. Cayley/Stiefel retraction under extreme steps

A Cayley update has the form

\[
X_{+}=\left(I-\frac{\alpha}{2}A\right)^{-1}
       \left(I+\frac{\alpha}{2}A\right)X,
\qquad A^{T}=-A.
\]

In exact arithmetic, the Cayley factor is orthogonal whenever the inverse exists, so it preserves the Stiefel constraint \(X^{T}X=I\). The cited literature supports Cayley transforms as valid Stiefel retractions and describes iterative approximations for efficiency.[11][13]

That does **not** establish stability for \(|\alpha|\ge 10^{10}\). For such steps:

- finite-precision cancellation can dominate;
- forming \(I\pm \alpha A/2\) may overflow or lose relative accuracy;
- iterative truncated Cayley solves may diverge or stagnate;
- conditioning depends on the spectrum of \(A\), not merely on the fact that \(A\) is skew-symmetric;
- a mathematically orthogonal exact transform does not imply numerically orthogonal output.

A defensible SOTA claim is therefore:

> **Cayley retraction offers exact manifold preservation in exact arithmetic, but no unconditional finite-precision stability guarantee exists for arbitrary extreme steps.**

Householder and polar QR methods likewise require a specified implementation and error model. Householder QR is generally backward stable for factorization, while the polar factor can provide a high-quality nearest-orthonormal projection, but neither establishes a universal guarantee at \(|\text{step}|\ge10^{10}\) without scaling, overflow controls, and residual tests.

The strongest architectural guarantee would require:

\[
\|X_{+}^{T}X_{+}-I\| \le \tau_{\mathrm{orth}},
\]

with explicit \(\tau_{\mathrm{orth}}\), norm choice, floating-point format, matrix-size bounds, conditioning assumptions, and behavior on failure. Without those parameters, “superior stability” is not a mathematically meaningful conclusion.

### 2. PMTP descriptor barriers and RCU/QSBR isolation

Acquire/release operations can order accesses in a language memory model, but **Acquire/Release alone does not universally guarantee RCU or QSBR snapshot isolation**.

A valid snapshot protocol must specify at least:

- atomic publication of the descriptor pointer or generation;
- release publication by the writer;
- acquire observation by readers;
- reader registration and quiescent-state reporting;
- grace-period completion;
- reclamation only after every preexisting reader has passed a quiescent state;
- protection against ABA, torn descriptor fields, premature reuse, and wraparound of generations.

For a descriptor containing multiple fields, atomic ordering of one pointer does not automatically make every field independently atomic or immune to concurrent mutation. If the 88-byte object is mutable in place, readers need either immutable generations, a seqlock-style validation protocol, or an equivalent formal mechanism.

The defensible guarantee is:

> **Acquire/Release can establish publication visibility; RCU/QSBR isolation additionally requires a complete grace-period and reclamation protocol.**

Thus any Tribunal conclusion claiming that “Acquire/Release semantics alone guarantee snapshot isolation” should be rejected unless it includes the complete protocol and a proof under the target memory model.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single common memory or execution model shared identically by these ecosystems. Conformance must be defined as a contract, not inferred from source-level similarity.

Required proof and test obligations include:

- identical descriptor layout, alignment, padding, and endianness;
- explicit integer-width and floating-point semantics;
- defined aliasing and lifetime rules;
- backend-specific synchronization and visibility operations;
- race-free host/device publication;
- deterministic handling of NaNs, infinities, overflow, and denormals;
- numerical residual checks for orthogonality and descriptor validity;
- differential tests across all supported compilers and devices.

C++20 and Rust provide language-level atomic models, but CUDA device memory ordering, XLA compilation, and Triton lowering introduce backend-specific behavior. A portable guarantee must therefore be stated conditionally:

> **The implementation is conformant only where each backend’s lowered operations are proven to refine the abstract protocol.**

Source compatibility or matching numerical outputs on ordinary test cases is insufficient to establish multi-silicon conformance.

### Arbitration result

On the evidence available, the only supportable arbitration is:

| Claim | Status |
|---|---|
| Cayley is exactly orthogonality-preserving in exact arithmetic | Supported |
| Cayley is unconditionally stable for steps \(\ge 10^{10}\) | Unsupported |
| Acquire/Release alone guarantees RCU/QSBR isolation | Unsupported |
| An 88-byte descriptor has portable barrier semantics without a published layout/protocol | Unverifiable |
| One implementation is conformant across CUDA, XLA, Triton, C++20, and Rust by construction | Unsupported |
| A definitive ranking of the eight Tribunal models | Impossible without their actual reports and evidence |

Accordingly, no mathematically valid “exact architectural guarantees” can be formulated for the six V1350 kernels from the supplied information. The appropriate SOTA specification would be **conditional guarantees with explicit numerical tolerances, memory-model assumptions, reclamation invariants, backend mappings, and conformance tests**, rather than an unconditional claim of superiority.