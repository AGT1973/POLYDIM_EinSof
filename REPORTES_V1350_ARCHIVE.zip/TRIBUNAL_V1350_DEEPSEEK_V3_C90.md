# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 90)

# POLYDIM V1350 — High Tribunal Audit, Cycle 90

**Presiding note.** The Tribunal treats each target as a *claim of correctness* under adversarial inputs. We do not accept "it compiles" as evidence. We require: (i) bit-level descriptor conformance, (ii) asymptotic conditioning under `step → 0` and `step → ∞`, (iii) FFI/ABI hardening, (iv) vendor-neutrality under Rule 27, and (v) absence of 1-D token leakage under Rule 22.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte PMTP descriptor — bit-exact layout

The struct format `<4sHHQQQQQBB6x4Q` decodes as:

| Offset | Field | Type | Bytes |
|---|---|---|---|
| 0 | magic | `4s` | 4 |
| 4 | version | `H` | 2 |
| 6 | flags | `H` | 2 |
| 8 | n_rows | `Q` | 8 |
| 16 | n_cols | `Q` | 8 |
| 24 | stride | `Q` | 8 |
| 32 | dtype_code | `Q` | 8 |
| 40 | device_id | `Q` | 8 |
| 48 | reserved_a | `B` | 1 |
| 49 | reserved_b | `B` | 1 |
| 50 | pad | `6x` | 6 |
| 56 | aux[4] | `4Q` | 32 |
| **Total** | | | **88** |

**Tribunal finding (T1, T3):** The layout is *self-consistent* only if the C++/Rust mirrors use `#pragma pack(1)` / `#[repr(C, packed)]` **and** the compiler does not reorder. Rust's `#[repr(C, packed)]` on a struct containing `u64` fields is **UB-adjacent** for reference-taking (`&self.aux[i]` on a packed field is a misaligned reference). **Required fix:** access via `read_unaligned` / `ptr::addr_of!` + `read_unaligned`, or split into `#[repr(C)]` with explicit `[u8; 88]` serialization. This is a **hardening blocker**, not a style nit.

**Rule 22 compliance:** The descriptor is fixed-width and contains no variable-length token stream. ✅ *provided* the `magic` field is validated before any field is dereferenced (otherwise a 1-D byte stream can be smuggled through `aux[]`). Recommend: `magic == b"PMTP"` and `version ∈ {0x1350}` gate before any `aux` read.

### 0.2 Rule 27 — Silicon Contract

| Target | Vendor lock? | Verdict |
|---|---|---|
| T1 orchestrator | None (probe-only) | ✅ |
| T2 C++ AVX-512 | **Conditional lock** — AVX-512 is Intel/AMD-only; ARM SVE path absent | ⚠️ |
| T3 Rust SIMD | Portable if `std::simd` or `wide`; if `core::arch::x86_64::*` → lock | ⚠️ |
| T4 CUDA | **Hard lock** to NVIDIA (cuSOLVER `DnDsyevd`, CUDA Graphs) | ❌ |
| T5 XLA | Dual-vendor (TPU + Trainium) — but *both* are proprietary | ⚠️ |
| T6 Triton | ROCm + CUDA — dual-vendor, still no CPU fallback | ⚠️ |

**Finding:** Rule 27 as stated ("no component imposes vendor-lock") is **violated by T4** in the strict reading. Mitigation: T4 must expose a `PmtpBackend::CpuFallback` trait object so the orchestrator can degrade. T2/T3 must ship an SVE/NEON path or a scalar reference kernel behind the same ABI.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator

- **Degeneracy at `step → ∞`:** The orchestrator does not itself do arithmetic on `step`; it dispatches. **However**, if `step` is serialized into the 88-byte descriptor's `aux[]` as a raw `f64` and the allocator uses it as a slab-size hint, `step ≥ 1e10` can overflow `n_rows * n_cols * sizeof(dtype)` in `Q` arithmetic. **Proof of hazard:** `Q` max = 2⁶⁴−1; a 2K×2K FP64 slab at K=2³⁰ overflows. **Fix:** saturating mul + explicit `checked_mul` returning `Err(PmtpError::SlabOverflow)`.
- **Degeneracy at `step → 0`:** If `step` is used as a *timeout* or *epsilon* in the probe, subnormal `step` (|step| < 2⁻¹⁰²²) collapses to 0 in FP64 and the probe degenerates to a busy-wait. **Fix:** clamp `step` to `[2⁻¹⁰⁰⁰, 2⁶⁰]` at the orchestrator boundary and log the clamp.

### 1.2 12/12 physical conformance checks

The Tribunal demands the *list*. Without it, "12/12" is unfalsifiable. **Required disclosure:** each check must be a pure predicate `descriptor → bool` with a named failure mode. Recommended canonical set:

1. `magic == b"PMTP"`
2. `version == 0x1350`
3. `len(serialized) == 88`
4. `n_rows > 0 ∧ n_cols > 0`
5. `stride ≥ n_cols * dtype_size`
6. `dtype_code ∈ {FP32, FP64, BF16, FP16}`
7. `device_id < probe.device_count`
8. `aux[0]` (step) finite
9. `aux[1]` (scale) > 0
10. `aux[2]` (K) even (Stiefel requires 2K)
11. `aux[3]` reserved == 0
12. `checksum(descriptor[0:80]) == aux[3]` (or similar)

**Rule 22:** ✅ if and only if check #11 enforces `aux[3] == 0` — otherwise `aux[3]` is a 1-D covert channel.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant:
```
s = 0; c = 0
for x, y:
    t = s + x*y
    if |s| ≥ |x*y|: c += (s - t) + x*y
    else:           c += (x*y - t) + s
    s = t
return s + c
```

**Asymptotic condition number.** For a dot product of length `n` with inputs bounded by `M`, the *forward* error of naive summation is `O(n·u·M)`; Neumaier achieves `O(u·M + n·u²·M)` — i.e., **the `n` factor is removed from the leading term**. Formally, if `γ_n = nu/(1−nu)`, naive gives `|err| ≤ γ_n Σ|xᵢyᵢ|`; Neumaier gives `|err| ≤ (u + γ_n²) Σ|xᵢyᵢ|`. **Proof sketch:** the compensation `c` accumulates the exact residual of each `t = fl(s + x*y)` via Sterbenz-style exact subtraction when `|s| ≥ |x*y|`; the two-branch structure guarantees the residual is representable. ∎

**Degeneracy at `step → ∞`:** If `step` multiplies the dot product (e.g., `step · ⟨a,b⟩`), then `step ≥ 1e10` with `⟨a,b⟩ ~ 1e-300` (subnormal) yields `step·⟨a,b⟩ ~ 1e-290` — still subnormal, and Neumaier's compensation term `c` may itself underflow. **Fix:** scale *before* the dot product: compute `⟨a/scale, b⟩ · (step·scale)` with `scale = max(|a|,|b|)`. This is the **Woodbury-style global scaling** already used in T4 — propagate it to T2.

**Degeneracy at `step → 0`:** Subnormal `step` (e.g., `5e-324`) times a normal dot product is fine *unless* the compiler flushes-to-zero (FTZ/DAZ). **Required:** compile with `-fno-fast-math -ffp-contract=off` and explicitly test `std::fpclassify(step) == FP_SUBNORMAL` in the audit path. The claimed subnormal audits at `-12, -14` (presumably `2⁻¹²`, `2⁻¹⁴` exponents) are **insufficient** — the IEEE-754 subnormal boundary is `2⁻¹⁰²²` for FP64. **Tribunal demands:** audit at `2⁻¹⁰²²`, `2⁻¹⁰²³`, and `2⁻¹⁰⁷⁴` (smallest subnormal).

### 2.2 Zero-copy PMTP validation

Zero-copy requires the descriptor's `stride` to match the actual memory layout. **Hazard:** if `stride > n_cols * dtype_size` (padded rows), AVX-512 loads of 64 bytes may cross row boundaries. **Fix:** require `stride % 64 == 0` for AVX-512 paths, else fall back to masked loads. **FFI hardening:** the C++ entry point must be `extern "C"` with `noexcept`, take `const PmtpDescriptor* __restrict`, and validate `magic`/`version`/`len` before any pointer arithmetic.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` FFI safety barrier

**Finding:** `panic = unwind` across an `extern "C"` boundary is **UB** in Rust 2021 unless the function is `extern "C-unwind"`. The claim of a "safety barrier" is only valid if every FFI entry point is wrapped in `std::panic::catch_unwind` and returns a sentinel error code. **Required pattern:**

```rust
#[no_mangle]
pub extern "C" fn pmtp_dot(
    desc: *const PmtpTensorDescriptor,
    out: *mut f64,
) -> i32 {
    let r = std::panic::catch_unwind(|| unsafe { inner(desc, out) });
    match r { Ok(Ok(())) => 0, Ok(Err(_)) => -1, Err