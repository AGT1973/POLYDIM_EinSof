# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 98)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 98 · Six-Component Adversarial Review

**Preliminary note on evidentiary basis.** The audit is conducted against the *specification as stated in the brief*. I do not have the source files in front of me; where the brief is silent or self-contradictory I flag it as a **material defect of the specification** rather than of the code. Every claim below is therefore either (a) a proof from the stated invariants, (b) a counterexample construction, or (c) an explicit "cannot be adjudicated without artifact X."

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Format string: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Cumulative |
|---|---|---|---|
| magic | 4s | 4 | 4 |
| two H | HH | 4 | 8 |
| five Q | QQQQQ | 40 | 48 |
| two B | BB | 2 | 50 |
| pad | 6x | 6 | 56 |
| four Q | QQQQ | 32 | **88** |

**Verdict: byte-count is arithmetically correct (88).** Alignment: `<` forces little-endian, no padding, so `struct.calcsize` = 88 on every platform. Good.

**Defect D-1 (specification-level).** The brief says "88-byte binary descriptor" but the field semantics are not enumerated. Without a canonical field table (magic, version, dtype, rank, shape[4], strides[4], flags, …) the "12/12 physical conformance checks" in Target 1 are **unfalsifiable**. A conformance suite that cannot be falsified is not a conformance suite. **Demand:** publish the field table and the 12 predicates as a machine-checkable schema (e.g., a JSON-Schema + a `ctypes.Structure` with `_pack_ = 1`).

**Defect D-2.** `4sHHQQQQQBB6x4Q` has **no explicit endianness tag in the magic** and no version field distinguishable from the two `H`s unless the spec says so. Cross-ISA (x86-64 ↔ aarch64 ↔ TPU host) is fine for `<`, but a Rust `#[repr(C, packed)]` struct on a big-endian target would silently mis-parse. **Recommendation:** assert `sys.byteorder == 'little'` at import, or add a `b'PD'` magic + endian byte.

### 0.2 Rule 22 — "Zero 1D tokens in inter-agent communication"

Interpretation: inter-agent messages must be **structured, ≥2-D, and exactly 88 bytes** (no scalar/1-D leakage). Audit:

- **Target 1 (Python orchestrator):** `struct.pack('<4sHHQQQQQBB6x4Q', …)` — compliant *if* every IPC write goes through this packer. **Risk:** Python's `pickle`, `json`, or `msgpack` fallbacks would violate Rule 22. **Demand:** a `sys.settrace`-level or `audit`-hook guard that raises on any `socket.send`/`write` whose payload ≠ 88 bytes.
- **Target 2 (C++):** zero-copy PMTP validation is compliant only if the descriptor is `static_assert(sizeof(...) == 88)`. **Demand:** `static_assert` + `alignas(8)`.
- **Target 3 (Rust):** `#[repr(C, packed)]` + `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` — **required**, else UB on FFI.
- **Target 4 (CUDA):** CUDA Graphs capture host-side launches; if any kernel argument is passed by value as a 1-D scalar *outside* the 88-byte descriptor, Rule 22 is violated. **Demand:** all kernel params must be `const PmtpTensorDescriptor*`.
- **Target 5 (XLA):** `@jax.jit` with `donate_argnums` — HLO is 2-D+ by construction, but **host↔TPU transfer of a scalar step size** is a 1-D token. **Demand:** step must be a rank-0 *inside* the descriptor, not a separate argument.
- **Target 6 (Triton):** Triton kernel args are scalars by default. **This is the highest Rule-22 risk in the stack.** Demand a `tl.constexpr`-free path where all runtime scalars ride in the descriptor.

**Verdict on Rule 22:** *Not verifiable* from the brief. Targets 4, 5, 6 have plausible violations.

### 0.3 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor lock risk | Assessment |
|---|---|---|
| 1 Python | none | ✅ |
| 2 C++ AVX-512 | Intel/AMD only | ⚠️ **AVX-512 is not on Apple Silicon, not on ARM server (until SVE2), not on older Xeons.** Needs a scalar/AVX2 fallback path or Rule 27 is violated. |
| 3 Rust SIMD | `std::simd` is portable; if using `core::arch::x86_64::*` intrinsics → locked | ⚠️ |
| 4 CUDA | **Hard NVIDIA lock** unless HIP/ROCm path exists | ❌ **Rule 27 violation as stated.** |
| 5 XLA | Google TPU *and* AWS Trainium — two vendors, but both require vendor SDKs | ⚠️ partial |
| 6 Triton | AMD ROCm + NVIDIA — **this is the only genuinely multi-vendor target** | ✅ |

**Finding F-1 (major).** Target 4 as described is **vendor-locked to NVIDIA** (cuSOLVER `DnDsyevd`, CUDA Graphs). Rule 27 is violated unless a HIP/rocSOLVER shim is present. The brief does not mention one.

**Finding F-2.** Target 2's AVX-512 requirement violates Rule 27 on any non-x86 host. A `#if defined(__AVX512F__)` guard with a Neumaier-compensated scalar fallback is mandatory.

---

## 1. Target 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy

The orchestrator itself does no arithmetic, but it *dispatches* on `step`. The critical question: **what does the orchestrator do when `|step| ≥ 10^10` or `step` is subnormal?**

- If it forwards `step` as a Python `float` into the 88-byte descriptor as a `Q` (uint64), then **negative steps and subnormals are silently reinterpreted**. `struct.pack('<Q', -1.0)` raises; `struct.pack('<Q', 5e-324)` raises. So the descriptor's `Q` fields **cannot carry a float step**. This is a **specification contradiction**: the brief says the descriptor is 88 bytes with five `Q` + four `Q` = nine `Q` fields, but a step size is a float.
- **Resolution required:** either (a) the step is stored as `double` bit-pattern in a `Q` (reinterpret via `struct.pack('<d', step)` then unpack as `Q`), or (b) the descriptor is not the step carrier and Rule 22 is violated.

**Degeneracy at step → ∞:** if the orchestrator computes `scale = max(|step|, 1)` and passes `step/scale`, then for `step = 1e300`, `step/scale = 1.0` — fine. But if it computes `step * step` anywhere (e.g., for a trust-region radius), `1e300^2 = inf`. **Demand:** all step-dependent quantities must be computed in log-space or with explicit `frexp`/`ldexp` scaling.

**Degeneracy at step → 0:** subnormal `step = 5e-324` (min subnormal). If the orchestrator does `1.0/step`, → `inf`. If it does `step/scale` with `scale = max(|step|,1) = 1`, → `5e-324` (subnormal, preserved). **The `max(|step|,1)` guard is the correct pattern** and should be mandated.

### 1.2 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe:** must not *require* any vendor. If `HardwareProbe` raises when no AVX-512 is found, Rule 27 is violated. **Demand:** probe returns a capability bitmask; orchestrator selects the highest available backend; a pure-Python fallback must exist.
- **Slab allocator:** 88-byte objects are not power-of-two aligned. If the slab uses 64-byte cache-line alignment, each 88-byte descriptor straddles two lines → **false sharing** in multi-threaded dispatch. **Recommendation:** pad to 128 bytes internally, keep 88 on the wire.

### 1.3 12/12 conformance checks

Unfalsifiable without the predicate list. **Demand:** publish as `conformance_v1350.json` with 12 named predicates and a `pytest` harness.

---

## 2. Target 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — proof sketch

Neumaier's variant of Kahan:

```
s = 0; c = 0
for i: t = s + x[i]*y[i]
       if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
       else:                  c += (x[i]*y[i] - t) + s
       s = t
return s + c
```

**Error bound (Neumaier 1974):** for `n` terms, `|result - exact| ≤ (2u + O(nu²)) · Σ|x_i y_i|`, where `u = 2^-53`. This is **not** the same as Kahan's bound; Neumaier is *unconditionally* second-order accurate, whereas Kahan requires `|s| ≥ |term|` at each step.

**Degeneracy at step → ∞:** if `x[i]` or `y[i]` overflow to `inf`, then `s + c` = `inf - inf` = `NaN`. **Demand:** pre-scale inputs by `2^-k` where `k = max exponent`, accumulate, then `ldexp` back. This is the **only** correct handling of `|step| ≥ 10^10` in a dot product.

**Degeneracy at step → 0 (subnormals):** AVX-512 with `FTZ`/`DAZ` set (default on many builds!) will **flush subnormals to zero**, destroying the compensation. The brief mentions "subnormal audits (-12, -14)" — these are presumably exponent thresholds. **Demand:** `_MM_SET_FLUSH_ZERO_MODE