# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 80

The six-model findings cannot be independently compared as submitted because the actual Claude, Qwen, Kimi, Gemini, DeepSeek, and Perplexity reports—and the six kernel specifications—are not included. No publicly verifiable record of “POLYDIM V1350,” “PMTP,” or the claimed Tribunal cycle was found. The defensible SOTA result is therefore a **conditional architectural synthesis**, not a certification of an existing implementation.

## 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

### Arbitration

A Cayley retraction is not automatically more stable than Householder QR or polar retraction for an extreme step. The correct comparison depends on:

- the tangent-vector scaling;
- whether the Cayley system is solved stably;
- conditioning of the shifted linear system;
- overflow/underflow handling;
- whether the result is explicitly reorthogonalized;
- the required error metric: orthogonality, distance to the exact manifold projection, or backward error.

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), a typical Cayley update has the form

\[
X_{+}
=
\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)X,
\]

where \(A^\top=-A\). In exact arithmetic, the Cayley transform is orthogonal because

\[
\left[\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)\right]^\top
\left[\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)\right]
=I.
\]

That identity does **not** imply numerical stability at \(\tau\ge 10^{10}\). A mathematically sound implementation must avoid explicit matrix inversion, use a backward-stable factorization or iterative solve, scale the problem, and verify the residual.

Householder QR is generally the strongest baseline for robust orthogonalization: it is backward stable and does not require forming \(Y^\top Y\). Polar retraction is attractive because it gives the closest orthonormal factor in the Frobenius norm, but the usual formula

\[
\operatorname{polar}(Y)=Y(Y^\top Y)^{-1/2}
\]

can be numerically inferior if \(Y^\top Y\) is explicitly formed, since its condition number is squared. Stable SVD-, eigensolver-, or Newton–Schulz-based implementations avoid some of this risk, but they have different convergence and hardware requirements. Published Stiefel-retraction analyses report favorable conditioning for canonical Cayley and polar-light constructions, but those local conditioning results do not constitute a guarantee for unscaled steps of magnitude \(10^{10}\).[12][13]

### Definitive kernel policy

The superior architecture is **not “Cayley everywhere.”** It is a guarded hybrid:

1. Compute the scaled update with
   \[
   \alpha=\frac{\|\Delta\|}{s_{\max}},
   \]
   where \(s_{\max}\) is chosen to keep the solve and intermediate products within a safe floating-point range.

2. Apply the Cayley transform through a stable solve, never through an explicit inverse.

3. Measure
   \[
   r_{\mathrm{orth}}=\|X_+^\top X_+-I\| ,
   \qquad
   r_{\mathrm{solve}}=\|MZ-B\|.
   \]

4. If either residual exceeds the configured tolerance, fall back to Householder QR or a stable polar/SVD path.

5. Optionally perform one final Householder reorthogonalization when the contract requires a hard orthogonality bound.

The strongest portable guarantee is therefore:

\[
\|Q^\top Q-I\|
\le
c\,u\,\kappa_{\mathrm{alg}}+\varepsilon_{\mathrm{fallback}},
\]

provided the factorization/solve succeeds without overflow and the implementation’s residual checks pass. Here \(u\) is unit roundoff and \(c\) is implementation- and dimension-dependent. A blanket guarantee for arbitrary \(|\mathrm{step}|\ge10^{10}\), independent of scaling, precision, matrix dimensions, and input conditioning, is mathematically unjustified.

**Arbitration:** Householder QR is the default stability oracle; Cayley is permitted as the fast path only with scaling, residual certification, and fallback. Polar is appropriate when nearest-point projection is the objective, but not when a low-cost, universally robust path is required.

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

An 88-byte layout by itself provides no memory-safety or snapshot-isolation guarantee. The guarantee comes from the protocol governing its fields and the lifetime of the objects referenced by those fields.

C++ release/acquire ordering establishes synchronization only when an acquire operation reads a value released by the corresponding atomic release operation, or an appropriate later value in the release sequence. Writes sequenced before the release become visible to operations sequenced after the acquire.[1][2] Acquire and release therefore constrain ordering, but they do not automatically provide reclamation, multi-field atomicity, or a globally consistent snapshot.

### Required descriptor protocol

A valid descriptor should separate:

- immutable or versioned payload metadata;
- a published pointer or handle;
- a generation/version field;
- reader-registration or epoch state;
- ownership and reclamation state;
- integrity information, such as a checksum or tag, where corruption detection is required.

The publication sequence must be conceptually:

```text
initialize immutable payload
initialize descriptor metadata
release-store published pointer/version
```

The reader must perform:

```text
acquire-load published pointer/version
enter RCU/QSBR read-side critical section
read the immutable snapshot
validate version or sequence
exit read-side critical section
```

For a seqlock-style descriptor, the reader must reject an observation if the version is odd or changes during the read:

\[
v_{\text{before}}=v_{\text{after}}
\quad\land\quad
v_{\text{before}}\bmod 2=0.
\]

For RCU, the writer must not reclaim the old object until every reader that could have observed it has passed through a grace period. RCU verification work specifically identifies release/acquire publication as necessary for safe initialization visibility and grace-period synchronization as necessary before deallocation.[14]

### Exact guarantee

Under the following assumptions:

- publication fields are atomic;
- all readers acquire the published state;
- the writer releases the fully initialized replacement;
- readers register before dereferencing;
- reclamation occurs only after a valid RCU grace period or QSBR quiescent-state proof;
- no reader uses non-atomic mutable fields concurrently with a writer;
- descriptor copies preserve alignment, representation, and pointer provenance;

the architecture can guarantee:

1. **Initialization visibility:** readers acquiring the published state observe the preceding initialization.
2. **No premature reclamation:** a retired object is not freed while a registered reader can still hold a reference.
3. **Snapshot consistency:** readers observe one validated generation, rather than an unvalidated mixture of generations.
4. **Lock-free read-side operation**, subject to the progress properties of the underlying implementation.

It cannot guarantee, from acquire/release alone:

- atomic publication of an arbitrary 88-byte descriptor as one indivisible operation;
- wait-free readers;
- immunity to ABA;
- reclamation without a grace-period protocol;
- consistency of multiple separately published atomics;
- device-wide ordering across CUDA, XLA, or Triton execution domains.

The descriptor should therefore publish a compact atomic handle—such as a pointer plus generation, or an index plus epoch—and keep the remaining 88-byte record immutable after publication. If the entire 88-byte object must be atomically replaced, the design needs a platform-supported atomic width or an indirection/version protocol; ordinary C++ acquire/release operations do not make an 88-byte struct atomic.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared identically by these five environments. “Conformance” must be defined as **semantic conformance to an abstract contract**, not as identical instruction sequences or identical synchronization primitives.

### Portable abstract contract

The kernels should specify:

- representation and alignment of every descriptor field;
- endianness and width of integer and floating-point fields;
- legal NaN, infinity, and signed-zero behavior;
- ownership and lifetime rules;
- publication and reclamation protocol;
- numerical tolerances;
- ordering scope: thread, block, device, host, or distributed device;
- permitted nondeterminism;
- failure behavior on overflow, singular solve, or failed validation.

### Platform mapping

| Environment | Required implementation interpretation |
|---|---|
| **C++20** | Use `std::atomic` or atomics over compact handles; acquire/release synchronizes only through the same atomic object or valid release sequence.[1][2] |
| **Rust** | Use `Atomic*` orderings and `UnsafeCell`/ownership discipline; `Acquire`/`Release` do not make non-atomic payload mutation safe, and unsafe reclamation still requires a proven epoch/RCU scheme. |
| **CUDA** | Distinguish block-, device-, and system-scope atomics and fences; a device kernel’s ordering does not automatically establish host or peer-device visibility. |
| **Triton** | Treat supported atomics and barriers as backend-dependent; do not assume that a source-level operation provides C++-style global acquire/release semantics across all targets without an explicit backend contract. |
| **XLA** | Treat operations as graph/compiler IR semantics; ordinary tensor dataflow is not a general-purpose shared-memory RCU mechanism. Stateful publication requires explicit supported synchronization or an external runtime protocol. |

### Numerical conformance

For the Stiefel kernel, exact bitwise equality across all five targets is usually unrealistic because reduction order, fused operations, tensor-core use, and compiler transformations may differ. The appropriate contract is:

\[
\|Q^\top Q-I\| \le \tau_{\mathrm{orth}},
\]

\[
\frac{\|Q-Q_{\mathrm{ref}}\|}{\max(1,\|Q_{\mathrm{ref}}\|)}
\le \tau_{\mathrm{rel}},
\]

and, for the retraction,

\[
\|Q-\mathcal{R}_X(\Delta)\|
\le \tau_{\mathrm{retr}},
\]

with tolerances specified by precision, dimension, and backend.

For the descriptor kernel, conformance should be tested with:

- publication-before-read litmus tests;
- delayed-reader and delayed-writer tests;
- reclamation-after-grace-period tests;
- ABA and version-wrap tests;
- misalignment and endian tests;
- stress under maximum reader count;
- compiler and sanitizer validation on C++20 and Rust;
- CUDA race-checking and fence-scope tests;
- backend-specific XLA and Triton execution tests.

## Definitive arbitration

The mathematically and architecturally defensible SOTA synthesis is:

1. **Retraction:** use scaled Cayley as an optimized fast path, but certify it with solve and orthogonality residuals; use Householder QR as the robust fallback and reference oracle. Do not claim unconditional stability for \(|\mathrm{step}|\ge10^{10}\).

2. **Descriptor publication:** make the published handle atomic and acquire/release synchronized; keep the referenced snapshot immutable; use RCU/QSBR grace periods for reclamation; add version validation to prevent torn or mixed snapshots.

3. **Cross-silicon portability:** define one abstract memory-and-numerics contract, then provide backend-specific mappings. Do not infer CUDA, Triton, XLA, C++20, and Rust equivalence from similarly named barriers or atomics.

4. **Guarantee boundary:** the exact guarantees are conditional on alignment, atomicity of the publication handle, successful synchronization, valid lifetime tracking, bounded numerical residuals, and backend-supported fence scope. Any Tribunal conclusion claiming unconditional extreme-step stability, atomicity of an 88-byte record, or universal cross-platform acquire/release equivalence exceeds what the underlying mathematics and memory models establish.