# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 83

No verifiable specifications or outputs from the six named tribunal models were provided, and the public evidence available here does not establish that “POLYDIM V1350,” “PMTP,” or the six kernels are standardized artifacts. Therefore, a definitive arbitration of their model-specific findings is not possible. The strongest defensible synthesis is a **conditional architectural specification**, not a claim that any unprovided implementation satisfies it.

## 1. Extreme-step Stiefel retraction

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), \(X^\top X=I\), and tangent direction \(\Delta\), an update must produce

\[
Y^\top Y=I
\]

within the declared floating-point tolerance.

### Arbitration

| Method | Behavior for \(\lVert\text{step}\rVert\ge 10^{10}\) | Architectural judgment |
|---|---|---|
| Unscaled Cayley iteration | Not guaranteed; its usual contraction condition depends on a sufficiently small scaling parameter, such as \(\alpha < 2/\lVert W\rVert\).[7] | Reject as an unconditional extreme-step guarantee |
| Closed-form Cayley solve | Orthogonality-preserving in exact arithmetic, but potentially ill-conditioned near the transform’s singular region; requires stable factorization and scaling | Accept only with scaling, conditioning checks, and fallback |
| Householder QR | Generally robust when implemented with norm-stable Householder reflectors, but the raw matrix may overflow or lose meaningful direction if the step is formed without scaling | Strong baseline, not a proof against overflow |
| Polar decomposition | Provides the closest orthogonal factor in the Frobenius norm and is geometrically attractive, but requires a stable SVD or Newton–Schulz-type procedure | Strong reference implementation, with numerical safeguards |

The Cayley map is not automatically superior merely because it preserves orthogonality algebraically. Published work presents Cayley retractions as efficient alternatives to QR or polar methods, but also uses explicit convergence restrictions for iterative evaluation.[7] Available conditioning results report favorable bounds for canonical Cayley and polar-light constructions, but those bounds do not constitute an implementation guarantee at a step magnitude of \(10^{10}\).[10]

### Definitive guarantee

The V1350 kernel should implement **scale–solve–unscale**, not direct extreme-step evaluation:

\[
s=\max\!\left(1,\frac{\lVert W\rVert}{\tau}\right),\qquad
\widetilde W=\frac{W}{s},
\]

where \(\tau\) is a bounded numerical scale selected for the target precision. It must then:

- compute the Cayley update using a backward-stable QR or LU-with-pivoting solve;
- verify the residual
  \[
  \lVert Y^\top Y-I\rVert \le c\,u\,\kappa_{\mathrm{eff}},
  \]
  where \(u\) is unit roundoff;
- detect nonfinite values, rank loss, excessive condition estimates, and failed residual checks;
- fall back to Householder QR or a polar factorization;
- never claim “exact orthogonality” in finite precision.

The mathematically superior policy is therefore **adaptive Cayley with certified fallback**, rather than unconditional Cayley, unconditional QR, or unconditional polar evaluation. Householder QR is the preferred emergency fallback for portability and predictable workspace behavior; polar decomposition is the preferred reference oracle for validation.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering synchronizes accesses only through the **same atomic synchronization object**.[2] A release publication followed by an acquire load makes prior writes visible to operations following the acquire.[1][3] This is also the relationship specified by the C++ and Rust memory models.[1][2]

### Required publication protocol

A descriptor publication must follow this ordering:

1. Writer allocates or reuses an immutable payload.
2. Writer initializes the complete payload and descriptor fields.
3. Writer publishes the descriptor pointer, generation, or sequence through a release operation.
4. Reader enters its RCU/QSBR read-side critical section.
5. Reader performs an acquire load of the publication atomic.
6. Reader validates the generation or sequence and reads the immutable snapshot.
7. Reader exits the critical section.
8. Reclamation occurs only after every relevant reader has passed a quiescent state or otherwise acknowledged a later epoch.

The 88-byte size is not itself a synchronization guarantee. Correctness depends on:

- atomic publication of the ownership/version field;
- immutable contents after publication;
- no reader dereference before the acquire operation;
- correct reader registration and quiescent-state reporting;
- delayed reclamation;
- avoidance of torn, misaligned, or concurrently mutated fields.

Release/acquire does **not** by itself provide reclamation safety. A reader can acquire a perfectly published pointer to memory that has already been freed unless the RCU/QSBR grace-period protocol prevents reclamation. It also does not automatically make a multiword descriptor update atomic. If the descriptor’s 88 bytes must change as one indivisible snapshot, publish an immutable descriptor by pointer, use a sufficiently wide atomic version/pointer mechanism, or use a seqlock-style protocol with explicit retry validation.

### Definitive guarantee

The strongest valid guarantee is:

> Every reader that successfully acquires publication epoch \(e\), remains inside the read-side critical section, and observes a valid descriptor version reads a fully initialized immutable snapshot from epoch \(e\) or an explicitly newer epoch; no such snapshot is reclaimed before that reader reports quiescence.

This guarantee requires a proof of the entire publication and reclamation protocol. “Acquire/release descriptor” alone is insufficient.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single common execution or memory model across these environments. C++20 and Rust have closely corresponding atomic ordering concepts.[1][2] CUDA, XLA, and Triton introduce separate compiler, device, tensor, and synchronization semantics. Consequently, source-level portability cannot be treated as proof of semantic portability.

### Conformance layers

A valid multi-silicon claim must distinguish:

- **Numerical conformance:** orthogonality residuals, solve residuals, NaN/Inf behavior, and tolerance envelopes.
- **Memory-model conformance:** publication, visibility, lifetime, and reclamation behavior.
- **Shape/layout conformance:** descriptor alignment, byte layout, endian assumptions, strides, and padding.
- **Compiler conformance:** absence of undefined behavior, illegal aliasing, invalid atomics, and unsupported synchronization lowering.
- **Device conformance:** behavior across GPU architectures, CPU backends, and accelerator-specific lowering.
- **Determinism conformance:** whether equal inputs must produce bitwise-identical or only numerically equivalent outputs.

A kernel conforming in CUDA does not automatically conform in XLA or Triton. In particular, host-language C++20/Rust atomics cannot simply be assumed to map to equivalent device-wide synchronization. RCU/QSBR reclamation is generally a host/runtime responsibility unless the target backend explicitly specifies the required device memory and progress guarantees.

### Required conformance contract

V1350 should define a backend-neutral abstract contract:

\[
\texttt{publish}(p,e),\quad
\texttt{acquire}()\to(p,e),\quad
\texttt{enter}(e),\quad
\texttt{quiesce}(e),\quad
\texttt{reclaim}(e)
\]

and require each backend adapter to prove:

- release-before-publication and acquire-before-dereference;
- no use-after-reclamation;
- aligned and non-torn publication fields;
- identical descriptor interpretation;
- explicit behavior for unsupported atomics or synchronization scopes;
- numerical residuals within a documented tolerance;
- tested fallback behavior.

## Final arbitration

The defensible SOTA synthesis is:

1. **Retraction:** use a scaled Cayley method only as the fast path; certify its residual and condition; fall back to Householder QR, with polar decomposition as the high-accuracy reference path.
2. **Snapshot isolation:** publish immutable descriptors through a release/acquire synchronization object and pair that protocol with a separately proved RCU/QSBR grace period. The 88-byte layout alone provides no guarantee.
3. **Portability:** define semantic contracts first and implement backend-specific adapters. C++20/Rust ordering equivalence supports the host implementation, but it does not establish CUDA/XLA/Triton equivalence.
4. **Guarantee boundary:** the architecture may guarantee bounded numerical error, initialized snapshots, and safe reclamation only after residual checks, alignment checks, backend capability checks, and formal epoch/lifetime invariants pass. It cannot honestly guarantee universal bitwise identity, exact orthogonality, or identical memory behavior across all five execution ecosystems without substantially stronger implementation and verification evidence.