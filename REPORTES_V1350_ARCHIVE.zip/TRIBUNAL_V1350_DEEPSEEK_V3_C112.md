# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 112)

# POLYDIM V1350 — High Tribunal Audit, Cycle 112

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute
**Verdict posture:** Adversarial. Claims of "SOTA" are treated as unproven until each invariant is discharged.

---

## 0. Preliminary: What the Tribunal Can and Cannot Verify

The audit brief describes six artifacts by *specification*, not by source. The Tribunal therefore audits the **stated contracts** and flags every place where the specification is either (a) mathematically under-determined, (b) numerically degenerate at the stated limits, or (c) in tension with Rules 22/27. Where a claim is unverifiable without source, it is marked **[UNVERIFIED — DEMAND ARTIFACT]**.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us count bytes rigorously (native `struct` with `=` prefix assumed; if `<` is used, no padding is inserted, which is what the format string implies):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major | `H` | 2 |
| version_minor | `H` | 2 |
| flags | `Q` | 8 |
| n_rows | `Q` | 8 |
| n_cols | `Q` | 8 |
| stride | `Q` | 8 |
| scale_bits | `Q` | 8 |
| dtype | `B` | 1 |
| layout | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

**Arithmetic check:** 4+2+2+8+8+8+8+8+1+1+6+32 = **88**. ✅

**Tribunal finding (Rule 22 compliance):** The 88-byte PMTP is *structurally* satisfied **iff** the orchestrator never emits a variable-length token in inter-agent channels. The format string alone does not guarantee this. **Demand:** a static assertion `assert struct.calcsize("<4sHHQQQQQBB6x4Q") == 88` **and** a runtime guard that every IPC frame is exactly 88 bytes (reject `len != 88`).

### 1.2 Numerical degeneracy at step → ∞ and step → 0

The descriptor carries `scale_bits` as a raw `Q`. If `scale` is stored as an IEEE-754 bit pattern:

- **step → ∞ (|step| ≥ 10¹⁰):** If any downstream kernel computes `W = (step/scale) · B` (as in Target 4), then `step/scale` can overflow to `+inf` when `scale` is subnormal. **Degeneracy:** `inf · B` → `inf` or `NaN` if any `B_ij = 0`. **Mitigation:** clamp `step` to `[2^-40, 2^40]` at the orchestrator boundary and reject `scale < 2^-1000` (subnormal guard).
- **step → 0:** If `step` is subnormal, `step/scale` underflows to `0`, silently zeroing the Woodbury update. **Mitigation:** enforce `step ≥ 2^-1000` (normal range) or use a compensated representation.

**Asymptotic condition number:** For the Woodbury form `(M/scale) W = (step/scale) B`, the effective condition number is
κ = κ(M) · (1 + ‖step·B‖ / ‖M‖) · (1 + O(‖step·B‖/‖M‖)⁻¹).
As `step → ∞`, κ → ∞ linearly in `step`. As `step → 0`, κ → κ(M) but the *signal* vanishes — a **relative** degeneracy, not absolute.

### 1.3 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe:** No vendor-lock *if* the probe is a pure capability query (e.g., `cpuid`, `cudaGetDeviceCount`, `hipGetDeviceCount`, `torch.xla`). **Vendor-lock risk:** if the probe hard-codes a preference order (e.g., "CUDA first"), it violates Rule 27. **Demand:** probe must return a *set* of capabilities, and the orchestrator must select by policy, not by hard-coded vendor priority.
- **PmtpSlabAllocator:** Slab allocation of 88-byte descriptors is fine, but **alignment** matters. If the slab is `mmap`'d without `MAP_HUGETLB` or 64-byte alignment, AVX-512 loads in Target 2 will fault or degrade. **Demand:** `alignof(PmtpTensorDescriptor) == 64` and slab base aligned to 64.

### 1.4 12/12 physical conformance checks

Without the checklist, the Tribunal cannot verify. **Demand:** publish the 12 checks. A credible set would include: (1) size == 88, (2) alignment ≥ 64, (3) endianness, (4) magic, (5) version, (6) dtype ∈ enum, (7) layout ∈ enum, (8) reserved == 0, (9) scale normal, (10) strides monotone, (11) no aliasing, (12) checksum.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:
```
s = x[0]*y[0]; c = 0
for i in 1..n-1:
    t = s + x[i]*y[i]
    if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
    else:                  c += (x[i]*y[i] - t) + s
    s = t
return s + c
```
**Error bound:** |result − exact| ≤ (2u + O(nu²)) · Σ|x_i y_i|, where u = 2⁻⁵³. This is **not** correctly rounded but is *faithful* for well-scaled inputs.

**Degeneracy at step → ∞:** If `x[i]*y[i]` overflows to `inf`, Neumaier's branch `|s| >= |x[i]*y[i]|` compares `inf` vs `inf` → `true`, and `c += (s - t) + inf` → `NaN`. **Mitigation:** pre-scale inputs by `2^-k` where `k = max exponent`, then rescale. **Demand:** a `scale_inputs()` pass before the dot product.

**Degeneracy at step → 0 (subnormals):** The audit mentions "subnormal audits (-12, -14)". These are presumably exponents (2⁻¹², 2⁻¹⁴) — but IEEE-754 double subnormals begin at 2⁻¹⁰²². If the kernel operates in **FP32**, subnormals begin at 2⁻¹²⁶. The values -12/-14 suggest **FP16** (subnormals at 2⁻¹⁴). **Tribunal finding:** if the kernel is FP16, Neumaier compensation is *insufficient* — FP16 has only 11 bits of mantissa, and the compensation term itself may underflow. **Demand:** clarify precision. If FP16, use FP32 accumulation (which the AVX-512 path likely does) and document the subnormal flush-to-zero (FTZ) policy.

### 2.2 Zero-copy PMTP validation

Zero-copy requires that the 88-byte descriptor's `stride` and `n_rows/n_cols` describe a **contiguous** or **strided** view that the C++ kernel can `reinterpret_cast` without copying. **Risk:** if the descriptor's `layout` field is `ROW_MAJOR` but the producer wrote `COL_MAJOR`, the kernel silently reads garbage. **Demand:** a `validate_pmtp()` that checks `stride == n_cols * sizeof(dtype)` for row-major, and rejects otherwise.

### 2.3 Rule 27 (Silicon Contract)

C++20 + AVX-512 + OpenMP is **x86-only**. This is a **vendor-lock** unless:
- The kernel is compiled with runtime dispatch (`__builtin_cpu_supports("avx512f")`) and falls back to AVX2/SSE.
- OpenMP is not tied to a specific runtime (libomp vs libgomp).

**Tribunal finding:** **Rule 27 violation risk — HIGH.** **Demand:** runtime CPU feature dispatch + a scalar fallback path.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 Safe SIMD + panic=unwind FFI barrier

Rust's `panic=unwind` across an FFI boundary is **undefined behavior** unless the panic is caught at the boundary. The standard hardening is:
```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```
**Tribunal finding:** The brief says "panic=unwind FFI safety barrier" — this is **only safe if `catch_unwind` is present**. **Demand:** verify `catch_unwind` at every `extern "C"` entry point. Otherwise, set `panic=abort` for the FFI crate.

### 3.2 Neumaier sums

Same analysis as Target 2. Rust's `f64` is IEEE-754, so the error bound holds. **Degeneracy:** Rust does **not** flush subnormals by default (unlike some C++ builds with `-ffast-math`). This is *good* for correctness but *bad* for performance. **Demand:** document the FTZ policy.

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` on a struct with `u64` fields will produce **unaligned** accesses, which are UB on some architectures (ARMv7) and slow on x86. **Demand:** use `#[repr(C, align(64))]` with explicit padding, or `#[repr(C, packed(8))]` if 8-byte alignment suffices. The 88-byte size is achievable with `#[repr(C)]` + explicit `[u8; 6]` padding.

**Rule 22 compliance:** ✅ if the struct is exactly 88 bytes and no `Vec`/`String` is serialized.

---

## 4. TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)

The Cayley retraction on the Stiefel manifold St(n, p) is:
```
Y(τ) = (I − (τ/2) A)⁻¹ (