# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 91)

# POLYDIM V1350 — High Tribunal Audit, Cycle 91

**Presiding Sages:** Numerical Analysis, Systems FFI, Hardware Contracts, Differential Geometry
**Verdict class:** *Conditional Pass with 4 Mandatory Remediations (M1–M4)*

---

## 0. Preliminary: What the Tribunal Can and Cannot Verify

The Tribunal notes that the six artifacts were presented as **architectural specifications**, not as compiled binaries with reproducible hashes. All findings below are therefore **static-semantic audits** of the described contracts. Any claim of "12/12 physical conformance" is treated as a *self-attestation* pending independent reproduction on the declared silicon matrix (x86-64 AVX-512, aarch64 NEON, NVIDIA SM90+, AMD gfx942, TPU v5e, Trainium2).

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout `<4sHHQQQQQBB6x4Q`

Let us enumerate the struct:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version_major | `H` | 2 | 4 |
| version_minor | `H` | 2 | 6 |
| flags | `Q` | 8 | 8 |
| n_rows | `Q` | 8 | 16 |
| n_cols | `Q` | 8 | 24 |
| stride | `Q` | 8 | 32 |
| dtype_code | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| pad0 | `B` | 1 | 49 |
| pad1 | `6x` | 6 | 50 |
| reserved | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict:** 88 bytes confirmed. Alignment is 8 (natural for `Q`), so `sizeof == 88` under both `__attribute__((packed))` and default alignment on LP64. **No padding hazard.**

### 1.2 Rule 22 compliance (zero 1D tokens)

The descriptor is a **fixed-width record**, not a token stream. Rule 22 is satisfied *iff* the orchestrator never emits variable-length JSON/msgpack between agents. The Tribunal flags a **latent violation**: `HardwareProbe` typically returns a *list* of devices. If that list is serialized as a 1D array of variable length, Rule 22 is breached. **Remediation M1:** the probe must return a fixed-size `[N_MAX_DEVICES]` array with a `count` field, itself wrapped in an 88-byte envelope.

### 1.3 Numerical degeneracy

The orchestrator is control-plane; no FP arithmetic. **No degeneracy.** However, `PmtpSlabAllocator` must reject `n_rows * n_cols * dtype_size` overflow — recommend `__builtin_mul_overflow` semantics and a hard cap at `2^47` bytes (x86-64 canonical user VA).

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Standard Neumaier:

```
s = x[0]*y[0]; c = 0
for i in 1..n-1:
    t = x[i]*y[i]
    if |s| >= |t|: c += (s - (s + t)) + t
    else:          c += (t - (t + s)) + s
    s += t
return s + c
```

**Error bound (Ogita–Rump–Oishi):** for `n` terms with unit roundoff `u = 2^-53`,

$$|\hat{s} - s| \le \gamma_{n-1} \sum |x_i y_i| + O(u^2), \quad \gamma_k = \frac{ku}{1-ku}$$

This is **first-order accurate in the sum of absolute products**, not in the sum itself. For ill-conditioned dot products (cancellation), the *relative* error is still `O(u · cond)`. **The Tribunal rejects any claim of "exact" dot products.**

### 2.2 Subnormal audit at `-12, -14`

Subnormals in FP64 live in `[2^-1074, 2^-1022)`. The exponents `-12` and `-14` are **not subnormal** — they are ordinary normal numbers. The Tribunal suspects the author meant **FP32 subnormals** (`2^-149`) or **FP16 subnormals** (`2^-24`). **Remediation M2:** clarify the audit points. If the intent is to test flush-to-zero (FTZ/DAZ) behavior, note that **AVX-512 does not FTZ by default**; `_MM_SET_FLUSH_ZERO_MODE` must be set explicitly, and this is a *process-global* MXCSR mutation — a **thread-safety hazard** in OpenMP regions.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be **cache-line aligned** (64B) and the payload to be **page-aligned** for `mmap`/`cudaHostRegister`. The descriptor at 88 bytes straddles two cache lines if not padded to 128. **Remediation M3:** pad descriptor to 128 bytes for hot-path zero-copy, or accept a 2-line fetch.

### 2.4 Rule 27 (Silicon Contract)

AVX-512 is **Intel/AMD-specific**. The Tribunal rules this a **soft vendor-lock** unless a NEON/SVE fallback path is compiled under the same translation unit with runtime dispatch (`__builtin_cpu_supports`). **Conditional pass.**

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI barrier

**This is the most serious finding of the audit.**

Rust's `panic=unwind` across an `extern "C"` boundary is **undefined behavior** unless every FFI entry point is wrapped in `std::panic::catch_unwind`. The Tribunal demands:

```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> c_int {
    match std::panic::catch_unwind(AssertUnwindSafe(|| { /* ... */ })) {
        Ok(r) => r,
        Err(_) => -1,  // sentinel; caller must not assume state
    }
}
```

Without this, a panic in Rust unwinds into C++ frames that are not unwind-aware → `std::terminate` at best, memory corruption at worst. **Remediation M4 (mandatory):** either `panic=abort` for the FFI crate, or `catch_unwind` at every boundary. The Tribunal prefers `panic=abort` for a numerical kernel — a panic in a SIMD loop is unrecoverable anyway.

### 3.2 Safe SIMD + Neumaier

Rust's `std::simd` (portable SIMD) is still nightly. If the crate uses `core::arch::x86_64::_mm512_*`, it is **unsafe** and the "Safe SIMD" claim is false. The Tribunal requires the exact feature gates and `#![forbid(unsafe_code)]` scope to be declared.

### 3.3 Packed 88-byte descriptor

`#[repr(C, packed)]` on a struct containing `u64` fields produces **unaligned loads** on some targets (notably aarch64 with strict alignment for `ldp`). The compiler will emit byte-wise loads, destroying performance. **Recommendation:** `#[repr(C)]` with explicit `_pad: [u8; 6]` and `align(8)`, yielding 88 bytes with natural alignment.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction

For `Y ∈ St(2K, 2K)` (i.e., `Y^T Y = I`), the Cayley retraction is

$$R_Y(\xi) = \left(I - \tfrac{1}{2}W\right)^{-1}\left(I + \tfrac{1}{2}W\right) Y, \quad W = \xi Y^T - Y \xi^T$$

where `ξ` is the tangent step. The **globally scaled Woodbury** form `(M/scale) W = (step/scale) B` is a **preconditioning trick**: it rescales the linear solve to keep the condition number of `(I - W/2)` bounded as `step → ∞`.

**Asymptotic condition number:** as `‖step‖ → ∞`, `W → ∞` and `cond(I - W/2) → ∞` unless `scale ~ ‖step‖`. With `scale = ‖step‖`, `cond → O(1)`. **The scaling is mathematically necessary, not cosmetic.** The Tribunal commends this.

### 4.2 `cuSOLVER DnDsyevd`

`DnDsyevd` is the **divide-and-conquer symmetric eigensolver**. It is **not** the right primitive for a Cayley retraction — Cayley needs a **linear solve** (`getrf`/`getrs` or `potrf`/`potrs`), not an eigendecomposition. If the author is using `DnDsyevd` to compute `(I - W/2)^{-1}` via spectral decomposition, that is **O(n^3) with a large constant** vs. **O(n^3/3)** for Cholesky. **Flag:** possible performance anti-pattern. Unless `W` is symmetric (it is skew-symmetric for Stiefel!), `DnDsyevd` is inapplicable. **For skew-symmetric `W`, use `DnDsyevd` on `iW` (Hermitian) or a real Schur decomposition.** The Tribunal requests clarification.

### 4.3 `step → ∞` degeneracy

With `scale = ‖step‖`, the Woodbury solve is well-conditioned. But the **retraction itself** degenerates: as `step → ∞`, `R_Y(ξ) → -Y` (the antipode). This is a **topological** degeneracy, not numerical. The Tribunal recommends a **step-norm clamp** at `‖step‖ ≤ π` (geodesic radius of `St(2K,2K)`).

### 4.4 `step → 0` (subnormals)

As `step → 0`, `W → 0`, `(I - W/2)^{-1} → I`, and `R_Y(ξ) → Y`. The Woodbury solve becomes `I · x = 0`, which is trivially `x = 0`. **No subnormal hazard** because the RHS scales with `step`. However, if `step` is subnormal, `step/scale` may underflow to 0, producing a **spurious identity retraction**. **Recommendation:** clamp `‖step‖ ≥ 2^-1000` or use `fma`-based scaling.

---

## TARGET 5 — `kernel_xla_v1350.py`

