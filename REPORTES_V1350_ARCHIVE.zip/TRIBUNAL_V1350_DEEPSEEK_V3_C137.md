# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 137)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 137 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been handed six artifacts whose *claimed* invariants (88-byte descriptor, Neumaier compensation, Stiefel Cayley retraction, Lyapunov solve, Clifford bivector rotations) are individually well-understood. The audit therefore focuses on **cross-file consistency**, **edge-case degeneracy**, and **contract enforcement** — the three places where multi-file systems historically fail. Where the artifacts are described only by their headers (as here), the Tribunal issues **conditional verdicts** and demands the specific evidence enumerated in §7.

---

## §0. Notation and Standing Assumptions

- `step ∈ ℝ` is the retraction/update scalar; `M ∈ ℝ^{2K×2K}` is the metric; `B` the gradient; `W` the Woodbury correction.
- `ε_mach ≈ 2.22e-16` (FP64), `ε_sub ≈ 4.94e-324` (min subnormal), `ε_norm ≈ 2.23e-308` (min normal).
- `u = ε_sub/ε_norm ≈ 2.22e-16` — the subnormal gap ratio.
- Rule 22: inter-agent payloads are **fixed 88-byte PMTP descriptors**, no 1-D token streams.
- Rule 27: no component may impose vendor lock; every silicon path must be reachable through the same 88-byte ABI.

---

## §1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Struct layout audit — `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Offset | Notes |
|---|---|---|---|---|
| magic | 4s | 4 | 0 | OK |
| version | H | 2 | 4 | OK |
| flags | H | 2 | 6 | OK |
| n_dims | Q | 8 | 8 | OK |
| stride0 | Q | 8 | 16 | OK |
| stride1 | Q | 8 | 24 | OK |
| stride2 | Q | 8 | 32 | OK |
| stride3 | Q | 8 | 40 | OK |
| dtype | B | 1 | 48 | OK |
| rank | B | 1 | 49 | OK |
| pad | 6x | 6 | 50 | OK |
| aux[4] | 4Q | 32 | 56 | OK |
| **total** | | **88** | | **exact** |

**Verdict:** Layout is byte-exact at 88 with **no implicit padding** on any ABI (LP64, LLP64, ILP32). `struct.calcsize` must equal 88 on all three; the Tribunal demands a CI assertion `assert struct.calcsize("<4sHHQQQQQBB6x4Q") == 88` on every target triple.

### 1.2 Degeneracy at `step → ∞` and `step → 0`

The orchestrator itself does not perform arithmetic on `step`; it dispatches. **However**, the descriptor's `aux[4]` field is the natural carrier for `step` and `scale`. Two failure modes:

- **`step ≥ 1e10`:** if `aux[0]` stores `step` as a raw FP64, the downstream Woodbury solve `(M/scale) W = (step/scale) B` loses precision when `step/scale` overflows the mantissa of the *smallest* operand. The orchestrator must **pre-normalize** `step` and `scale` jointly (see §4.2).
- **`step → 0` (subnormal):** if `aux[0]` is written as a subnormal FP64, the descriptor is still 88 bytes, but the *semantic* payload is degenerate. The orchestrator must **reject** `|step| < ε_norm` at dispatch time and emit a `PMTP_ERR_SUBNORMAL_STEP` flag in `flags`.

**Recommendation:** Add a `flags` bit `0x0004 = STEP_NORMALIZED` and require the orchestrator to set it only after verifying `ε_norm ≤ |step| ≤ 1e10`.

### 1.3 Rule 22 compliance

The 88-byte descriptor is the *only* inter-agent payload. **PASS**, conditional on the orchestrator never emitting variable-length debug strings across the ABI. The Tribunal demands a static check that no `send()`/`recv()` call site passes a `bytes` object whose length is not statically 88.

### 1.4 Rule 27 compliance

`HardwareProbe` must enumerate **all** silicon (CPU, CUDA, ROCm, TPU, Trainium) and expose them through the *same* 88-byte descriptor. **PASS** if `PmtpSlabAllocator` does not branch on vendor at the ABI boundary. **Demand:** a unit test that constructs a descriptor on CPU and replays it on CUDA/ROCm/TPU without re-encoding.

---

## §2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Standard Neumaier:

```
s = 0; c = 0
for i: t = s + a[i]*b[i]
       if |s| ≥ |a[i]*b[i]|: c += (s - t) + a[i]*b[i]
       else:                 c += (a[i]*b[i] - t) + s
       s = t
return s + c
```

**Error bound:** `|fl(x·y) - x·y| ≤ (2u + O(u²)) Σ|a_i b_i|` — i.e., **componentwise forward stability**, not just normwise. This is the correct choice for Stiefel retraction where `M` is ill-conditioned.

**Degeneracy at `step → ∞`:** Neumaier is *not* the bottleneck; the bottleneck is the **Cayley denominator** `(I + (step/2) A)^{-1}`. As `step → ∞`, `(step/2) A` dominates and the solve becomes a **projection onto the orthogonal complement of A's range**. The C++ kernel must detect `|step| > 1e10` and switch to the **asymptotic Cayley form** `Y_∞ = -A^{-1} (I - P_A)` rather than attempting the solve.

**Degeneracy at `step → 0`:** `(step/2) A → 0`, so `(I + (step/2)A)^{-1} → I`. The kernel must **not** attempt to invert a near-identity matrix via LU; it should short-circuit to `Y = Y_0 + step * B` (Euler step) when `|step| < 1e-8`.

### 2.2 Subnormal audits at `-12` and `-14`

The notation `(-12, -14)` almost certainly refers to **exponent thresholds** `2^-12` and `2^-14` (FP16 subnormal boundaries) or **log10 thresholds** `1e-12`, `1e-14`. Either way:

- **`1e-12`:** above `ε_norm`; safe for FP64, **subnormal for FP32** (min normal ≈ 1.18e-38, so 1e-12 is *normal* in FP32 — the audit must clarify).
- **`1e-14`:** still normal in FP64 and FP32; **subnormal in FP16** (min normal ≈ 6.1e-5).

**Verdict:** The audit thresholds are **mis-specified** unless the kernel is FP16. The Tribunal demands the kernel declare its working precision and re-derive thresholds: for FP64, subnormal audit must trigger at `|x| < 2.23e-308`, not `1e-14`.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be **aligned to 8 bytes** and **pinned** (page-locked) for DMA. The C++ kernel must:

1. `static_assert(alignof(PmtpDescriptor) == 8)`.
2. `static_assert(sizeof(PmtpDescriptor) == 88)`.
3. Validate `magic == 0x504D5450` ("PMTP") before any pointer arithmetic.

**FFI hardening:** wrap the descriptor in a `std::span<const std::byte, 88>` and never reinterpret-cast to a larger struct.

---

## §3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

**This is a red flag.** `panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is `extern "C-unwind"` (stabilized 1.71). The Tribunal's position:

- If the Rust kernel is called from C++/Python via `extern "C"`, **`panic = abort` is mandatory**.
- If the kernel uses `extern "C-unwind"` and the caller is also `-unwind`-aware, `panic = unwind` is permissible but **must be documented** and the caller must not be a C ABI that assumes no unwinding.

**Verdict:** **CONDITIONAL FAIL** until the kernel declares its ABI. The Tribunal demands `#[no_mangle] pub extern "C-unwind"` on every FFI entry point, or a switch to `panic = abort`.

### 3.2 Neumaier sums in Rust

Rust's `f64::mul_add` (FMA) is **not** the same as Neumaier. The kernel must implement Neumaier explicitly; `mul_add` alone gives `|fl(x·y) - x·y| ≤ u |x·y|` per term, which is *not* compensated. **Demand:** a `#[inline] fn neumaier_dot(a: &[f64], b: &[f64]) -> f64` with a Kahan-style test vector.

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` on a struct with `u64` fields will produce **unaligned loads** on some targets. The Tribunal recommends `#[repr(C)]` with explicit `_pad: [u8; 6]` and `static_assert` via `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`.

**Degeneracy:** packed structs + `step → 0` subnormals → the Rust kernel must use `f64::is_subnormal()` (stable since 1.53) and reject at the boundary.

---

## §4. TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in `R^{2K × 2K}`

Cayley: `Y(step) = (I - (step/2) A)^{-1} (I + (step/2) A) Y_0`, where `A = Y_0^T B -