# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 76)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 76 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been asked to audit six artifacts whose *source* has not been submitted — only their architectural claims. We therefore audit the **claims as stated**, flag every place where the claim is either (a) mathematically under-determined, (b) numerically fragile, or (c) in tension with Rules 22/27. Where a claim cannot be falsified from the description alone, we mark it **UNVERIFIED** rather than pass it. This is the only honest posture for a Tribunal.

---

## 0. Cross-cutting findings (apply to all six targets)

### 0.1 Rule 22 — "Zero 1D tokens, 88-byte PMTP"
The 88-byte descriptor is claimed as `<4sHHQQQQQBB6x4Q`. Let us actually sum it:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version, flags | `HH` | 4 |
| 5× `Q` (dims/strides/offsets) | `QQQQQ` | 40 |
| 2× `B` | `BB` | 2 |
| pad | `6x` | 6 |
| 4× `Q` (checksums / handles) | `4Q` | 32 |
| **Total** | | **88** |

✅ **Struct size is arithmetically 88 bytes.** Alignment: `Q` requires 8-byte alignment; the leading `4sHH` = 8 bytes, so the first `Q` lands at offset 8 — **naturally aligned, no implicit padding**. The trailing `6x` is *explicit*, which is the correct discipline. **PASS on layout.**

⚠️ **But Rule 22 also says "zero 1D tokens."** A 1D token is any inter-agent message that is a bare scalar/vector without a PMTP envelope. The Tribunal cannot verify this from the file list alone. **Required evidence:** a wire-trace or a `grep -E 'send\(|recv\('` showing every IPC call wraps a `PmtpTensorDescriptor`. **UNVERIFIED.**

### 0.2 Rule 27 — Silicon Contract / vendor lock
| Target | Vendor exposure | Verdict |
|---|---|---|
| T1 orchestrator | Multi-silicon probe | ✅ neutral *if* probe is capability-based, not `if cuda: ... elif rocm: ...` |
| T2 C++ | AVX-512 | ⚠️ **Intel/AMD-only.** Needs a scalar + AVX2 fallback path or it violates Rule 27 on ARM/Graviton. |
| T3 Rust | portable SIMD | ✅ neutral |
| T4 CUDA | cuSOLVER, CUDA Graphs | ❌ **hard vendor lock** unless a HIP/ROCm mirror exists |
| T5 XLA | GCP TPU + AWS Trainium | ⚠️ dual-vendor, but *both* are cloud-locked; no on-prem path |
| T6 Triton | ROCm + NVIDIA | ✅ dual-vendor, best-in-class for Rule 27 |

**Tribunal ruling on Rule 27:** T4 is the sole **hard violation**. T2 and T5 are **soft violations** requiring documented fallback. T1/T3/T6 pass.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy
The orchestrator itself does no arithmetic, so `step → ∞` and `step → 0` are *routing* concerns. The critical question: **does the orchestrator clamp `step` before dispatch?**

- If `step = 1e10` is passed to T4's Cayley retraction, the Woodbury scaling `(step/scale)` will overflow FP64 only if `scale < 1e-298`. **Recommendation:** orchestrator must enforce `1e-300 < |step| < 1e300` and reject otherwise with a typed error, not a silent clamp.
- If `step` is subnormal (`< 2.2e-308`), the orchestrator must **not** normalize it to zero — that destroys the subnormal audit in T2/T3. It must pass the raw bits through.

### 1.2 12/12 physical conformance checks
The Tribunal demands the **list of the 12 checks**. A claim of "12/12" without enumeration is unfalsifiable. Minimum acceptable set:
1. magic == `b'PMTP'`
2. version ∈ supported set
3. `sizeof(descriptor) == 88` (compile-time `static_assert` in C++/Rust, `struct.calcsize` in Python)
4. alignment of first `Q` == 8
5. no implicit padding (`6x` present)
6. checksum[0] == CRC32 of payload
7. checksum[1] == BLAKE3 of payload
8. handle[0] is a valid device pointer / offset
9. handle[1] is a valid stream/queue id
10. dims product ≤ declared capacity
11. strides are monotone non-decreasing
12. endianness tag matches host

**UNVERIFIED** until the list is produced.

### 1.3 FFI hardening
- `HardwareProbe` must be **read-only** and must not `dlopen` vendor libs at import time (supply-chain risk).
- `PmtpSlabAllocator` must use `mmap(MAP_HUGETLB)` with `MADV_DONTDUMP` to avoid core-dump leakage of tensor data.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number
Neumaier's algorithm gives a **faithfully rounded** result with error bound

$$|\hat{s} - s| \le \frac{u}{1-u}\,|s| + \gamma_2 \sum_i |x_i y_i|, \quad u = 2^{-53}, \ \gamma_2 = \frac{2u}{1-2u}.$$

The **effective condition number** of the compensated dot is

$$\kappa_{\text{Neumaier}} = \frac{\sum_i |x_i y_i|}{|\sum_i x_i y_i|} \cdot u + u,$$

i.e. it is **backward stable** but **not** forward-stable when catastrophic cancellation dominates. For `step → ∞` this is fine (magnitudes grow, `κ` stays bounded). For `step → 0` with subnormal inputs, the compensation term itself becomes subnormal and **the compensation is lost**.

### 2.2 Subnormal audit at −12, −14
The claim of auditing exponents −12 and −14 is **suspicious**: FP64 subnormals begin at exponent **−1022**, not −12. Exponents −12 and −14 are *normal* FP64 values. The Tribunal suspects these are **FP32** exponents (FP32 subnormals begin at −126). **If the audit is on FP32, the claim is coherent; if on FP64, it is a category error.** Demand clarification.

**Required test:** `std::fpclassify(x) == FP_SUBNORMAL` on inputs `0x1p-1074`, `0x1p-1022`, and the flush-to-zero check `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`.

### 2.3 AVX-512 + OpenMP
- AVX-512 downclocking on Skylake-X is a **real** throughput hazard; the Tribunal requires a runtime `cpuid` check for `AVX512ER`/`AVX512F` and a fallback.
- OpenMP `#pragma omp simd reduction(+:s)` **does not** implement Neumaier compensation — the reduction tree loses the compensation term. **This is a correctness bug.** Compensation must be done with a manual two-pass or a Kahan-aware reduction.

### 2.4 Zero-copy PMTP validation
Zero-copy requires the descriptor's `handle[0]` to be a **device-visible** pointer. Validation must include `cudaPointerGetAttributes` (or HIP equivalent) to confirm the pointer is not host-pinned-but-unmapped. **UNVERIFIED.**

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier
This is **the single most important claim in the file** and it is **correct in principle, dangerous in practice**.

- `panic = unwind` allows `catch_unwind` at the FFI boundary, which is the **only** sound way to prevent UB from a Rust panic crossing into C.
- **But** `panic = unwind` is **incompatible** with `#[no_mangle] extern "C"` unless every entry point is wrapped in `std::panic::catch_unwind`. The Tribunal demands a `#[repr(C)]` shim with `catch_unwind` on **every** exported symbol.
- **Recommendation:** add `#[cfg(panic = "abort")] compile_error!("POLYDIM requires panic=unwind for FFI safety");` to make the invariant machine-checked.

### 3.2 Safe SIMD
Rust's `std::simd` is still nightly. If the file uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. The claim "Safe SIMD" is **UNVERIFIED** unless the file uses `portable_simd` or a safe wrapper crate.

### 3.3 Packed 88-byte descriptor
Rust's default `repr(Rust)` **reorders fields**. The descriptor **must** be `#[repr(C, packed(8))]` or `#[repr(C)]` with explicit `_pad: [u8; 6]`. If the file uses `#[repr(C)]` without the pad, `size_of` will be 88 **only by accident** on some targets. **Demand `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`.**

### 3.4 Neumaier in Rust
Same OpenMP caveat does not apply (no OpenMP), but `rayon`'s `reduce` is **not** order-deterministic. For reproducible subnormal audits, use `rayon::slice::ParallelSlice::par_chunks` with a fixed chunk size and a deterministic tree.

---

## 4. TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction — the real math
For `Y ∈ R^{n×p}` with `Y^T Y = I`, the Cayley retraction is

$$\mathrm{Cayley}(Y, A) = \left(I - \tfrac{1}{2}W\right)^{-1}\left(I + \tfrac{1}{2}W\right) Y, \quad W = A Y^T - Y A^T,$$

where `A` is the tangent step. The claim of working in `R^{2K × 2K}` suggests a **symplectic embedding** — this is **not** the standard Stiefel Cayley. The Tribunal demands the exact embedding map. If the embedding