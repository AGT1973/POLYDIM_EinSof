# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 152

The requested **definitive arbitration cannot be performed as stated** because the eight Tribunal reports, the definitions of the six V1350 kernels, and the PMTP descriptor specification were not provided or publicly verifiable. The available literature supports general conclusions about Stiefel retractions and memory ordering, but not product-specific architectural guarantees.

## 1. Cayley/Stiefel retraction versus Householder/Polar QR at \(|\mathrm{step}|\ge 10^{10}\)

For a Stiefel point \(X\) and tangent update \(\Xi\), the principal alternatives are:

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)\bigl(I+\Xi^{\mathsf T}\Xi\bigr)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley transformation based on a skew-symmetric generator. Polar, QR, and Cayley retractions are established classes of Stiefel retractions; their cost and numerical behavior differ materially.[2][3]

**Arbitration:**

- **Cayley is not automatically stable for extreme steps.** A Cayley update requires solving a system involving a matrix such as \(I-\tfrac12 W\). For very large \(\|W\|\), conditioning, overflow, cancellation, and the quality of the skew-symmetric construction become decisive.
- **Polar retraction is the strongest mathematical baseline for orthogonality**, provided the factorization and inverse square root are computed with backward-stable algorithms and scaling. It directly returns the orthogonal polar factor of \(X+\Xi\).[3]
- **Householder QR is generally the preferred implementation baseline** for robust orthogonalization, especially when using blocked Householder transformations and suitable pivot/sign conventions. It avoids explicitly forming normal equations.
- **Classical Gram–Schmidt or unscaled normal-equation implementations cannot receive an extreme-step guarantee.**
- For \(|\mathrm{step}|\ge10^{10}\), no method can guarantee meaningful accuracy merely from its formula. The update must use **dynamic scaling**, overflow-safe norms, finite-value checks, rank/conditioning diagnostics, and a specified fallback path.

A defensible kernel guarantee would therefore be:

\[
\widehat Q^{\mathsf T}\widehat Q
=I+\Delta,\qquad
\|\Delta\|\le C\,u\,\kappa_{\mathrm{scaled}}(X+\Xi),
\]

subject to finite inputs, a bounded condition number, a specified floating-point model, and a stable factorization. Without those preconditions, the claim “stable for every step of magnitude at least \(10^{10}\)” is mathematically unjustified.

**Verdict:** choose **scaled Householder QR or scaled polar decomposition** as the correctness path. Cayley may be retained as a performance path only with conditioning tests and QR/polar fallback. The available evidence does not support declaring Cayley categorically superior.

## 2. PMTP 88-byte descriptors and RCU/QSBR snapshot isolation

An 88-byte size says nothing by itself about memory ordering or snapshot safety. Descriptor correctness depends on:

- which fields are immutable,
- ownership and lifetime rules,
- publication protocol,
- reader critical-section rules,
- reclamation protocol,
- alignment and atomicity of each field,
- whether the descriptor contains pointers, offsets, generation counters, or checksums.

For RCU/QSBR-style publication, the essential protocol is:

1. Writer fully initializes a new immutable descriptor.
2. Writer publishes its pointer/index with **release** semantics.
3. Reader enters the read-side critical section before loading the pointer.
4. Reader loads the published pointer with **acquire** semantics.
5. Reader accesses only immutable fields of that snapshot.
6. Writer retires the old descriptor.
7. Reclamation occurs only after every pre-existing reader has passed a quiescent state.

Acquire/release ordering establishes visibility and ordering; it does **not** by itself provide reclamation safety. In particular, this is insufficient:

```text
reader: p = acquire_load(current)
writer: old = exchange(current, new, release)
writer: free(old)
```

The reader can still dereference `old` unless a hazard-pointer, epoch/QSBR, grace-period, or equivalent protection mechanism is active.

**Arbitration:** the exact guarantee should be stated as:

> A reader that enters the prescribed RCU/QSBR read-side protocol before acquiring the descriptor observes one coherent, fully initialized descriptor version, and that version remains alive until the reader exits the read-side critical section.

This is stronger and more precise than saying “Acquire/Release gives snapshot isolation.” It does not guarantee multi-field atomicity for mutable descriptors, nor does it guarantee isolation across devices or language runtimes without an explicitly defined cross-device publication mechanism.

For an 88-byte descriptor, the architecture should additionally specify:

- immutable payload after publication;
- one atomic publication word, normally a pointer, index, or generation-tagged handle;
- no reader dependence on torn multiword updates;
- explicit cache-coherence/domain scope;
- release publication and acquire consumption;
- grace-period completion before reuse;
- ABI layout, alignment, endianness, and padding;
- validation of descriptor version, length, and checksum where corruption is possible.

**Verdict:** Acquire/release is necessary for publication ordering but insufficient as a standalone RCU/QSBR guarantee. The guarantee requires acquire/release **plus lifetime protection and immutable snapshots**.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single semantic contract can be shared across these environments, but bit-for-bit or memory-model equivalence cannot be assumed.

| Environment | What can be specified reliably | Important limitation |
|---|---|---|
| CUDA | Kernel ordering, stream/event dependencies, scoped atomics, device/system visibility | Host/device and peer-device visibility require explicit scope and synchronization |
| XLA | Functional tensor semantics and compiler-level dependency structure | Backend lowering may change operation order, precision, fusion, and reproducibility |
| Triton | Kernel-level tensor behavior and explicit synchronization where supported | Portability depends on backend capabilities and compiler lowering |
| C++20 | Host-side atomic publication, object lifetime, and ABI contract | The C++ memory model does not automatically define GPU visibility |
| Rust | Ownership, aliasing discipline, and host-side synchronization wrappers | Unsafe FFI/device code must uphold the external ABI and memory model |

**Arbitration:** conformance should be layered:

1. **Representation conformance:** identical 88-byte layout, offsets, alignment, byte order, and versioning.
2. **Mathematical conformance:** identical tensor/manifold operation within declared tolerances.
3. **Memory-safety conformance:** no use-after-reclaim, invalid descriptor, data race, or out-of-bounds access.
4. **Ordering conformance:** publication and observation satisfy the specified acquire/release and quiescence protocol.
5. **Numerical conformance:** explicit tolerances for orthogonality, residuals, overflow handling, NaN/Inf behavior, and rank deficiency.
6. **Reproducibility conformance:** guaranteed only if reduction order, precision, compiler transformations, and atomics are constrained.

XLA and Triton should not be advertised as having identical low-level memory semantics to C++20 or Rust. Their portable contract should be expressed in terms of **observable tensor results and explicit synchronization boundaries**, with backend-specific implementations validated against that contract.

## Definitive synthesis

The strongest defensible SOTA architecture is:

- **Retraction:** scaled Householder QR or polar decomposition as the reference implementation; Cayley as an optimized conditional path with residual checking and fallback.
- **Extreme-step handling:** scale before factorization, use overflow-safe norms, reject nonfinite intermediates, detect rank deficiency, and validate
  \[
  \|Q^{\mathsf T}Q-I\|\le\tau_{\mathrm{orth}}.
  \]
- **Descriptor publication:** immutable 88-byte snapshots, published through one release-ordered atomic handle and consumed through acquire loads.
- **Reclamation:** QSBR/RCU grace periods or hazard protection; acquire/release alone is not a reclamation mechanism.
- **Cross-silicon contract:** define layout, mathematical results, lifetime, ordering, numerical tolerances, and failure behavior separately.
- **Guarantee scope:** claims must be conditional on hardware memory scope, finite inputs, declared precision, valid descriptor alignment, completed synchronization, and conforming compiler lowering.

Accordingly, the proposed claims that **Cayley is universally more stable at \(|\mathrm{step}|\ge10^{10}\)**, that **Acquire/Release alone guarantees RCU snapshot isolation**, or that **CUDA, XLA, Triton, C++20, and Rust are automatically memory-model equivalent** should be rejected absent the missing Tribunal reports and formal specifications.