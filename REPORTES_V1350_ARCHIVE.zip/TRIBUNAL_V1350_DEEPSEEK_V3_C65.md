# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 65)

# POLYDIM V1350 — High Tribunal Audit, Cycle 65

**Presiding note.** The Tribunal treats the six artifacts as *specifications* (source not attached), so findings are stated as **conditional theorems**: "if the implementation matches the described contract, then …". Where a claim is unverifiable from the description alone, it is flagged **[UNVERIFIED]** and a falsification test is prescribed. No component is granted a pass on rhetoric.

---

## 0. Notation and Standing Invariants

- `step ∈ ℝ` is the retraction/update scalar; `M ∈ ℝ^{2K×2K}` is the (scaled) metric; `B` the update matrix; `W` the Woodbury correction.
- PMTP descriptor: `<4sHHQQQQQBB6x4Q` → 4+2+2+8·5+1+1+6+8·4 = **88 bytes**. ✅ arithmetic confirmed.
- Rule 22: inter-agent payloads must be **zero 1-D tokens** and exactly **88 bytes**.
- Rule 27: no component may impose vendor lock.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout audit
`<4sHHQQQQQBB6x4Q`:
| field | bytes | role |
|---|---|---|
| `4s` | 4 | magic |
| `HH` | 4 | version, flags |
| `QQQQQ` | 40 | 5×u64 (dims, strides, offsets) |
| `BB` | 2 | dtype, rank |
| `6x` | 6 | pad |
| `4Q` | 32 | 4×u64 (checksums / pointers) |
| **Σ** | **88** | ✅ |

**Finding 1.1 (PASS, conditional).** Struct is 88 B and 8-byte aligned. **Risk:** `6x` pad is *implicit*; if any field is reordered by a future refactor, `struct.calcsize` silently changes. **Hardening:** assert `struct.calcsize("<4sHHQQQQQBB6x4Q") == 88` at import; emit a `PMTP_LAYOUT_HASH` (BLAKE2s of the format string) into the descriptor's checksum slot.

### 1.2 Rule 22 compliance
"Zero 1-D tokens" means the inter-agent channel carries **only** the 88-byte descriptor — no variable-length arrays, no JSON, no pickled lists. The orchestrator's `HardwareProbe` and `PmtpSlabAllocator` must therefore serialize *all* state into the 5×u64 + 4×u64 fields.

**Finding 1.2 (CONDITIONAL PASS).** 5×u64 = 40 B of geometry is sufficient for a 2-D slab (rows, cols, ld, base, epoch). **But** if the probe returns >5 scalars (e.g., per-NUMA-node counts), the orchestrator will be tempted to append a side-channel — **Rule 22 violation**. **Falsification test:** fuzz the probe with 64 NUMA nodes and assert the emitted frame is exactly 88 B.

### 1.3 12/12 physical conformance checks
Without the check list, the Tribunal notes the *category*: alignment, endianness, size, magic, version, dtype, rank, checksum, base-pointer validity, stride monotonicity, slab non-overlap, epoch monotonicity. **Finding:** 12 checks is a *plausible* but **unproven** count. Demand the check table be hashed into the descriptor.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound
For `s = Σ aᵢbᵢ` with Neumaier compensation, the forward error satisfies (Ogita–Rump–Oishi):

\[
|\hat{s} - s| \le \gamma_{n-1}\,|s| + \mathcal{O}(u^2), \quad \gamma_k = \frac{ku}{1-ku}
\]

with `u = 2⁻⁵³` (FP64). **Asymptotic condition number** of the dot product w.r.t. relative perturbations of inputs:

\[
\kappa_{\text{dot}} = \frac{\sum_i |a_i b_i|}{|\sum_i a_i b_i|}
\]

**Finding 2.1 (PASS).** Neumaier is *faithfully rounded* for `n·u < 1`. **Degeneracy:** if `Σ|aᵢbᵢ| / |Σaᵢbᵢ| → ∞` (catastrophic cancellation), even Neumaier loses relative accuracy — it preserves *absolute* accuracy. **Recommendation:** for the Stiefel projection, use **Kahan–Babuska** or **two-product (FMA) accumulation** to recover the *relative* bound.

### 2.2 Subnormal audits at −12, −14
Subnormals in FP64 live in `[2⁻¹⁰⁷⁴, 2⁻¹⁰²²)`. "−12, −14" almost certainly denote **decimal exponents** `10⁻¹², 10⁻¹⁴` — i.e., *not* subnormal in FP64 (they are normal). **Finding 2.2 (SUSPECT).** If the audit claims to test subnormals but uses `1e-12`, it is testing **normal** numbers and the audit is vacuous.

**Correct subnormal test:** `x = 5e-324` (min subnormal), `y = 1e-320`. Assert `x*y == 0` (underflow) and that Neumaier compensation does **not** resurrect it. **Falsification:** run with `-ffast-math` — FTZ/DAZ will silently flush subnormals; the audit must be compiled **without** `-ffast-math` and with `-fno-ftz` (or `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`).

### 2.3 Zero-copy PMTP validation
Zero-copy requires the 88-byte descriptor's `4Q` pointer slots to be **validated** (alignment, ownership, epoch) before dereference. **Finding 2.3:** if validation is done *after* the pointer is used, it is not zero-copy — it is use-after-free bait. **Hardening:** validate in a `[[gnu::always_inline]]` prologue that reads only the descriptor's first 24 bytes (magic+version+flags) before touching pointers.

### 2.4 AVX-512 / OpenMP
**Finding 2.4 (VENDOR-LOCK RISK — Rule 27).** AVX-512 is Intel-specific (though AMD Zen 4+ supports it). If the kernel *requires* AVX-512 with no scalar/AVX2 fallback, it violates Rule 27. **Required:** runtime dispatch via `__builtin_cpu_supports("avx512f")` with a portable fallback. OpenMP is portable; `#pragma omp simd` is fine.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier
**Finding 3.1 (CRITICAL).** `panic=unwind` across an FFI boundary is **UB** unless every `extern "C"` function is wrapped in `std::panic::catch_unwind`. The Tribunal demands:

```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> i32 {
    match std::panic::catch_unwind(|| inner(...)) {
        Ok(r) => r,
        Err(_) => -1, // sentinel; caller must not read outputs
    }
}
```

Without this, a panic in Rust unwinds into C++ → `std::terminate` or worse. **Falsification:** inject `panic!()` in the SIMD path; assert the C++ caller receives `-1` and does not crash.

### 3.2 Safe SIMD + Neumaier
Rust's `std::simd` (nightly) or `wide`/`packed_simd` crates. Neumaier in SIMD requires **two accumulators** (sum + compensation) and a final horizontal reduction. **Finding 3.2:** the horizontal reduction itself must be Neumaier-compensated, else the last `log₂(lanes)` additions lose the compensation. **Recommendation:** reduce with pairwise + Kahan.

### 3.3 Packed 88-byte descriptor
`#[repr(C, packed)]` with `#[repr(align(8))]` is **contradictory** in Rust — `packed` removes alignment. **Finding 3.3 (BUG).** Use `#[repr(C)]` with explicit `_pad: [u8; 6]` and `#[repr(align(8))]`. Verify with `std::mem::size_of::<PmtpTensorDescriptor>() == 88` and `align_of == 8` in a `const _: () = assert!(...)`.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction
For `Y ∈ St(n,p)`, the Cayley retraction is:

\[
R_Y(\xi) = \left(I - \tfrac{1}{2}W\right)^{-1}\left(I + \tfrac{1}{2}W\right)Y, \quad W = \xi Y^\top - Y\xi^\top
\]

**Finding 4.1 (PASS, conditional).** The `(I - ½W)` solve is well-conditioned iff `‖W‖₂ < 2`. **Asymptotic condition number:**

\[
\kappa_2(I - \tfrac{1}{2}W) = \frac{1 + \tfrac{1}{2}\|W\|_2}{1 - \tfrac{1}{2}\|W\|_2}
\]

**Degeneracy as step → ∞:** if `step` scales `ξ`, then `‖W‖₂ → ∞` and the solve **diverges**. The globally-scaled Woodbury `(M/scale) W = (step/scale) B` is precisely the mitigation — but only if `scale` is chosen as `scale = max(‖M‖, ‖step·B‖)`. **Demand:** prove `scale` is computed from a **norm estimate** (e.g., `cuBLAS nrm2` or `Lanczos`), not a heuristic.

### 4.2 cuSOLVER `DnDsyevd` in R^{2K×2K}
`DnDsyevd` is the **divide-and-conquer** symmetric eigensolver. **Finding 4.2:** D&C is `O(K³)` but with a large constant; for `2K ≤ 512` it is fine, for `2K ≥ 4096` prefer `Dsyevr` (MRRR). **Numerical:** D&C can return eigenvalues with **absolute** error `O(u‖A‖)`, not