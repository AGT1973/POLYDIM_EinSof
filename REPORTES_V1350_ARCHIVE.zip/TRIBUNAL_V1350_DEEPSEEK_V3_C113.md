# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 113)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 113 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been given six artifacts by *name and claimed contract* only. No source bytes were submitted. Under Rule 22 §4 (evidence discipline) and Rule 27 §2 (silicon contract attestation), the Tribunal will therefore:

- **Grade what is *asserted*** against the mathematical and systems invariants that *must* hold for the claim to be true.
- **Flag every claim that is unverifiable from the descriptor alone** as `UNATTESTED` rather than pass/fail.
- **Refuse to certify** any component whose correctness depends on a numeric bound that has not been supplied.

Verdicts below are therefore *conditional*: they become binding only when the source is produced and the invariants are checked mechanically.

---

## 0. Cross-cutting invariants the Tribunal will enforce

Let the PMTP descriptor be the 88-byte record

```
struct PmtpDescriptor {           // 88 bytes, packed, no padding
    char     magic[4];            // "<4s"
    uint16_t version;             // "H"
    uint16_t flags;               // "H"
    uint64_t n_rows;              // "Q"
    uint64_t n_cols;              // "Q"
    uint64_t stride;              // "Q"
    uint64_t base_off;            // "Q"
    uint64_t checksum;            // "Q"
    uint8_t  dtype;               // "B"
    uint8_t  rank;                // "B"
    uint8_t  _pad[6];             // "6x"
    uint64_t ext[4];              // "4Q"
};                                // 4+2+2+8*5+1+1+6+8*4 = 88
```

**Tribunal arithmetic check:** `4 + 2 + 2 + 40 + 1 + 1 + 6 + 32 = 88`. ✅ The format string `<4sHHQQQQQBB6x4Q` is *self-consistent* and little-endian. This is the only claim in the entire submission that the Tribunal can verify without source.

**Rule 22 (Zero 1D tokens):** every inter-agent message must be a *structured* PMTP record, not a flat byte stream. Any component that emits `bytes`, `str`, or `list[float]` across an FFI boundary is in violation.

**Rule 27 (Silicon Contract):** no component may require a specific vendor's ISA, driver, or runtime to *function*. Vendor-specific *fast paths* are permitted only if a portable fallback exists and is exercised in CI.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / multi-silicon dispatch

**Claim:** probes CPU (AVX-512), CUDA, ROCm, TPU, Trainium and dispatches.

**Tribunal finding — `UNATTESTED`, with a structural warning.**

The probe must be *monotone*: if a backend is present but its numerical contract cannot be met (e.g. no FP64 on consumer NVIDIA), the probe must **demote**, not silently accept. The classic failure mode is:

```python
if torch.cuda.is_available(): backend = "cuda"   # ← WRONG
```

This violates Rule 27 because it binds correctness to a vendor runtime. The correct form is a *capability lattice*:

```
capability = (fp64_native, subnormal_preserved, fma_contracted, deterministic_reduction)
backend    = argmax_{b ∈ available} score(b, capability)
```

**Required attestation:** publish the capability matrix and the demotion policy. Without it, T1 is `UNATTESTED`.

### 1.2 PmtpSlabAllocator

**Claim:** slab allocator for 88-byte descriptors.

**Tribunal finding — `UNATTESTED`, with a hard alignment requirement.**

88 is not a power of two. A slab of 88-byte records must be aligned to at least `alignof(std::max_align_t)` (typically 16) and preferably 64 to avoid false sharing across cores. If the allocator packs descriptors at stride 88 with base alignment 8, every cache line straddles two descriptors → **false sharing on every write**. This is a *correctness-adjacent* performance bug that becomes a correctness bug under `-ffast-math` + relaxed atomics.

**Recommendation:** stride = 128 (pad to cache line), or stride = 96 with 32-byte alignment. The 88-byte *wire format* is fine; the *in-memory* stride need not equal it.

### 1.3 12/12 physical conformance checks

**Tribunal finding — `UNATTESTED`.** The Tribunal requires the list of the 12 checks. A conformance suite that does not include the following is *incomplete*:

1. `sizeof(PmtpDescriptor) == 88` on every target ABI.
2. `offsetof` of each field matches the format string.
3. Endianness round-trip on big-endian host (s390x, ppc64le).
4. `checksum` is computed over the *canonical* byte order, not host order.
5. Descriptor survives `memcpy` across `extern "C"` boundary without UB.
6. `dtype` enum is closed (no uninitialized values accepted).
7. `rank` ≤ `min(n_rows, n_cols)`.
8. `base_off + stride * (n_rows - 1) + n_cols * itemsize ≤ allocation_size`.
9. No aliasing between two live descriptors (checked via `base_off` interval tree).
10. `version` is monotone and rejected if `> CURRENT`.
11. `flags` reserved bits are zero (forward-compat).
12. `ext[4]` is zero unless a documented extension bit is set.

If any of these is missing, the "12/12" claim is `UNATTESTED`.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

**Claim:** Neumaier summation for `dot(a, b)`.

**Tribunal analysis.** Neumaier's algorithm:

```
s = 0; c = 0
for i: t = s + x_i
       if |s| >= |x_i|: c += (s - t) + x_i
       else:            c += (x_i - t) + s
       s = t
return s + c
```

**Error bound (Rump, Ogita, Oishi 2008):** for `n` terms with unit roundoff `u`,

```
|computed - exact| ≤ (u + O(n u²)) · Σ|x_i|
```

i.e. **the result is as accurate as if computed in twice the working precision**, *provided no overflow/underflow occurs in the intermediate `t`*.

**Degeneracy at `step → ∞`:** if `|step| ≥ 10^10` and the dot product is used to form a *step-scaled* update, the compensated term `c` can itself overflow before `s + c` is formed. Neumaier does **not** protect against overflow — it only protects against *cancellation*. The Tribunal requires an explicit `isfinite(c)` guard and a fallback to scaled summation (e.g. `frexp`-based) when `|s| > DBL_MAX / 4`.

**Degeneracy at `step → 0` (subnormals):** if `step` is subnormal, `x_i = step * b_i` may flush to zero on hardware with FTZ/DAZ enabled (AVX-512 default under `-ffast-math`). Neumaier then returns `0` for a mathematically nonzero dot product. **This is a silent correctness failure.** The kernel must either (a) disable FTZ/DAZ via `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)` and `_MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_OFF)`, or (b) pre-scale by `2^k` and post-scale.

### 2.2 Subnormal audits at `-12`, `-14`

**Tribunal finding.** `-12` and `-14` are presumably exponents (i.e. `2^-12`, `2^-14`). For FP64, the subnormal threshold is `2^-1022`; for FP32, `2^-126`. Testing at `2^-12` and `2^-14` exercises **normal** numbers, not subnormals. **The audit is mislabeled.** Either:

- the exponents are *decimal* (`10^-12`, `10^-14`), in which case they are still normal for FP64 but subnormal for FP32 — clarify; or
- the audit is intended to test *near*-subnormal behavior, in which case the correct thresholds are `2^-1022`, `2^-1023`, `2^-1074` (FP64) and `2^-126`, `2^-127`, `2^-149` (FP32).

**Required:** publish the exact bit patterns tested and the expected/observed results.

### 2.3 Zero-copy PMTP validation

**Claim:** zero-copy validation of the 88-byte descriptor.

**Tribunal finding — `UNATTESTED`.** Zero-copy across FFI requires:

- `alignof(PmtpDescriptor) ≥ alignof(max_align_t)` on both sides;
- no `reinterpret_cast` that violates strict aliasing (use `std::bit_cast` or `memcpy`);
- lifetime: the producer must outlive the consumer, or the descriptor must be copied into a `std::shared_ptr` with a custom deleter.

Without these, "zero-copy" is a euphemism for "use-after-free waiting to happen."

### 2.4 AVX-512 / OpenMP

**Rule 27 violation risk.** AVX-512 is Intel-specific (and now AMD Zen 4+). A portable fallback (SSE2, NEON, scalar) **must** exist and be selected at runtime via `__builtin_cpu_supports`. If the kernel *requires* AVX-512, it violates Rule 27.

**OpenMP determinism.** `#pragma omp parallel for reduction(+:s)` is **not** bit-reproducible across thread counts. For a Neumaier sum, this is fatal: the compensation term depends on order. The Tribunal requires either:

- a fixed reduction tree (e.g. pairwise with fixed block size), or
- a documented `OMP_NUM_THREADS` pin in the contract.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 Safe SIMD

**Claim:** Rust 2021 Safe SIMD.

**Tribunal finding.** `std::simd` is **not stable** in Rust 2021 (it is nightly-only as of the 2024 edition). If the kernel uses `core::arch::x86_64::*` intrinsics, those are `unsafe`. The claim "Safe SIMD" is therefore either:

- using `wide` / `packed_simd` crates (which wrap `uns