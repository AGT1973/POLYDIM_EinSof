# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 63

A definitive arbitration is **not possible from the supplied record**: the six tribunal reports and the concrete V1350 kernel specifications are not included, and the publicly discoverable material does not establish that “POLYDIM V1350,” “PMTP,” or its 88-byte descriptor is a recognized published design. The technically defensible synthesis is therefore a **conditional architecture**, not a claim that all six models agreed or that the design has been experimentally proven.

## 1. Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For a point \(Z\in\mathrm{St}(d,k)\), a retraction must return a matrix satisfying

\[
R_Z(\xi)^\top R_Z(\xi)=I_k.
\]

The main candidates have materially different numerical behavior:

| Method | Mathematical guarantee | Extreme-step assessment |
|---|---|---|
| **Polar** | \(R_{\mathrm{polar}}(Z+\xi)=(Z+\xi)\big((Z+\xi)^\top(Z+\xi)\big)^{-1/2}\), when the input has full column rank | Best default for accuracy and nearest-orthogonal projection, but requires a stable inverse square root and rank protection |
| **Householder QR** | Produces an orthonormal \(Q\) through orthogonal transformations | Usually robust and efficient, but sign conventions, rank deficiency, and loss of smoothness at pivot/sign boundaries must be specified |
| **Cayley/Stiefel** | Orthogonality can be exact in exact arithmetic when implemented as a valid Cayley transform | **Not intrinsically stable for arbitrary extreme steps**; solving a poorly scaled system or forming large intermediate quantities can overflow, lose accuracy, or become ill-conditioned |

The literature identifies polar and QR retractions in the standard forms above, with different computational costs; it does not establish a universal numerical-stability theorem for a proprietary “Cayley V1350” implementation.[5]

### Arbitration

The strongest defensible result is:

1. **Do not guarantee Cayley superiority for extreme steps.**
2. For \(|\mathrm{step}|\ge 10^{10}\), scale before forming products:
   \[
   \alpha=\max(1,\|\xi\|),\qquad \widehat{\xi}=\xi/\alpha.
   \]
3. Use a **rank-revealing, backward-stable QR or polar fallback** when conditioning, overflow, or residual checks fail.
4. Accept the result only if
   \[
   \|Q^\top Q-I\| \le \tau_{\mathrm{orth}}
   \]
   and the computation reports no overflow, NaN, singular solve, or rank-deficiency violation.
5. Make the output deterministic by fixing column-sign conventions and reduction order.

Thus, the SOTA guarantee should be stated as:

> **Conditional orthogonality guarantee:** if the selected factorization completes without numerical exception and its residual test passes, the returned matrix is orthogonal to the declared tolerance. No implementation can honestly guarantee stable finite-precision behavior for every input with step magnitude \(10^{10}\) or larger without assumptions on scaling, rank, precision, and overflow handling.

Cayley may remain preferable for a restricted, well-scaled regime where its linear solve is demonstrably well-conditioned. It is not the universal extreme-step winner.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering alone does **not** provide memory reclamation or a complete RCU protocol. Release publication ensures that prior writes become visible before the published pointer or version; acquire consumption ensures that subsequent reads observe the published state. The Linux memory-barrier documentation describes these one-way ordering guarantees and the usual acquire/release pairing.[14]

A correct snapshot protocol needs all of the following:

### Writer

1. Construct an immutable descriptor or immutable payload.
2. Publish the pointer/version with **release** semantics.
3. Retire the old object only after a completed grace period.

### Reader

1. Enter an RCU/QSBR read-side critical section.
2. Load the published pointer/version with **acquire** semantics.
3. Validate the descriptor’s generation, checksum, or sequence field if the design requires torn-read detection.
4. Read the immutable payload.
5. Exit the read-side critical section or report a QSBR quiescent state.

RCU publication requires ordering the data before the pointer, and readers require an ordered dereference; reclamation additionally requires waiting for pre-existing readers to finish.[1] QSBR specifically depends on readers periodically announcing quiescent states, and its correctness is application-dependent.[3][10]

### Exact guarantee that can be made

With:

- atomic publication of the descriptor pointer or version,
- release publication,
- acquire consumption,
- immutable payload after publication,
- correct reader registration,
- correct RCU/QSBR grace-period tracking,
- and reclamation only after that grace period,

the design can guarantee:

> A reader that successfully acquires generation \(g\) observes a self-consistent immutable snapshot associated with \(g\), and the associated storage is not reclaimed until all readers that could have acquired or retained it have passed through the required grace period.

It **cannot** guarantee:

- wait-free reads,
- freedom from torn fields if fields are independently non-atomic and concurrently modified,
- reclamation safety from acquire/release alone,
- correctness when a reader fails to report quiescence,
- or cross-device coherence merely because the descriptor is 88 bytes.

The 88-byte size is an ABI/layout constraint, not a synchronization proof. The descriptor should therefore include explicit alignment, atomic-width, padding, endian, version, and ownership rules. If it crosses CUDA, host C++, Rust, or XLA boundaries, its wire representation should be treated as a stable serialized ABI rather than as an arbitrary language-native struct.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared identically by all five environments. Host C++20 and Rust provide language-level atomic semantics; CUDA provides host/device and device-scope synchronization mechanisms; XLA represents operations through compiler-level effects and may reorder or fuse computations; Triton exposes lower-level GPU operations whose exact ordering depends on the generated target and scope.

Consequently, “multi-silicon conformance” must mean **observational conformance**, not identical instruction sequences.

The required conformance contract is:

- identical descriptor byte layout and versioning;
- explicitly defined ownership and lifetime;
- atomic publication at the correct scope;
- acquire/release mapping validated separately for host, device, and host–device paths;
- no assumption that a compiler barrier is a hardware barrier;
- deterministic numerical tolerances for retractions;
- explicit behavior for NaN, infinity, overflow, rank deficiency, and unsupported precision;
- litmus tests on every target architecture;
- randomized differential tests against a high-precision reference;
- stress tests with delayed readers, preemption, concurrent writers, and forced reclamation attempts.

A compiler barrier alone is insufficient for hardware ordering; RCU publication and dereference require suitable compiler and hardware ordering.[1][13] Likewise, QSBR correctness depends on timely quiescent-state announcements rather than solely on atomic loads and stores.[3][10]

## Definitive arbitration

The mathematically strongest defensible V1350 specification is:

1. **Retraction:** use a scaled Cayley path only when its solve and residual checks pass; otherwise fall back to backward-stable Householder QR or polar retraction. Do not claim unconditional Cayley stability at extreme step sizes.
2. **Snapshot publication:** publish immutable descriptors with release semantics and consume them with acquire semantics.
3. **Reclamation:** require a separately proven RCU/QSBR grace-period protocol; acquire/release is necessary for visibility but insufficient for lifetime safety.
4. **ABI:** define the 88-byte descriptor as an explicit byte-level ABI with fixed offsets, alignment, atomic fields, versioning, and endian rules.
5. **Cross-platform guarantee:** claim conformance only after target-specific litmus, layout, numerical, and reclamation tests pass.
6. **Failure semantics:** any failed residual, invalid generation, unsupported atomic scope, overflow, NaN, or missed quiescent-state report must produce a defined failure or fallback—not silent success.

Accordingly, the exact architectural guarantee should be phrased as:

> V1350 provides **conditional numerical orthogonality**, **acquire/release snapshot visibility**, and **grace-period reclamation safety** under explicitly stated rank, scaling, atomic-scope, registration, and quiescence assumptions. It does not provide unconditional extreme-step stability, automatic memory reclamation, or universal cross-silicon equivalence solely from the Cayley formula, an 88-byte layout, or acquire/release annotations.