# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 151

I cannot produce a valid **Cycle 151 arbitration** from the available evidence: the eight models’ actual findings, the six V1350 kernel specifications, and the PMTP memory model were not provided, and public search results do not identify a verifiable “POLYDIM V1350” or “PMTP 88-byte Descriptor” specification. The available PolyDiM results concern a PDE library, not this architecture.[1][2]

What can be stated rigorously from established numerical and concurrency principles is:

## 1. Cayley–Stiefel retraction under extreme steps

No retraction method can be guaranteed stable merely because the step satisfies \(|\mathrm{step}|\ge 10^{10}\). For a skew-symmetric generator \(A\), the Cayley map is

\[
Q=(I-\tfrac12 A)^{-1}(I+\tfrac12 A),
\]

and is orthogonal when the inverse exists. However:

- Its computation can be ill-conditioned when \(I-\tfrac12 A\) is poorly conditioned.
- Forming \(A\) directly from an enormous step can overflow or lose the directional information through scaling and rounding.
- Stability depends on norm scaling, factorization quality, conditioning, precision, and residual checks—not on the Cayley formula alone.
- Householder QR is generally the stronger default for orthogonalization because it is backward stable; polar decomposition can provide a high-quality nearest-orthogonal factor but requires a robust implementation and may be more expensive.

A defensible architectural guarantee would therefore be:

\[
\|Q^\top Q-I\| \le c\,u\,\kappa_{\mathrm{alg}},
\]

subject to finite inputs, bounded intermediate values, a specified floating-point model, and a failed-status result when conditioning or overflow checks are violated. An unconditional guarantee for arbitrary \(|\mathrm{step}|\ge10^{10}\) is not mathematically supportable.

The preferred design is to normalize or rescale the step before constructing the generator, use QR or a scaled polar fallback when the Cayley solve is ill-conditioned, and validate the orthogonality residual.

## 2. PMTP descriptor barriers and RCU/QSBR isolation

Acquire/release operations alone do **not** establish complete RCU/QSBR snapshot isolation.

A sound publication protocol requires, at minimum:

1. Fully initialize immutable descriptor contents.
2. Publish the descriptor pointer or generation using **release** semantics.
3. Readers load the publication state with **acquire** semantics before dereferencing the descriptor.
4. Readers enter a read-side critical section before obtaining the snapshot.
5. Writers retire old descriptors only after the relevant grace period.
6. Reclamation must not occur while any reader can still hold the descriptor.

The key invariant is:

\[
\text{reader dereference} \prec \text{reader quiescence}
\prec \text{writer reclamation}.
\]

For QSBR, each participating reader must report quiescent states correctly; a release store by the writer cannot compensate for a reader that fails to announce quiescence. The 88-byte size has no inherent memory-ordering significance. It affects alignment, packing, cache-line interaction, and atomic-field layout, but it does not itself confer atomicity or isolation.

A defensible guarantee is therefore **publication visibility plus grace-period-safe reclamation**, not “Acquire/Release gives snapshot isolation” in isolation. The descriptor ABI must also specify alignment, field offsets, ownership, generation validation, ABA handling, and whether any field is independently atomic.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single cross-platform memory or execution model that makes an implementation automatically conformant across all five environments.

The architecture must define a portable abstract contract, then provide backend-specific realizations:

- **C++20:** use the C++ memory model for host-side atomics and lifetime; do not assume host atomics imply device ordering.
- **Rust:** use `Ordering::Acquire`, `Release`, or `AcqRel` only with a formally defined ownership and lifetime protocol; `unsafe` code must preserve those invariants.
- **CUDA:** distinguish compiler, thread-block, device, and system scopes; a device-level atomic is not automatically equivalent to a system-wide release/acquire protocol.
- **Triton:** establish ordering through the operations and synchronization guarantees actually supported by the target backend; source-level similarity to C++ atomics is insufficient.
- **XLA:** treat operations as graph computations subject to compiler transformations unless the chosen operation explicitly provides the required ordering or collective semantics.

The portable conformance target should be expressed as observable invariants:

\[
\text{publish} \rightarrow \text{acquire} \rightarrow
\text{consistent immutable snapshot} \rightarrow
\text{grace period} \rightarrow \text{reclaim}.
\]

Each backend passes only if litmus tests demonstrate those invariants under its own execution scope, including reordered execution, concurrent publication, delayed readers, repeated generations, and reclamation races.

## Arbitration

On the evidence available, the only technically defensible ruling is:

- **Cayley:** not unconditionally superior under extreme steps; use scaling, conditioning checks, and a QR/polar fallback.
- **PMTP barriers:** Acquire/Release are necessary for publication visibility but insufficient for RCU/QSBR reclamation safety without reader registration, quiescent-state tracking, and grace periods.
- **Multi-silicon conformance:** cannot be claimed from source-level portability; it requires backend-specific ordering proofs and litmus-test validation.
- **Exact guarantees:** no unconditional numerical-stability, snapshot-isolation, or cross-silicon-conformance guarantee can be formulated without the missing kernel definitions, descriptor schema, memory scopes, and the eight model reports.

The search results provide only general RCU/QSBR documentation and unrelated PolyDiM material; they do not substantiate the named V1350 kernels or the tribunal findings.[3][4]