# PERPLEXITY SONAR-PRO SOTA AUDIT — POLYDIM V1350 (2026-10-04)

The three designs are **promising but not sufficient as stated**. The Woodbury Cayley path is usually preferable for \(D\gg K\), but its stability depends on how the small Sylvester systems and the final solve are formed. The 88-byte descriptor removes raw-pointer relocation errors, not all segmentation faults or synchronization hazards. “Zero-vendor-lock” dispatch is achievable only at the **front-end/IR and capability-detection layers**; it cannot guarantee identical kernels, performance, or semantics across CUDA, TPU, Trainium, ROCm, XPU, and CPUs.

## 1. Cayley–Woodbury versus spectral eigendecomposition

Let \(X\in\mathbb R^{D\times K}\), \(X^\top X=I\), and let the Cayley update be written in the standard form

\[
Y(t)=\left(I-\frac{t}{2}W\right)^{-1}
      \left(I+\frac{t}{2}W\right)X,
\]

where \(W^\top=-W\) and \(W\) has rank at most \(2K\). A low-rank factorization \(W=UV^\top\) reduces the large solve to a \(2K\times 2K\) system through Sherman–Morrison–Woodbury. This changes the dominant cost from dense \(D\times D\) linear algebra to approximately

\[
O(DK^2+K^3)
\]

work and \(O(DK)\) storage, which is the correct asymptotic regime for \(D\ge 10^5\), \(K\le64\). Low-rank Woodbury implementations of Cayley retractions are used specifically for this \(O(DK^2)\) scaling.[5][11]

### Is the proposed scaling globally stable?

No—not automatically.

Your scaling

\[
s=\max(1,|t|),\qquad \tau=\frac{t}{s},\qquad |\tau|\le1
\]

is useful because it prevents the small system from containing coefficients of magnitude \(10^{10}\) or larger. However, it does **not** by itself guarantee a uniformly well-conditioned computation.

For a skew-symmetric \(W\), the eigenvalues are \(i\omega_j\), so the exact Cayley matrix has singular values

\[
\left|\frac{1+i(t/2)\omega_j}{1-i(t/2)\omega_j}\right|=1.
\]

Thus the exact transform is norm-preserving for every finite real \(t\). In exact arithmetic, the large-step limit is well defined:

\[
\lim_{|t|\to\infty}
\left(I-\frac{t}{2}W\right)^{-1}
\left(I+\frac{t}{2}W\right)
=
-I
\]

on \(\operatorname{range}(W)\), while it is \(+I\) on \(\ker(W)\). The limiting operator is therefore a reflection-like orthogonal map, not an ill-conditioned mathematical object.

The numerical issue is different:

- Forming \(tB\), \(tC\), or \(tW\) directly can cause overflow, cancellation, or loss of relative accuracy.
- The Woodbury core can become poorly scaled if the low-rank factors are not equilibrated.
- Forming \(I+\alpha V^\top U\) with \(\alpha=t/2\) can suffer cancellation when \(|\alpha|\|V^\top U\|\gg1\).
- Solving the two Sylvester equations independently can amplify errors if \(G\) is nearly nonnormal or if its symmetric part is not positive definite.
- A mathematically orthogonal Cayley transform can lose orthogonality because the computed small solve is not backward stable.

For the Sylvester operator

\[
\mathcal L_G(C)=GC+CG,
\]

the relevant conditioning is

\[
\kappa(\mathcal L_G)
=
\|\mathcal L_G\|\,\|\mathcal L_G^{-1}\|.
\]

If \(G\) is symmetric positive definite with eigenvalues \(\lambda_i>0\), then

\[
\operatorname{spec}(\mathcal L_G)
=
\{\lambda_i+\lambda_j\}_{i,j},
\]

and, in the spectral norm,

\[
\kappa_2(\mathcal L_G)
=
\frac{2\lambda_{\max}(G)}
     {2\lambda_{\min}(G)}
=
\kappa_2(G).
\]

Therefore the Sylvester solve is well behaved when \(G\) is well conditioned and positive definite. But if \(G\) is indefinite, nearly singular, or merely nonsymmetric, the sums \(\lambda_i+\lambda_j\) can approach zero even though \(G\) itself is nonsingular. In that case the Sylvester equation can be intrinsically ill-conditioned.

### Large-\(|t|\) asymptotics

For a generic reduced system of the form

\[
(I+\alpha H)z=b+\alpha c,\qquad \alpha=t/2,
\]

the large-step limit is obtained by dividing by \(\alpha\):

\[
(\alpha^{-1}I+H)z=\alpha^{-1}b+c.
\]

As \(|\alpha|\to\infty\), this approaches

\[
Hz=c.
\]

A direct formulation using \(I+\alpha H\) may therefore be badly scaled even though the limiting problem is well posed. A robust implementation should switch representations:

- **Moderate steps:** solve \(I+\alpha H\).
- **Large steps:** solve \((\alpha^{-1}I+H)z=\alpha^{-1}b+c\).
- **Near-singular \(H\):** use rank-revealing QR, SVD, or a regularized/pseudoinverse path.
- **Very large steps:** use the exact limiting Cayley operator on the range and nullspace components where that decomposition is available.

The proposed \(s\)-scaling is a useful first step, but it is not equivalent to this complete large-\(|t|\) treatment.

### Does spectral `eigh(H)` provide better conditioning?

Not universally.

If \(H\) is symmetric, eigendecomposition gives

\[
H=Q\Lambda Q^\top,
\]

and the shifted solve becomes elementwise:

\[
z_i=\frac{r_i}{1+\alpha\lambda_i}.
\]

This is attractive because:

- the eigenvectors are orthogonal;
- the condition number is transparent;
- large-\(\alpha\) limits can be evaluated as \(1/(\alpha\lambda_i)\);
- no nonnormal eigenvector conditioning occurs.

However, the shifted system is singular whenever

\[
1+\alpha\lambda_i=0.
\]

For a genuine skew-symmetric Cayley matrix, the analogous factors are complex \(1\pm i\alpha\omega_i\), whose magnitudes never vanish. Replacing that structure by a real symmetric \(H\) can introduce artificial poles unless \(H\) is precisely the correct symmetric reduced operator.

For \(K\le64\), `eigh` is computationally cheap: \(O(K^3)\) is negligible relative to the \(O(DK^2)\) tall-skinny operations. It can be the more reliable choice when:

- \(H\) is truly symmetric;
- repeated updates reuse the same \(H\);
- the spectrum is needed for step-size control;
- eigenvalues are clustered near a dangerous shift;
- the implementation uses a stable symmetric eigensolver and avoids explicitly forming ill-scaled inverses.

But it is not inherently more stable than a backward-stable QR solve. For a single small dense system, pivoted QR or a stable symmetric-indefinite factorization is often preferable to explicitly forming \(H^{-1}\) or eigenvalue reciprocals.

### Recommendation

Use a **hybrid algorithm**:

1. Construct the low-rank factors with orthogonalization or equilibration.
2. Solve the reduced problem with QR/SVD by default.
3. Use `eigh` only when the reduced operator is provably symmetric and spectral information is useful.
4. For \(|t|\) beyond a threshold based on machine precision and \(\|H\|\), use the scaled large-step formulation.
5. Monitor:
   \[
   \|Y^\top Y-I\|_2,\qquad
   \frac{\|r\|_2}{\|A\|_2\|z\|_2+\|b\|_2},
   \]
   and the estimated condition number of the reduced system.
6. Fall back to QR/SVD or a polar/QR retraction when the reduced solve is poorly conditioned.

Thus, **Woodbury is the right performance choice**, but the stated scaling alone is not a proof of global numerical stability. A correctly implemented spectral route can improve diagnostics and large-step handling, but it is not automatically superior.

## 2. The 88-byte pointer-free PMTP descriptor

The descriptor is structurally appropriate:

```text
<4sHHQQQQQBB6x4Q
```

It contains identifiers and offsets rather than process-local addresses. Resolving a payload as

\[
\text{address}=\text{mapped\_base}+\text{byte\_offset}
\]

avoids the central ASLR problem: a pointer serialized by one process is generally invalid in another process. Offset-based shared-memory designs are recommended for this reason, together with explicit bounds checking.[10]

However, pointer elimination does **not** fully eliminate segmentation faults. Remaining failure modes include:

- `segment_id` referring to the wrong mapping;
- stale or recycled `buffer_id`;
- generation-counter wraparound;
- integer overflow in
  \[
  \text{byte\_offset}+\text{byte\_length};
  \]
- an offset that is aligned incorrectly for the declared dtype;
- a shape whose product exceeds `byte_length`;
- a corrupted or malicious descriptor;
- a segment being unmapped while a reader still uses it;
- inconsistent metadata publication;
- ABI disagreement about endianness, dtype codes, or shape interpretation;
- truncation or resizing of the backing file;
- use-after-reclamation.

The descriptor therefore needs a validation procedure before dereference:

\[
0\le o\le L,\qquad
0\le \ell\le L-o,
\]

where \(L\) is the mapped segment length, together with checks that

\[
\prod_i \text{shape}_i \times \text{sizeof(dtype)}
\le \text{byte\_length}.
\]

The `magic`, `version`, and `encoded_size` fields are useful, but they are integrity markers, not memory safety. Add a checksum or authenticated integrity field if descriptors can be corrupted or supplied by an untrusted process.

### Does it support lockless RCU/QSBR across processes?

Not by itself.

RCU and QSBR require a reclamation protocol, not merely a pointer-free record. A writer may publish a new snapshot, but it may reclaim the old buffer only after proving that every reader that could have observed the old generation has exited its read-side critical section. QSBR defines a quiescent state as a point at which a reader no longer holds a reference to shared data; reclamation is safe only after all readers have reported the relevant quiescent state.[14]

A cross-process design needs at least:

- a process-shared reader registry;
- a per-reader epoch or generation announcement;
- acquire/release publication semantics;
- a writer-side retired-list;
- a reclamation scan;
- crash and abandonment handling;
- protection against PID reuse;
- generation validation on every acquisition;
- a defined policy for readers that disappear without reporting quiescence.

A typical protocol is:

1. Reader enters by loading the published descriptor with acquire semantics.
2. Reader announces the observed epoch.
3. Reader validates `segment_id`, `buffer_id`, and `generation`.
4. Reader accesses the payload.
5. Reader clears or advances its announced epoch with release semantics.
6. Writer publishes a replacement descriptor.
7. Writer retires the old generation.
8. Writer reclaims it only after every active reader has passed the retirement epoch.

Across processes, C/C++ memory-model guarantees must be mapped onto actual interprocess atomics. Not every nominally atomic operation is safe across independently mapped regions on every platform, and lock-free does not mean crash-safe. You also need a process-shared robust mutex, futex/event mechanism, or equivalent for registration and recovery, even if the fast read path is lockless.

### Verdict

The descriptor **eliminates relocation-dependent raw pointers**, but it does not by itself provide:

- complete memory safety;
- lifetime safety;
- crash consistency;
- lockless cross-process reclamation;
- ABA protection;
- protection from malformed metadata.

It is a good wire format for PMTP, provided it is paired with bounds validation, generation/epoch discipline, process-shared atomics, and recovery rules.

## 3. Dynamic hardware dispatch

The proposed backend set spans different abstraction levels:

| Backend | Primary abstraction | Main limitation |
|---|---|---|
| CUDA Graphs | NVIDIA execution-graph capture and replay | NVIDIA-specific runtime and memory model |
| XLA/JAX HLO | Compiler IR and whole-program optimization | Static-shape and compiler-lowering constraints |
| Triton | Kernel DSL/compiler | Backend support and feature parity vary |
| AVX-512 C++20/Rust | CPU instruction-level implementation | ISA-specific and compiler-dependent |

These cannot be treated as interchangeable “drivers.” CUDA Graphs are an execution mechanism, HLO is an intermediate representation, Triton is a kernel authoring system, and AVX-512 is an ISA target. Portability is therefore best expressed as a layered contract:

\[
\text{mathematical operation}
\rightarrow
\text{portable IR}
\rightarrow
\text{backend lowering}
\rightarrow
\text{hardware-specific execution}.
\]

XLA uses HLO as a statically shaped tensor computation graph, and StableHLO is intended as a portable IR; nevertheless, portable representation does not imply portable performance because TPU, GPU, and CPU lowerings require different layouts, fusion decisions, and tiling strategies.[9][13] Triton likewise provides a higher-level tile-oriented kernel model, but remains a kernel authoring system rather than a universal binary or semantic compatibility layer.[8]

### What can be vendor-neutral?

A practical vendor-neutral contract can standardize:

- tensor shapes and strides;
- dtype and accumulation policy;
- aliasing rules;
- synchronization semantics;
- error behavior;
- determinism level;
- numerical tolerance;
- workspace requirements;
- graph mutability;
- supported reductions and atomics.

The following should remain backend-specific:

- kernel launch geometry;
- memory layouts;
- asynchronous execution details;
- graph capture restrictions;
- collective implementations;
- tensor-core or matrix-engine use;
- compiler flags and autotuning;
- device-specific numerical modes.

For the Stiefel workload, the portable core should expose operations such as:

\[
X^\top Z,\qquad
ZG,\qquad
X C,\qquad
\text{small }K\times K\text{ or }2K\times2K\text{ solves},
\]

rather than forcing every backend to implement the same monolithic Cayley kernel. The tall-skinny products dominate at large \(D\), while the reduced solve is small enough to run on the host or device depending on launch overhead and batching.

### Dispatch design

Use capability-based dispatch rather than vendor-name dispatch:

```text
capabilities:
  dtype support
  matrix-engine support
  graph capture
  asynchronous memcpy
  atomics
  deterministic reductions
  maximum shared memory
  preferred tile sizes
  compiler availability
```

Then select among:

1. CUDA Graph path for stable, repeatedly replayed NVIDIA workloads.
2. XLA/StableHLO path for compiled static-shape TPU/Trainium-style execution.
3. Triton path for custom GPU kernels where the target backend supports the required features.
4. AVX-512 C++ or Rust path for CPU execution.
5. A conservative reference path using BLAS/LAPACK or vendor-neutral kernels.

“Zero vendor lock” should mean that the **API and numerical contract** do not depend on one vendor. It cannot mean that the implementation has no vendor-specific code, because optimal use of CUDA Graphs, TPU matrix units, ROCm/XPU kernels, and AVX-512 requires target-specific lowering.

### Numerical portability warning

The Cayley update is especially sensitive to reduction order and small-system solves. Across backends, expect differences from:

- fused multiply-add;
- tensor-core lower precision;
- nonassociative reductions;
- fast-math transformations;
- different QR/eigensolver implementations;
- flush-to-zero behavior;
- asynchronous error timing.

Define tolerances in terms of manifold and solve residuals, for example:

\[
\|Y^\top Y-I\|_F
\le c\,u\,\operatorname{poly}(D,K),
\]

and require a backend-specific backward-error bound for the reduced solve. Bitwise reproducibility should be an optional mode, not assumed.

## Overall assessment

- **Cayley Woodbury:** correct asymptotic choice for \(D\gg K\), but the proposed \(s=\max(1,|t|)\) scaling is not a global stability guarantee. Add large-step reformulation, conditioning checks, stable QR/SVD fallback, and orthogonality monitoring.
- **88-byte PMTP descriptor:** successfully removes raw serialized pointers and ASLR relocation hazards, but it does not by itself guarantee memory safety or cross-process reclamation. Add bounds validation, generation/epoch checks, process-shared synchronization, and crash recovery.
- **Dynamic dispatch:** feasible as a capability-driven layered architecture, not as literal implementation uniformity. Keep a portable numerical contract above backend-specific CUDA, XLA, Triton, and AVX-512 lowerings.