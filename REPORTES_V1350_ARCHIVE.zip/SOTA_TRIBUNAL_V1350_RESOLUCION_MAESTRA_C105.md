# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 105

The available evidence does **not** substantiate a real, publicly documented “POLYDIM V1350” release, six-kernel specification, or the six Tribunal models’ individual findings. Therefore, no defensible arbitration can declare a proven V1350 SOTA implementation. What can be stated rigorously is a set of **conditional architectural guarantees** based on numerical linear algebra, C++20 memory semantics, RCU/QSBR theory, and cross-backend portability requirements.

## Arbitration

| Issue | Defensible finding | Arbitration |
|---|---|---|
| Cayley–Stiefel vs. Householder/Polar QR for \(|\text{step}|\ge 10^{10}\) | A Cayley transform preserves orthogonality algebraically when evaluated accurately, but extreme scaling makes its linear solve and skew-generator construction vulnerable to overflow, cancellation, conditioning problems, and implementation-dependent solver behavior. QR and polar methods also require scaling, but Householder QR is generally the strongest default for backward stability; polar retraction gives a geometrically natural orthogonal factor but needs a stable matrix-sign/SVD/iterative implementation. | **Reject any unconditional claim that Cayley is more stable at extreme steps.** Use scaled Cayley only with explicit conditioning checks and fallback to Householder QR or a robust polar method. |
| 88-byte PMTP descriptor barriers | Acquire/release operations can order publication and observation of immutable snapshot metadata, but they do not automatically make an 88-byte object atomically transferable. A descriptor must have a separately atomic publication mechanism—typically an atomic pointer, index, sequence number, or packed version—and reclamation must obey RCU/QSBR grace-period rules. | **Acquire/release is necessary but not sufficient.** Snapshot isolation requires publication ordering plus lifetime protection and a precise reclamation protocol. |
| CUDA/XLA/Triton/C++20/Rust conformance | These systems differ in execution, synchronization, aliasing, atomics, floating-point contraction, layout, and compilation guarantees. Source-level similarity is not semantic equivalence. | **Bitwise cross-silicon identity cannot be guaranteed by a common algorithm alone.** Guarantee only a defined contract—shape, layout, synchronization, numerical tolerance, and ownership—and validate each backend independently. |

## 1. Extreme-step Stiefel retraction

For \(X\in\mathrm{St}(n,p)\), a Cayley update commonly has the form

\[
Y=\left(I-\frac12 W\right)^{-1}
  \left(I+\frac12 W\right)X,
\qquad W^\top=-W.
\]

In exact arithmetic, the Cayley factor is orthogonal because \(W\) is skew-symmetric. That establishes **algebraic orthogonality**, not floating-point stability.

At \(|\text{step}|\ge 10^{10}\), the important quantity is not the nominal step alone but the norm and conditioning of the scaled generator:

\[
A=\frac12\,\text{step}\,W.
\]

A robust implementation must:

- scale \(A\) before forming products;
- avoid explicitly forming \(I\pm A\) when their scales differ substantially;
- solve the structured linear system rather than invert it;
- monitor residuals and loss of orthogonality;
- reject nonfinite intermediates;
- use iterative refinement where appropriate;
- fall back to QR or polar retraction when conditioning or residual thresholds fail.

Householder QR is the strongest general-purpose fallback because it has well-established backward-stability properties when implemented with stable reflectors and appropriate scaling. The QR retraction is

\[
Y= \operatorname{qf}(X+\Delta),
\]

where \(\operatorname{qf}\) denotes the orthonormal \(Q\) factor. Polar retraction is

\[
Y=(X+\Delta)
\left(I+\Delta^\top\Delta\right)^{-1/2},
\]

assuming \(\Delta\) is tangent at \(X\). It has attractive geometric properties, but the inverse square root must itself be computed robustly.

The available literature supports the narrower statement that canonical Cayley and polar retractions can have favorable local conditioning under their respective assumptions, while also identifying singular or ill-defined inverse cases when a relevant matrix has eigenvalue \(-1\).[1] It does **not** support a universal theorem that Cayley dominates Householder QR for arbitrary extreme steps.

### Definitive kernel policy

For a production V1350-style kernel:

1. Use a scaled Cayley path only within a certified conditioning region.
2. Compute an orthogonality defect
   \[
   \varepsilon_{\mathrm{orth}}
   =\|Y^\top Y-I\|,
   \]
   and a solve residual
   \[
   \varepsilon_{\mathrm{solve}}
   =\| (I-A)Y-(I+A)X\|.
   \]
3. Fall back to Householder QR if either defect exceeds a configured tolerance.
4. Optionally use polar retraction when a high-quality symmetric orthogonalization is required.
5. Never advertise unconditional stability for \(|\text{step}|\ge 10^{10}\); advertise **certified acceptance or deterministic fallback**.

Thus, the mathematically superior synthesis is not “Cayley always wins.” It is a **guarded hybrid retraction**:

\[
\boxed{
\text{scaled Cayley}
\;\xrightarrow{\text{certification}}\;
\text{Householder QR fallback}
}
\]

with polar retraction as an optional accuracy-oriented path.

## 2. PMTP 88-byte descriptor and snapshot isolation

An 88-byte descriptor cannot be assumed to be atomically loaded or stored merely because its size is fixed. On many platforms it exceeds the width of naturally lock-free atomic objects. The correct publication pattern is:

```cpp
struct Descriptor {
    // 88 bytes of immutable state
};

struct Published {
    std::atomic<const Descriptor*> ptr;
};
```

The writer:

1. constructs a new immutable descriptor privately;
2. initializes all fields;
3. publishes its pointer with `store(..., std::memory_order_release)`;
4. retires the old descriptor only after the applicable grace period.

The reader:

1. enters an RCU read-side critical section or QSBR epoch;
2. loads the pointer with `load(std::memory_order_acquire)`;
3. reads the immutable descriptor;
4. exits the read-side section.

The release/acquire pair guarantees that descriptor initialization sequenced before publication becomes visible to a reader that observes the published pointer. It does **not** by itself guarantee:

- atomic transfer of all 88 bytes;
- protection against reclamation;
- consistency if fields are subsequently mutated;
- ordering across unrelated devices or runtimes;
- correctness of a non-atomic in-place update.

For lock-free replacement, the descriptor should be immutable after publication. If updates require mutation, use either:

- copy-and-publish with a new descriptor;
- a seqlock-style version protocol;
- a mutex or platform-supported wider atomic primitive.

For ABA resistance, use a generation counter, tagged pointer, or monotonically increasing publication sequence. For reclamation, use a real RCU/QSBR grace period: no retired descriptor may be freed until every reader that could have observed it has passed through a quiescent state.

### Exact guarantee

The strongest valid guarantee is:

> If the descriptor is fully initialized before a release publication, readers acquire the published pointer, descriptors are immutable after publication, and reclamation waits for a valid RCU/QSBR grace period, then every reader observes one fully initialized descriptor version and cannot access a reclaimed version.

That is **snapshot isolation for object versions**, not transactional atomicity across multiple descriptors or arbitrary fields.

## 3. Multi-silicon and multi-compiler conformance

CUDA, XLA, Triton, C++20, and Rust do not share one memory or numerical execution model.

Conformance must therefore be specified at several layers:

### Functional contract

All implementations must agree on:

- tensor shapes and strides;
- alignment requirements;
- descriptor layout and endianness;
- ownership and lifetime rules;
- valid synchronization domains;
- accepted NaN, infinity, and overflow behavior;
- output tolerances.

### Numerical contract

Unless deterministic modes are explicitly enabled, do not require bitwise identity. Require instead bounds such as

\[
\|Y_{\text{backend}}-Y_{\text{reference}}\|
\le
\tau_{\mathrm{abs}}
+
\tau_{\mathrm{rel}}\|Y_{\text{reference}}\|.
\]

For Stiefel outputs, also require

\[
\|Y^\top Y-I\|\le \tau_{\mathrm{orth}}.
\]

The tolerances must be calibrated separately for precision, backend, and silicon family.

### Memory contract

C++20 acquire/release semantics govern C++ objects and atomics; they do not automatically establish device-wide ordering for CUDA or Triton operations. Device publication requires the relevant device atomic and fence primitives, while host/device visibility requires the appropriate runtime synchronization or mapped-memory protocol.

Rust can express ownership and aliasing constraints, but `unsafe`, atomics, FFI, GPU buffers, and external allocators remain governed by their actual synchronization rules. Rust’s type system does not prove correctness of an incorrectly implemented GPU or FFI protocol.

### Compiler contract

XLA and Triton may fuse, reorder, tile, or change precision. CUDA compilation may use fused multiply-add, fast-math transformations, or architecture-specific instruction selection. To claim reproducibility, specify:

- compiler and runtime versions;
- target architecture;
- fast-math and contraction settings;
- deterministic-reduction policy;
- seed and initialization rules;
- permitted tolerance;
- descriptor ABI version.

## Definitive SOTA architecture

The strongest defensible architecture is:

1. **Retraction layer:** guarded, scaled Cayley implementation with residual certification.
2. **Fallback layer:** Householder QR for failed certification; robust polar retraction for selected accuracy-critical paths.
3. **Publication layer:** immutable 88-byte descriptors published through an atomic pointer or index, not by assuming 88-byte atomicity.
4. **Ordering layer:** release publication and acquire observation, with device-specific fences where applicable.
5. **Reclamation layer:** RCU/QSBR grace periods plus generation tagging when ABA is possible.
6. **ABI layer:** one versioned, endian-defined, alignment-checked descriptor schema.
7. **Conformance layer:** property-based tests for orthogonality, residuals, publication visibility, reclamation safety, and numerical tolerance on every backend.
8. **Failure layer:** explicit rejection or fallback for overflow, nonfinite values, ill-conditioned solves, stale generations, unsupported atomics, and failed tolerance checks.

The exact guarantees should be stated narrowly:

- **Numerical:** accepted outputs meet residual and orthogonality bounds; rejected Cayley steps use a specified fallback.
- **Memory:** acquire/release orders immutable descriptor publication; RCU/QSBR prevents reclamation during protected reads.
- **Portability:** every backend conforms to the same observable contract, but not necessarily the same instruction sequence or bit pattern.
- **Concurrency:** no guarantee exists for in-place mutation of the 88-byte descriptor without an additional synchronization protocol.
- **Extreme-step behavior:** no unconditional stability guarantee; only bounded behavior under certification and fallback.

The Tribunal finding that most closely matches these conditions should prevail. Any finding asserting unconditional Cayley superiority, atomicity of the complete 88-byte descriptor, or automatic CUDA/XLA/Triton/C++20/Rust equivalence should be rejected as stronger than the available mathematics and platform memory models support.