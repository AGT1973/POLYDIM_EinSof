# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 137)

**POLYDIM V1350 – Multi‑File Adversarial SOTA Audit (Cycle 137)**  
*High Tribunal of Mathematical and Systems Sages – PhD‑level Review*  

---

## 1. Audit Scope & Methodology  

| Item | What is examined | Core references |
|------|------------------|-----------------|
| **Numerical Degeneracy** | Behaviour of every kernel when the *step* scalar → ∞ (|step| ≥ 10¹⁰) and when *step* → 0 (sub‑normal regime).  We analyse floating‑point overflow/underflow, loss of significance, and stability of the underlying algebraic transforms. | IEEE‑754‑2008, Higham *Accuracy and Stability of Numerical Algorithms* (2nd ed.) |
| **Rule 22 (Zero‑Length 1‑D Tokens)** | The 88‑byte `PMTP` descriptor must be *exactly zero* for any inter‑agent 1‑D communication.  We inspect the construction, serialization, and any implicit padding that could violate the “zero‑token” invariant. | POLYDIM specification § 22, bit‑wise zero‑check methodology. |
| **Rule 27 Silicon Contract** | Identify any *vendor‑lock* (hard dependence on a single silicon vendor) introduced by APIs, binary formats, or compile‑time flags.  We consider the whole stack: Python, C++, Rust, CUDA, XLA, Triton. | POLYDIM specification § 27, “silicon‑agnostic” design principles. |
| **Mathematical Proofs & Condition‑Number Bounds** | Provide concise derivations (or proof sketches) of stability claims, asymptotic condition numbers, and any hidden ill‑conditioning that may surface at extreme *step* values. | Perturbation theory (Stewart 1990), matrix analysis (Horn & Johnson), condition‑number literature. |
| **FFI Hardening** | Recommendations for safe foreign‑function‑interface (FFI) boundaries: alignment, size checks, exception safety, bounds‑checking on descriptors, and mitigation of *unwinding across language boundaries*. | “Safe Interoperability of Rust and C” (Rust RFC 2585), “C‑to‑Python ABI guidelines” (PEP 384). |

All analysis below assumes **strict IEEE‑754‑2008 compliance** (binary64 FP64) on every execution unit (Silicon, GPU, TPU, Trainium) and the *exact* 88‑byte layout defined as:

```
struct PmtpTensorDescriptor {
    uint16_t version;          // 2
    uint16_t type;             // 2
    uint64_t rows;             // 8
    uint64_t cols;             // 8
    uint64_t stride;           // 8
    uint64_t offset;           // 8
    uint64_t flags;            // 8
    uint8_t  padding[6];      // 6 (must be zero)
    uint32_t reserved;        // 4 (must be zero)
};
```

The binary layout (`<4sHHQQQQQBB6x4Q`) matches the above structure byte‑for‑byte, guaranteeing *zero‑padding* (`6x`) and *reserved* fields (the final `4Q` are forced to zero for 1‑D messages).  

---

## 2. Target‑by‑Target Audit  

### 2.1 `kernel_orchestrator_v1350.py` – Multi‑Silicon HardwareProbe & PMTP Allocation  

| Aspect | Findings |
|--------|----------|
| **Numerical Degeneracy** | The orchestrator only *dispatches* tensors; it never performs arithmetic.  The only numeric operation is the **generation of the 88‑byte binary descriptor** from Python integers.  Python’s `int` → `struct.pack` conversion is exact up to 2⁶³‑1; values beyond that are truncated to unsigned 64‑bit, potentially causing silent overflow if a user supplies a `step` that feeds into `rows`/`cols`.  For `|step| ≥ 10¹⁰` there is no overflow because the descriptor fields store *counts* (≤ 2⁶³‑1), not the scalar step.  **Sub‑normal step** does not affect the descriptor. |
| **Rule 22** | The orchestrator zero‑initialises the 6‑byte padding (`6x`) and the three 4‑byte reserved fields (`4Q`).  However, the *serialization path* uses `struct.pack("<4sHHQQQQQBB6x4Q", ...)` where the first 4‑byte field (`magic`) is a literal string `"PMTP"`.  For a **1‑D inter‑agent channel** the spec demands the *entire* descriptor be zero.  The current implementation does **not** zero‑out `magic` when `mode == "1‑D"`.  *Violation*: an 88‑byte token containing the magic string is transmitted, breaking Rule 22. |
| **Rule 27** | The orchestrator relies on **`pmtplib`** (a proprietary “Silicon‑aware” library) that internally queries `lspci` and vendor‑specific registers (Intel UCSI, AMD SMU).  This creates a *soft vendor lock* – the orchestrator refuses to run when the detected silicon is not Intel Xeon S.  **Non‑compliant**. |
| **Mathematical Proofs** | The **allocation algorithm** is a simple *first‑fit* on a fixed‑size slab.  A proof of *conflict‑free* allocation follows from the invariant that the sum of allocated sizes ≤ slab size (by construction).  Since step does not appear, the proof trivially holds for any step magnitude. |
| **Condition‑Number** | Not applicable – no matrix solve. |
| **FFI Hardening** | - Ensure `struct.pack` is called with **explicit `& 0xFFFFFFFFFFFFFFFF`** masks on each integer to reject overflow‑induced truncation.  <br>- Add a *guard* before emitting a 1‑D token: `if mode == "1‑D": descriptor = b'\x00'*88`.  <br>- Replace the proprietary `pmtplib` with a pure‑Python shim that queries **`/proc/cpuinfo`** and **`/sys/class/drm/card*/device/vendor`**, which are vendor‑agnostic. |

**Recommendations for TARGET 1**  

1. **Rule 22 Fix** – Insert a branch that overwrites the descriptor with zeros for 1‑D communication, or expose a `zero_token=True` flag.  
2. **Rule 27 Remediation** – Abstract hardware queries behind an interface (`HardwareProbe`) that can be implemented for any vendor; ship a *fallback* implementation that simply reports “unknown”.  
3. **FFI Hardening** – Validate descriptor size (`len(buf) == 88`) and alignment before passing to downstream C/Rust kernels; raise a Python `ValueError` on mismatch.  

---

### 2.2 `kernel_cpp_v1350.cpp` – AVX‑512 / OpenMP Core, Neumaier Compensated Dot‑Products  

| Aspect | Findings |
|--------|----------|
| **Numerical Degeneracy** | The kernel computes **Neumaier‑compensated dot products**: `s += a[i]*b[i];  c += ((a[i]*b[i]) - y) - t;` where `t` holds the compensation.  This algorithm is **exact** for binary64 when the intermediate product does not under‑/overflow.  - **Large step (`|step| ≥ 10¹⁰`)**: the *scaled* vectors may contain entries ≈ 10¹⁰·x.  FP64 can represent up to 1.8e308, so overflow is *not* a concern.  However, the **product** of two 10¹⁰‑scaled entries may reach 10²⁰, still far from overflow.  The **relative error** is bounded by `|c| ≤ ϵ·|s|` where ϵ ≈ 2⁻⁵³.  Hence the dot product stays stable.  - **Sub‑normal step** (`step ≈ 2⁻¹⁰⁰`): products can fall below the normal range (≈ 2⁻¹⁰⁰).  Neumaier still works, but **catastrophic cancellation** can happen when the sum of many sub‑normals is added to a normal term, because the compensation `c` may be sub‑normal and later *rounded to zero*.  This yields a *loss of the correction* and effectively reduces the algorithm to a naive sum. |
| **Rule 22** | The C++ kernel receives a `PmtpTensorDescriptor` via a **C‑FFI** function `extern "C" void launch(const void* descriptor)`.  The descriptor is *memcpy’d* into a local struct without validation.  For 1‑D messages the upstream Python zeroes the descriptor, but the C++ code checks **`if (desc.flags & FLAG_NONZERO) abort();`** where `FLAG_NONZERO = 0x1`.  The flag field is part of the descriptor and is *always* zero for a 1‑D message.  However, **no explicit *zero‑token* test exists**; if any stray bit in the padding (the 6‑byte gap) is non‑zero due to a compiler extension, the flag may be mis‑interpreted.  Using `#pragma pack(push, 1)` guarantees no padding, but some compilers silently insert **tail padding** to align the struct to 8 bytes, causing the final 4 bytes (`reserved`) to be *uninitialized* when `memcpy` copies only 84 bytes.  This can violate Rule 22. |
| **Rule 27** | The kernel uses **Intel‑specific AVX‑512 intrinsics** (`_mm512_mul_ps`, `_mm512_add_ps`).  The code path falls back to scalar loops if `__AVX512F__` is not defined, but the build system **forces** `