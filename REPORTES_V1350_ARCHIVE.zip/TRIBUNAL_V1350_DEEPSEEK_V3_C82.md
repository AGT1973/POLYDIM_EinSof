# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 82)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 82 · Six-Component Adversarial Review

**Preliminary note on evidentiary posture.** The Tribunal has been presented with *architectural claims* (file names, descriptor layouts, algorithm names) rather than source artifacts. Where a claim is falsifiable from the descriptor alone (e.g., the 88-byte struct), we audit it directly. Where the claim is algorithmic (Neumaier, Cayley, Woodbury), we audit the *stated* mathematics and flag any place where the claim is under-determined by the evidence. We do not certify what we cannot see; we do certify what the stated mathematics *forces*.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor arithmetic (the only hard evidence in the brief)

Claimed layout: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `H H` | 4 |
| five `Q` | `Q Q Q Q Q` | 40 |
| two `B` | `B B` | 2 |
| pad | `6x` | 6 |
| four `Q` | `Q Q Q Q` | 32 |
| **Total** | | **88** |

**Verdict: 88 bytes confirmed.** Alignment is 8 (largest member `Q`), so `struct.calcsize` returns 88 with no trailing pad. This is a *correct* fixed-width descriptor and satisfies the Rule 22 byte-budget.

### 1.2 Rule 22 — "Zero 1D tokens in inter-agent communication"

The descriptor is a **flat, fixed-width, self-describing record**. It carries no variable-length payload, no length-prefixed strings, no JSON, no 1-D token stream. **Compliant by construction** — *provided* the orchestrator never appends a variable trailer (e.g., a pickled dict, a `bytes` blob, a `str`). The brief does not show the serialization path; the Tribunal **conditionally certifies** and demands the following invariant be asserted at every IPC boundary:

```python
assert len(buf) == 88 and struct.unpack_from("<4sHHQQQQQBB6x4Q", buf)[0] == MAGIC
```

### 1.3 Numerical degeneracy at `step → ∞` and `step → 0`

The orchestrator itself is a *dispatcher*; the degeneracy question is inherited by the kernels it dispatches. However, two orchestrator-level hazards are real:

- **`step` as a `Q` (unsigned 64-bit).** If `step` is stored as `Q`, then `step → 0` is representable but `step < 0` is not, and `step ≥ 2^64` wraps. If the orchestrator ever computes `step = t * dt` in Python and packs it into `Q`, a negative or fractional step will raise `struct.error` (good) or silently truncate (bad, if `int()` is applied first). **Recommendation:** store `step` as `q` (signed) or as a fixed-point `Q` with an explicit scale field, and reject `step == 0` at the dispatcher with a typed error before any kernel sees it.
- **`step → ∞`:** the orchestrator must not pass `step` into any kernel that computes `step * B` or `step / scale` without a pre-flight `isfinite` and magnitude check. A `Q` cannot hold `10^10` in a `float` sense, but if the orchestrator uses `float` internally and packs the *bit pattern* into `Q`, the kernel will read garbage. **Recommendation:** the descriptor should carry a `scale` field (one of the five `Q`s) and the orchestrator should enforce `|step| ≤ 2^53` before packing.

**Verdict:** Rule 22 **compliant**; numerical degeneracy **not proven safe** without the packing path.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška summation gives a *forward* error bound

$$
|\hat{S} - S| \;\le\; \big(2u + O(nu^2)\big)\sum_{i=1}^{n}|x_i y_i|,
$$

where $u = 2^{-53}$ for FP64. The **condition number** of the dot product is

$$
\kappa_{\text{dot}} = \frac{\sum_i |x_i y_i|}{\big|\sum_i x_i y_i\big|},
$$

so Neumaier is *backward-stable* and *forward-accurate to $\kappa_{\text{dot}} \cdot u$*. This is the correct tool for the stated use.

**Degeneracy at `step → ∞`:** if the kernel forms `step * B` before the dot product, and `step ~ 10^10`, then `step * B` may overflow to `inf` for `B` near `DBL_MAX`, and Neumaier's compensation term will itself become `inf - inf = NaN`. **The compensation does not save you from overflow.** Required guard:

```cpp
if (!std::isfinite(step) || std::abs(step) > 1e10) return ERR_STEP_RANGE;
```

**Degeneracy at `step → 0` (subnormals):** the brief cites audits at `-12` and `-14` (presumably exponents). For FP64, subnormals live below $2^{-1022} \approx 2.2\times10^{-308}$. A "subnormal audit at -12/-14" is *not* a subnormal audit — those are ordinary normal numbers. **The Tribunal flags this as a likely mislabel.** If the intent was FP32 subnormals ($2^{-126}$), then `-12/-14` are still normal. Either the audit is misnamed, or the exponents refer to something else (e.g., log-magnitudes of a different quantity). **Demand clarification.**

### 2.2 Zero-copy PMTP validation

Zero-copy requires that the 88-byte descriptor be *read directly from the mapped buffer* without a `memcpy` into a host struct. In C++20 this is legal only if:

1. The buffer is 8-byte aligned (guaranteed by `Q` alignment).
2. The struct is `std::is_trivially_copyable` and `std::is_standard_layout`.
3. No strict-aliasing violation: reading a `Q` from a `char*` requires `std::bit_cast` or `memcpy` in C++20 (the old `reinterpret_cast` UB is not fixed by `-fno-strict-aliasing` in portable code).

**Recommendation:** use `std::bit_cast<PmtpDescriptor>(std::array<std::byte,88>{...})` or `memcpy` into a local — the compiler will elide it. "Zero-copy" in the strict sense is a *lie* in C++20 unless the descriptor is accessed field-by-field via `std::launder` on a properly-typed pointer.

### 2.3 AVX-512 / OpenMP

No vendor lock (Intel-specific ISA, but the code is portable C++20; AMD Zen 4/5 support AVX-512). **Rule 27 compliant** at the source level, *conditional* on a runtime `__builtin_cpu_supports("avx512f")` dispatch and a scalar fallback.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as an FFI safety barrier

This is **the single most important claim in the brief**, and it is **correct in spirit but incomplete in letter**.

- `panic = unwind` ensures that a Rust panic does *not* abort the process, so a C++ caller can catch it — **but only if the panic does not cross the FFI boundary as an unwind**. Since Rust 1.71, `extern "C"` functions abort on unwind by default (`-C panic=abort` semantics at the boundary). To actually catch, the Rust side must use `extern "C-unwind"` and the C++ side must compile with `-fexceptions` and catch `...`.
- **Recommendation:** every `extern "C"` entry point must be wrapped:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> i32 {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => ERR_PANIC,
    }
}
```

This converts unwind into a *return code*, which is the only portable FFI contract. `panic = unwind` alone is **not** a safety barrier; it is a *precondition* for one.

### 3.2 Neumaier in Rust

Rust's `f64` follows IEEE-754; `f64::mul_add` is a fused multiply-add and is *not* the same as Neumaier. Neumaier must be implemented explicitly. **No degeneracy beyond the C++ case.**

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C)]` with `u64` fields gives 8-byte alignment and 88-byte size, matching the C++ layout. **Cross-language ABI compatible** *provided* both sides use `#[repr(C)]` / `#pragma pack` consistently and the `6x` pad is explicit. **Recommendation:** add a `const _: () = assert!(std::mem::size_of::<PmtpTensorDescriptor>() == 88);` and a `#[cfg(test)]` round-trip against the Python `struct` format.

### 3.4 Rule 27

Rust 2021 + `std::simd` (nightly) or `wide`/`packed_simd` crates are vendor-neutral. **Compliant.**

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in $\mathbb{R}^{2K \times 2K}$

The Cayley retraction on the Stiefel manifold $St(n,p)$ is

$$
Y(\alpha) = \big(I - \tfrac{\alpha}{2}W\big)^{-1}\big(I + \tfrac{\alpha}{2}W\big)Y, \qquad W = A Y^\top - Y A^\top,
$$

where $A$ is the ambient gradient. This is a **second-order retraction** and is *unconditionally* well-defined for any $\alpha$ because $I - \frac{\alpha}{2}W$ is invertible for all real $\alpha$ when $W$ is skew-symmetric (eigenvalues of $W$ are purely imaginary, so $1 - \frac{\alpha}{2}i\lambda \neq 0$).

**Degeneracy at `step → ∞`:** as $\alpha \to \infty$, $Y(\alpha) \to -Y$ (the antipode). The retraction is *bounded* — no overflow — but the *step direction* is lost. **This is a silent failure mode:** the optimizer will oscillate between