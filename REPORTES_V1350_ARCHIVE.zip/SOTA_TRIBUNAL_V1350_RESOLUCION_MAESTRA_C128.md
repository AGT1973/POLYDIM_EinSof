# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 128

No verifiable public record of the **“POLYDIM V1350,” six kernels, Cycle 128, or the eight Tribunal reports** was found in the available search results. Therefore, a definitive arbitration of those model outputs would be unjustified. The results identify general Stiefel-manifold and RCU/QSBR literature, but not an implementation specification or benchmark proving the claimed guarantees.[2][6][10]

The strongest technically defensible synthesis is conditional on the kernels implementing the following contracts.

## 1. Extreme-step Stiefel retraction

For \(X\in\mathrm{St}(n,p)\), \(X^\ast X=I\), and a tangent update \(\Xi\), the Cayley map is typically

\[
X^+ =
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

where \(W^\ast=-W\). This structure-preserving form is designed to remain on the Stiefel manifold in exact arithmetic.[2][4][6]

However, **\(|\mathrm{step}|\ge 10^{10}\) does not establish stability**. In floating-point arithmetic, stability depends on the scaled tangent matrix, conditioning, overflow behavior, solve accuracy, and whether the implementation forms large intermediate values. A mathematically sound implementation should use:

- step normalization or bounded parameterization;
- a stable skew-symmetric construction \(W^\ast=-W\);
- a factorization or iterative solve that avoids explicit inversion;
- residual verification of
  \[
  \|{X^+}^\ast X^+-I\|;
  \]
- finite-value checks and deterministic fallback.

The defensible ranking is therefore:

| Method | Extreme-step claim that can be justified |
|---|---|
| Cayley/Stiefel retraction | Structure-preserving in exact arithmetic; numerically stable only with scaling, stable solves, and residual checks |
| Householder QR | Usually robust for orthogonalization, but requires sign conventions and can suffer from overflow or loss of accuracy if inputs are badly scaled |
| Polar retraction | Strong geometric projection, but usually requires an SVD or inverse square root and therefore has higher computational cost and its own conditioning limits |

The correct arbitration is **not** “Cayley is unconditionally superior.” It is:

> Cayley is preferable when the kernel exploits skew structure and stable solves; Householder QR is the safest general fallback; polar retraction is the most direct nearest-point projection but not automatically the most stable or economical implementation.

The exact guarantee should be stated as a tolerance contract, for example:

\[
\|{X^+}^\ast X^+-I\| \le \tau_{\mathrm{orth}},
\]

provided the input is finite, the solve is successful, and the condition estimate remains below a specified bound. No unconditional guarantee for arbitrary \(10^{10}\)-scale steps follows from the retraction formula alone.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte descriptor can be made an ABI-stable metadata record, but its size does **not** itself provide memory safety or snapshot isolation. The required protocol is:

1. Fully initialize an immutable descriptor payload.
2. Publish its pointer or generation using **release** semantics.
3. Readers load the published pointer/generation using **acquire** semantics.
4. Readers enter a QSBR/RCU read-side critical section before dereferencing.
5. Writers retire replaced descriptors only after every pre-existing reader has passed a quiescent state.
6. Reclamation must occur after a completed grace period.

Formally, if publication \(P\) uses release and observation \(A\) uses acquire, then

\[
P \;\text{release}\;\rightarrow\; A \;\text{acquire}
\]

establishes the required happens-before relation for the initialized fields. It does **not** by itself protect the object from reclamation. Lifetime safety additionally requires the RCU/QSBR grace-period condition.

Thus the exact guarantee is:

> Readers observe either a completely initialized old descriptor or a completely initialized new descriptor, and no descriptor is reclaimed while an RCU/QSBR-protected reader may still access it.

That guarantee requires immutable-after-publication fields, correct atomic alignment, no mixed atomic/non-atomic access to concurrently modified state, and a reclamation implementation whose QSBR progress rules are explicitly satisfied. The search results support release operations in QSBR implementations, but they do not validate the PMTP layout or a complete protocol for it.[10][13]

Acquire/release is also insufficient if the descriptor contains device-visible memory or crosses a host/device boundary. CUDA, XLA, and Triton may require explicit stream, event, collective, or device-fence semantics in addition to language-level atomics.

## 3. Multi-silicon conformance

A single abstract algorithm can be portable across CUDA, XLA, Triton, C++20, and Rust, but **identical architectural guarantees do not arise automatically**. The implementations have different execution and memory models:

- **C++20:** guarantees are defined by the C++ memory model and atomic operations.
- **Rust:** gives stronger language-level aliasing and data-race protections when unsafe code correctly upholds its contracts, but hardware ordering and FFI/device behavior remain implementation-specific.
- **CUDA:** host atomics, device atomics, scopes, fences, streams, and unified memory have distinct semantics.
- **Triton:** kernel-level synchronization and supported atomics are constrained by compiler and target capabilities.
- **XLA:** operations may be reordered, fused, replicated, or lowered differently; an HLO-level ordering assumption must be represented explicitly in the program semantics.

The proper conformance target is **observational equivalence**, not source-level equivalence. Each backend should be tested against a reference model for:

- descriptor publication and reclamation;
- snapshot consistency;
- orthogonality residual;
- NaN, infinity, overflow, and failed-solve behavior;
- alignment and 88-byte layout;
- endianness and field offsets;
- concurrent readers and writers;
- deterministic fallback behavior.

A valid conformance claim would require at least:

\[
\text{all backends}
\Rightarrow
\begin{cases}
\text{same descriptor ABI},\\
\text{same allowed snapshot outcomes},\\
\|X^\ast X-I\|\le\tau_{\mathrm{orth}},\\
\text{no use-after-grace-period},\\
\text{defined failure behavior}.
\end{cases}
\]

Without those tests, “multi-silicon conformance” is an assertion rather than an architectural guarantee.

## Arbitration

The mathematically strongest defensible position is:

- **Retraction:** use a scaled Cayley method as the primary fast path, Householder QR as the robust fallback, and polar/SVD only when nearest-point projection or higher geometric fidelity is required.
- **Descriptor protocol:** require release publication, acquire observation, RCU/QSBR read-side protection, and grace-period reclamation; descriptor size alone is irrelevant to correctness.
- **Portability:** define one language-independent abstract state machine and prove or test each backend against it; do not assume that C++20 acquire/release semantics automatically transfer to CUDA, Triton, or XLA.
- **Guarantees:** state bounded, testable tolerances and preconditions—not unconditional claims for arbitrary extreme steps, arbitrary hardware, or unspecified compiler lowerings.

Accordingly, no “definitive SOTA” or exact unconditional architectural guarantee can be awarded to the alleged Tribunal consensus from the available evidence. The available material supports the underlying mathematical techniques—Cayley retractions preserve Stiefel structure in exact arithmetic and are established optimization tools—but does not substantiate the V1350-specific kernels, their eight-model arbitration, or their claimed cross-platform guarantees.[2][4][6]