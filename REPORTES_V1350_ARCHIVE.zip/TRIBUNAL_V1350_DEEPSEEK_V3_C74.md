# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 74)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 74 · Multi-File Adversarial SOTA Review

**Preliminary note on scope.** The Tribunal has been asked to audit six artifacts whose *source* has not been attached to this docket — only their architectural claims. I will therefore audit the **claims as stated**, flag every place where the claim is either (a) mathematically under-determined, (b) numerically fragile, or (c) in tension with Rules 22/27, and I will mark each finding with a **confidence class**:

- **[P]** = provable from the stated claim alone
- **[C]** = conditional on the standard interpretation of the named primitive
- **[?]** = requires source inspection; the claim as written is insufficient

I will not fabricate line numbers or invent code that was not provided. Where the Tribunal demands "proofs," I give the proof *of the stated property*, not of an unseen implementation.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let me first do the byte arithmetic, because Rule 22 hinges on it.

| Field | Type | Size |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**[P]** The struct is exactly 88 bytes *iff* the compiler applies no trailing padding. Under the native `struct` module with `=` (standard size, no alignment) this holds. Under `@` (native) it does **not** — `Q` requires 8-byte alignment, so `4sHH` (8 bytes) is fine, but the trailing `4Q` after `BB6x` lands at offset 56, which is 8-aligned, so actually native also yields 88. **However**, on a 32-bit ABI where `Q` is 8-aligned but the struct base is 4-aligned, `@` can insert 4 bytes of leading pad. **Recommendation:** pin the format string to `=` and add a `static_assert(sizeof(...) == 88)` in C++/Rust and `assert(ctypes.sizeof(...) == 88)` in Python. This is the single most important Rule-22 hardening item.

**[P]** The `6x` pad is *load-bearing*: it aligns the trailing `4Q` block to offset 56. If any future field is inserted before the pad, the descriptor silently grows and Rule 22 is violated at the ABI boundary without a compile error in Python. **Recommendation:** replace `6x` with a named `_reserved: [u8;6]` and a version tag in one of the `H` fields.

### 0.2 Rule 22 — "Zero 1D tokens"

The rule as stated is ambiguous. Two readings:

- **(R22-a)** No 1-D (flat) token arrays may cross the inter-agent boundary; all payloads must be the 88-byte PMTP descriptor plus out-of-band tensor handles.
- **(R22-b)** No scalar/1-D *control* tokens; only structured descriptors.

Under **(R22-a)**, the audit question is: does any of the six kernels serialize a flat buffer into the descriptor's `4Q` region? The `4Q` block is 32 bytes = 4 × u64. If those are *pointers* (device addresses / handles), Rule 22 is satisfied. If they are *inline scalars* (e.g., `step`, `scale`, `M`, `K`), then the descriptor is carrying 1-D token state and Rule 22 is violated. **This is the #1 unresolved question in the docket.** I cannot certify Rule 22 compliance without seeing how the `4Q` block is populated in each of the six files.

### 0.3 Rule 27 — Silicon Contract / vendor lock

I will score each target on a 0–3 scale: 0 = hard vendor lock, 3 = fully portable.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe
**[C]** A probe that enumerates CPU/GPU/TPU/NPU is portable *only if* it degrades gracefully when a backend is absent. The failure mode to audit: does the probe **raise** on missing CUDA, or **return a capability bitmask**? If it raises, the orchestrator is vendor-locked at import time. **Recommendation:** probe must return a frozen `CapabilitySet` and never raise; the orchestrator selects the highest-priority *available* backend.

### 1.2 PmtpSlabAllocator
**[?]** "Slab" implies a pre-reserved arena. The numerical question: is the slab **zero-initialized**? If not, the first PMTP read of an uninitialized slot yields a descriptor whose `magic` may accidentally match `4s`, and the orchestrator will dispatch on garbage. **Recommendation:** `mmap(MAP_ANONYMOUS)` gives zero pages on Linux; `cudaMalloc` does **not** guarantee zero. Force `cudaMemsetAsync(slab, 0, ...)` on allocation.

### 1.3 12/12 physical conformance checks
**[?]** Without the list, I can only say: a 12-check suite that does not include **(i)** `sizeof(descriptor) == 88`, **(ii)** endianness of the `4Q` block, **(iii)** alignment of the slab base to 64 B (cache line) and 4 KB (page), and **(iv)** a round-trip `pack → unpack → pack` byte-equality test, is incomplete. **Demand:** publish the 12 checks.

### 1.4 Numerical degeneracy at the orchestrator layer
The orchestrator itself does no arithmetic, so `step → ∞` is not a degeneracy *here* — but it is a **dispatch** degeneracy: if `step` is stored in a `Q` field and the orchestrator computes `step * scale` in Python `int`, Python promotes to arbitrary precision and the downstream C++/Rust/CUDA kernels will **truncate** on cast to `double` or `int64`. **Recommendation:** the orchestrator must clamp `step` to the intersection of all backends' representable ranges *before* dispatch, and record the clamp in the descriptor's `B` flags.

**Rule 27 score: 2/3** (portable if probe is non-raising; otherwise 0/3).

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

Let $x, y \in \mathbb{R}^n$, and let $\hat{s}$ be the Neumaier-compensated sum of $x_i y_i$ computed in IEEE-754 binary64 with unit roundoff $u = 2^{-53}$.

**Claim [P]:** Neumaier's algorithm satisfies
$$
|\hat{s} - x^\top y| \;\le\; \bigl(2u + O(nu^2)\bigr) \sum_{i=1}^n |x_i y_i| + O(u^2)\,|x^\top y|.
$$
This is the standard result (Neumaier 1974; Higham 2002, §4.3). The key point: the bound is **independent of $n$** to first order — that is the entire reason for using Neumaier over naive summation. **However**, the bound is *relative to $\sum |x_i y_i|$*, not to $|x^\top y|$. When $x^\top y \to 0$ by cancellation (the Stiefel/Cayley case!), the **relative** error blows up as $\sum|x_i y_i| / |x^\top y|$.

**This is the critical numerical finding for Target 2.** In a Cayley retraction, the denominator is $1 + \tfrac14 \|W\|_F^2$ and the numerator involves $A^\top B$ terms that can cancel. As `step → ∞`, $\|W\|_F \to \infty$, the denominator dominates, and the *relative* error of the compensated dot is fine. As `step → 0`, $W \to 0$, and the numerator's cancellation ratio can be $\sim 10^{16}$, at which point even Neumaier loses all significant digits. **Recommendation:** for `|step| < 2^{-20}`, fall back to the **exact** (Dekker/TwoProduct) dot product, or better, use the identity $\mathrm{cayley}(W) = I + 2W(I - \tfrac12 W)^{-1}$-style reformulations that avoid the cancellation.

### 2.2 Subnormal audits at $-12$ and $-14$

The exponents $-12$ and $-14$ are almost certainly **decimal** exponents ($10^{-12}$, $10^{-14}$), not binary. In binary64, the subnormal threshold is $2^{-1022} \approx 2.2\times 10^{-308}$. So $10^{-12}$ and $10^{-14}$ are **normal** numbers, not subnormal. **Finding [P]:** if the audit is checking "is this subnormal?", the answer is *no* for both, and the audit is mislabeled. If the audit is checking "does the compensated sum preserve relative accuracy at these magnitudes?", the answer depends on the *ratio* of terms, not the magnitude. **Demand:** clarify whether $-12/-14$ are decimal exponents, binary exponents, or log-magnitudes. If binary, $2^{-12}$ and $2^{-14}$ are also normal. The only way to hit subnormal is $\lesssim 2^{-1022}$.

### 2.3 Zero-copy PMTP validation
**[C]** Zero-copy requires that the C++ side receives a pointer into the slab and validates the 88-byte descriptor **in place**. The hazard: if the descriptor is `reinterpret_cast` from a `char*` that is not 8-aligned, the `Q` reads are UB on strict-alignment architectures (ARM64 with `-mno-unaligned-access`). **Recommendation:** validate alignment first (`(uintptr_t)p % 8 == 0`), then `memcpy` into an aligned local, then validate magic/version, then proceed. "Zero-copy" should mean *zero tensor copy*, not *zero descriptor copy*.

### 2.4 AVX-512 + OpenMP
**[C]** AVX-512 downclocking on Skylake-X is a *performance* degeneracy, not numerical. But `-ffast-math` (if enabled) **breaks Neumaier** by allowing reassociation. **Demand:** confirm `-fno-fast-math -ffp-contract=off` on the compensated kernels. If `-ffp-contract=fast`, FMA contraction changes the error bound from $2u$ to $u$ per term but also changes the *compensation* term's correctness — Neumaier's `t = s +