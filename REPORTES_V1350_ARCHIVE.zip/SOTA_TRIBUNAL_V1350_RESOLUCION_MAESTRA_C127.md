# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 127

I cannot produce a definitive arbitration of the eight Tribunal models or the six V1350 kernels from the information available. The public search results do not identify a verifiable “POLYDIM V1350” specification, kernel corpus, benchmark record, or the eight model reports; the identifiable “PolyDiM” project is a C++ library for polytopal discretization methods, which is not sufficient evidence for the architecture described.[1][2]

What can be stated rigorously from established numerical-analysis and concurrency principles is:

1. **Cayley/Stiefel retraction under extreme steps**

   A Cayley retraction is not automatically stable for \(\lvert \text{step}\rvert \ge 10^{10}\). Its computation typically involves solving a system such as

   \[
   \left(I-\frac{\alpha}{2}A\right)X
   =
   \left(I+\frac{\alpha}{2}A\right)Y,
   \qquad A^\mathsf{T}=-A.
   \]

   For very large \(\alpha\), stability depends on scaling, conditioning, factorization quality, and overflow/underflow handling. Orthogonality may be preserved algebraically while numerical accuracy is lost.

   Householder QR is generally the strongest baseline for robust orthogonalization. Polar decomposition can provide a high-quality nearest-orthogonal factor, but its implementation also requires a stable SVD, Newton–Schulz iteration, or equivalent scaling strategy. Therefore, no unconditional claim that Cayley is superior to Householder or polar QR is mathematically justified. A valid guarantee would require explicit bounds on backward error, residual orthogonality, conditioning, scaling, and finite-precision behavior.

2. **PMTP descriptor and RCU/QSBR semantics**

   An 88-byte descriptor size alone provides no memory-ordering guarantee. Snapshot isolation requires a protocol, not merely a layout. A conventional publication pattern is:

   \[
   \text{writer initializes snapshot}
   \;\xrightarrow{\text{release}}\;
   \text{publishes pointer/version},
   \]

   followed by:

   \[
   \text{reader acquires pointer/version}
   \;\xrightarrow{}\;
   \text{reads immutable snapshot}.
   \]

   Reclamation must occur only after every relevant reader has passed through a quiescent state or otherwise released its read-side protection. QSBR systems use quiescent-state reporting to determine when deferred objects can safely be reclaimed.[3][4]

   Acquire and release operations alone do not establish full RCU correctness if readers can retain pointers beyond the protected interval, if descriptors are reused prematurely, or if version publication and reclamation are not connected by a formally defined happens-before relation. The exact guarantee would need to specify atomic fields, alignment, ownership, lifetime, ABA protection, reader registration, grace-period completion, and whether device memory participates in the same memory model.

3. **CUDA, XLA, Triton, C++20, and Rust conformance**

   “Multi-silicon conformance” cannot be inferred from source-level similarity. CUDA, XLA, Triton, C++20 atomics, and Rust atomics have different execution and compilation models. In particular:

   - C++20 and Rust define host-language memory models, but neither automatically specifies CUDA device ordering.
   - CUDA memory scopes and fences must be mapped explicitly to the intended producer–consumer scope.
   - Triton and XLA may transform, fuse, reorder, or replicate operations unless the intermediate representation and synchronization constraints prohibit those transformations.
   - Floating-point reassociation, tensor-core use, denormal handling, and reduction order can prevent bitwise equivalence even when mathematical results are equivalent.
   - A portable guarantee must distinguish **functional equivalence**, **numerical tolerance**, **memory safety**, **ordering correctness**, and **bitwise reproducibility**.

The strongest defensible synthesis is therefore conditional:

- Use **scaled, pivoted Householder QR** as the reference orthogonalization path for extreme-step validation.
- Permit Cayley or polar paths only when they satisfy explicit residual and conditioning checks, with deterministic fallback to QR.
- Publish PMTP snapshots with release semantics and consume them with acquire semantics, but couple this with a formally specified RCU/QSBR grace-period protocol and lifetime/ABA protections.
- Define conformance through executable litmus tests, numerical error budgets, synchronization-scope tests, and cross-backend reference comparisons rather than by API correspondence.
- Claim guarantees only at the level actually proven: for example, orthogonality residual \(\|Q^\mathsf{T}Q-I\|\le\varepsilon\), snapshot immutability during a protected read section, and backend-specific numerical tolerance. An unconditional guarantee across all silicon and all steps \(\lvert\text{step}\rvert\ge10^{10}\) would not be justified without the missing specifications and Tribunal reports.