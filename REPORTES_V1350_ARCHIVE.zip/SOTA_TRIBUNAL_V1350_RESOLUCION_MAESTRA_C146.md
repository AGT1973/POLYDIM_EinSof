# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 146

The requested arbitration cannot be established as a factual SOTA result from the material available. I found no public, authoritative specification for **“POLYDIM V1350,” “PMTP 88-byte Descriptor,”** the six kernels, or the cited Cycle 146 tribunal reports; the public PolyDiM references instead describe a C++ library for polytopal discretization methods, not this architecture.[1][2] Therefore, no defensible comparison of Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM, and Perplexity findings—or exact guarantees attributed to them—can be made.

A technically valid arbitration would be:

## 1. Cayley retraction versus Householder and polar QR

For a Stiefel point \(X\in\mathrm{St}(n,p)\), a Cayley update of the form

\[
X_{+}=\left(I-\frac{\alpha}{2}A\right)^{-1}
       \left(I+\frac{\alpha}{2}A\right)X,
\qquad A^\mathsf{T}=-A,
\]

is orthogonality-preserving in exact arithmetic because the Cayley transform is orthogonal. That does **not** imply numerical stability for \(|\alpha|\ge 10^{10}\).

At such scales, the implementation must specify:

- scaling or range reduction for \(\alpha A\);
- conditioning and solution method for \(I-\frac{\alpha}{2}A\);
- overflow, underflow, NaN, and singularity behavior;
- reorthogonalization policy;
- floating-point error bounds and residual thresholds.

Householder QR is generally the strongest default for backward-stable orthogonalization. Polar decomposition can provide a high-quality nearest orthogonal/Stiefel factor, but its stability depends on the chosen algorithm—e.g., SVD, scaled Newton–Schulz, or eigensolver—and on conditioning. A Cayley method may be preferable for structure preservation and efficient small-rank updates, but it cannot be declared superior under extreme steps without a specified stabilized algorithm and measured error bounds.

**Defensible guarantee:** exact orthogonality for the mathematical transform only. A finite-precision guarantee requires a theorem or test contract such as

\[
\|X_{+}^{\mathsf T}X_{+}-I\|
\le C(n,p)\,u\,\kappa(\text{kernel}),
\]

plus explicit behavior when the bound is exceeded. No unconditional “stable for every \(|\text{step}|\ge10^{10}\)” claim is justified.

## 2. PMTP descriptor and Acquire/Release

Acquire/Release operations can establish ordering, but they do not automatically provide complete RCU or QSBR snapshot isolation.

A valid publication protocol normally requires:

1. The writer initializes the immutable descriptor and payload.
2. The writer publishes the pointer or generation with **release** semantics.
3. The reader loads the publication state with **acquire** semantics.
4. The reader announces a read-side epoch, hazard, or QSBR state according to the reclamation protocol.
5. The writer delays reclamation until all pre-existing readers have passed through a quiescent state or otherwise ceased protecting the object.

The critical distinction is:

- **Acquire/Release:** orders visibility of initialization and publication.
- **RCU/QSBR reclamation:** prevents reuse or destruction while readers may still hold references.

An 88-byte size and alignment alone provide no memory-safety or isolation guarantee. The architecture must define field offsets, atomic widths, alignment, ownership, versioning, lifetime rules, ABA protection, and the exact mapping of atomics to each target memory model. If a descriptor spans multiple independently updated words, a reader may observe a torn or mixed-generation snapshot unless the design uses immutable records, a sequence counter, double collection with validation, or a genuinely atomic publication unit.

**Defensible guarantee:** Acquire/Release is sufficient for publication visibility only when the object is immutable after publication and reclamation is separately coordinated. It is insufficient by itself to guarantee RCU/QSBR snapshot isolation.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single portable memory model spanning these systems. Their semantics differ in important ways:

- **C++20:** defines language-level atomic ordering and happens-before, subject to implementation and platform support.
- **Rust:** provides ownership and concurrency guarantees at the language level, but unsafe code, FFI, atomics, and device execution require separate contracts.
- **CUDA:** has host/device scopes, block/device/system synchronization domains, compiler reordering rules, and architecture-dependent details.
- **Triton:** exposes compiler- and backend-dependent synchronization and atomic behavior; source-level equivalence to C++ atomics cannot be assumed.
- **XLA:** is primarily an optimizing computation-graph/compiler abstraction; arbitrary pointer publication, reclamation, and RCU semantics are not automatically represented by ordinary tensor operations.

Consequently, “multi-silicon conformance” must be stated as a **refinement contract**, not assumed from matching source code. Each backend needs:

- an operational memory-model mapping;
- supported atomic sizes and scopes;
- alignment and layout assertions;
- synchronization primitives equivalent to the abstract protocol;
- litmus tests for publication, stale reads, torn reads, ABA, and reclamation;
- numerical tests for orthogonality and residuals;
- device-specific failure handling.

The strongest justified synthesis is therefore:

> The V1350 design may be specified as a mathematically orthogonality-preserving retraction plus a separately verified publication/reclamation protocol, with backend-specific implementations. It cannot presently be certified as uniformly superior to Householder/polar QR, cannot claim RCU/QSBR isolation from Acquire/Release alone, and cannot claim CUDA–XLA–Triton–C++20–Rust conformance without explicit mappings and cross-backend tests.

To produce a genuine Tribunal arbitration, the six kernel definitions, the eight model reports, descriptor layout, memory-ordering pseudocode, target architectures, and numerical acceptance criteria would need to be supplied.