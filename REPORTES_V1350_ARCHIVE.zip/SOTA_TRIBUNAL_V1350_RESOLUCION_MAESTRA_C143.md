# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 143

The available public search results do **not** contain the claimed “POLYDIM V1350,” “Cycle 143,” eight Tribunal reports, six kernel specifications, or a defined PMTP 88-byte descriptor ABI. The only identifiable POLYDIM result is an unrelated 2025 C++ library for polytopal discretization methods,[6] while the RCU result is a generic userspace QSBR implementation.[10] Therefore, a factual arbitration of the eight models or a definitive implementation guarantee cannot be established from the supplied evidence.

A mathematically defensible synthesis of the three technical questions is:

### 1. Cayley–Stiefel retraction under extreme steps

No retraction method can honestly guarantee stability for arbitrary \(\lvert\text{step}\rvert \ge 10^{10}\) without specifying scaling, conditioning, precision, and the exact update equation.

For a Stiefel matrix \(X\) with \(X^\top X=I\), a Cayley update commonly has the form

\[
X_{+}
=
\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)X,
\qquad A^\top=-A .
\]

In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists. In floating-point arithmetic, however, the solve can suffer severe loss of accuracy for large \(\tau\), especially when the skew operator is poorly scaled or nearly singular in the relevant representation. The correct guarantee is therefore conditional:

- **Cayley:** preserves the manifold structurally in exact arithmetic; finite-precision quality depends on a stable solve and scaling.
- **Householder QR:** generally offers strong backward stability for orthogonalization, but its result is a projection/retraction whose behavior depends on rank and pivoting conventions.
- **Polar retraction:** is the closest Frobenius-norm projection onto the Stiefel manifold and is often preferable when geometric fidelity is the priority, but it requires a matrix square-root or SVD/eigendecomposition and can be expensive or sensitive near rank deficiency.

For \(\lvert\tau\rvert\ge 10^{10}\), the superior architecture is **not** unconditional Cayley evaluation. It should use step normalization, overflow-safe parameterization, a stable factorization, residual checks, and a fallback to QR or polar projection when

\[
\|X_{+}^{\top}X_{+}-I\| > \varepsilon_{\mathrm{orth}}
\]

or when the linear solve reports inadequate conditioning. The exact guarantee should be stated as:

> The kernel guarantees orthogonality only up to a specified floating-point residual and only when the factorization succeeds; it does not guarantee stability for all extreme steps.

### 2. PMTP descriptor barriers and RCU/QSBR

Acquire/release operations alone do **not** automatically provide snapshot isolation. A valid RCU/QSBR protocol requires all of the following:

- The writer publishes a fully initialized immutable descriptor using a **release** store or release exchange.
- The reader obtains the descriptor pointer and associated generation/version using an **acquire** load.
- Readers announce entry into a read-side critical section before dereferencing the snapshot.
- Writers retire old descriptors only after every pre-existing reader has passed through a quiescent state or otherwise acknowledged a later grace-period epoch.
- Descriptor reclamation uses appropriate atomicity and lifetime rules; an acquire load does not make non-atomic concurrent mutation safe.

A robust publication pattern is conceptually:

\[
\text{initialize}(D_{\mathrm{new}})
\;\rightarrow\;
\text{store-release}(P,D_{\mathrm{new}})
\]

followed by reader-side:

\[
D \leftarrow \text{load-acquire}(P)
\;\rightarrow\;
\text{dereference}(D).
\]

The **88-byte size** has no inherent memory-ordering meaning. It may create alignment, padding, cache-line, or atomic-field hazards. The ABI must explicitly define field offsets, alignment, endianness, ownership, versioning, and which fields are atomic. If the descriptor is copied across devices or language boundaries, host-language memory order does not by itself establish CUDA, XLA, or device-agent ordering.

The strongest valid guarantee is:

> A reader that enters the protected read-side section before acquiring the published pointer observes a fully initialized immutable descriptor and remains safe from reclamation until it exits; later updates may be invisible to that reader.

That is snapshot consistency, not necessarily global linearizability.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

Cross-silicon conformance cannot be inferred from source-level similarity. These environments have different execution and memory models:

- **C++20 and Rust** provide language-level atomic semantics, but only for operations represented by their respective memory models.
- **CUDA** has distinct host, device, block, system, and peer-memory scopes; device atomics and fences must use the appropriate scope.
- **Triton** exposes a narrower and backend-dependent set of atomic and barrier operations.
- **XLA** may reorder, fuse, replicate, or lower operations unless the graph explicitly expresses the required side effects and ordering.

Accordingly, one portable descriptor protocol should be defined at the abstract level:

1. immutable payload;
2. atomic publication pointer or index;
3. generation counter;
4. reader registration/epoch announcement;
5. grace-period completion;
6. reclamation only after the grace period.

Each backend then needs a verified lowering of that protocol. “Acquire/release” must be mapped to a concrete scope and operation on every target. A host C++ release store cannot, by itself, guarantee visibility to a GPU kernel; similarly, a GPU fence cannot automatically establish ordering for unrelated host threads.

### Definitive arbitration

Given the absence of the eight alleged reports, the only supportable arbitration is:

- **Reject** any claim that Cayley is unconditionally superior to Householder or polar QR at steps of \(10^{10}\) or larger.
- **Accept** acquire/release as necessary publication primitives, but **reject** the claim that they alone guarantee RCU/QSBR snapshot isolation.
- **Reject** unconditional multi-silicon conformance unless each backend has an explicit memory-scope mapping, numerical-residual test, lifetime proof, and differential conformance suite.

The appropriate architectural contract is therefore **conditional and testable**, not absolute:

\[
\text{correctness}
=
\text{stable numerical update}
\land
\text{explicit publication ordering}
\land
\text{grace-period lifetime safety}
\land
\text{backend-specific memory-scope conformance}.
\]

No stronger “exact architectural guarantee” can be responsibly asserted without the missing kernel definitions, model reports, ABI layout, target architectures, precision requirements, and conformance-test results.