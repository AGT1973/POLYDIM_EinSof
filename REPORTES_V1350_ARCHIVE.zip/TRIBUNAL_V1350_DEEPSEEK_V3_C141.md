# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 141)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 141 · Six-Component Adversarial SOTA Review

**Tribunal posture.** We treat each artifact as a *claim* under adversarial falsification. Where the source is not in evidence, we audit the *specification as stated* and flag every place where the stated invariants are either (a) provably insufficient, (b) numerically degenerate in a stated limit, or (c) unverifiable without the actual bytes. We do not grant "SOTA" on assertion.

---

## 0. Cross-cutting findings (apply to all six targets)

### 0.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us byte-count the struct format string literally:

| Field | Format | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version, flags | `HH` | 4 |
| dims (4×) | `QQQQ` | 32 |
| strides (4×) | `QQQQ` | 32 |
| dtype, rank | `BB` | 2 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **112** |

**Finding 0.1 (BLOCKER).** The format string `<4sHHQQQQQBB6x4Q` is **112 bytes**, not 88. To hit 88 you must drop either the `6x` pad (→106) or reduce reserved to `2Q` (→96) or drop one `Q` from the dims/strides group. **The stated 88-byte invariant is arithmetically inconsistent with the stated format string.** Any "12/12 physical conformance check" that passes must be checking a *different* layout than the one documented. This is a Rule 22 violation at the schema level: the wire format is not self-consistent.

**Required remediation.** Publish the canonical `ctypes.sizeof` / `std::mem::size_of` / `sizeof(PmtpTensorDescriptor)` for each language and prove they are equal. Until then, cross-language FFI is undefined behavior.

### 0.2 Rule 22 — Zero 1D tokens

Rule 22 forbids 1D token streams in inter-agent communication. The 88-byte descriptor is a *fixed-width record*, which is compliant **only if** every field is a scalar or fixed-arity tuple. The `4Q` reserved block is fine; the `4s` magic is fine. **However**, if any component serializes variable-length metadata (e.g., CUDA Graph node lists, HLO module names, Triton autotune keys) into the reserved block, Rule 22 is violated. Audit each target's reserved-block usage.

### 0.3 Rule 27 — Silicon Contract / vendor lock

Rule 27 requires that no component *impose* vendor lock. We audit each target below. Preliminary: **Targets 4 and 5 are the highest-risk** (cuSOLVER, TPU/Trainium HLO). Target 6 is medium-risk (ROCm vs CUDA divergence).

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe

**Claim:** probes CPU/GPU/TPU/NPU and selects a backend.

**Adversarial finding 1.1.** A probe that *selects* a backend is a *policy* engine, not a *probe*. If the probe's decision is cached in the 88-byte descriptor's `flags` field (2 bytes = 16 bits), you have at most 16 backend states. Enumerate them. If the probe returns a *string* (e.g., `"cuda:0"`), Rule 22 is violated (1D token stream). **Demand:** the probe must return a `uint16` enum, and the mapping must be published.

### 1.2 PmtpSlabAllocator

**Claim:** slab allocator for PMTP tensors.

**Adversarial finding 1.2 (numerical).** Slab allocators are size-class based. If the 88-byte descriptor is the allocation unit, then `step → ∞` (|step| ≥ 10¹⁰) does not affect allocation, but `step → 0` (subnormal) does: a subnormal `step` stored in a `Q` (uint64) field is *not* a subnormal — it's an integer. **The descriptor cannot represent subnormal floats.** If `step` is meant to be a float, the format string is wrong. If it's an integer, then "subnormal audit (-12, -14)" in Target 2 refers to a *different* quantity. **Demand:** clarify whether `step` is `Q` (integer) or `d` (double). The current schema is ambiguous.

### 1.3 12/12 physical conformance checks

**Adversarial finding 1.3.** "12/12" is a *count*, not a *proof*. The Tribunal requires the 12 predicates to be published as executable assertions with witnesses. Without them, "12/12" is a marketing claim.

**Verdict on Target 1:** **CONDITIONAL FAIL** — schema inconsistency (0.1) propagates here; probe return type unspecified; subnormal semantics undefined.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

**Claim:** Neumaier summation for dot products.

**Mathematical audit.** Neumaier's algorithm maintains `(sum, c)` where `c` is the compensation. For a dot product `Σ aᵢbᵢ`, the error bound is:

$$|\text{fl}(\text{Neumaier}(a,b)) - a\cdot b| \le (2u + O(u^2)) \sum |a_i b_i| + O(u^2)|\sum a_i b_i|$$

where `u = 2⁻⁵³` for FP64. This is *not* the same as Kahan; Neumaier is *unconditionally* stable (Kahan is not, for non-monotone magnitudes). **Good choice.** But:

**Adversarial finding 2.1 (step → ∞).** If `step ≥ 10¹⁰` and the dot product is `step · B` (as in Target 4's Woodbury), then `Σ|aᵢbᵢ|` can overflow FP64 (`~1.8×10³⁰⁸`). Neumaier does **not** protect against overflow — it only compensates rounding. **Demand:** a pre-scaling step (`step/scale`) must be applied *before* the dot product, and the scale must be chosen so that `max|aᵢbᵢ| < 10³⁰⁰`. The claim "globally scaled Woodbury solve (M/scale) W = (step/scale) B" in Target 4 suggests this is done, but Target 2's C++ core must *enforce* it, not assume it.

**Adversarial finding 2.2 (step → 0, subnormals).** For `step` in the subnormal range (`< 2⁻¹⁰²²`), `aᵢbᵢ` products underflow to zero *before* Neumaier can compensate. The compensation term `c` is then also subnormal, and the final `sum + c` loses the compensation. **The "-12, -14" subnormal audit** presumably checks exponents -12 and -14 (i.e., `~2⁻¹²`, `~2⁻¹⁴`), which are *normal* doubles. **This is not a subnormal audit.** A true subnormal audit must test `step ∈ {2⁻¹⁰²², 2⁻¹⁰²³, ..., 2⁻¹⁰⁷⁴}`. **Demand:** publish the actual test vectors.

### 2.2 AVX-512 / OpenMP

**Adversarial finding 2.3 (Rule 27).** AVX-512 is Intel-specific. If the C++ core *requires* AVX-512 (not just uses it when available), it imposes vendor lock on Intel (or AMD Zen 4+). **Demand:** a scalar fallback path with identical numerical semantics (same Neumaier order, same FMA usage). Without it, Rule 27 is violated.

### 2.3 Zero-copy PMTP validation

**Adversarial finding 2.4.** "Zero-copy" implies the 88-byte descriptor is `memcpy`'d or `reinterpret_cast`'d. Given Finding 0.1 (112 vs 88 bytes), this is **undefined behavior** unless the actual struct is 88 bytes. **Demand:** `static_assert(sizeof(PmtpTensorDescriptor) == 88)`.

**Verdict on Target 2:** **FAIL** on subnormal audit semantics; **CONDITIONAL FAIL** on Rule 27 (AVX-512 lock); **BLOCKER** on struct size.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 Safe SIMD

**Claim:** Rust 2021 Safe SIMD.

**Adversarial finding 3.1.** "Safe SIMD" in Rust 2021 is `std::simd` (nightly) or `wide`/`packed_simd` crates. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. **Demand:** clarify whether "Safe SIMD" means (a) `std::simd` (portable, nightly), or (b) `unsafe` intrinsics wrapped in a safe API. If (b), the safety claim is a *wrapper* claim, not a *kernel* claim.

### 3.2 `panic=unwind` FFI safety barrier

**Adversarial finding 3.2 (CRITICAL).** `panic=unwind` across an FFI boundary is **undefined behavior** unless the panic is caught at the boundary (`catch_unwind`) and converted to an error code. The claim "panic=unwind FFI safety barrier" is *backwards*: `panic=abort` is the safe choice for FFI, because it prevents unwinding into C/C++. If the kernel uses `panic=unwind` and does *not* `catch_unwind` at every `extern "C"` boundary, it is UB. **Demand:** every `extern "C"` function must be wrapped in `std::panic::catch_unwind`, and the panic payload must be converted to a `PmtpError` enum (which fits in the 2-byte `flags` field? No — it needs its own field). **This is a Rule 22 violation** if the panic payload is a string.

### 3.3 Neumaier sums

Same as Target 2. **Finding 3.3:** Rust's `f64::mul_add` (FMA) is *not* guaranteed to be fused unless the target supports it. On x86-64 without FMA, `mul_add` is a software fallback with *different* rounding than Neumaier expects. **Demand:** `#[target_feature(enable = "fma")]