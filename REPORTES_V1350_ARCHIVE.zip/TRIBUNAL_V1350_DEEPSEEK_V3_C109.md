# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 109)

# POLYDIM V1350 — High Tribunal Audit, Cycle 109

**Presiding Sages:** Numerical Analysis, Systems Programming, Heterogeneous Compute, Formal Methods.
**Verdict posture:** Adversarial. Claims are treated as unproven until the artifact is shown. Where the artifact is not shown, we audit the *specification* and flag every place where the spec is under-determined or self-contradictory.

---

## 0. Preliminary: what we can and cannot audit

The six targets are described by **one-line summaries**, not by source. A PhD-grade audit of a *description* is a category error unless we explicitly reframe: we audit (a) the **claims**, (b) the **implied numerics**, (c) the **interface contracts** (88-byte descriptor, Rule 22, Rule 27). Every finding below is therefore either (i) a **proof obligation** the artifact must discharge, or (ii) a **counterexample** to the claim as stated. We mark each finding **[OBLIGATION]**, **[COUNTEREXAMPLE]**, or **[CONTRADICTION]**.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us actually count. `struct` format characters:

| Field | Type | Bytes |
|---|---|---|
| `4s` | char[4] | 4 |
| `H` | uint16 | 2 |
| `H` | uint16 | 2 |
| `Q` | uint64 | 8 |
| `Q` | uint64 | 8 |
| `Q` | uint64 | 8 |
| `Q` | uint64 | 8 |
| `Q` | uint64 | 8 |
| `B` | uint8 | 1 |
| `B` | uint8 | 1 |
| `6x` | pad | 6 |
| `4Q` | uint64[4] | 32 |

Sum: 4+2+2+8+8+8+8+8+1+1+6+32 = **88 bytes**. ✅ Arithmetic is correct.

**[OBLIGATION]** Alignment. With `struct` (not `struct.pack_into` with explicit alignment), CPython uses **native alignment by default only if you omit `<`**. The `<` prefix forces **standard size, no alignment**. So the descriptor is *packed*, not naturally aligned. On x86-64 this is fine for `memcpy`-style access, but:

- **[COUNTEREXAMPLE]** If the C++/Rust/CUDA sides declare the descriptor as a `struct` with natural alignment (e.g., `uint64_t` fields at 8-byte boundaries), the layouts **will not match**. The Python `<` layout puts the two `B` fields at offsets 44 and 45, then 6 pad bytes, then `4Q` at offset 52 — **not 8-byte aligned**. A C++ `struct { char[4]; uint16_t; uint16_t; uint64_t×5; uint8_t; uint8_t; uint64_t[4]; }` will place the `4Q` at offset 56 (after 3 bytes of tail padding from the `BB` pair plus 5 more). **This is a silent ABI break.** The 12/12 "physical conformance checks" must include an `offsetof` cross-check against the Python `struct.calcsize` and per-field offsets; if they don't, the check is theater.

**[OBLIGATION]** Endianness. `<` = little-endian. On a big-endian host (POWER9, some Trainium control planes), the descriptor is byte-swapped. The orchestrator must either (a) forbid BE hosts, or (b) emit `>` on BE. Rule 22 compliance is *host-endian-dependent* unless this is pinned.

### 1.2 `PmtpSlabAllocator`

**[OBLIGATION]** Slab allocators have a classic failure mode: **fragmentation under mixed-size allocation**. If PMTP slabs are fixed 88-byte descriptors plus variable payloads, the allocator must publish a **worst-case fragmentation bound**. Without it, "12/12 conformance" is a snapshot, not a guarantee.

**[OBLIGATION]** Concurrency. If the orchestrator is multi-threaded (it dispatches to CUDA/XLA/Triton), the slab allocator needs a lock-free or per-thread-arena design. A single mutex around slab allocation will serialize the orchestrator and destroy the throughput claim.

### 1.3 `HardwareProbe` multi-silicon

**[OBLIGATION]** Probe must be **fail-closed**. If AVX-512 detection is ambiguous (e.g., Xeon with AVX-512 fused off in BIOS), the probe must not silently fall back to a slower path that violates a latency SLA. Publish the fallback matrix.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's algorithm:

```
s = 0; c = 0
for x, y in zip(a, b):
    t = s + x*y
    if |s| >= |x*y|: c += (s - t) + x*y
    else:            c += (x*y - t) + s
    s = t
return s + c
```

**[OBLIGATION — proof]** The compensated sum `s + c` has error bound

  |error| ≤ (2u + O(nu²)) · Σ|xᵢyᵢ|,  u = 2⁻⁵³ (FP64)

**provided no intermediate overflows and no subnormal flush occurs.** The claim of "Neumaier compensated dot products" is only meaningful if the compiler is forbidden from contracting `s + x*y` into an FMA that **breaks the compensation** (the `t - s` term must be exact). **`-ffp-contract=off` is mandatory** on the dot-product TU. If the build uses `-ffast-math` or default `-ffp-contract=fast`, the compensation is silently destroyed. **[COUNTEREXAMPLE]** GCC ≥ 4.6 with `-O2` on x86-64 defaults to `-ffp-contract=fast` for FMA-capable targets. This is a real, shipping bug class.

### 2.2 Subnormal audits at −12, −14

**[OBLIGATION]** "Subnormal audit (−12, −14)" presumably means exponents 2⁻¹² and 2⁻¹⁴? Those are **normal** in FP64 (min normal exponent is −1022). If the intent is **decimal** exponents 10⁻¹² and 10⁻¹⁴, those are also normal. If the intent is **subnormal** (below 2⁻¹⁰²²), the audit must:

1. Set `MXCSR.FTZ = 0` and `DAZ = 0` (flush-to-zero and denormals-are-zero **off**).
2. Verify the compiler did not emit `vaddpd` with FTZ semantics.
3. Verify the OS did not enable FTZ via `prctl(PR_SET_FP_MODE)`.

**[COUNTEREXAMPLE]** On many HPC clusters, the job scheduler or a linked library (e.g., an old MKL) sets FTZ=1 globally. The audit must **read MXCSR at kernel entry and assert FTZ=0**, not assume it.

### 2.3 Zero-copy PMTP validation

**[OBLIGATION]** "Zero-copy" across the Python↔C++ boundary requires the buffer to be **pinned** and **lifetime-managed**. If the Python side frees the buffer while the C++ kernel is still reading, you get a use-after-free. The FFI contract must specify: who owns the buffer, when it is released, and whether the C++ side holds a reference (e.g., via `Py_INCREF` on the buffer object).

### 2.4 AVX-512 + OpenMP

**[OBLIGATION]** AVX-512 downclocking on Skylake-X / Ice Lake server parts is real. The kernel must either (a) use 256-bit ops on those parts, or (b) accept the frequency penalty. Publish the measured GFLOPS/W on the target SKUs.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

**[CONTRADICTION]** This is **backwards**. `panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the panic is caught at the boundary. The correct pattern is:

- `panic = abort` for the whole binary, **or**
- `extern "C"` functions wrapped in `std::panic::catch_unwind`, returning an error code.

If the Rust kernel is called from C++/Python and a panic unwinds into C++ frames, you get UB. The claim "panic=unwind FFI safety barrier" is **the opposite of safe**. **[OBLIGATION]** Replace with `catch_unwind` at every `extern "C"` entry point, or set `panic = abort` and document that a panic kills the process.

### 3.2 Safe SIMD

**[OBLIGATION]** `std::simd` is still nightly-only (as of Rust 2021 stable). If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" is only true if wrapped in a safe abstraction with a runtime feature check (`is_x86_feature_detected!("avx512f")`). Publish the wrapper.

### 3.3 Packed 88-byte descriptor

**[OBLIGATION]** Rust's `#[repr(C)]` does **not** pack. You need `#[repr(C, packed)]` to match the Python `<` layout. But `#[repr(C, packed)]` makes field access **unsafe** (unaligned reads). The idiomatic fix is `#[repr(C)]` with explicit padding fields, or `zerocopy`/`bytemuck` with `Pod` + `Unaligned`. **[COUNTEREXAMPLE]** A naive `#[repr(C, packed)]` struct with `u64` fields will compile but generate `mov` instructions that fault on strict-alignment targets (some ARM64 configs, SPARC). On x86-64 it works but is slow.

### 3.4 Neumaier in Rust

**[OBLIGATION]** Same FMA-contraction hazard as C++. Rust does **not** contract by default (LLVM's `contract` flag is off unless `-C target-feature=+fma` plus explicit `fma` intrinsic), so Rust is actually **safer** here than C++. But `#[target_feature(enable = "fma")]` on a function does **not** enable contraction; you must call `f64::mul_add` explicitly. Verify the kernel does not use `mul_add` inside the Neumaier loop.

---

## 4. TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K