# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 118)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 118 · Six-Component Adversarial Review

**Preliminary note on evidentiary posture.** The Tribunal has been asked to audit six artifacts by name and by claimed property. No source has been submitted for inspection — only the architectural claims. The Tribunal will therefore (a) audit the *claims as stated* for internal mathematical consistency, (b) flag every place where a claim is either unverifiable from the description or where the description itself implies a defect, and (c) issue binding recommendations. Where a claim cannot be falsified from the description alone, the Tribunal says so explicitly rather than manufacturing a verdict.

---

## §0. Cross-cutting findings (apply to all six targets)

### 0.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us count the struct as declared:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `H H` | 4 |
| five `Q` | `Q Q Q Q Q` | 40 |
| two `B` | `B B` | 2 |
| pad | `6x` | 6 |
| four `Q` | `Q Q Q Q` | 32 |
| **Total** | | **88** |

**Verdict:** the layout is *arithmetically* 88 bytes and, under the default `struct` alignment rules of CPython's `struct` module (native alignment, no `=` prefix), the `6x` pad is *redundant* — the compiler would already insert it. Under `=` (standard size, no alignment) the pad is *necessary*. **The Tribunal demands the format string be pinned to `=` or `<` explicitly and that `sizeof` be asserted at compile time in C++/Rust and at import time in Python.** A silent ABI drift of one byte here is a Rule 22 violation waiting to happen.

**Rule 22 compliance (Zero 1D tokens):** the descriptor is a *fixed-width* record, which is the correct shape for inter-agent transport. However, the claim "zero 1D tokens" is only satisfied if:
- the descriptor is transmitted as a **single 88-byte blob**, never as a Python list/tuple of fields;
- no variable-length string, no `None`, no sentinel `-1` is smuggled into any `Q` field;
- the `4s` magic is a *constant*, not a per-message tag.

The Tribunal cannot certify Rule 22 from the description alone. **Demand:** a byte-level golden-vector test (`hashlib.sha256(descriptor_bytes) == <pinned>`) in CI for all six components.

### 0.2 Rule 27 (Silicon Contract) — vendor-lock audit

| Target | Claimed silicon | Vendor-lock risk |
|---|---|---|
| T1 orchestrator | multi-silicon probe | **Low** if probe is a pure capability query; **High** if it links `libcuda`/`librocm` at import |
| T2 C++ | AVX-512 + OpenMP | **Medium** — AVX-512 is Intel/AMD-only; ARM (Graviton, Apple) has no AVX-512 |
| T3 Rust | Safe SIMD | **Low** — `std::simd` / `wide` are portable |
| T4 CUDA | cuSOLVER `DnDsyevd` | **Critical** — hard NVIDIA lock |
| T5 XLA | TPU / Trainium | **Critical** — hard Google/AWS lock, and the two are *mutually exclusive* |
| T6 Triton | ROCm + CUDA | **Medium** — Triton itself is portable, but the two backends are disjoint |

**Binding finding:** T4 and T5 as described **violate Rule 27** unless the orchestrator (T1) treats them as *optional accelerators* behind a capability flag, with a CPU fallback (T2/T3) that is bit-compatible. The description does not state that such a fallback exists. **The Tribunal rules T4 and T5 non-compliant pending evidence of a portable fallback path.**

### 0.3 The step → ∞ / step → 0 degeneracy (Requirement 1)

This is the deepest question and it recurs in every target. Let us treat it once, rigorously, then specialize.

Let the update be a retraction `R_X(step · G)` on a manifold `M` (Stiefel, sphere, or `R^{2K×2K}`). Two limits matter:

**(A) step → 0 (subnormal regime).** IEEE-754 binary64 subnormals live in `[2^{-1074}, 2^{-1022})`. The claimed "subnormal audits (-12, -14)" in T2 refer to *decimal* exponents, i.e. `10^{-12}` and `10^{-14}` — these are **not subnormal in binary64** (they are ~`2^{-40}` and `2^{-47}`). **The Tribunal flags this as a terminology error in the T2 description.** True subnormal audit requires testing at `2^{-1023}` and `2^{-1074}`.

The real degeneracy at small step is **catastrophic cancellation in the Neumaier sum**: if `step · G` has magnitude `~10^{-14}` and the accumulator holds values `~1`, the compensated sum still loses the low bits because the *product* `step · G` is already rounded. Neumaier compensation cannot recover information destroyed by the multiply. **Recommendation:** compute `step · G` in extended precision (double-double or `fma`-based TwoProduct) before accumulation.

**(B) step → ∞ (`|step| ≥ 10^{10}`).** For a Cayley retraction `R_X(V) = (I - V/2)^{-1}(I + V/2) X` with `V = step · G`, the resolvent `(I - V/2)^{-1}` has condition number

  κ = ‖I - V/2‖ · ‖(I - V/2)^{-1}‖ ≈ ‖V‖/2 · 2/‖V‖ = 1  (asymptotically, for ‖V‖ ≫ 1)

but the *intermediate* `I - V/2` is dominated by `V/2`, so the retraction collapses to `-X` (antipodal) for any `‖V‖ ≫ 1`. **The map is not injective in the limit.** For the Stiefel case with `V` skew-symmetric (the only case where Cayley is a true retraction), `‖V‖ → ∞` sends `X → -X`, which is a *different point* on `St(n,p)` unless `n = p`. **This is a genuine numerical degeneracy, not a rounding artifact.**

**Asymptotic condition number of the Woodbury solve** `(M/scale) W = (step/scale) B`:
- As `step → ∞`, `scale` must grow with `step` or the RHS overflows. If `scale = ‖step · B‖`, then `W = (step/scale) B` is `O(1)` — good. But `M/scale` then has `‖M/scale‖ → 0`, and the solve `(M/scale) W = RHS` is **ill-conditioned in the opposite direction**: `κ(M/scale) = κ(M)`, unchanged, but the *relative* residual `‖M W - step B‖ / ‖step B‖` is amplified by `κ(M)`. **Demand:** a proof that `scale` is chosen as `max(‖step B‖, ‖M‖ · ‖W_prev‖)` and that `κ(M)` is bounded by the Stiefel curvature.

---

## §1. TARGET 1 — `kernel_orchestrator_v1350.py`

**Claim:** Multi-silicon `HardwareProbe`, `PmtpSlabAllocator`, 88-byte descriptor, 12/12 physical conformance checks.

**Audit:**
- "12/12 physical conformance checks" is a *self-reported* metric. The Tribunal demands the 12 checks be enumerated and each be a *falsifiable predicate* (e.g., `sizeof(descriptor) == 88`, `alignof(descriptor) == 8`, `magic == b'PMTP'`, …). A check that cannot fail is not a check.
- `PmtpSlabAllocator`: slab allocation implies a fixed-size pool. If the slab size is not a multiple of 88, the descriptor will straddle cache lines and the "zero-copy" claim in T2/T3 fails. **Demand:** `slab_stride % 88 == 0` and `slab_stride % 64 == 0` (cache-line alignment).
- `HardwareProbe` multi-silicon: if it imports `torch.cuda.is_available()` or `jax.devices()`, it has already paid the vendor-lock cost at import time. **Recommendation:** probe via `ctypes.CDLL(..., mode=RTLD_LAZY)` with `try/except OSError`, never via a framework import.

**Rule 22:** the orchestrator is the *enforcer*. It must reject any inter-agent message whose length is not a multiple of 88. **Demand:** a `assert len(msg) % 88 == 0` at every FFI boundary, plus a `struct.unpack_from` loop, never `struct.unpack` on a slice.

**Rule 27:** compliant *iff* the probe is capability-based and the orchestrator can run with zero accelerators present.

---

## §2. TARGET 2 — `kernel_cpp_v1350.cpp`

**Claim:** C++20, AVX-512, OpenMP, Neumaier compensated dot, subnormal audits at `-12, -14`, zero-copy PMTP validation.

**Audit:**
- **Neumaier dot product:** the algorithm is
  ```
  s = 0; c = 0
  for i: t = s + x[i]*y[i]
         if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
         else:                  c += (x[i]*y[i] - t) + s
         s = t
  return s + c
  ```
  This is **not** correctly rounded; it is *faithfully* rounded with error `≤ 1 ulp` under the assumption that `x[i]*y[i]` is exact. **That assumption is false** unless `fma` is used. **Demand:** replace `x[i]*y[i]` with `fma(x[i], y[i], 0.0)` or use TwoProduct. Otherwise the "compensated" claim is overstated.
- **AVX-512:** `_mm512_fmadd_pd` is the correct primitive. But AVX-512 downclocking on Skylake-X and the 512-bit split on Ice Lake mean the *throughput* claim is silicon-dependent. **Demand:** a runtime dispatch (`__builtin_cpu_supports("avx512f")`) with an AVX2 fallback, or Rule 27 is violated on any non-AVX-512 host.
- **Subnormal audits