# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 153)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 153 · Six-Component Adversarial Review

**Presiding note.** The Tribunal treats every claim as *unproven until demonstrated*. Where the submission asserts "12/12 conformance," "zero-copy," "pure FP64," or "vendor-neutral," we demand the invariant, the witness, and the failure mode. Below, each target is dissected under the four audit axes: **(A) numerical degeneracy at step→0 and step→∞**, **(B) Rule 22 (88-byte PMTP, zero 1D tokens)**, **(C) Rule 27 (Silicon Contract / vendor-lock)**, **(D) FFI & proof obligations**.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor: `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly (little-endian, standard `struct` alignment disabled by `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major, version_minor | `HH` | 4 |
| flags, dtype | `BB` | 2 |
| dims[0..4] | `QQQQQ` | 40 |
| rank, reserved | `BB` | 2 |
| pad | `6x` | 6 |
| tail[0..3] | `4Q` | 32 |
| **Total** | | **90** |

**Finding 1.1 — ARITHMETIC DEFECT.** The format string sums to **90 bytes**, not 88. The claimed "88-byte binary descriptor" is **false by 2 bytes**. Either:
- the pad must be `4x` (→ 88), or
- one `Q` must be dropped (→ 82), or
- the header must be `4sHHQQQQQBB4x4Q` = 88.

This is a **Rule 22 violation** at the wire level: any peer that trusts the declared size will misalign every subsequent record. **Verdict: REJECT until the format string is corrected and a `struct.calcsize` assertion is added.**

### 1.2 Numerical degeneracy at step extremes

The orchestrator dispatches `step` to backends. Two hazards:

- **step → 0 (subnormal regime).** If `step` is passed as `float64` and multiplied into a Woodbury scale `step/scale`, the quotient can underflow to subnormal or zero. IEEE-754 subnormals lose precision gradually; a `step = 1e-308` yields `step/scale ≈ 0` for any `scale > 1`, collapsing the update to a no-op. **Proof obligation:** orchestrator must clamp `step` to `[2^-1022 * scale, 2^1023 / scale]` and log a `DegeneracyEvent`.
- **step → ∞ (|step| ≥ 1e10).** The Cayley retraction `(I - (step/2)W)^{-1}(I + (step/2)W)` becomes ill-conditioned as `‖step·W‖ → ∞`; the resolvent norm grows like `O(step·‖W‖)`. Condition number `κ ≈ (1 + step‖W‖/2)/(1 - step‖W‖/2)` → ∞ as `step‖W‖ → 2`. **The orchestrator must reject `|step| ≥ 2/‖W‖_F`** or route to a geodesic (matrix exponential) fallback.

### 1.3 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe** is fine *if* it returns a capability bitmask, not a vendor enum. If it returns `"nvidia" | "amd" | "tpu" | "trainium"`, that is a **Rule 27 soft violation** (see §C).
- **PmtpSlabAllocator** must guarantee 64-byte alignment (AVX-512) and 128-byte (cache line) separation to avoid false sharing. No proof of this is given. **Demand:** `assert(addr % 64 == 0)` and a stride ≥ 128 for per-thread slabs.

### 1.4 "12/12 physical conformance checks"

Unfalsifiable as stated. **Demand the 12 predicates** as executable assertions with witnesses. A conformance check without a counterexample generator is a *claim*, not a *check*.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant is *correct* for the sum of two floats but **not associative under vectorization**. With AVX-512 `_mm512_fmadd_pd`, the compiler may reassociate unless `-ffp-contract=off -fno-fast-math` is set. **Proof obligation:** the compensated sum `s + c` satisfies `|s + c - Σxᵢyᵢ| ≤ (n·u² + O(u³))·Σ|xᵢyᵢ|` where `u = 2^-53`. This bound **fails** if FMA contraction is enabled, because the compensation term `c` is computed from a fused product whose rounding differs.

**Recommendation:** compile with `-ffp-contract=off` and add a runtime `#ifdef __FMA__` guard that *disables* Neumaier and falls back to Kahan-Babuška-Neumaier with explicit `volatile` accumulators.

### 2.2 Subnormal audits at -12, -14

The exponents -12 and -14 correspond to `2^-12 ≈ 2.44e-4` and `2^-14 ≈ 6.1e-5`. These are **not subnormal** in FP64 (subnormal threshold is `2^-1022`). If the intent is FP32 subnormals (`2^-126`), the audit is mislabeled. **Finding 2.2 — CATEGORY ERROR.** Either:
- the audit is on FP32 and the exponents should be `-126, -149`, or
- the audit is on FP64 and the exponents should be `-1022, -1074`.

As written, the "subnormal audit" tests *normal* numbers and provides **zero coverage** of the subnormal regime. **Verdict: REJECT the audit claim.**

### 2.3 Zero-copy PMTP validation

Zero-copy requires that the 88-byte descriptor (see §1.1 — actually 90) be `memcpy`-able into a `PmtpTensorDescriptor` POD with `static_assert(sizeof(...) == 88)`. Given the format defect, this `static_assert` **will fail to compile** or, worse, silently truncate. **Demand:** `static_assert(sizeof(PmtpTensorDescriptor) == 88, "PMTP wire size");` and a `std::bit_cast` round-trip test.

### 2.4 Degeneracy at step extremes

- **step → 0:** `step * B` underflows; the Woodbury update `W = (step/scale) B` becomes zero. Guard: `if (std::abs(step) < std::numeric_limits<double>::min() * scale) return identity_update;`
- **step → ∞:** `step * B` overflows to `inf`; the subsequent `DnDsyevd` on `inf` entries returns `NaN` eigenvalues. Guard: `if (std::abs(step) > 1e10) throw StepOverflow{};`

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI barrier

**Finding 3.1 — SOUNDNESS HAZARD.** `panic=unwind` across an FFI boundary is **undefined behavior** unless the panic is caught with `std::panic::catch_unwind` *and* the foreign side is compiled with matching unwind tables. The Rust Nomicon explicitly forbids unwinding into C/C++. The correct pattern is:

```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> i32 {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1, // PMTP_ERR_PANIC
    }
}
```

With `panic=abort`, the process dies — also unacceptable for a long-running kernel. **Recommendation:** `panic=unwind` + `catch_unwind` at every `extern "C"` entry, and `#[repr(C)]` on all shared structs.

### 3.2 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` on a struct with `u64` fields will produce **unaligned loads** on some architectures (ARM64 with strict alignment). The `PmtpTensorDescriptor` must be `#[repr(C)]` (not packed) with explicit padding, and `size_of::<PmtpTensorDescriptor>() == 88` asserted via `const _: () = assert!(...)`. Given §1.1, this assertion **fails**.

### 3.3 Safe SIMD + Neumaier

Rust's `std::simd` is still nightly. If the kernel uses `core::arch::x86_64::_mm512_*`, it is **unsafe** and the "Safe SIMD" claim is false. **Demand:** either nightly `portable_simd` with `#[target_feature]` guards, or drop the "Safe" adjective.

### 3.4 Degeneracy

Same as C++: `step → 0` underflow, `step → ∞` overflow. Rust's `f64::is_subnormal()` is available; use it as a gate.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)

The Cayley retraction `Y = (I - (step/2)A)^{-1}(I + (step/2)A) X` is **orthogonality-preserving** only if `A` is skew-symmetric. If `A` is the *gradient* projected onto the tangent space, it must be **skew-symmetrized**: `A ← (A - Aᵀ)/2`. **Proof obligation:** the submission must show `A + Aᵀ = 0` to machine precision before the solve. Otherwise the retraction drifts off the Stiefel manifold by `O(step²·‖A + Aᵀ‖)`.

### 4.2 cuSOLVER `DnDsyevd` on a non-symmetric matrix

`DnDsyevd` is for **symmetric** matrices. The Cayley resolvent `(I - (step/2)A)` is **not symmetric** when `A` is skew. **Finding 4.2 — API MISMATCH.** The correct call is `cusolverDnDgetrf` + `cusolverDnDgetrs` (LU), or `cusolverDnDgeev` if eigenvalues are needed. Using `syevd` on a non-symmetric matrix produces **garbage** (it reads only the lower