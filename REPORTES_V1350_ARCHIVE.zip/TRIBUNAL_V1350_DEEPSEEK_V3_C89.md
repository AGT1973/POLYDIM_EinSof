# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 89)

# POLYDIM V1350 — High Tribunal Audit, Cycle 89

**Presiding Sages:** Numerical Analysis, Systems Architecture, Formal Methods, Heterogeneous Compute
**Verdict class:** Adversarial SOTA — findings are graded **BLOCKER / MAJOR / MINOR / OBSERVATION**.

A preliminary caveat the Tribunal must state up front: the six artifacts were submitted as *specifications*, not as compilable source. Where a claim is unverifiable from the spec alone (e.g., "12/12 physical conformance checks"), the Tribunal marks it **UNVERIFIED** and treats the claim as a *hypothesis to be falsified*, not as evidence. This is standard adversarial-audit discipline.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Struct layout (little-endian, natural alignment assumed):

| Field | Type | Offset | Size |
|---|---|---|---|
| magic | 4s | 0 | 4 |
| version_major | H | 4 | 2 |
| version_minor | H | 6 | 2 |
| flags | Q | 8 | 8 |
| n_rows | Q | 16 | 8 |
| n_cols | Q | 24 | 8 |
| stride | Q | 32 | 8 |
| scale_bits | Q | 40 | 8 |
| rank | B | 48 | 1 |
| dtype | B | 49 | 1 |
| pad | 6x | 50 | 6 |
| reserved | 4Q | 56 | 32 |
| **Total** | | | **88** |

**Finding T1-A (MAJOR).** `struct.calcsize` on CPython with `=` (native) vs `<` (standard) yields different results. The spec does not pin the byte-order prefix. If any producer uses `=` and any consumer uses `<`, the `Q` fields at offsets 8–47 will be byte-swapped on big-endian hosts (POWER10, s390x). **Recommendation:** mandate `struct.Struct("<4sHHQQQQQBB6x4Q")` as a module-level singleton and assert `size == 88` at import time.

**Finding T1-B (BLOCKER for Rule 22).** The descriptor carries `scale_bits` as a raw `Q` (bit-pattern of an IEEE-754 double). This is *correct* for zero-copy, but the spec does not state that `scale_bits` must be **canonicalized** (no NaN payloads, no signaling NaN, no negative zero). A malicious or buggy peer can inject `0x7FF8000000000001` (qNaN) and downstream Neumaier sums will silently propagate NaN through the entire reduction tree. **Rule 22 compliance requires a canonicalization gate** at the FFI boundary: reject if `(scale_bits & 0x7FF0000000000000) == 0x7FF0000000000000`.

**Finding T1-C (MAJOR).** `rank` is `B` (uint8) but the CUDA target (§4) uses `2K × 2K` Stiefel blocks. If `K > 127`, `rank` overflows. The spec must either widen to `H` or document `rank ≤ 127` as a hard precondition with a runtime assert.

**Finding T1-D (OBSERVATION).** "12/12 physical conformance checks" is a claim without a falsifier. The Tribunal demands the check list be published as a machine-readable manifest (e.g., `conformance.json`) with each check's predicate and expected value, so a third party can re-run it.

### 1.2 `PmtpSlabAllocator`

**Finding T1-E (MAJOR).** No alignment guarantee is stated. AVX-512 requires 64-byte alignment; CUDA `cudaMalloc` returns 256-byte; Rust `Vec<u8>` is 1-byte. If the allocator hands a slab to the C++ kernel without `alignas(64)`, the compiler will emit unaligned loads and the "zero-copy" claim degrades to a copy-on-fault path. **Recommendation:** `posix_memalign(64)` / `cudaHostAlloc(..., cudaHostAllocDefault)` with `cudaHostRegister` for pinned slabs.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

The Neumaier variant of Kahan–Babuška is:

```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
    else:                c += (x_i*y_i - t) + s
    s = t
return s + c
```

**Finding T2-A (MAJOR — numerical degeneracy as step → ∞).** The spec claims Neumaier compensation, but the *product* `x_i*y_i` is computed in FP64 without FMA. When `|step| ≥ 10^10` and the operands are O(1), the product is O(10^10), and the compensation term `(s - t) + x_i*y_i` is computed in FP64 — its magnitude is bounded by `ulp(t) ≈ 2^-52 · 10^10 ≈ 2.2 × 10^-6`. The *true* rounding error of the product is `≤ 0.5 ulp(x_i*y_i) ≈ 1.1 × 10^-6`. So the compensation is *just barely* sufficient. **But** if the kernel is compiled with `-ffast-math` or `-funsafe-math-optimizations`, the compiler is free to reassociate `(s - t) + x_i*y_i` and destroy the compensation entirely. **Recommendation:** compile the reduction TU with `-fno-fast-math -ffp-contract=off` and add a `static_assert` on `__STDC_IEC_559__`.

**Finding T2-B (BLOCKER — subnormal audit at -12, -14).** The spec claims subnormal audits at exponents −12 and −14. These are *not* subnormal in FP64 (subnormal threshold is 2^-1022 ≈ 2.2 × 10^-308). The Tribunal suspects the spec means **FP32** subnormals (threshold 2^-126) or **FP16** (2^-14). If the kernel is FP64, the audit points are meaningless. If the kernel is FP32, then `-12` and `-14` are *normal* FP32 values, not subnormal. **This is a specification defect.** The correct audit points for FP64 subnormals are `0x000FFFFFFFFFFFFF` (largest subnormal) and `0x0000000000000001` (smallest). **Recommendation:** publish the exact bit patterns being audited.

**Finding T2-C (MAJOR — step → 0).** As `step → 0`, the Woodbury solve `(M/scale) W = (step/scale) B` (see §4) has RHS → 0. The solution `W → 0`, but the *relative* error is governed by `cond(M/scale)`. If `M` is ill-conditioned (e.g., near-singular Stiefel tangent), the relative error blows up even though the absolute error is tiny. **Asymptotic condition number:** for a Stiefel manifold `St(n,p)`, the Riemannian Hessian's condition number scales as `cond ≈ (σ_max/σ_min)^2` where `σ` are the singular values of the retraction Jacobian. Near the poles of the Cayley transform (rotation angle → π), `σ_min → 0` and `cond → ∞`. **Recommendation:** clamp `step` to `[ε_mach · ||M||, 10^10]` and log a warning when the clamp fires.

### 2.2 Zero-copy PMTP validation

**Finding T2-D (MAJOR).** "Zero-copy" is asserted but the validation path is not specified. If validation reads the 88-byte descriptor via `memcpy` into a local struct, that is a copy. If it reads via `reinterpret_cast<const PmtpDescriptor*>` on a potentially unaligned pointer, that is UB. **Recommendation:** use `std::bit_cast<PmtpDescriptor>(std::array<std::byte,88>)` (C++20) or `__builtin_memcpy` with `-O2` (which the compiler will elide).

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` FFI safety barrier

**Finding T3-A (BLOCKER).** `panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is marked `extern "C-unwind"` (stabilized in Rust 1.71). The spec says "panic=unwind FFI safety barrier" — this is a contradiction. Either:
- (a) the boundary is `extern "C"` and panics must be caught with `std::panic::catch_unwind` before returning, or
- (b) the boundary is `extern "C-unwind"` and the C++ side must be compiled with `-fexceptions` and prepared to receive a foreign exception.

**Recommendation:** use `catch_unwind` at every `extern "C"` entry point and convert panics to error codes. This is the only portable option.

### 3.2 Packed 88-byte descriptor

**Finding T3-B (MAJOR).** Rust's `#[repr(C)]` does *not* guarantee packing. The spec says "packed 88-byte" — if `#[repr(packed)]` is used, then taking a reference to any field is UB (E0793). **Recommendation:** use `#[repr(C, align(8))]` with explicit padding fields, and `static_assert!(size_of::<PmtpTensorDescriptor>() == 88)` via `const _: () = assert!(...)`.

### 3.3 Safe SIMD

**Finding T3-C (OBSERVATION).** "Safe SIMD" in Rust 2021 requires `std::simd` (nightly) or `wide`/`packed_simd` crates. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. The spec's "Safe SIMD" claim is therefore either (a) a wrapper over unsafe intrinsics, or (b) nightly-only. **Recommendation:** document the exact crate and feature flags.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction

The Cayley retraction on `St(n,p)` is:

```
Y(τ) = (I - (τ/2) A)^{-1} (I + (τ/2) A) Y
```

where `A = G Y^T - Y G^T` is skew-s