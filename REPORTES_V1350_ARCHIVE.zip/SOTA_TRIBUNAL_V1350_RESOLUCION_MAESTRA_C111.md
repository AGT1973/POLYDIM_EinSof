# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 111

The available record does **not contain the six Tribunal models’ actual reports, kernel specifications, or benchmark data**, and “POLYDIM V1350,” “PMTP,” and the six named V1350 kernels are not publicly verifiable from the gathered material. Therefore, no defensible arbitration can declare one implementation SOTA or guarantee cross-platform behavior. The strongest valid synthesis is a set of **conditional architectural guarantees**.

## 1. Stiefel retraction under \(\lvert\text{step}\rvert \ge 10^{10}\)

For a point \(Z\in\mathrm{St}(d,k)\) and tangent update \(\Xi\), the relevant candidates are approximately

\[
R_{\mathrm{polar}}(Z,\Xi)
=(Z+\Xi)\bigl(I+\Xi^\top\Xi\bigr)^{-1/2},
\]

\[
R_{\mathrm{QR}}(Z,\Xi)=\operatorname{qf}(Z+\Xi),
\]

and a Cayley-type map based on a skew-symmetric generator. The polar and QR formulas are standard Stiefel retractions.[5]

### Arbitration

No method is mathematically stable merely because it is called “Cayley,” “Householder,” or “polar.” At extreme step magnitudes, the decisive issue is **scaling and conditioning**:

- Forming \(Z+\Xi\) directly can overflow, lose the contribution of \(Z\), or produce a severely ill-conditioned factorization.
- QR with Householder reflectors is generally preferable to classical Gram–Schmidt, but unpivoted QR can still become numerically problematic when the input is rank-deficient or badly scaled.
- Polar retraction gives the closest orthonormal factor in the Frobenius norm when computed accurately, but explicitly forming \(\Xi^\top\Xi\) can square the condition number and overflow.
- A Cayley update can preserve orthogonality algebraically, but only if the skew generator is constructed accurately and the linear solve is stable. A naïve implementation that evaluates expressions containing \(10^{10}\)-scale quantities without balancing has no extreme-step guarantee.

### Superior synthesis

The defensible design is a **scaled, rank-aware polar/Cayley implementation**, not an unqualified claim that Cayley dominates Householder QR:

1. Compute a scale \(s=\max(1,\|\Xi\|)\) using a stable norm algorithm.
2. Work with \(\widehat{\Xi}=\Xi/s\).
3. Use a backward-stable orthogonalization path:
   - QR with Householder reflectors for the default path; or
   - an SVD/eigendecomposition-based polar factor when closest-point behavior is required.
4. If the Cayley path is retained, solve the associated shifted system with pivoting or a backward-stable factorization and verify the residual.
5. Check
   \[
   \|Q^\top Q-I\|,\qquad
   \|Q-(Z+\Xi)_{\text{orth}}\|,
   \]
   and reject, rescale, or fall back when tolerances fail.

The exact guarantee should be stated as:

> For finite inputs and a correctly implemented backward-stable factorization, the kernel returns an orthogonality defect bounded by the platform’s floating-point error, conditioning, and supplied tolerance—not by a universal constant independent of step size.

A claim of unconditional stability for every \(\lvert\text{step}\rvert\ge10^{10}\) is not mathematically credible. Extreme scaling must be handled explicitly.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte layout alone provides **no memory-ordering guarantee**. Correctness depends on atomic publication, reader registration, grace-period detection, and reclamation.

The essential RCU publication rule is:

\[
\text{initialize descriptor fields}
\;\prec_{\mathrm{hb}}\;
\text{release-publish pointer},
\]

and the reader must perform:

\[
\text{acquire-load pointer}
\;\prec_{\mathrm{hb}}\;
\text{read descriptor fields}.
\]

Acquire operations order subsequent memory operations after the acquire, while release operations order preceding operations before the release.[13] RCU publication similarly requires ordering initialization before publishing the updated pointer, and readers must use a matching dereference operation.[1]

### Minimum descriptor protocol

A valid immutable-snapshot protocol requires:

- The descriptor is fully initialized before publication.
- The published pointer is atomic.
- Writers publish with **release** semantics.
- Readers load with **acquire** semantics.
- Readers announce entry before dereferencing the snapshot.
- Writers wait for a grace period covering all readers that could have observed the old pointer.
- Reclamation occurs only after that grace period.
- Descriptor fields are immutable after publication, or each mutable field has its own correctly specified atomic protocol.
- The descriptor does not contain uninitialized padding that is compared, hashed, transferred, or exposed across an ABI boundary.

QSBR is not simply “RCU with acquire/release.” It relies on readers reaching announced quiescent states; reclamation cannot safely complete while a participating reader fails to report quiescence.[3][4] QSBR is therefore appropriate only when the application controls reader checkpoints.

### Exact guarantee

With those conditions, the architecture can guarantee:

> A reader that acquires a published descriptor observes a fully initialized snapshot, and the descriptor remains allocated until every pre-existing reader that could reference it has passed through the required grace period.

It cannot guarantee:

- progress if a QSBR participant never reports quiescence;
- snapshot consistency for data mutated outside the published object;
- safety when a descriptor pointer is retained beyond the reader’s protection interval;
- portability from compiler barriers alone;
- lock-free behavior unless the atomic pointer, registration, and grace-period machinery are separately proven lock-free.

The 88-byte size should therefore be treated as an ABI/storage constraint, not as part of the synchronization proof.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared identically by all five environments. A kernel can be numerically equivalent while having different synchronization semantics, aliasing rules, launch behavior, or lowering constraints.

### Required conformance layers

| Layer | Required property |
|---|---|
| Mathematical | Same retraction map, domain checks, and tolerance policy |
| Numerical | Defined error bounds, scaling behavior, NaN/Inf handling, and deterministic reduction policy |
| Memory | Explicit publication, acquire/release, lifetime, and reclamation rules |
| ABI | Fixed field offsets, alignment, endianness, padding, and versioning |
| Execution | Defined synchronization scope: thread, block, device, host, or distributed |
| Compiler | No reliance on undocumented aliasing, ordering, or fusion behavior |
| Testing | Cross-backend differential tests plus litmus tests for memory ordering |

### Platform-specific caveats

- **C++20:** Use `std::atomic` and the language memory model for host-side publication. A compiler barrier is not a hardware synchronization primitive.
- **Rust:** Use atomics and ownership/lifetime discipline; `unsafe` FFI must preserve alignment, validity, aliasing, and reclamation invariants. Rust’s type system does not automatically prove an external RCU implementation correct.
- **CUDA:** Host C++ atomics do not automatically synchronize device memory. Device, block, system, and host visibility require the appropriate CUDA-scoped operations and synchronization.
- **Triton:** Kernel barriers and compiler scheduling rules must be expressed using Triton-supported primitives. Host-side RCU guarantees do not automatically extend into an executing GPU kernel.
- **XLA:** HLO compilation may fuse, reorder, replicate, or materialize operations according to its execution model. Pointer publication and reclamation must remain outside computations whose buffer lifetimes are controlled by the XLA runtime.

Consequently, “conformance” should mean **observational equivalence under a declared contract**, not identical implementation internals.

## Definitive arbitration

The mathematically and architecturally defensible SOTA position is:

1. **Retraction:** use scale-aware, backward-stable Householder QR or stable polar decomposition as the reference implementation; retain Cayley only with stable solves, scaling, residual checks, and fallback. No unconditional \(10^{10}\)-step stability claim is valid.
2. **Descriptor isolation:** use immutable descriptors, atomic release publication, acquire consumption, explicit reader protection, and a proven RCU/QSBR grace-period protocol. The 88-byte layout does not itself provide isolation.
3. **Multi-silicon portability:** define one language-independent mathematical and memory contract, then implement backend-specific synchronization and lifetime mechanisms. CUDA, XLA, Triton, C++20, and Rust cannot be declared conformant solely from matching source code or output on ordinary tests.
4. **Guarantee boundary:** the strongest exact guarantee is conditional—bounded numerical error under stated conditioning and floating-point assumptions, plus snapshot safety under a completed grace-period protocol. Claims stronger than that require the missing kernel specifications, model reports, formal proofs, and cross-platform test evidence.