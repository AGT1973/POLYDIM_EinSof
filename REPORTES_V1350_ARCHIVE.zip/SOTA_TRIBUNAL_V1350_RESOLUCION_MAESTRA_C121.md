# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 121

The requested arbitration cannot be made definitively from the available evidence. I found no publicly verifiable specification, benchmark corpus, source repository, or per-model reports for **“POLYDIM V1350,” “PMTP 88-byte Descriptor,”** or the six named kernels; the search results instead point to the unrelated **PolyDiM** PDE library.[3][6][9] Consequently, attributing findings to Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM, or Perplexity would be fabricated.

What can be stated rigorously is the following conditional synthesis.

## 1. Extreme-step Cayley retraction versus Householder or polar QR

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), \(X^\top X=I\), a Cayley update typically has the form

\[
X_{+}=\left(I-\frac{\alpha}{2}A\right)^{-1}
       \left(I+\frac{\alpha}{2}A\right)X,
\qquad A^\top=-A .
\]

In exact arithmetic, whenever the inverse exists, the Cayley transform is orthogonal:

\[
Q(\alpha)^\top Q(\alpha)=I.
\]

That is an **algebraic** guarantee, not a floating-point stability guarantee. For \(|\alpha|\ge 10^{10}\), the implementation must address:

- overflow or underflow in forming \(\alpha A\);
- loss of significance when evaluating \(I\pm \alpha A/2\);
- conditioning and pivoting of the linear solve;
- finite-precision drift from the solve and matrix products;
- singular or nearly singular shifted systems;
- residual orthogonality, not merely the absence of a crash.

Householder QR is generally the strongest default for numerical robustness because it uses backward-stable orthogonal transformations. A polar factor computed with a stable method—such as SVD or a carefully implemented Newton–Schulz variant with scaling—can provide an especially accurate nearest-orthogonal projection, but its cost and convergence requirements differ.

Therefore, no unconditional claim that Cayley is superior at extreme steps is justified. A defensible guarantee is:

> **Cayley:** exact orthogonality only in exact arithmetic; finite-precision stability requires a scaled, factorization-based implementation and an explicit residual bound.

> **Householder QR:** backward stability under standard assumptions, with orthogonality error typically on the order of machine precision times problem-dependent polynomial factors.

> **Polar/SVD:** nearest-orthogonal-factor characterization, with stability governed by the chosen polar algorithm and singular-value conditioning.

A production kernel should either cap or rescale the step, solve an equivalent scaled system, and reject the result when

\[
\frac{\|X_{+}^{\top}X_{+}-I\|}{\|I\|}
\]

exceeds a specified tolerance. Without such a policy, “stable for \(|\text{step}|\ge10^{10}\)” is not an architectural guarantee.

## 2. PMTP descriptor barriers and RCU/QSBR isolation

Acquire/release operations alone do **not** establish complete snapshot isolation. The guarantee depends on the full publication and reclamation protocol.

A valid RCU-style publication sequence is conceptually:

1. Construct and fully initialize an immutable descriptor and the object graph it references.
2. Publish the descriptor pointer with **release** semantics.
3. Read the pointer with **acquire** semantics.
4. Keep the object protected through an RCU read-side critical section or QSBR epoch.
5. Reclaim the old object only after every reader that could have observed it has passed a grace period.

The resulting guarantee is:

\[
\text{reader observes either a fully initialized old snapshot or a fully initialized new snapshot,}
\]

provided that:

- the descriptor is immutable after publication, or all mutations are separately synchronized;
- every referenced object is covered by the same lifetime protocol;
- readers enter protection before dereferencing;
- writers wait for a valid grace period before reclamation;
- all relevant atomic operations use the intended memory orders;
- the implementation obeys the target language and hardware memory model.

An 88-byte size has no intrinsic memory-ordering significance. Alignment, cache-line placement, atomic field layout, pointer validity, ABA prevention, and reclamation discipline matter more than the byte count. If the descriptor contains non-atomic mutable fields that readers access concurrently, acquire/release on the pointer does not eliminate the data race.

The strongest defensible contract is thus:

> **Publication safety:** release-store followed by acquire-load makes prior initialization visible.

> **Lifetime safety:** RCU/QSBR grace-period completion prevents reclamation while protected readers remain active.

> **Snapshot consistency:** guaranteed only if the snapshot is immutable or versioned and all reachable state obeys the same protocol.

It is not valid to promise arbitrary multi-field atomicity merely because the descriptor is 88 bytes.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single shared memory model across these environments. “Conformance” must be defined as a portability profile, not inferred from source-level similarity.

A credible profile would specify:

- data representation, endianness, alignment, and padding;
- integer and floating-point widths;
- permitted atomic operations and scopes;
- synchronization domains;
- ordering guarantees;
- aliasing and lifetime rules;
- deterministic versus nondeterministic reductions;
- error and overflow behavior;
- tolerance thresholds for numerical outputs;
- supported device architectures and compiler versions.

Important distinctions include:

- **C++20:** acquire/release semantics apply to C++ atomics under the C++ memory model; they do not automatically describe GPU device memory or foreign runtime objects.
- **Rust:** atomic ordering and ownership rules are strong at the language level, but `unsafe` FFI, raw pointers, and device memory require an explicit external contract.
- **CUDA:** ordering depends on the atomic operation, memory scope, synchronization primitive, and address space.
- **Triton:** generated behavior depends on compiler lowering and target backend; source annotations alone are insufficient as a cross-device proof.
- **XLA:** asynchronous execution, buffering, fusion, and backend-specific lowering mean that host-language ordering assumptions cannot simply be transferred to an HLO computation.

The exact guarantee should therefore be expressed as:

\[
\text{same specified abstract result}
\;\pm\;
\text{declared numerical tolerance},
\]

plus a separately specified happens-before and lifetime contract for shared metadata. Bitwise identity across all five targets should not be promised unless it has been demonstrated and deliberately enforced.

## Arbitration outcome

The only mathematically supportable arbitration from the available material is:

- **No model-by-model findings can be authenticated.**
- **Cayley is not automatically superior to Householder or polar QR at extreme steps.**
- **Acquire/release is necessary for safe publication but insufficient by itself for RCU/QSBR snapshot isolation.**
- **An 88-byte layout does not imply atomicity, consistency, or portability.**
- **Cross-backend conformance requires an explicit abstract specification, memory model, numerical tolerance, and reclamation protocol.**
- **No exact architectural guarantees can be assigned to V1350 without its actual kernel definitions, descriptor schema, source code, target matrix, and the eight tribunal reports.**

To produce a genuine Cycle 121 arbitration, the missing artifacts would need to include the six kernel specifications, all eight reports, benchmark logs at \(|\text{step}|\ge10^{10}\), descriptor field offsets and alignment, the publication/reclamation pseudocode, and backend-specific conformance tests.