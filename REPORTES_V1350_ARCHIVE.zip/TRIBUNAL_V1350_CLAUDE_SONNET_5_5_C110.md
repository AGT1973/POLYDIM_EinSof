# AUDITORÍA TRIBUNAL DE SABIOS — Claude_Sonnet_5_5 (CICLO 110)

I realize the six files being referenced weren't actually attached, so I don't have access to the actual code to audit. Rather than fabricate findings, I should be upfront about this and instead offer a rigorous framework for analysis—covering the math behind the described algorithms like Cayley retraction, Woodbury with global scaling, Neumaier summation, and the descriptor struct format—plus a verification checklist and FFI hardening suggestions.

I'm working through the byte layout of the 88-byte struct and confirming the field sizes add up correctly, and noting that natural alignment actually produces 88 bytes without needing explicit packing, which means repr(C) should suffice and repr(packed) would be unnecessary and risky in Rust due to unaligned reference issues. Then I start sketching out the Cayley retraction math on the Stiefel manifold using the low-rank Woodbury identity to reduce the matrix inversion to a smaller 2k×2k system.

But I catch a problem: using a symmetric eigensolver here doesn't actually work since V^T U isn't symmetric in general, so applying syevd would silently read only one triangle and give wrong results — I need to flag this and think about whether there's a way to reformulate the problem with proper Hermitian structure instead.

For the Cayley transform itself, I'm checking that Q stays orthogonal and that its condition number grows only linearly with t, which is tractable even as t gets large. But I notice the retraction becomes degenerate as t→∞ since Q collapses toward -I on the range of W, meaning the step loses meaning at large scale.

I need scaling by powers of two to stay exact in floating point, and dividing the system by a scale factor avoids overflow without changing the condition number — though at large t the identity term becomes a tiny perturbation, and if the core matrix is rank-deficient the conditioning could still blow up.

I should also guard against scale collapsing to zero or subnormal values when step is tiny, since that risks underflow or losing the update entirely — the retraction needs to preserve the first-order expansion, otherwise updates smaller than machine epsilon simply vanish, so I need to be careful about compiler flags like fast-math that flush denormals to zero.

Compiler reassociation under -ffast-math is also dangerous because it can silently destroy Neumaier compensated summation, and parallel reductions (OpenMP, AVX-512 lane-wise accumulation) need careful compensated combination across lanes to avoid the same issue. I'm also second-guessing the "subnormal audit" thresholds mentioned at 1e-12 and 1e-14 — those aren't actually subnormal magnitudes for FP64 (subnormals are below ~2.2e-308), so that labeling seems off and worth flagging as a possible error.

For dot products specifically, true compensated accuracy requires pairing Neumaier-style summation with FMA-based error-free transformation of each product (like Dot2/Ogita-Rump-Oishi), since Neumaier alone only fixes summation error, not the rounding error from each multiplication.

Switching to Lyapunov equation solves, I'm realizing the standard Bartels-Stewart approach needs a Schur decomposition, which isn't available on TPU in JAX (CPU-only), and TPU/Trainium hardware doesn't natively support FP64 anyway—so a "pure FP64" solve path on these accelerators is basically not viable. I'm thinking through the conditioning via the separation function sep(A,-A^T) and whether a Kronecker-product formulation offers a more portable alternative.

Working through the conditioning bound, I note it scales with the Frobenius norm over the separation, and gets worse by the square of the eigenvector matrix's condition number for nonnormal matrices—meaning the solution norm explodes as eigenvalues approach the imaginary axis.

