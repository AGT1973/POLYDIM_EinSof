# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 161

A definitive arbitration is **not possible from the available evidence**: the eight Tribunal reports, the definitions of the six V1350 kernels, the PMTP memory layout, and the conformance test results were not provided, and no authoritative public specification for “POLYDIM V1350” or “PMTP 88-byte Descriptor” was found. The verifiable material supports only general conclusions about Stiefel retractions—not the claimed implementation-specific guarantees.

## 1. Cayley–Stiefel retraction versus Householder/Polar QR

For \(X\in\mathrm{St}(n,p)\) and tangent step \(\Xi\), the standard alternatives are:

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)\bigl(I+\Xi^{\mathsf T}\Xi\bigr)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley update of the form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

where \(W\) is a skew-symmetric matrix constructed from \(X\) and \(\Xi\). Polar, QR, and Cayley maps are established Stiefel retractions, with different computational costs and numerical behavior.[2][3]

The strongest defensible arbitration is:

| Criterion | Cayley | Householder/QR | Polar |
|---|---|---|---|
| Orthogonality in exact arithmetic | Exact, if the Cayley solve is exact | Exact for exact QR | Exact for exact inverse square root |
| Extreme \(\lvert\text{step}\rvert\ge 10^{10}\) | **No unconditional stability guarantee** | Usually preferable with stable Householder QR, but not guaranteed if \(X+\Xi\) is rank-deficient or badly scaled | Can be accurate, but \(I+\Xi^{\mathsf T}\Xi\) may be severely ill-conditioned in finite precision |
| Scaling sensitivity | Sensitive to forming and solving the Cayley system | Generally the most robust default because Householder QR is backward stable | Sensitive to spectral conditioning and inverse-square-root implementation |
| Cost | Often higher; Cayley involves a structured solve | Typically lower than Cayley for common dimensions | More expensive than QR in many regimes |
| Invertibility requirements | Requires a nonsingular Cayley system | Requires \(X+\Xi\) to have sufficient rank | Requires full column rank of \(X+\Xi\) |

Thus, the mathematically correct claim is **not** that Cayley is unconditionally more stable for extreme steps. A step of magnitude \(10^{10}\) is outside the regime where a retraction alone can guarantee finite-precision reliability. The implementation must use scaling, overflow-safe norm evaluation, rank checks, residual checks, and—where necessary—a fallback to Householder QR or a scaled polar decomposition.

The strongest architectural guarantee that can legitimately be stated is conditional:

\[
\|Q^{\mathsf T}Q-I\|
\le
C\,u\,\kappa_{\mathrm{effective}}
\]

for a backward-stable implementation, where \(u\) is machine precision and \(\kappa_{\mathrm{effective}}\) reflects the conditioning of the factored or solved matrix. No exact bound independent of step magnitude, matrix dimensions, conditioning, or hardware arithmetic follows merely from choosing Cayley, QR, or polar retraction.

**Arbitration:** use **Householder QR as the extreme-step safety fallback**, polar retraction where smoothness and metric fidelity matter, and Cayley only with a scaled, residual-checked solve. A claimed unconditional Cayley win at \(\lvert\text{step}\rvert\ge10^{10}\) should be rejected.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte size does not itself establish any memory-ordering guarantee. Correct RCU/QSBR snapshot isolation requires a specified publication protocol, including:

1. All descriptor fields are fully initialized before publication.
2. The writer publishes the descriptor pointer or generation using **release** semantics.
3. Readers acquire the pointer or generation before reading dependent fields.
4. Retired descriptors are reclaimed only after every pre-existing reader has passed a quiescent state or an equivalent grace period.
5. Readers validate generation/version data if descriptors can be reused or updated in place.
6. Atomic fields are naturally aligned and have explicitly defined widths.
7. The protocol forbids unsynchronized mutation of non-atomic fields while readers may access them.

A minimal publication pattern is conceptually:

```cpp
// Writer
initialize_descriptor(d);
publish_ptr.store(d, std::memory_order_release);

// Reader
auto* d = publish_ptr.load(std::memory_order_acquire);
consume_descriptor(d);
```

Acquire/release ordering can establish **publication visibility**, but it does not by itself provide reclamation safety. In particular, release/acquire does not replace an RCU grace period, hazard pointers, epochs, or QSBR tracking. It also does not make concurrent in-place writes to ordinary fields safe.

Therefore the exact guarantee should be stated as:

> If publication uses release, readers use acquire, descriptor fields are immutable after publication, and reclamation occurs only after a valid RCU/QSBR grace period, readers observe a fully initialized immutable snapshot and cannot access reclaimed storage.

Without those conditions, the guarantee is not snapshot isolation but merely a partially ordered access pattern. The 88-byte layout may be useful for cache-line or ABI design, but its byte count has no inherent semantic significance.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no basis for claiming automatic multi-silicon conformance across these ecosystems. They differ in:

- memory models and scope semantics;
- synchronization primitives;
- compiler reordering rules;
- floating-point contraction and rounding behavior;
- tensor layouts and aliasing assumptions;
- atomic support and alignment requirements;
- GPU execution models and device-specific numerical behavior.

A valid conformance claim must distinguish at least three levels:

| Level | Required guarantee |
|---|---|
| Functional | Same logical result within an explicitly defined tolerance |
| Numerical | Defined error, orthogonality, residual, and determinism bounds |
| Memory-model | Proven happens-before/publication/reclamation behavior on each target |

C++20 and Rust can express host-side atomic protocols, but CUDA device code, Triton kernels, and XLA lowering may require separate target-specific implementations. An acquire/release designation in one language cannot simply be assumed to map to an equivalent guarantee in every backend. Likewise, bitwise identity across CUDA, XLA, Triton, and CPU Rust/C++ is not a reasonable default unless reductions, math modes, layouts, and compiler flags are tightly constrained.

A defensible conformance contract would specify:

\[
\|Q^{\mathsf T}Q-I\| \le \tau_{\mathrm{orth}},
\qquad
\frac{\|Q-(X+\Xi)\|}{\|X+\Xi\|}\le\tau_{\mathrm{fact}},
\]

plus descriptor publication tests, reclamation stress tests, race detection, alignment checks, and target-specific atomic-ordering tests. The tolerances must be parameterized by datatype, matrix size, backend, and hardware.

## Definitive arbitration

The strongest synthesis supported by established numerical-analysis and concurrency principles is:

- **Retraction:** no method is unconditionally stable for arbitrary \(10^{10}\)-scale steps. Use scaled arithmetic, condition/rank detection, residual validation, and Householder QR fallback; prefer polar for well-conditioned smooth retraction and Cayley for cases where its structured solve is demonstrably well-conditioned.
- **Descriptor memory ordering:** release publication plus acquire consumption is necessary for visibility, but RCU/QSBR grace-period reclamation is separately necessary for lifetime safety. An 88-byte layout provides no semantic guarantee by itself.
- **Multi-silicon conformance:** guarantee semantic equivalence only through explicit backend contracts and tolerance-based validation. Do not claim bitwise identity or universal memory-model equivalence without target-specific proofs and tests.

Accordingly, any Tribunal finding asserting unconditional Cayley superiority at extreme steps, snapshot isolation from acquire/release alone, or automatic CUDA/XLA/Triton/C++20/Rust conformance should be classified as **overstated unless backed by the missing kernel specifications, formal memory-ordering proof, and cross-backend test data**.