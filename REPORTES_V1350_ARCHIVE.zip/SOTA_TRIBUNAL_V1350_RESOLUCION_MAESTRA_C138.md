# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 138

I cannot substantiate a definitive arbitration of the claimed **POLYDIM V1350 / Cycle 138** findings because no public specification, six-kernel definitions, benchmark data, or reports from the eight named Tribunal models were provided. The available search evidence supports only general facts about Cayley retractions on the Stiefel manifold, not the purported V1350 architecture or its cross-silicon guarantees.[1][3][6]

## 1. Cayley–Stiefel retraction under extreme steps

For \(X\in\mathrm{St}(n,p)\) and a skew-symmetric generator \(\Omega^\top=-\Omega\), the Cayley update has the form

\[
X^{+}
=
\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
\left(I+\frac{\alpha}{2}\Omega\right)X.
\]

In exact arithmetic, the Cayley factor is orthogonal because it is a Cayley transform of a skew-symmetric matrix. Thus, when the solve exists, it preserves \(X^{+\top}X^+=I\). The literature identifies it as a valid Stiefel retraction and, under the canonical metric, a second-order retraction.[1][3][6]

That does **not** establish numerical stability for \(|\alpha|\ge 10^{10}\). At such scales:

- the products \(\alpha\Omega\) may overflow or lose relative accuracy;
- the solve can become poorly scaled even if the exact matrix remains nonsingular;
- forming \(I\pm \alpha\Omega/2\) can cause catastrophic cancellation or conditioning problems;
- iterative “few-matrix-multiplication” implementations do not automatically inherit the exact orthogonality guarantee.[3]

A mathematically defensible arbitration is therefore:

| Method | Exact-arithmetic invariant | Extreme-step numerical guarantee |
|---|---|---|
| Cayley retraction | Orthogonality if the linear solve is exact and nonsingular | No unconditional guarantee without scaling, stable solves, residual checks, and fallback |
| Householder QR | Orthogonality up to backward error under a stable implementation | Generally the strongest default for robust re-orthogonalization |
| Polar factor | Closest orthogonal factor under the Frobenius norm, when defined | Strong geometric quality, but requires a stable SVD or polar iteration |

The superior architectural rule is **not** “Cayley always wins.” It is a safeguarded hybrid:

1. Scale the generator and step before evaluation.
2. Use a backward-stable solve or structured Cayley implementation.
3. Check the residual and orthogonality defect.
4. Fall back to Householder QR or a stable polar decomposition when thresholds are exceeded.
5. Report the achieved bound, for example
   \[
   \|X^{+\top}X^+-I\| \le \tau_{\mathrm{orth}},
   \]
   rather than claiming exact stability.

Without those controls, no model can honestly guarantee stability for every \(|\mathrm{step}|\ge10^{10}\).

## 2. PMTP 88-byte descriptors and RCU/QSBR

The phrase **“PMTP 88-byte Descriptor”** is not corroborated by the available sources. Consequently, the exact field layout, alignment, ownership rules, and publication protocol cannot be arbitrated.

The correct memory-ordering contract for an immutable snapshot descriptor is:

- The writer fully initializes the descriptor payload.
- The writer publishes the descriptor pointer or generation with **release** semantics.
- A reader acquires that publication before dereferencing the payload.
- The writer retires the old descriptor only after the applicable RCU grace period or QSBR quiescent-state condition.
- Readers do not access a retired object after leaving their read-side critical section.

In abstract C++ terms, the essential relation is:

\[
\text{payload initialization}
\;\sequenced\text{-before}\;
\text{release publication}
\;\ synchronizes\text{-with}\;
\text{acquire observation}
\;\text{before}\;
\text{payload read}.
\]

Acquire/release alone does **not** provide reclamation safety. It orders visibility; RCU/QSBR supplies the lifetime guarantee. A correct architecture therefore needs both:

\[
\text{publication ordering}
+
\text{reader protection}
+
\text{deferred reclamation}.
\]

An 88-byte size has no bearing on these semantics. It can affect cache-line placement, atomicity assumptions, padding, and false sharing, but it cannot make a non-atomic publication safe. If the descriptor contains mutable fields, those fields require their own synchronization or must be excluded from the immutable snapshot contract.

The strongest defensible guarantee is:

> A reader that enters the read-side critical section before acquiring the published pointer observes a fully initialized descriptor version, and that version remains alive until the reader exits the critical section and the reclamation mechanism completes a grace period.

That guarantee requires an explicitly specified RCU/QSBR implementation; it cannot be inferred from the descriptor’s byte count.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared uniformly by these environments. “Multi-silicon conformance” must therefore be defined as a constrained portability profile, not assumed from source-level similarity.

Important distinctions include:

- **C++20 and Rust** define language-level atomic and data-race rules, but GPU back ends may impose additional restrictions.
- **CUDA** has device, block, system, and host visibility scopes; a block-level barrier is not a device-wide publication primitive.
- **Triton** exposes program-instance and device-oriented synchronization abstractions whose exact behavior depends on the generated backend.
- **XLA** is an optimizing compiler IR/runtime system; operation ordering and aliasing must be expressed through supported primitives, not inferred from source sequencing.
- Different silicon targets may differ in cache coherence, atomics, subgroup behavior, supported widths, and floating-point contraction.

A conformant V1350 profile would need to specify, for every kernel:

1. Data layout, alignment, endianness, and padding.
2. Integer widths and overflow behavior.
3. Floating-point mode, including FMA, flush-to-zero, NaN, and reassociation policy.
4. Atomic width, scope, ordering, and availability.
5. Barrier scope and participation requirements.
6. Whether descriptor publication is host-visible, device-visible, or both.
7. Deterministic reduction and tie-breaking rules.
8. Numerical tolerances for manifold invariants and iterative solvers.
9. A reference implementation and differential tests.
10. A failure behavior for unsupported hardware features.

The resulting guarantee should be phrased conditionally:

\[
\text{same specified input}
\Longrightarrow
\text{observationally equivalent result within declared tolerance},
\]

under a declared capability set and memory model. Bitwise identity across CUDA, XLA, Triton, C++20, Rust, and arbitrary silicon is not a reasonable default guarantee.

## Arbitration

Based on the evidence available, the only technically supportable synthesis is:

- **Cayley** is attractive because it preserves the Stiefel constraint in exact arithmetic and is a second-order retraction under the canonical metric.[1][3][6]
- **Householder QR** should be the mandatory robustness fallback for extreme steps.
- **Polar decomposition** is the preferred geometric projection when nearest-orthogonal behavior matters and a stable polar/SVD routine is available.
- **Acquire/release** is necessary for snapshot publication but insufficient for RCU/QSBR reclamation.
- **Cross-silicon conformance** requires an explicit portability contract; it cannot be claimed merely because implementations exist in five programming/compiler ecosystems.

Accordingly, no exact architectural guarantees for the six V1350 kernels can be certified from the supplied information. A definitive arbitration would require the eight model reports, the V1350 specification, descriptor schema, memory-ordering protocol, kernel source or pseudocode, target matrix, and reproducible conformance results.