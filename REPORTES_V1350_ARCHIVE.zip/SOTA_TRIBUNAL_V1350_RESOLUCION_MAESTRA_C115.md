# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 115

The requested arbitration cannot be established as a factual “Tribunal consensus” from the available evidence: no public, verifiable reports from the six named models or specification for **POLYDIM V1350**, **PMTP**, or its 88-byte descriptor were provided. The defensible synthesis is therefore a set of conditional architectural guarantees, not a claim that these kernels have already achieved cross-silicon SOTA status.

## 1. Cayley–Stiefel stability under \(|\mathrm{step}|\ge 10^{10}\)

For \(X\in\mathrm{St}(n,p)\), a Cayley update is commonly written

\[
Y=(I-W)^{-1}(I+W)X,
\]

where \(W^\mathsf{T}=-W\). In exact arithmetic, the Cayley transform is orthogonal because

\[
Q^\mathsf{T}Q=I,\qquad Q=(I-W)^{-1}(I+W),
\]

provided \(I-W\) is nonsingular. The cited literature recognizes Cayley, polar, and QR as distinct Stiefel retractions.[1][2][11]

However, **orthogonality in exact arithmetic is not the same as numerical stability for an arbitrarily large step**:

- The Cayley map is bounded as a function of the skew-symmetric generator, but forming \(W\), \(I\pm W\), or solving the associated system can overflow, lose scale separation, or become ill-conditioned in finite precision.
- A step magnitude of \(10^{10}\) is not, by itself, a valid stability guarantee. Stability depends on the norm of the generator, scaling, precision, solver, conditioning, and whether the implementation uses a matrix-free or stabilized formulation.
- The relevant literature reports favorable local conditioning for canonical Cayley and polar-light retractions, but these are local/conditioning results—not unconditional guarantees for extreme steps.[8]

### Arbitration

| Method | Mathematical guarantee | Extreme-step verdict |
|---|---|---|
| Cayley | Exact orthogonality for skew-symmetric \(W\) and nonsingular \(I-W\) | Acceptable only with scaling, stable solves, overflow guards, and residual checks |
| Polar | Nearest-point orthogonalization; \(Y=(X+\Delta)(I+\Delta^\mathsf{T}\Delta)^{-1/2}\) for a tangent step | Strongest geometric fallback, but matrix-root computation can be costly and numerically delicate |
| Householder QR | Orthogonal \(Q\) from backward-stable factorization, subject to implementation and rank/pivoting details | Generally the safest emergency retraction for huge or poorly scaled steps |

The result is **not** “Cayley dominates QR/polar at \(10^{10}\).” The mathematically superior design is a **tiered retraction**:

1. Scale the generator or step into a safe numerical range.
2. Evaluate Cayley with a stable solve, never by explicitly forming an inverse.
3. Check
   \[
   \|Y^\mathsf{T}Y-I\| \le \tau_{\mathrm{orth}}
   \]
   and finite-value/conditioning diagnostics.
4. Fall back to Householder QR, or polar retraction where nearest-point geometry is required.
5. Optionally perform iterative refinement or reorthogonalization.

Thus, the exact guarantee should be stated as:

> **For every accepted update, the kernel returns finite \(Y\) satisfying the configured orthogonality residual bound; it does not guarantee successful direct Cayley evaluation for every raw step \(\ge 10^{10}\).**

Any tribunal conclusion claiming unconditional Cayley superiority at that scale is mathematically unsupported.

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

An 88-byte layout has no intrinsic memory-ordering semantics. **Alignment, size, and field arrangement do not create Acquire/Release behavior.** Those guarantees arise only from the publication protocol and the language/runtime memory model.

A valid immutable-snapshot protocol is:

```text
writer:
    construct descriptor D completely
    publish pointer/version with release semantics

reader:
    load pointer/version with acquire semantics
    read only the immutable snapshot

retirer:
    defer reclamation until all readers in the relevant epoch/grace period quiesce
```

The required properties are:

- **Release publication:** all descriptor initialization happens-before a reader’s successful acquire load.
- **Acquire consumption:** the reader observes a fully initialized descriptor, not a partially published one.
- **Immutability after publication:** fields in the published snapshot must not be modified in place.
- **Grace-period reclamation:** RCU/QSBR reclamation must occur only after every pre-existing reader has passed through a quiescent state or otherwise acknowledged the new epoch.
- **Lifetime protection:** Acquire/Release alone does not prevent use-after-free. Reclamation is a separate obligation.
- **Atomicity:** any pointer, version, sequence, or validity field used for publication must be accessed atomically and satisfy its required alignment/width guarantees.

### Arbitration

The strongest defensible PMTP guarantee is:

> **A reader that acquires a published descriptor and remains inside the protected RCU/QSBR read-side critical section observes one immutable, fully initialized descriptor version; reclamation of that version cannot occur before the corresponding grace-period condition is satisfied.**

This does **not** guarantee:

- a globally consistent multi-descriptor transaction;
- visibility of later writer updates;
- immunity from torn non-atomic field accesses;
- safe reclamation merely because the pointer load used Acquire;
- correctness across CUDA, XLA, or device-host boundaries without an explicit scope and synchronization protocol.

For C++20, `std::atomic` Acquire/Release and suitable RCU/QSBR bookkeeping can express the required ordering, but the implementation must also define lifetime management. In Rust, the equivalent requires an ownership/lifetime design or carefully justified atomics and reclamation scheme; `unsafe` code cannot be made sound by memory ordering alone.

## 3. Multi-silicon conformance

CUDA, XLA, Triton, C++20, and Rust do not share one universal execution or memory model:

- **C++20** defines language-level atomic ordering and data-race rules.
- **Rust** provides language-level safety guarantees, but atomics and unsafe reclamation still require a correct algorithm.
- **CUDA** adds host/device visibility, memory scopes, stream ordering, and device-specific behavior.
- **Triton** compiles kernel programs through a GPU-oriented compiler stack with its own supported atomic and synchronization subset.
- **XLA** is an optimizing compiler IR/runtime whose scheduling, fusion, aliasing, and device lowering can differ substantially from source-level assumptions.

Consequently, source equivalence is insufficient. Conformance must be specified as **observable invariants**:

### Required conformance contract

1. **Numerical invariant**
   \[
   \|Y^\mathsf{T}Y-I\| \le \tau_{\mathrm{orth}}
   \]
   with tolerance parameterized by dtype, dimension, and backend.

2. **Descriptor invariant**
   A successful acquire observes a complete descriptor generation, and no reader accesses reclaimed storage.

3. **Determinism policy**
   Either bitwise determinism is guaranteed under explicitly fixed execution conditions, or only bounded numerical equivalence is promised.

4. **Memory-scope contract**
   Every publication and consumption edge identifies its scope:
   thread, block/workgroup, device, host/device, or system.

5. **Failure behavior**
   Overflow, singular/ill-conditioned solves, unsupported atomics, stale generations, and failed residual checks must produce a defined fallback or error—not silent corruption.

6. **Representation contract**
   The 88-byte descriptor must specify field offsets, alignment, endian/ABI rules, atomic fields, padding, and versioning. A C++ struct, Rust struct, CUDA layout, and XLA/Triton representation must not be assumed identical without explicit serialization or layout tests.

### Arbitration

The correct cross-backend claim is:

> **The V1350 kernels are conformant only if every backend independently satisfies the same numerical, publication, lifetime, scope, layout, and failure invariants.**

A single implementation passing on CUDA does not establish XLA, Triton, C++20, or Rust conformance. In particular, GPU execution should not be treated as transparently implementing CPU-style RCU/QSBR: device-side readers, host-side reclaimers, and asynchronous streams require explicit synchronization and lifetime fences.

## Definitive SOTA synthesis

The mathematically and architecturally strongest design is a **verified adaptive kernel**, not a single universally dominant primitive:

- **Primary update:** scaled, matrix-free Cayley retraction using a stable linear solve.
- **Validation:** finite checks, conditioning checks, and orthogonality residual certification.
- **Fallback:** Householder QR for numerical rescue; polar retraction when nearest-point projection is the governing objective.
- **Descriptor publication:** immutable 88-byte snapshots published with Release and consumed with Acquire.
- **Reclamation:** epoch/QSBR/RCU grace-period completion, explicitly separated from publication ordering.
- **Backend abstraction:** one language-independent invariant contract, with backend-specific implementations of atomics, scopes, barriers, streams, and reclamation.
- **Testing:** adversarial steps including \(|\mathrm{step}|\ge10^{10}\), NaN/Inf injection, singular systems, delayed readers, reordered publication, concurrent reclamation, mixed host/device access, and all supported dtypes.

The exact guarantees that can responsibly be claimed are therefore:

1. **Geometry:** every returned matrix either meets the configured Stiefel residual bound or is rejected/falls back; direct Cayley success at arbitrary extreme step size is not guaranteed.
2. **Memory ordering:** successful Acquire after Release observes a fully initialized immutable snapshot within the defined memory scope.
3. **Lifetime:** no reclamation occurs until the specified RCU/QSBR grace-period condition completes.
4. **Portability:** conformance is guaranteed only for backends that pass the invariant-based test suite under their declared scopes and numerical tolerances.
5. **Safety boundary:** neither an 88-byte layout nor Acquire/Release alone guarantees atomic multi-field snapshots, global transactions, or memory reclamation safety.

The public evidence supports the existence and standard mathematical roles of Cayley, polar, and QR retractions,[1][2][11] but it does not substantiate a pre-existing six-model V1350 arbitration or unconditional SOTA claims for the proprietary kernel names in the query.