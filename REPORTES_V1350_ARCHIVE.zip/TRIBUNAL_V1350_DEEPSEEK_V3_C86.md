# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 86)

# POLYDIM V1350 — High Tribunal Audit, Cycle 86

**Presiding note.** The Tribunal treats the six artifacts as *claims*, not as verified code. Where the submission asserts a property (e.g., "12/12 physical conformance checks", "88-byte descriptor", "Neumaier compensated"), we audit the *claim's mathematical consistency* and flag what cannot be certified without the source. We do not fabricate line numbers or benchmark numbers.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor `<4sHHQQQQQBB6x4Q` decomposes as:

| Field | Type | Bytes | Cumulative |
|---|---|---|---|
| magic | `4s` | 4 | 4 |
| version | `H` | 2 | 6 |
| flags | `H` | 2 | 8 |
| dims[0..4] | `Q×5` | 40 | 48 |
| rank, dtype | `B,B` | 2 | 50 |
| pad | `6x` | 6 | 56 |
| aux[0..3] | `Q×4` | 32 | **88** |

**Verdict (Rule 22):** Structurally compliant *iff* `struct.calcsize` is asserted at import time and the C++/Rust/CUDA mirrors use `#pragma pack(1)` / `#[repr(C, packed)]` / `__align__(8)` respectively. **Required hardening:** a single canonical header (`pmtp_v1350.h`) with `static_assert(sizeof(PmtpTensorDescriptor)==88)` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>()==88);` in Rust, and a Python `assert struct.calcsize("<4sHHQQQQQBB6x4Q")==88` at module load. Without these, the "88-byte" claim is a *convention*, not an *invariant*.

**Zero 1D tokens:** The descriptor carries `rank` and `dims[5]`. A "1D token" in inter-agent traffic would be a payload whose rank field is 1 and whose dims[1..4] are zero. Rule 22 forbids this. **Audit finding:** none of the six targets explicitly rejects `rank==1` at the FFI boundary. **Recommendation:** add a `PMTP_ERR_RANK1` rejection in the orchestrator's `validate_descriptor()` and mirror it in the Rust `TryFrom<&[u8]>` impl.

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Lock risk |
|---|---|---|
| T1 orchestrator | none (probe only) | **low** |
| T2 C++ AVX-512 | Intel/AMD ISA | **medium** — AVX-512 is not universal (Zen4 yes, Zen3 no, Apple no) |
| T3 Rust SIMD | portable via `std::simd` or `wide` | **low** |
| T4 CUDA | NVIDIA-only (cuSOLVER, CUDA Graphs) | **high** |
| T5 XLA | Google TPU / AWS Trainium | **high** (two-vendor, still closed) |
| T6 Triton | AMD ROCm + NVIDIA | **medium** (open ISA, closed toolchain) |

**Verdict (Rule 27):** T4 and T5 **violate** a strict reading of Rule 27 unless the orchestrator's `HardwareProbe` provides a *functional fallback* (T2/T3 path) that preserves the same numerical contract. The submission claims "Multi-silicon HardwareProbe" — the Tribunal requires the probe to expose a `capability_matrix` and the orchestrator to *refuse* dispatch (not silently degrade) when the required capability is absent. Silent degradation is the actual Rule 27 violation.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

**Claims audited:** Multi-silicon probe, `PmtpSlabAllocator`, 88-byte descriptor, 12/12 conformance.

**Numerical degeneracy:**
- The orchestrator itself performs no arithmetic, so `step → ∞` is not a degeneracy *here*. However, the orchestrator is the *dispatcher*: if it forwards `step` as a Python `float` (IEEE-754 binary64) to a C++ `double`, the round-trip is exact. If it forwards as `float32` (e.g., via a NumPy `astype`), then `step ≥ 2^128` overflows to `inf` and `step ≤ 2^-149` flushes to zero. **Finding:** the descriptor's `dtype` byte must gate the wire format; the orchestrator must reject `step` outside `[2^-1022, 2^1023]` for FP64 and `[2^-126, 2^127]` for FP32 *before* dispatch.

**Slab allocator:** `PmtpSlabAllocator` implies a bump/pool allocator over 88-byte-aligned slabs. **Risk:** if slab size is not a multiple of 88, the last descriptor in a slab straddles a cache line, breaking the "zero-copy PMTP validation" claim in T2. **Required proof:** `slab_bytes % 88 == 0` and `slab_bytes % 64 == 0` (cache-line alignment). Recommend `slab_bytes = lcm(88, 64) = 704` or a multiple thereof.

**12/12 conformance:** The Tribunal cannot certify this without the test harness. **Demand:** publish the 12 checks as a machine-readable manifest with pass/fail and the *exact* byte offsets validated.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

**Claims audited:** AVX-512 + OpenMP, Neumaier compensated dot, subnormal audits at `-12` and `-14`, zero-copy PMTP.

### 2.1 Neumaier dot product — asymptotic condition number

For vectors `x, y ∈ R^n`, the Neumaier (improved Kahan–Babuška) sum computes `s = Σ xᵢyᵢ` with compensation `c`. The *forward* error bound is

```
|ŝ − s| ≤ (2u + O(nu²)) · Σ |xᵢyᵢ| + O(u²)·|s|
```

where `u = 2^-53` for FP64. The **condition number** of the dot product is

```
κ_dot = (Σ |xᵢyᵢ|) / |Σ xᵢyᵢ|
```

Neumaier does **not** reduce `κ_dot`; it reduces the *constant* in the error bound from `nu` to `2u`. **Consequence:** if `κ_dot ≥ 10^16`, even Neumaier returns garbage. **Finding:** the kernel must expose `κ_dot` as a diagnostic and the orchestrator must reject `κ_dot > 1/u` for the requested precision.

### 2.2 Subnormal audits at `-12`, `-14`

These are almost certainly *exponent* thresholds (i.e., `2^-12`, `2^-14`), not literal values. **Degeneracy analysis:**
- `step → 0`: if `step < 2^-1022` (FP64), the value is subnormal; if `step < 2^-1074`, it is zero. AVX-512 `vfmadd` handles subnormals correctly *unless* FTZ/DAZ is set in MXCSR. **Finding:** the kernel must explicitly clear FTZ/DAZ (`_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`) and assert it in a `static_assert`-style runtime check. Otherwise the "subnormal audit" is theater.
- `step → ∞`: `step ≥ 10^10` is *not* an overflow for FP64 (max ≈ 1.8×10^308). The real risk is in the *Cayley retraction* (T4) and *Lyapunov solve* (T5), where `step` enters as `(I + step·A/2)^{-1}(I − step·A/2)`. For `step·‖A‖ ≫ 1`, the Cayley transform → `−I`, which is a *valid* orthogonal matrix but a *degenerate* retraction (rank-deficient tangent). **Finding:** T2's dot product is safe for `step ≥ 10^10`; the degeneracy lives downstream.

### 2.3 Zero-copy PMTP

**Proof obligation:** the C++ side must `reinterpret_cast<const PmtpTensorDescriptor*>(buf)` only after `alignof(buf) ≥ 8` and `sizeof(buf) ≥ 88`. **Recommendation:** use `std::span<const std::byte, 88>` and `std::bit_cast` (C++20) rather than `reinterpret_cast`, which is UB under strict aliasing.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

**Claims audited:** Rust 2021 Safe SIMD, `panic=unwind` FFI barrier, Neumaier sums, packed 88-byte descriptor.

### 3.1 `panic=unwind` as FFI safety barrier

**This is a category error.** `panic=unwind` *allows* unwinding; it does **not** make unwinding across an FFI boundary safe. Rust's `extern "C"` ABI is `nounwind` by default since Rust 1.71 — a panic in an `extern "C"` function aborts. **Correct hardening:**
- Use `extern "C-unwind"` if the C++ side is compiled with `-fexceptions` and can catch.
- Otherwise, wrap every FFI entry in `std::panic::catch_unwind` and convert to an error code.
- **Finding:** the claim "panic=unwind FFI safety barrier" is **false as stated**. The Tribunal demands the actual `#[no_mangle] pub extern "C"` signatures and the `catch_unwind` wrappers.

### 3.2 Packed 88-byte descriptor

`#[repr(C, packed)]` on a struct containing `u64` fields produces *unaligned* field access, which is UB-adjacent in Rust (the compiler will generate byte-wise loads, and `&desc.dims[0]` is a misaligned reference → E0793). **Recommendation:** use `#[repr(C)]` with explicit `#[repr(align(8))]` and a `[u8; 6]` pad, *not* `packed`. The 88-byte size is achievable without `packed` because 88 is a multiple of 8.

### 3.3 Neumaier in Rust

`f64::mul_add` (FMA) is *not* Neumaier; it is a single-rounded fused multiply-add. Neumaier requires the two-sum / two-product decomposition. **Finding:** verify the implementation uses `two_prod` (