# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 88

The available evidence does **not** contain the six Tribunal models’ actual reports or any verifiable specification for “POLYDIM V1350,” its six kernels, or the “PMTP 88-byte Descriptor.” Therefore, no defensible arbitration can declare a model-by-model winner or claim an implementation-specific guarantee. The strongest supportable synthesis is a **conditional architecture** based on established numerical-linear-algebra and memory-model principles.

## 1. Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

There is no universal theorem that a Cayley retraction is more stable than Householder QR or polar retraction for arbitrarily extreme steps. The result depends on the matrix scaling, conditioning, precision, solver, and whether the Cayley system is solved stably.

For a tangent update \(\eta\) at \(X\in\mathrm{St}(n,p)\), the standard alternatives are:

\[
R_{\mathrm{polar}}(X,\eta)
=(X+\eta)\left(I+\eta^\top\eta\right)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\eta)=\operatorname{qf}(X+\eta),
\]

and a Cayley form such as

\[
R_{\mathrm{Cayley}}(X,\eta)
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

where \(W^\top=-W\) and \(W\) represents the tangent direction. These formulations and their computational costs are documented in the Stiefel-retraction literature.[2][3][8][11]

### Arbitration

- **Householder QR** should be the default robustness fallback. Householder transformations are backward stable, and QR avoids explicitly forming \((X+\eta)^\top(X+\eta)\), which can square a condition number.
- **Polar retraction** is geometrically canonical and often highly accurate, but a naïve implementation using normal equations or an unstable inverse square root is unsuitable for extreme steps.
- **Cayley retraction** preserves orthogonality structurally when the skew-symmetric system is solved accurately. However, extreme steps can make the linear solve difficult, and the Cayley inverse/retraction may encounter problematic \(-1\) eigenvalue conditions in related inverse mappings.[1]
- A fixed-point Cayley iteration is not an unconditional guarantee for a step of \(10^{10}\). Its convergence and finite-precision behavior require bounds on the scaled operator and a reliable stopping criterion.[5]

### Definitive SOTA policy

For \(|\mathrm{step}|\ge10^{10}\), the mathematically strongest design is **not “Cayley always wins.”** It is:

1. Rescale or normalize the tangent update before constructing the retraction.
2. Compute a candidate with a structure-preserving Cayley or polar method.
3. Verify
   \[
   \|Q^\top Q-I\| \le \tau_{\mathrm{orth}}
   \]
   and a backward-error criterion.
4. Fall back to Householder QR if the test fails, the solve is ill-conditioned, an overflow/underflow is detected, or the requested precision cannot support the update.
5. Return an explicit diagnostic rather than silently claiming success.

Thus the guarantee should be:

> **Conditional orthogonality guarantee:** if the selected kernel completes without arithmetic exceptions and its residual tests pass, it returns a matrix satisfying the configured orthogonality tolerance. No kernel should promise unconditional accuracy for arbitrary \(10^{10}\)-scale inputs in finite precision.

The available source material supports bounded conditioning for particular second-order Cayley and polar-light constructions, but not an unconditional extreme-step theorem.[1]

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

No public specification for the PMTP layout was found, so the exact field offsets, ownership rules, and alignment cannot be established. The byte size alone says nothing about memory ordering.

The correct acquire/release protocol is:

### Publication

A writer constructs the descriptor and all immutable pointed-to state privately. It then publishes the descriptor pointer with **release** semantics:

```cpp
published.store(new_descriptor, std::memory_order_release);
```

### Read-side acquisition

A reader announces its read-side protection before loading the pointer, then loads with **acquire** semantics:

```cpp
reader_epoch.store(current_epoch, std::memory_order_release);

auto* d = published.load(std::memory_order_acquire);
```

The reader may access the descriptor only while its RCU/QSBR protection remains active.

### Retirement

The writer removes the old descriptor using release ordering, places it on a retirement list, and reclaims it only after every reader that could have observed it has passed through a quiescent state or advanced beyond the retirement epoch.

The architectural guarantee is:

> **Snapshot isolation:** a protected reader observes one immutable descriptor generation and its associated immutable payload; reclamation cannot occur before that reader leaves the protected interval.

Acquire/release does **not** by itself provide snapshot isolation. It must be combined with:

- immutable post-publication fields;
- correct reader registration;
- a grace-period or epoch-reclamation algorithm;
- no unsynchronized mutation through interior pointers;
- lifetime-safe pointer publication;
- appropriate fences when crossing non-C++ memory domains.

An 88-byte descriptor should therefore be treated as an ABI constraint, not as a synchronization primitive. If the descriptor contains mutable counters or flags, those fields need their own atomic protocol. If it contains pointers, the pointed-to objects require explicit lifetime and immutability rules.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no evidence establishing bitwise or semantic conformance of the six kernels across all five execution environments. These systems have materially different execution and memory models:

- **C++20 and Rust** can express acquire/release atomics and ownership constraints directly, subject to their language memory models.
- **CUDA** requires explicit attention to scope: block, device, or system. A device-level atomic ordering is not automatically equivalent to host synchronization or cross-device visibility.
- **Triton** exposes GPU memory-ordering capabilities through compiler- and hardware-dependent operations; source-level resemblance to C++ atomics is not sufficient proof.
- **XLA** uses compiler transformations and backend-specific lowering. A high-level operation should not be assumed to preserve a particular low-level atomic protocol unless the backend contract explicitly guarantees it.

The correct conformance target is **observational equivalence**, not identical instruction sequences:

\[
\text{same input}
\;\Longrightarrow\;
\begin{cases}
\text{same mathematical result within tolerance},\\
\text{same validity/error classification},\\
\text{same publication and reclamation invariants},\\
\text{same descriptor ABI interpretation}.
\end{cases}
\]

A valid conformance suite must include:

- randomized and adversarial Stiefel inputs;
- steps spanning normal values through \(10^{10}\)-scale values;
- rank-deficient and nearly singular updates;
- NaN, infinity, overflow, and underflow cases;
- concurrent publication/read/reclamation stress;
- litmus tests for stale reads and premature reclamation;
- per-backend tolerances and documented precision modes;
- ABI tests for all 88-byte offsets, alignment, endianness, and padding;
- differential comparison against a high-precision reference implementation.

The strongest safe guarantee is:

> **Cross-silicon conformance is achieved only for the explicitly tested backend, device, compiler, precision, and memory-scope tuple.** It cannot be inferred merely from sharing source code or an intermediate representation.

## Final arbitration

Given the evidence available:

| Question | Defensible ruling |
|---|---|
| Extreme-step Stiefel stability | Use adaptive Cayley/polar computation with residual validation and Householder QR fallback; no unconditional Cayley superiority claim is justified. |
| PMTP synchronization | Acquire/release is necessary for publication visibility but insufficient alone; RCU/QSBR grace periods and immutable generations are required for reclamation safety. |
| Multi-silicon conformance | Require backend-specific lowering, memory-scope specifications, and conformance tests; source-level portability is not a guarantee. |

Accordingly, the mathematically superior SOTA architecture is a **verified adaptive pipeline**: structure-preserving retraction where numerically admissible, Householder QR as the stability fallback, immutable generation-tagged descriptors, explicit acquire/release publication, epoch-based reclamation, and backend-specific conformance certification. Any Tribunal conclusion stronger than these guarantees would require the missing six reports, the V1350 kernel definitions, and executable or formal verification results.