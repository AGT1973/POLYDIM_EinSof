# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 142

The requested arbitration is **not verifiable from the available evidence**. The search record contains no public specifications, benchmark reports, source code, formal proofs, or per-model outputs for “POLYDIM V1350,” the six kernels, “PMTP 88-byte Descriptor,” or the eight claimed Tribunal findings. The identifiable PolyDiM project is a C++ library for polytopal discretization methods, not evidence for the architecture described here.[1][2]

Accordingly, no defensible “definitive” SOTA ranking or exact implementation guarantee can be attributed to Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, or Perplexity. A mathematically responsible synthesis is instead:

## 1. Extreme-step Stiefel retraction

For \(X^\top X=I\), a Cayley update commonly has the form

\[
X_{+}
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)X,
\qquad A^\top=-A .
\]

In exact arithmetic, the Cayley factor is orthogonal whenever the inverse exists. However, this does **not** establish numerical stability for \(|\alpha|\ge 10^{10}\):

- The solve may be poorly scaled.
- Forming \(I\pm \alpha A/2\) can create severe dynamic-range and cancellation issues.
- Finite precision can produce substantial loss of orthogonality.
- A formal retraction property is not the same as a backward-stability or forward-error guarantee.

Householder QR is generally the strongest default for orthogonalization because it is backward stable under standard floating-point assumptions. Polar decomposition can provide a high-quality nearest orthogonal factor, but its stability and cost depend on the implementation—Newton–Schulz, SVD-based, eigensolver-based, or otherwise.

**Arbitration:** no method can be declared universally superior at extreme step sizes without matrix dimensions, conditioning assumptions, precision, scaling strategy, solver details, and measured error bounds. A credible kernel should use step-size scaling, avoid explicitly formed ill-scaled matrices, monitor

\[
\|X^\top X-I\|,
\]

and fall back to Householder QR or a robust polar/SVD path when thresholds are exceeded.

The strongest valid guarantee is conditional:

> If the Cayley linear system is nonsingular and solved with a specified backward-stable method, and if overflow, underflow, and conditioning thresholds are excluded, the computed result has a stated floating-point error bound.

An unconditional guarantee for all \(|\text{step}|\ge 10^{10}\) is not mathematically justified.

## 2. 88-byte descriptor and RCU/QSBR semantics

Acquire/release operations alone do not define snapshot isolation. A valid RCU/QSBR protocol additionally requires:

- A release publication of the fully initialized descriptor or replacement pointer.
- An acquire load by readers before consuming the published state.
- Immutable-after-publication fields, or separate synchronization for mutable fields.
- Correct reader critical-section entry and exit.
- A grace-period mechanism that orders reclamation after all pre-existing readers have quiesced.
- Protection against ABA, stale pointer reuse, and descriptor tearing.
- An explicitly defined layout, alignment, padding, ownership, and atomicity model.

An 88-byte size has no inherent memory-ordering meaning. It may also straddle cache lines or violate assumptions about naturally atomic access. If readers access the descriptor through a pointer, publish the pointer—not an unsynchronized collection of ordinary fields—and ensure the pointed-to object remains alive through the reader critical section.

**Arbitration:** the exact guarantee should be stated as:

> A reader that performs the prescribed acquire publication/load and remains in a valid RCU/QSBR read-side critical section observes a fully initialized immutable snapshot; reclamation occurs only after a completed grace period covering that reader.

This guarantee is impossible to infer from the descriptor size or from “Acquire/Release” labels alone.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or execution model shared identically by all five environments:

- C++20 defines an abstract language memory model.
- Rust inherits platform atomic semantics while adding ownership and aliasing constraints.
- CUDA has device-, block-, system-, and scope-dependent synchronization and visibility rules.
- Triton exposes compiler- and backend-dependent semantics rather than a complete portable systems-memory model.
- XLA is an optimizing tensor compiler whose sequencing and aliasing guarantees depend on its operation definitions and backend.

Therefore, source-level portability cannot establish identical behavior. Conformance must be defined at an observable-contract level, with separate backend implementations and litmus tests.

The strongest realistic cross-silicon contract is:

- Identical logical results within a stated numerical tolerance.
- Identical descriptor versioning and snapshot-validity rules.
- No data race under each target’s native memory model.
- Explicit synchronization scopes for each backend.
- Defined behavior for retries, stale snapshots, reclamation, overflow, NaNs, and numerical failure.
- Validation on every supported architecture and compiler version.

Bitwise identity, identical instruction ordering, and identical memory timing across CUDA, XLA, Triton, C++20, and Rust cannot be guaranteed without much stronger restrictions.

## Definitive arbitration

The only defensible SOTA synthesis from the available record is:

1. **Use Cayley retraction as an optimized path, not as an unconditional extreme-step stability guarantee.** Apply scaling and conditioning checks, with Householder QR or robust polar/SVD fallback.
2. **Treat PMTP snapshot safety as a protocol property, not a descriptor-layout property.** Require release publication, acquire consumption, immutable snapshots, grace-period reclamation, alignment, and ABA protection.
3. **Define portability through a formal backend-neutral contract and conformance tests.** Do not claim that CUDA, XLA, Triton, C++20, and Rust acquire identical semantics merely because they expose similarly named operations.
4. **Withhold any ranking among the eight Tribunal models** until their actual reports, prompts, assumptions, test vectors, code, and evidence are supplied.

No exact architectural guarantee stronger than these conditional guarantees can be derived from the gathered sources.