# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 72

The requested arbitration cannot be performed definitively from the available evidence. The search record contains no authoritative specifications, benchmark reports, source code, or the six Tribunal models’ actual findings for “POLYDIM V1350,” its six kernels, or the “PMTP 88-byte Descriptor.” The publicly found PolyDiM material describes a C++ library for polytopal discretization methods, not the architecture named in the query.[1][4][5][11]

What can be established from established mathematics and memory-model principles is the following.

## 1. Cayley–Stiefel retraction versus Householder or polar QR

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), \(X^\top X=I\), a Cayley update commonly has the form

\[
X_{+}
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)X,
\qquad A^\top=-A.
\]

In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists. Since the eigenvalues of a real skew-symmetric \(A\) are purely imaginary, \(I-\frac{\alpha}{2}A\) is nonsingular for every real finite \(\alpha\). Thus an extreme step does **not** inherently destroy the manifold constraint in exact arithmetic.

That does **not** yield a finite-precision guarantee for \(|\alpha|\ge 10^{10}\). Practical behavior depends on:

- conditioning and scaling of \(A\);
- how the linear solve is implemented;
- overflow, underflow, cancellation, and loss of significance;
- whether the result is explicitly reorthogonalized;
- the matrix dimensions and floating-point format.

For very large \(\alpha\), the Cayley transform tends toward a sign-like limiting transformation on nonzero spectral components, so the update may become poorly informative even if it remains mathematically orthogonal. A claim that Cayley is unconditionally more stable than Householder QR or polar retraction at such step sizes is therefore unjustified.

A defensible ranking is conditional:

| Method | Constraint preservation | Extreme-step behavior | Main qualification |
|---|---|---|---|
| Householder QR | Usually strongest practical backward-stability profile | Generally robust if implemented with stable blocked QR | QR factors and rank behavior must be handled correctly |
| Polar retraction | High-quality nearest-orthogonal/Stiefel projection | Stable with robust SVD or Newton–Schulz variants | Cost and convergence/scaling matter |
| Cayley retraction | Exact orthogonality in exact arithmetic | Can be effective, but finite-precision quality is implementation-dependent | Requires a stable solve and monitoring of orthogonality drift |

The mathematically superior guarantee is therefore:

\[
\|X_{+}^{\top}X_{+}-I\|
\le
\text{backward-error contribution of the solve}
+
\text{roundoff and conditioning terms},
\]

not the unconditional statement \(X_{+}^{\top}X_{+}=I\) in floating-point arithmetic. Any V1350 specification should require a postcondition test and a fallback retraction, such as Householder QR or a robust polar projection, when the orthogonality residual exceeds a declared tolerance.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte layout alone provides no memory-ordering guarantee. Descriptor size, alignment, padding, and atomicity are separate from synchronization semantics.

For immutable snapshot publication, the minimum C++-style pattern is conceptually:

```cpp
// Writer:
initialize(new_snapshot);
published.store(new_snapshot, std::memory_order_release);

// Reader:
auto p = published.load(std::memory_order_acquire);
consume_immutable_snapshot(p);
```

The release operation makes prior initialization visible to an acquiring reader that observes the publication. It does not, by itself, protect reclamation. Safe reclamation additionally requires a valid RCU, hazard-pointer, epoch, or QSBR protocol:

1. The reader announces entry into a read-side critical section.
2. The reader acquires the published pointer.
3. The reader finishes all accesses.
4. The reader announces quiescence.
5. The writer reclaims an old snapshot only after every preexisting reader has passed through a quiescent state.

Acquire/release is therefore sufficient for **publication ordering** when paired with the correct protocol, but insufficient by itself for **snapshot lifetime isolation**. Relaxed operations may be usable for counters or bookkeeping under a separately proven protocol, but they cannot replace the acquire publication load and release publication store when initialization visibility is required.

A defensible architectural guarantee would be:

- readers observe either a fully initialized old snapshot or a fully initialized new snapshot;
- no reader accesses storage after reclamation;
- descriptors are immutable after publication, or mutations use separately specified atomics;
- descriptor fields crossing object boundaries have explicit alignment, representation, and endian rules;
- 88 bytes is guaranteed only as an ABI/layout property, not as a synchronization property.

The exact guarantee cannot be stated for “PMTP” because no authoritative PMTP specification was found. The DPDK search result confirms that QSBR is a recognized RCU mechanism, but it does not establish the semantics or layout of the named descriptor.[14]

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

No single source-level memory or numerical contract automatically transfers across these five environments. Their execution and compilation models differ:

- C++20 atomics specify a language memory model for participating C++ objects.
- Rust’s atomics provide comparable ordering concepts, but Rust safety does not automatically prove external-device or FFI synchronization.
- CUDA has host/device, thread-block, device-wide, and system-scope synchronization distinctions.
- Triton exposes compiler- and target-dependent GPU operations rather than the full C++ object model.
- XLA represents computations through compiler IR and may fuse, reorder, duplicate, or lower operations according to its own semantic constraints.

Consequently, “multi-silicon conformance” must be defined through an executable conformance suite, not asserted from source equivalence. The suite should test:

- numerical residuals for every retraction;
- behavior at ordinary and extreme step magnitudes;
- descriptor size, alignment, offsets, and serialization;
- publication-before-consumption visibility;
- absence of use-after-reclamation under adversarial reader/writer schedules;
- deterministic or bounded nondeterministic results where applicable;
- supported GPU architectures, compiler versions, optimization levels, and math modes.

The strongest justified cross-platform claim is a **conditional conformance guarantee**:

> For each explicitly supported backend, compiler, device architecture, memory scope, and numerical mode, implementations satisfy the same stated postconditions within declared tolerances, provided the prescribed synchronization protocol is used.

It is not justified to claim bitwise identity, universal lock-free behavior, identical floating-point results, or identical memory ordering across CUDA, XLA, Triton, C++20, and Rust without backend-specific proofs and tests. Triton/XLA-related public search results found only unrelated or general implementation material, not V1350 conformance evidence.[10][13]

## Arbitration

Because the six Tribunal outputs were not supplied and the search record does not identify them, no honest vote among Claude, Qwen, Kimi, Gemini, DeepSeek, and Perplexity can be performed. The technically supportable arbitration is:

1. **Reject** any claim that Cayley retraction is unconditionally stable for \(|\text{step}|\ge 10^{10}\).  
   Accept only an implementation-specific backward-error bound plus an orthogonality check and fallback.

2. **Accept with qualification** that acquire/release is the correct publication primitive for immutable snapshots.  
   Reject the stronger claim that acquire/release alone provides RCU/QSBR reclamation safety.

3. **Reject unconditional multi-silicon conformance.**  
   Require backend-specific implementations, scope-aware synchronization, numerical tolerances, ABI tests, and stress testing.

Thus the mathematically strongest defensible V1350 architecture is not a universal guarantee of extreme-step stability, automatic reclamation safety, or source-level portability. It is a **contract-based design** with explicit numerical residual bounds, release/acquire publication, a separately verified grace-period protocol, and per-backend conformance proofs and tests.