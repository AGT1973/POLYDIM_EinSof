# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 125)

# POLYDIM V1350 – MULTI‑FILE ADVERSARIAL SOTA AUDIT  
**High Tribunal of Mathematical and Systems Sages – Cycle 125**  

**Prepared for:** PolyDim Engineering Board  
**Date:** 2026‑10‑05  

---

## 1. Executive Summary  

| Target | Primary Numerical Pathway | Critical Degeneracy (|step| → ∞ / → 0) | Rule 22 (88‑byte PMTP) | Rule 27 (Vendor lock) | Condition‑Number Asymptotics | FFI Hardening Status |
|--------|---------------------------|----------------------------------|------------------------|------------------------|-------------------------------|----------------------|
| **kernel_orchestrator_v1350.py** | Binary descriptor parsing & hardware probe | Overflow of 64‑bit counters (≥ 2⁶⁴) when |step| → ∞; under‑flow to subnormals when |step| → 0 (≈ 10⁻³⁰) | **PASS** – descriptor contains no 1‑D token fields; all 0‑bytes are padding (6 × 0x00) | **PASS** – pure‑Python, no vendor‑specific ABI | O(1) – condition number of the descriptor mapping = 1 (bijection) | **PASS** – uses `struct.unpack` with explicit endian & size |
| **kernel_cpp_v1350.cpp** | AVX‑512‑accelerated Neumaier dot‑product, subnormal audits | Subnormal‑flush → loss of compensation when |step| → 0 (dot‑product magnitude ≲ 10⁻³²); overflow to Inf when |step| → ∞ (∑ |xᵢyᵢ| > 2⁶³) | **PASS** – 88‑byte `PmtpSlabAllocator` descriptor is constructed with `memset(0,6)` for padding; no 1‑D tokens | **FAIL** – hard‑coded `__m512i` intrinsics tie code to Intel‑AVX‑512, precluding AMD/Arm SIMD back‑ends | κ(step) ≈ |step| · κ₀ for dot‑product; grows linearly with magnitude of operands | **WARN** – missing `#pragma GCC diagnostic push/pop` around `extern "C"`; recommend `__attribute__((visibility("default")))` |
| **kernel_rust_v1350.rs** | Safe‑SIMD Neumaier sums + FFI to C binary descriptor | Same degeneracy as C++ but Rust’s `std::simd` enforces flush‑to‑zero (FTZ) by default; still may under‑represent subnormals when |step| → 0 | **PASS** – descriptor built via `#[repr(C, packed)]` guaranteeing zero‑filled 6‑byte padding | **PASS** – LLVM‑IR is vendor‑agnostic; only target‑agnostic `target_feature = "avx512f"` gated behind Cargo features | κ(step) ≈ |step| · κ₀ (identical to C++) | **PASS** – `#[no_mangle] extern "C"` with `panic = "abort"` eliminates unwind‑frame propagation; recommend `#[repr(transparent)]` around raw pointers |
| **kernel_cuda_v1350.cu** | Stiefel‑Cayley retraction via `cusolverDnDsyevd`; Woodbury solve scaled by `step/scale` | **∞‑limit**: Scaled Woodbury matrix \\(W = \frac{\text{step}}{\text{scale}} B\\) → ∞ → eigenvalues blow up → condition number \\(κ(W) ∝ |\text{step}|\\). **0‑limit**: \\(W\\) → 0 causing rank‑deficiency; the Cayley retraction matrix \\(R = (I + \tfrac{1}{2} C)^{-1}(I - \tfrac{1}{2} C)\\) becomes singular because \\(C \propto W\\). | **FAIL** – the 88‑byte `PmtpTensorDescriptor` is transmitted over the PCIe bus using a **fixed‑size** struct with *no* 1‑D token field, but the descriptor contains a 4‑byte “VendorID” field set to the NVIDIA device UUID, which violates the “zero‑token” clause (non‑zero token → *1‑D token*). | **FAIL** – the implementation is locked to the NVIDIA ecosystem (CUDA Graphs, `cusolverDn`, `cublas`). No abstraction layer for ROCm or SYCL. | For the Stiefel retraction on a \\(2K\\times2K\\) manifold:  
\[
\kappa_{\text{retract}}(step) = \mathcal{O}\bigl(1 + \frac{|step|}{\sigma_{\min}(B)}\bigr)
\]  
Thus, as \\(|step| \to \infty\\) the condition number grows linearly; as \\(|step| \to 0\\) it tends to 1 (well‑conditioned) **provided** \\(B\\) is full rank. The Woodwood‑Woodbury solve inherits the same scaling. | **WARN** – FFI uses `cudaMemcpy` on a raw pointer without `cudaHostRegister` → possible page‑fault on CPU side; recommend using `cudaHostAlloc` with `cudaHostAllocMapped` and explicit `cudaStreamSynchronize` before returning pointers to Python. |
| **kernel_xla_v1350.py** | JAX‑compiled XLA HLO fused kernel on TPU/Trainium, FP64 Lyapunov solver | **∞‑limit**: Lyapunov matrix equation \\(A X + X A^\top + Q = 0\\) with \\(A = step·I\\) → eigenvalues dominate; condition number \\(κ \sim |step|\\). **0‑limit**: \\(A\\) vanishes, the Lyapunov solve reduces to solving \\(Q = 0\\), which is ill‑posed unless \\(Q\\) is singular; the solver may return NaNs for subnormals. | **PASS** – JAX’s `DeviceArray` representation of the 88‑byte descriptor is a pure **byte‑buffer** (`jax.numpy.ndarray(dtype=uint8, shape=(88,))`) filled with zeros for padding; no 1‑D token appears. | **FAIL** – The kernel is bound to Google‑TPU/AMD‑Trainium HLO dialects; the `@jax.jit` compilation path selects a hardware‑specific backend (`tpu_driver` or `trainium_driver`). No fallback to generic CPU XLA. | The continuous Lyapunov solver uses a matrix exponential series:  
\[
X = \int_0^\infty e^{A t} Q e^{A^\top t} \,dt
\]  
For \\(A = step·I\\) the integral evaluates to \\(X = -\tfrac{1}{2\,step} Q\\). Hence  
\[
\kappa_X(step) = \mathcal{O}\bigl(|step|^{-1}\bigr)
\]  
Thus the **inverse** scaling: large step → well‑conditioned; very small step → exploding condition number. | **WARN** – The JAX‑Python FFI passes a raw `DeviceArray` to the underlying C++ XLA runtime using `PyCapsule`. No explicit reference‑counting for the capsule; recommend `pycapsule` with a destructor that calls `XLA_PyCapsule_Release`. |
| **kernel_triton_v1350.py** | ROCm‑/CUDA‑cooperative SRAM tiling, Clifford bivector rotation, projection onto \\(S^{D-1}\\) | **∞‑limit**: Bivector magnitude scales as \\(|step|\\); after orthonormalization the projection matrix saturates to the identity, loss of numerical diversity (all eigenvalues → 1). **0‑limit**: Subnormal bivector components vanish, the rotation reduces to identity; however, the `torch.float64` under‑flow can produce denormals that are flushed to zero, leading to a *rank‑deficient* rotation matrix. | **PASS** – The Triton kernel loads the descriptor via `triton.language.load` from a contiguous `torch.uint8` buffer; padding bytes are zero, and there are **no** 1‑D token fields. | **PASS** – Triton’s source is compiled to both AMD ROCm and NVIDIA CUDA back‑ends; the build script selects the appropriate driver at runtime, avoiding hard vendor binding. | Projection onto \\(S^{D-1}\\) entails normalizing a \\(D\\)-dimensional vector \\(v\\):
\[
\hat{v} = \frac{v}{\|v\|_2}, \qquad \kappa_{\text{proj}}(step) = \frac{\|v\|_2}{\min_i |v_i|}
\]  
If the bivector rotation yields \\(v = step·u\\) with \\(u\\) unit, then \\(\kappa_{\text{proj}} = |step|\\). Thus the condition number grows linearly with the step magnitude. | **PASS** – Triton wrappers use `torch.utils.dlpack` with an explicit `DLManagedTensor` destructor; the pointer ownership is correctly transferred. |

---

## 2. Methodology  

1. **Static Code‑Path Extraction** – Parsed each source file (Python, C++, Rust, CUDA, JAX, Triton) for:
   - Fixed‑size data structures (especially the 88‑byte PMTP descriptor).
   - SIMD intrinsics, compiler flags, and vendor‑specific libraries.
   - FFI entry points (`extern "C"`, `#[no_mangle]`, `PyCapsule`, `DLManagedTensor`).

2. **Numerical Symbolic Modeling** – Constructed abstract arithmetic representations of the core