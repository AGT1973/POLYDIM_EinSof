# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 167)

# POLYDIM V1350 — High Tribunal Audit, Cycle 167

**Presiding note.** The Tribunal treats each target as a *claim of correctness* under adversarial inputs, not as a marketing artifact. Findings are graded **PASS / CONDITIONAL / FAIL** with explicit counterexamples where the claim is falsifiable. Where the source is not in evidence, the Tribunal reasons from the *declared* invariants and flags any invariant that is under-specified as a **latent defect**.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor is declared as:

```
<4sHHQQQQQBB6x4Q
```

Let us audit the struct layout byte-by-byte under CPython `struct` semantics (native alignment disabled by `<`):

| Field | Type | Bytes | Cumulative |
|---|---|---|---|
| magic | `4s` | 4 | 4 |
| version_major | `H` | 2 | 6 |
| version_minor | `H` | 2 | 8 |
| flags | `Q` | 8 | 16 |
| n_rows | `Q` | 8 | 24 |
| n_cols | `Q` | 8 | 32 |
| stride | `Q` | 8 | 40 |
| scale_bits | `Q` | 8 | 48 |
| dtype_code | `B` | 1 | 49 |
| rank | `B` | 1 | 50 |
| pad | `6x` | 6 | 56 |
| reserved | `4Q` | 32 | **88** |

**Verdict: PASS on size.** 88 bytes exactly. The `6x` pad is *load-bearing*: it aligns the trailing `4Q` block to a 16-byte boundary relative to the struct start (offset 56 ≡ 8 mod 16, so the `4Q` block begins at offset 56, which is 8-aligned but **not** 16-aligned). If any consumer assumes 16-byte alignment of the reserved block (e.g., for `_mm_load_si128`), this is a **latent misalignment defect**. Recommendation: change pad to `14x` and drop one `Q`, or reorder so the `4Q` block starts at offset 64. As written, the descriptor is *packed-correct* but *SIMD-hostile*.

**Rule 22 "zero 1D tokens"** — the Tribunal interprets this as: no inter-agent message may carry a bare 1-D scalar/vector; all payloads must be the 88-byte PMTP envelope. Audit:

- **T1 (Python orchestrator):** `struct.pack('<4sHHQQQQQBB6x4Q', ...)` — **PASS** if and only if every IPC write goes through this packer. The Tribunal cannot verify without source; flag as **CONDITIONAL**.
- **T2 (C++):** zero-copy PMTP validation is claimed. Zero-copy + 88-byte fixed layout is compatible **only if** the C++ side uses `#pragma pack(1)` or `alignas(8)` with a static_assert. **Demand:** `static_assert(sizeof(PmtpDescriptor) == 88, ...)` and `static_assert(offsetof(PmtpDescriptor, reserved) == 56, ...)`. Absent these, **FAIL**.
- **T3 (Rust):** `#[repr(C, packed)]` on an 88-byte struct. Rust's `packed` disables alignment, which is correct for wire format but **forbids taking references to fields** (E0793). If the Rust code does `&desc.n_rows`, it will not compile — good. If it uses `read_unaligned`, fine. **CONDITIONAL** pending source.
- **T4/T5/T6:** CUDA/XLA/Triton are device-side; the 88-byte envelope must be *reconstructed* on host before any inter-agent hop. If any of these emit a raw `float*` or `int64` token across the FFI boundary, **Rule 22 is violated**. Flag as **CONDITIONAL — requires grep for `cudaMemcpy` of non-88-byte payloads**.

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Verdict |
|---|---|---|
| T1 Python | none (pure host) | PASS |
| T2 C++ AVX-512 | Intel/AMD ISA, but portable via `#ifdef __AVX512F__` | PASS if guarded |
| T3 Rust SIMD | `std::simd` is nightly; `packed_simd` is unmaintained | **CONDITIONAL** — pin toolchain |
| T4 CUDA | **hard vendor lock** to NVIDIA (cuSOLVER, CUDA Graphs) | **FAIL Rule 27** unless a HIP/ROCm shim exists |
| T5 XLA | JAX is portable, but `@jax.jit` on TPU vs Trainium requires PJRT plugins | **CONDITIONAL** |
| T6 Triton | Triton now targets both ROCm and CUDA — **PASS** if no `torch.cuda.*` leakage | PASS |

**Tribunal ruling:** T4 is the sole **hard** Rule 27 violation. The architecture claims "multi-silicon" in T1 but T4's cuSOLVER `DnDsyevd` has no vendor-neutral equivalent in the declared stack. Either (a) add a MAGMA/rocSOLVER fallback, or (b) reclassify T4 as an *optional accelerator* rather than a core component.

---

## 1. Numerical degeneracy: `step → ∞` and `step → 0`

This is the deepest finding. The Tribunal treats `step` as the Cayley/Woodbury step size in T4 and the Lyapunov step in T5.

### 1.1 `step → ∞` (|step| ≥ 10¹⁰)

**T4 — Cayley retraction.** The Cayley transform on the Stiefel manifold is

$$Y(\tau) = (I - \tfrac{\tau}{2} A)^{-1}(I + \tfrac{\tau}{2} A)\, Y_0, \quad A = Y_0^\top \nabla f - \nabla f^\top Y_0 \text{ (skew)}.$$

As `τ → ∞`, `Y(τ) → -Y_0` (the antipode). The Woodbury solve is declared as

$$(M/\text{scale})\, W = (\text{step}/\text{scale})\, B.$$

**Degeneracy:** if `scale` is chosen as `max(|step|, 1)`, then `step/scale → 1` and `M/scale → 0` as `step → ∞`. The linear system becomes **singular in the limit** — `M/scale` loses all conditioning information. The condition number

$$\kappa(M/\text{scale}) = \kappa(M) \quad \text{(scale-invariant)},$$

so scaling does **not** help conditioning; it only prevents overflow in the RHS. **The declared "globally scaled Woodbury" is a numerical no-op for conditioning.** This is a **FAIL** of the implied claim that scaling improves stability.

**Correct fix:** use the *shifted* form `(M + λI) W = step·B` with `λ = ε·‖M‖_F`, and solve via `DnDsyevd` on the symmetric part. The current formulation is **unconditionally ill-posed as step → ∞**.

**T5 — Lyapunov.** Continuous Lyapunov `A X + X Aᵀ + Q = 0` solved in HBM. As the effective step → ∞ (i.e., `A` becomes stiff), the Bartels–Stewart algorithm's condition number scales as

$$\kappa_{\text{Lyap}} \sim \frac{\|A\|_2^2}{\text{sep}(A, -A^\top)},$$

where `sep` is the separation of spectra. For stiff `A`, `sep → 0` and the solve **loses all digits**. Pure FP64 does not save you: FP64 has ~16 digits, and `κ ~ 10¹⁶` is the hard wall. **CONDITIONAL** — requires a `sep` monitor and a fallback to `scipy.linalg.solve_continuous_lyapunov` with balancing.

### 1.2 `step → 0` (subnormals)

**T2 — subnormal audits at -12, -14.** These are almost certainly the exponents of the smallest normal (`2⁻¹⁰²² ≈ 10⁻³⁰⁸`) and smallest subnormal (`2⁻¹⁰⁷⁴ ≈ 10⁻³²⁴`) in FP64, or the FP32 analogues (`2⁻¹²⁶`, `2⁻¹⁴⁹`). The audit at `-12` and `-14` suggests **FP32 subnormal boundaries** (`2⁻¹²⁶ ≈ 1.2e-38`, `2⁻¹⁴⁹ ≈ 1.4e-45`).

**Neumaier compensated dot product** with subnormal inputs: the compensation term `c` accumulates rounding errors, but if the *inputs* are subnormal, the products `a_i · b_i` underflow to zero **before** compensation can capture them. Neumaier does **not** recover underflowed products. **FAIL** of the implied claim that Neumaier handles subnormals.

**Correct fix:** pre-scale inputs by `2^s` where `s = -min(exponent(a), exponent(b))`, compute the dot product, then scale back by `2^{-2s}`. This is the standard "subnormal-safe dot product" (cf. Higham, *Accuracy and Stability*, §3.1). Without this, the `-12/-14` audits are **cosmetic**.

**T4 — Cayley as step → 0.** `(I - τA/2)⁻¹ → I`, so `Y(τ) → Y_0`. This is **well-conditioned** — the Cayley transform is a smooth retraction with `κ → 1` as `τ → 0`. **PASS** in this limit. The danger is the *opposite* limit (§1.1).

**T6 — Clifford bivector rotations.** As the rotation angle → 0, the bivector `B → 0` and the rotor `R = exp(B/2) → 1`. Streaming these through SRAM tiling is fine, but if `B` is stored in FP32 and the angle is `< 2⁻²⁴`, the rotor is **exactly 1** and the rotation is silently dropped. **CONDITIONAL** — requires FP64 accumulation for the bivector norm.

---

## 2. Asymptotic condition numbers (demanded proofs)

### 2.1 T4 Woodbury

Let `M ∈ R^{2K×2K}` be the Woodbury base, `U, V ∈ R^{2K×r}` the low-rank factors. The Woodbury identity:

$$(M + UV^\top)^{-1} = M^{-