# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 129)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 129 · Adversarial SOTA Review

**Presiding note.** The Tribunal treats the six artifacts as *claims*, not as code. Where the submission asserts a property (e.g., "12/12 physical conformance", "panic=unwind FFI safety barrier", "pure FP64"), we audit the claim against the mathematics it implies. Where the claim is unverifiable from the description alone, we mark it **UNSUBSTANTIATED** and demand the artifact.

---

## 0. Cross-Cutting Findings (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens / 88-byte PMTP

The descriptor layout `<4sHHQQQQQBB6x4Q` is audited byte-by-byte:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version | `H` | 2 | 4 |
| flags | `H` | 2 | 6 |
| n_rows | `Q` | 8 | 8 |
| n_cols | `Q` | 8 | 16 |
| stride | `Q` | 8 | 24 |
| scale_exp | `Q` | 8 | 32 |
| step_exp | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| dtype | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| aux[4] | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict:** Structurally 88 bytes, no implicit padding (the `6x` is explicit). **Rule 22 satisfied at the wire level.**

**However — adversarial finding.** The `6x` pad is a *silent extension slot*. If any of the six kernels writes into offsets 50–55 (e.g., via `memcpy` of a larger struct, or via `#[repr(C)]` in Rust with a different field order), the 88-byte invariant is preserved but the *semantic* contract is violated. **Demand:** a `static_assert(sizeof(PmtpTensorDescriptor)==88)` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>()==88);` in Rust, and a `struct.calcsize` check in Python. Without these, Rule 22 is *asserted*, not *enforced*.

**Zero-1D-token rule.** None of the six descriptions mention a 1D token channel. But TARGET 5 (XLA) and TARGET 6 (Triton) are Python — the natural failure mode is a `jax.Array` of shape `(N,)` or a Triton `tl.arange` 1D block being passed as an inter-agent message. **Demand:** a runtime guard `assert x.ndim >= 2 or x.dtype == descriptor_dtype` at every FFI boundary.

### 0.2 Rule 27 — Silicon Contract / Vendor Lock

| Target | Vendor exposure | Verdict |
|---|---|---|
| 1 (orchestrator) | Multi-silicon probe — good | **PASS** if probe is table-driven |
| 2 (C++ AVX-512) | Intel/AMD x86 only | **CONDITIONAL** — needs scalar fallback |
| 3 (Rust SIMD) | `std::simd` is portable; `core::arch` is not | **CONDITIONAL** |
| 4 (CUDA) | **NVIDIA-only** | **FAIL** unless a HIP/ROCm path exists |
| 5 (XLA) | Google TPU **and** AWS Trainium — dual-vendor | **PASS** (rare) |
| 6 (Triton) | AMD ROCm **and** NVIDIA | **PASS** |

**Finding:** TARGET 4 is the sole vendor-lock violation. cuSOLVER `DnDsyevd` has no ROCm equivalent with identical numerics (rocSOLVER `syevd` differs in workspace query semantics and in the treatment of the `jobz='V'` path for `n < 32`). **Demand:** either (a) a HIP port with a numerical equivalence proof, or (b) an explicit `#ifdef __HIP_PLATFORM_AMD__` fallback to a hand-rolled Jacobi eigensolver with documented condition-number bounds.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy at step → ∞

The orchestrator's job is dispatch, not arithmetic — but it *owns* the `step_exp` field (offset 40). If `step_exp` is stored as a raw `Q` (unsigned 64-bit), then `step = 2^step_exp` overflows for `step_exp > 1023` in FP64. **The claim `|step| >= 10^10` is representable** (10^10 ≈ 2^33.2), but the *square* `step^2` used in Cayley/Woodbury denominators is not, for `step > 10^154`.

**Theorem 1.1 (Overflow bound).** Let `step` be stored as `2^e` with `e ∈ [0, 2^64)`. The Cayley denominator `1 + step^2` overflows FP64 iff `2e > 1023`, i.e. `e > 511`. **Therefore any `step_exp > 511` is a silent `inf` in the denominator, producing `W = 0` and a frozen iterate.**

**Demand:** clamp `step_exp ≤ 500` at the orchestrator, or store `step` as a *logarithm* and never materialize it.

### 1.2 Subnormal audit

The claim "subnormal audits (-12, -14)" refers to exponents. FP64 subnormals live in `[-1074, -1022]`. An exponent of `-12` or `-14` is **not subnormal** — it is a perfectly normal number near `2^-12 ≈ 2.4e-4`. **This is a category error in the submission.** Either:
- the audit is in *decimal* exponents (`10^-12`, `10^-14`), which are also normal, or
- the audit is in *base-2* and the author confused "small" with "subnormal".

**Demand:** clarify the exponent base. If the intent is to test subnormal *handling*, the test vectors must be `2^-1074` and `2^-1022`, not `2^-12`.

### 1.3 12/12 physical conformance

Unverifiable from description. **Demand:** the 12 checks as executable assertions with pass/fail witnesses.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — condition number

Neumaier's algorithm (Kahan–Babuska–Neumaier) achieves a *forward* error bound of

\[
|\hat{s} - s| \le \big(2u + O(nu^2)\big) \sum_i |x_i y_i|,
\]

where `u = 2^-53`. The **asymptotic condition number** of the dot product is

\[
\kappa_{\text{dot}} = \frac{\sum_i |x_i y_i|}{|\sum_i x_i y_i|}.
\]

**Adversarial finding:** Neumaier does **not** improve the *relative* error when `κ_dot → ∞` (catastrophic cancellation). It only removes the `n·u` growth. For `x = [1, -1+ε]`, `y = [1, 1]`, `κ_dot ≈ 2/ε`, and Neumaier still loses `log10(1/ε)` digits. **Demand:** a documented `κ_dot` threshold above which the kernel falls back to double-double (Dekker) or `__float128`.

### 2.2 AVX-512 + OpenMP — determinism

OpenMP reduction order is **not** specified by the standard. Two runs with different thread counts produce different rounding. **This violates reproducibility** if the orchestrator expects bit-identical PMTP outputs. **Demand:** either `#pragma omp parallel for reduction(+:s)` with a *fixed* thread count, or a deterministic tree reduction (pairwise summation with a fixed schedule).

### 2.3 Zero-copy PMTP validation

"Zero-copy" + "validation" is a contradiction unless the validation is a *checksum* over the 88 bytes. **Demand:** the validation must be `crc32c(descriptor) == aux[0]` or similar, computed without dereferencing the payload.

### 2.4 FFI hardening

- `extern "C"` boundary must use `[[gnu::visibility("default")]]` and a versioned symbol (`pmtp_v1350_*`).
- All pointers must be `__restrict__` and `const` where applicable.
- **Demand:** `-fsanitize=address,undefined` in CI, and a `static_assert(alignof(PmtpTensorDescriptor) == 8)`.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier — **FALSE**

`panic=unwind` does **not** make FFI safe. A Rust panic unwinding across an `extern "C"` boundary is **undefined behavior** (the C ABI has no unwind tables). The correct barrier is `std::panic::catch_unwind` at every `extern "C"` entry point, or `panic=abort` with a documented abort policy.

**Theorem 3.1 (FFI unwind UB).** If `f: extern "C" fn()` panics and the panic is not caught before the boundary, the behavior is UB per the Rust Reference §"Behavior considered undefined". `panic=unwind` *enables* the UB; it does not prevent it.

**Demand:** replace the claim with `catch_unwind` + `std::process::abort()` on `Err`, or switch to `panic=abort`.

### 3.2 `std::simd` portability

`std::simd` is nightly-only (as of 2024). If the kernel uses `core::arch::x86_64::*`, it is **not** portable to ARM (Apple Silicon, Graviton). **Rule 27 violation** unless a `cfg(target_arch)` fallback exists.

### 3.3 Packed 88-byte descriptor

Rust's default `repr(Rust)` reorders fields. **Demand:** `#[repr(C, packed)]` or `#[repr(C)]` with explicit `_pad: [u8; 6]`. Note: `repr(packed)` makes references to fields UB-adjacent (unaligned reads); prefer `repr(C)` with explicit padding.

### 3.4 Neumaier in Rust

Same condition-number caveat as §2.1. Additionally, Rust's `f64::mul_add` (FMA) changes the rounding of the compensation term. **Demand