# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 168

The requested **Cycle 168 arbitration cannot be validated as stated**: no public evidence was found for a “POLYDIM V1350” specification, six named kernels, PMTP’s 88-byte descriptor, or the eight Tribunal models’ individual reports. The available results concern general Stiefel-manifold retractions and an unrelated PolyDiM PDE library, not the claimed architecture.[1][2][3][15]

A defensible SOTA synthesis, therefore, must distinguish established mathematics from unverified architectural claims.

## 1. Extreme-step Stiefel retraction

For \(X\in\mathrm{St}(n,p)\) and tangent update \(\Delta\), the standard candidates are:

\[
R_{\mathrm{polar}}(X,\Delta)
=(X+\Delta)\bigl((X+\Delta)^{\mathsf T}(X+\Delta)\bigr)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Delta)=\operatorname{qf}(X+\Delta),
\]

and a Cayley update of the form

\[
R_{\mathrm{Cayley}}(X,\Delta)
=
\left(I-\tfrac12 W\right)^{-1}
\left(I+\tfrac12 W\right)X,
\]

where \(W\) is an appropriate skew-symmetric matrix constructed from \(X\) and \(\Delta\).[2][3]

### Arbitration

- **No method is unconditionally stable for arbitrary \(\lVert\Delta\rVert\ge 10^{10}\)** in finite precision.
- Polar and QR methods operate on \(X+\Delta\). For extreme steps, this can cause overflow, severe scaling disparity, rank loss, or loss of meaningful directional information.
- A Cayley transform preserves orthogonality algebraically when its linear system is solved accurately, but it does **not** remove conditioning problems. The system
  \[
  \left(I-\tfrac12 W\right)Y=\left(I+\tfrac12 W\right)X
  \]
  must still be solved stably, and the construction of \(W\) can overflow or lose relative accuracy.
- The mathematically strongest guarantee is therefore **orthogonality preservation conditional on a stable solve**, not unconditional extreme-step stability.
- A robust implementation should rescale the step, use overflow-safe norm computation, apply iterative refinement or higher precision where required, and verify
  \[
  \|Y^{\mathsf T}Y-I\|
  \]
  against an explicit tolerance.

The claim that Cayley–Stiefel retraction is categorically superior to Householder QR or polar retraction at \(\lvert\mathrm{step}\rvert\ge10^{10}\) is not established by the available evidence. The strongest justified conclusion is:

> **Cayley is attractive for preserving the manifold constraint without explicitly factoring \(X+\Delta\), but extreme-step robustness requires scaling, guarded linear algebra, and postcondition checks.**

Polar retraction has a particularly clean closed form and is second-order under the relevant metric assumptions; QR is generally cheaper, while Cayley has higher arithmetic cost in the cited comparison.[1][3]

## 2. PMTP 88-byte descriptors and RCU/QSBR

No source retrieved documents PMTP or its 88-byte layout. Consequently, no exact guarantee about its memory barriers can be certified.

The correct architectural rule is:

- A writer must fully initialize the descriptor and any indirectly referenced immutable state.
- It must publish the descriptor with **release** semantics.
- A reader must acquire-load the published pointer or version before reading descriptor fields.
- Reclamation must occur only after every reader that could have observed the old snapshot has passed a QSBR quiescent state or after an equivalent RCU grace period.
- The descriptor’s 88-byte size has **no bearing by itself** on memory ordering or snapshot isolation. Alignment, cache-line placement, atomic field widths, versioning, and reclamation protocol matter.

A minimal C++20-style publication pattern is conceptually:

```cpp
// Writer
initialize_snapshot(snapshot);
descriptor->snapshot.store(snapshot, std::memory_order_release);

// Reader
auto* snapshot =
    descriptor->snapshot.load(std::memory_order_acquire);
consume_snapshot(snapshot);
report_quiescent_state();
```

This guarantees visibility only for writes sequenced before the release and reads sequenced after the acquire. It does **not** by itself guarantee safe reclamation, multi-field atomicity, or immunity from ABA problems.

The exact guarantee that can be stated without the missing PMTP specification is:

> **Acquire/release provides happens-before publication of an immutable snapshot; RCU/QSBR provides lifetime safety only when grace-period participation and reclamation rules are correctly implemented.**

A stronger claim—such as “the 88-byte descriptor guarantees snapshot isolation across all readers”—would be unsupported.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

No evidence was found establishing a single implementation or formal conformance suite spanning all five ecosystems. Such conformance cannot be inferred from mathematical equivalence.

The platforms have different execution and memory models:

- **C++20 and Rust** define language-level atomic semantics, but Rust’s guarantees depend on the chosen atomic types, unsafe code, aliasing discipline, and target support.
- **CUDA** has device, block, system, and host visibility scopes; a C++-style acquire/release statement must be mapped to the correct CUDA atomic and synchronization scope.
- **Triton** exposes GPU kernels through its own compilation and synchronization model; host-language memory-order semantics do not automatically transfer to generated device code.
- **XLA** may fuse, reorder, replicate, or lower operations unless the graph contains explicit ordering or side-effect constraints.

Thus, a valid conformance claim requires:

- a common abstract memory model;
- explicit lowering rules for publication, acquire, release, quiescence, and reclamation;
- target-specific litmus tests;
- numerical tolerances for retraction kernels;
- race detection and model checking;
- verification on every supported GPU/compiler/runtime combination.

The strongest portable guarantee is conditional:

> **Semantic equivalence can be guaranteed only for operations whose synchronization, aliasing, numerical precision, and side effects are explicitly represented in each backend’s model.**

## Definitive arbitration

Based on the available evidence, the mathematically and architecturally defensible verdict is:

1. **Cayley retraction:** preserves the Stiefel constraint algebraically under an accurate, nonsingular solve; it is not proven unconditionally stable for steps of magnitude \(10^{10}\) or greater.
2. **Polar and QR:** remain valid reference implementations; polar offers a principled orthogonal projection, while QR is often computationally cheaper. Neither is automatically safe under unscaled extreme inputs.
3. **PMTP barriers:** release/acquire can publish immutable snapshots, but the 88-byte layout does not itself establish isolation or reclamation safety. QSBR/RCU grace-period correctness is essential.
4. **Multi-silicon conformance:** cannot be asserted without a formal memory-model mapping and cross-backend test suite.
5. **Exact architectural guarantees:** only conditional guarantees are currently supportable—bounded numerical error under stated conditioning and precision assumptions, happens-before publication under correctly paired atomics, and lifetime safety under a correctly implemented grace-period protocol.

Accordingly, no “definitive” SOTA arbitration favoring a particular V1350 kernel or certifying all six kernels can be issued from the supplied record.