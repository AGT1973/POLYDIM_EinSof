# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 123)

# POLYDIM V1350 — High Tribunal Audit, Cycle 123

**Presiding note.** The Tribunal has reviewed the six artifacts as *specifications*, not as compiled binaries. Where the spec is silent, we mark it **UNVERIFIED** rather than assume. Findings are graded: **FATAL** (breaks a stated invariant), **SEVERE** (numerical or contract violation under stated regimes), **MODERATE**, **INFO**.

---

## 0. Cross-cutting invariants (Rules 22 & 27)

### Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor `<4sHHQQQQQBB6x4Q` decomposes as:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version | `H` | 2 | 4 |
| flags | `H` | 2 | 6 |
| dims[0..3] | `Q`×4 | 32 | 8 |
| strides[0..3] | `Q`×4 | 32 | 40 |
| dtype | `B` | 1 | 72 |
| rank | `B` | 1 | 73 |
| pad | `6x` | 6 | 74 |
| checksum[0..3] | `Q`×4 | 32 | 80 |
| **Total** | | **112** | |

**FATAL.** The struct is **112 bytes**, not 88. The `6x` pad plus `4Q` checksum block overshoots. To hit 88 bytes with the same field set you need either:
- drop the 4×`Q` checksum to 2×`Q` (16 B) and pad `2x` → 88 B, or
- drop `6x` pad and reduce checksum to `Q`×1 → 88 B.

The Rust `#[repr(C, packed)]` and C++ `#pragma pack(1)` variants will *silently* disagree with the Python `struct` if any of the three uses a different layout. **Rule 22 is violated at the wire level.** Any inter-agent message carrying this descriptor is either truncated (Python) or padded (C++/Rust) — a 1D-token leak by definition.

**Recommendation.** Freeze the layout with a single canonical `.proto`-style schema, generate all three bindings, and add a `static_assert(sizeof(PmtpTensorDescriptor)==88)` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>()==88);` in Rust, and `assert struct.calcsize(fmt)==88` in Python. CI must fail on mismatch.

### Rule 27 — Silicon Contract / vendor lock

| Target | Vendor lock? | Verdict |
|---|---|---|
| 1 orchestrator | None (probe-based) | OK |
| 2 C++ AVX-512 | **Intel/AMD x86 only** | Conditional |
| 3 Rust SIMD | Portable if `std::simd` or `wide` | OK |
| 4 CUDA | **NVIDIA-only** (cuSOLVER, CUDA Graphs) | **VIOLATION** |
| 5 XLA | **Google TPU / AWS Trainium** | **VIOLATION** |
| 6 Triton | AMD ROCm + NVIDIA | OK (dual-vendor) |

**SEVERE.** Targets 4 and 5 hard-bind to a single vendor. Rule 27 as stated ("no component imposes vendor-lock") is violated unless the orchestrator's `HardwareProbe` is permitted to *skip* these kernels on non-matching silicon. If skip is allowed, the contract is satisfied at the *system* level but not the *component* level — the Tribunal requires the spec to state which reading applies.

---

## 1. Target 1 — `kernel_orchestrator_v1350.py`

**12/12 physical conformance checks.** The Tribunal cannot verify the count without the check list, but the *pattern* is sound: probe → allocate → validate → dispatch.

**Numerical degeneracy at `step → ∞`.** The orchestrator itself does no arithmetic on `step`; it forwards. **INFO** — no degeneracy here, but see §4.

**FFI hardening.** The 88-byte descriptor is passed across FFI. With the layout bug above, the orchestrator is the *first* place corruption manifests. Add:
```python
import struct
_FMT = "<4sHHQQQQQBB6x4Q"
assert struct.calcsize(_FMT) == 88, f"PMTP layout drift: {struct.calcsize(_FMT)}"
```
and a runtime `memoryview(desc).cast('B')` length check before every `ctypes` call.

---

## 2. Target 2 — `kernel_cpp_v1350.cpp`

**Neumaier compensated dot.** Correct form:
```
s = 0; c = 0
for i: t = s + x[i]*y[i]
       if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
       else:                  c += (x[i]*y[i] - t) + s
       s = t
return s + c
```
Error bound: `|result − exact| ≤ (2u + O(nu²)) · Σ|x_i y_i|`, with `u = 2⁻⁵³`. This is **condition-number-independent** in the *summation*, but the *product* `x_i y_i` still carries relative error `u`. For `step ≥ 10¹⁰` with `x_i ~ step`, `x_i y_i ~ 10²⁰` — representable in FP64 (max ~1.8×10³⁰⁸), so no overflow, but **catastrophic cancellation** in the Woodbury solve (see §4) is not cured by Neumaier alone.

**Subnormal audits at −12, −14.** These are exponents (≈ 2⁻¹², 2⁻¹⁴), not subnormals (which begin at 2⁻¹⁰²²). **MODERATE.** If the intent is to test *denormal* behavior, the audit points are wrong by ~1000 orders of magnitude. If the intent is to test *small-but-normal* values, rename the audit. AVX-512 with `FTZ/DAZ` set will flush true subnormals to zero — verify MXCSR.

**Zero-copy PMTP validation.** Requires the descriptor's `strides` to match the actual buffer. With the 112-byte layout, the C++ side reads `checksum` from offset 80, which in the Python 88-byte layout is *inside* the checksum block — **FATAL** cross-language mismatch.

---

## 3. Target 3 — `kernel_rust_v1350.rs`

**`panic=unwind` as FFI barrier.** This is **SEVERE** and backwards. `panic=unwind` across an `extern "C"` boundary is **UB** in Rust 2021 unless every FFI entry point is wrapped in `std::panic::catch_unwind`. The correct hardening is:
```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```
or compile the FFI crate with `panic=abort`. `panic=unwind` *without* `catch_unwind` is the classic soundness hole.

**Packed 88-byte descriptor.** `#[repr(C, packed)]` on a struct containing `u64` fields produces **unaligned references**; taking `&desc.dims[0]` is UB. Use `#[repr(C)]` with explicit `u8` padding, or `zerocopy::FromBytes`. **SEVERE.**

**Neumaier sums.** Same as C++ — correct, but does not address cancellation in the outer solve.

---

## 4. Target 4 — `kernel_cuda_v1350.cu` (the numerical heart)

### 4.1 Stiefel Cayley retraction

For `Y ∈ St(n,p)`, `A ∈ ℝ^{n×p}`:
```
Y(τ) = (I − (τ/2) W)⁻¹ (I + (τ/2) W) Y,   W = A Yᵀ − Y Aᵀ  (skew)
```
The spec says `R^{2K × 2K}` — consistent with a *symplectic* Stiefel (Hamiltonian) manifold, where `W` is Hamiltonian, not skew. **Verify which manifold.** If symplectic, the Cayley transform must use the symplectic form `J`, not `I`.

### 4.2 `step → ∞` degeneracy

The Woodbury solve is stated as `(M/scale) W = (step/scale) B`. As `step → ∞`:
- If `scale = step`, the RHS is `B` and the LHS is `M/step → 0` for fixed `M`. The system becomes **singular** as `step → ∞`. **FATAL** unless `M` scales with `step`.
- If `scale = ‖M‖`, the RHS is `(step/‖M‖) B → ∞`, and `W → step · M⁻¹ B`. Overflow at `step ≥ 10¹⁰` if `‖M⁻¹ B‖ ≳ 10²⁹⁸`. **SEVERE.**

**Asymptotic condition number.** For the scaled system `M_s = M/scale`, `κ(M_s) = κ(M)`. The scaling does **not** improve conditioning — it only prevents overflow in the *intermediate* product. The Tribunal demands the spec state `scale` explicitly and prove `κ(M_s) · u < 1` for the operating regime.

### 4.3 `step → 0` (subnormals)

`(step/scale) B` with `step ~ 10⁻³⁰⁰` and `scale ~ 1` produces subnormal RHS entries. cuSOLVER's `DnDsyevd` (divide-and-conquer) **flushes subnormals** on most architectures. The solve returns `W = 0` silently. **SEVERE.** Mitigation: pre-scale `B` by `2^k` and post-scale `W` by `2⁻ᵏ`, choosing `k` so the RHS is in `[2⁻¹⁰⁰, 2¹⁰⁰]`.

### 4.4 CUDA Graphs

Graph capture of `DnDsyevd` is **not supported** on all CUDA versions (cuSOLVER uses host callbacks). **MODERATE** — verify against the target CUDA toolkit.

---

## 5. Target 5 — `kernel_xla_v1350.py`

**Continuous Lyapunov solve in HBM, pure FP64.** The Lyapunov equation `A X + X Aᵀ = −Q` has solution `X = ∫₀^∞ e^{At} Q e^{Aᵀt} dt`. Condition number:
```
κ(X) ≤ κ(Q) · κ(V)²