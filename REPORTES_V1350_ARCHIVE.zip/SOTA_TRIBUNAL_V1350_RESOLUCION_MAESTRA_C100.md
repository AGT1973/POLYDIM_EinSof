# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 100

A definitive arbitration is **not possible from the supplied material alone**: the six Tribunal reports, the six V1350 kernel specifications, and the exact PMTP descriptor layout were not provided. The available evidence supports a rigorous *conditional* synthesis, but it cannot establish implementation-specific guarantees or claim that one tribunal’s result is correct.

## 1. Stiefel retraction under \(\lvert\text{step}\rvert \ge 10^{10}\)

For a point \(X\in\mathrm{St}(n,p)\) and tangent update \(\Delta\), the relevant candidates are:

\[
\operatorname{Retr}_{\mathrm{polar}}(X+\Delta)
=(X+\Delta)\bigl((X+\Delta)^T(X+\Delta)\bigr)^{-1/2},
\]

\[
\operatorname{Retr}_{\mathrm{QR}}(X+\Delta)
=Q,\qquad X+\Delta=QR,
\]

and a Cayley update of the form

\[
X_{\mathrm{new}}
=
\left(I-\frac{\tau}{2}W\right)^{-1}
\left(I+\frac{\tau}{2}W\right)X,
\qquad W^T=-W.
\]

Polar and QR retractions are established Stiefel-manifold constructions; the cited literature gives polar cost approximately \(3np^2+O(p^3)\), QR cost approximately \(2np^2+O(p^3)\), and Cayley cost approximately \(7np^2+O(p^3)\).[2] The Cayley formulation can be reduced to a small system with Sherman–Morrison–Woodbury techniques, and iterative approximations are documented.[14]

**Arbitration:** no method is unconditionally stable merely because it is called “Cayley,” “QR,” or “polar.” At \(\lvert\tau\rvert\ge10^{10}\), the decisive issue is scaling and conditioning:

- A naïvely formed Cayley matrix \(I\pm(\tau/2)W\) can overflow, lose relative accuracy, or produce a poorly conditioned solve.
- A naïve explicit formation of \(X+\tau\Delta\) can likewise overflow or destroy useful low-order information.
- Householder QR is generally the preferred **robust fallback** for finite inputs because it avoids explicitly forming normal equations and preserves orthogonality more reliably than classical Gram–Schmidt.
- Polar retraction is geometrically attractive—it is the closest orthogonal factor in Frobenius norm—but Newton–Schulz or related iterations require appropriate scaling and a verified stopping criterion.[14][15]
- Cayley is attractive when the update is represented as a structured low-rank skew-symmetric operator, but its stability must be demonstrated through scaled solves, pivoting or orthogonal factorizations, residual checks, and finite-result checks.

The strongest defensible guarantee is therefore:

> **For extreme steps, V1350 must use a norm-scaled, overflow-safe implementation with residual verification and a Householder-QR or SVD/polar fallback. A direct unscaled Cayley solve cannot be certified as SOTA-stable.**

A mathematically superior policy is a **hybrid**:

1. Represent the tangent/update operator in factored form.
2. Scale the step so intermediate quantities remain in a safe floating-point range.
3. Compute the Cayley transform through a structured solve where possible.
4. Verify
   \[
   \|X_{\mathrm{new}}^TX_{\mathrm{new}}-I\|
   \]
   and the solve residual.
5. Fall back to Householder QR or a robust polar/SVD path on failure.
6. Canonicalize signs or orientation if deterministic results are required.

This gives a conditional numerical guarantee, not an unconditional one: the result is reliable **provided the factorization, solve, and fallback all report success**.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release semantics provide a publication relationship only when they operate on the **same atomic synchronization object**:

- A release store publishes prior writes.
- An acquire load that reads from that release—or from its release sequence—makes those prior writes visible to the acquiring thread.[1]

Thus, a valid publication pattern is conceptually:

```cpp
// Writer
descriptor_fields_are_initialized();
published_pointer.store(new_descriptor, std::memory_order_release);

// Reader
auto p = published_pointer.load(std::memory_order_acquire);
consume_descriptor(*p);
```

However, acquire/release alone does **not** guarantee all aspects of RCU or QSBR snapshot isolation. It does not by itself provide:

- protection from reclamation while a reader still holds a pointer;
- a consistent multi-field snapshot if fields are independently mutable;
- atomicity of an 88-byte descriptor;
- ordering across unrelated atomics;
- GPU/device-wide coherence;
- safe publication when the reader loads a different atomic or uses a relaxed/unordered path.

For QSBR/RCU, the architectural guarantee must include a complete lifetime protocol:

1. Construct the descriptor privately.
2. Publish one immutable descriptor pointer or generation token with release semantics.
3. Readers acquire the pointer/token before dereferencing.
4. Readers announce entry into the relevant read-side critical section.
5. Writers retire old descriptors but do not reclaim them until every pre-existing reader has passed a quiescent state.
6. Descriptor contents remain immutable after publication, or updates use a new immutable version.
7. Readers validate the generation/version if multi-object consistency matters.

The **88-byte size is not itself meaningful for atomicity**. It exceeds common lock-free atomic widths and must not be copied concurrently as though it were one indivisible object. Use an atomic pointer, an index into a stable pool, or a compact atomic generation/handle. If the descriptor crosses CPU/GPU or host/device domains, the relevant platform memory model and explicit synchronization operations must also be specified; C++ acquire/release does not automatically establish CUDA, XLA, or Triton visibility.

**Definitive conditional guarantee:**

> A PMTP snapshot is isolated if and only if publication uses a release operation, acquisition reads the corresponding publication atomic with acquire semantics, all descriptor fields are immutable for the snapshot’s lifetime, and reclamation is delayed by a correctly implemented RCU/QSBR grace-period protocol.

Without those conditions, “Acquire/Release descriptor barriers guarantee snapshot isolation” is too strong.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single source-level claim of complete conformance across these systems is not justified by C++20 or Rust memory semantics. They have different execution and synchronization models:

- **C++20** defines language-level atomic ordering and happens-before relationships.
- **Rust** largely exposes analogous atomic orderings, but its safety guarantees additionally depend on ownership, aliasing, and unsafe-code correctness.
- **CUDA** has device, block, warp, host, and system scopes; a CPU release/acquire pair does not automatically substitute for the required device-scope synchronization.
- **Triton** exposes compiler- and target-dependent GPU operations rather than the complete C++ abstract machine.
- **XLA** may reorder, fuse, duplicate, or eliminate operations unless the computation and its side effects are represented through supported ordering mechanisms.

Therefore, the correct conformance target is not bit-for-bit identical implementation behavior by default. It should be a layered contract:

| Layer | Required guarantee |
|---|---|
| Mathematical | Same Stiefel invariant and descriptor state-transition specification |
| Numerical | Bounded orthogonality defect and residual under declared precision/range |
| Memory | Explicit publication, acquisition, lifetime, and reclamation rules |
| Backend | Backend-specific barriers and scopes mapped to the abstract contract |
| Determinism | Defined tolerance, reduction order, sign convention, and NaN/Inf policy |
| Safety | No use-after-retire, data race, out-of-bounds access, or unchecked failed solve |

The kernels should expose a backend-neutral specification such as:

\[
\|X^TX-I\| \le \varepsilon_{\mathrm{orth}},
\qquad
\|r_{\mathrm{solve}}\| \le \varepsilon_{\mathrm{solve}},
\]

together with a descriptor generation \(g\) and the rule that every read observes one valid generation for the duration of its read-side critical section.

Each backend then implements that contract using its own primitives. Conformance testing should include:

- extreme steps, including \(\pm10^{10}\) and values near overflow thresholds;
- ill-conditioned and rank-deficient updates;
- concurrent publication and retirement;
- delayed readers crossing multiple epochs;
- CPU/device and multi-stream visibility;
- NaN, infinity, underflow, and denormal behavior;
- repeated runs for deterministic and nondeterministic modes;
- differential comparison against a high-precision reference.

## Final arbitration

The strongest SOTA synthesis supported by the evidence is:

1. **Retraction:** use a scaled structured Cayley path only for well-conditioned, verifiably successful solves; otherwise use Householder QR, with robust polar/SVD available where closest-orthogonal projection is required. The literature supports all three as legitimate Stiefel retractions but does not support an unconditional claim that Cayley dominates QR or polar under extreme steps.[2][14][15]

2. **Descriptor synchronization:** treat the 88-byte PMTP descriptor as immutable versioned data behind an atomically published pointer or handle. Pair release publication with acquire consumption on the same synchronization object, and require QSBR/RCU grace-period reclamation. Acquire/release alone is insufficient for lifetime safety or cross-device visibility.[1]

3. **Portability:** define one mathematical and temporal contract, then provide backend-specific implementations and litmus tests for CUDA, XLA, Triton, C++20, and Rust. No exact cross-silicon guarantee can be claimed without specified hardware, compiler versions, memory scopes, precision modes, and test tolerances.

Accordingly, the phrase **“exact architectural guarantees”** should be limited to the explicit contract above. Claims of unconditional extreme-step stability, automatic 88-byte atomicity, or transparent cross-backend memory-model equivalence would not be mathematically or architecturally justified by the available findings.