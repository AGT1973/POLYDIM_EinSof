# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 114

The six “V1350 kernels” and the six Tribunal reports are not present in the supplied material, and no public specification for **POLYDIM V1350** or its **PMTP 88-byte descriptor** was found. Therefore, a definitive arbitration of model-specific findings is not possible. The strongest defensible synthesis is a set of conditional architectural guarantees, not a claim that an implementation already satisfies them.

## 1. Stiefel retraction under \(\lvert\text{step}\rvert \ge 10^{10}\)

No retraction is numerically guaranteed merely because its mathematical formula is stable. Extreme-step behavior depends on scaling, conditioning, finite precision, overflow handling, and the linear-solver implementation.

For a Stiefel point \(X\) and tangent update \(\Delta\), the principal candidates have different failure modes:

| Method | Mathematical property | Extreme-step assessment |
|---|---|---|
| **Cayley** | Orthogonality-preserving transform, commonly implemented through a solve involving \(I-\frac{\alpha}{2}A\), with \(A^\top=-A\) | Can preserve orthogonality well when the skew-symmetric structure is retained and the solve is stable; a raw \(\alpha=10^{10}\) should not be passed unscaled into finite-precision arithmetic |
| **Householder QR** | Produces an orthonormal \(Q\) from \(X+\Delta\) | Usually robust for factorization, but the formed matrix may overflow, lose relative information, or become dominated by \(\Delta\) at extreme scale; sign conventions and rank deficiency also require handling |
| **Polar** | Returns the nearest orthonormal factor in Frobenius norm when the matrix is sufficiently well conditioned | Often the strongest geometric projection, but iterative or eigendecomposition-based implementations require scaling and convergence safeguards; nearly rank-deficient inputs are problematic |

The mathematically superior design is therefore **not “Cayley always wins.”** It is a guarded, scale-aware Cayley-or-polar pipeline:

\[
\Delta = \alpha D,\qquad
s=\max\!\left(\|X\|,\|\Delta\|,\|D\|,\text{safe scale}\right),
\]

followed by computation using \(\widehat{\Delta}=\Delta/s\), compensated or factored operators, and a bounded solve. The implementation should never explicitly form quantities that can overflow solely because \(\alpha\) is large.

A defensible guarantee is:

\[
X_{\mathrm{new}}^\top X_{\mathrm{new}}=I+E,
\]

where \(E\) is bounded by a backward-stability estimate proportional to machine precision, matrix dimension, and the condition number of the solve or factorization—not identically zero in floating point.

For an exact Cayley update, if \(A^\top=-A\) and the solve is exact,

\[
Q=(I-\tfrac12 A)^{-1}(I+\tfrac12 A)
\]

is orthogonal whenever the inverse exists. In floating point, the guarantee becomes conditional:

- preserve skew symmetry of \(A\) explicitly by forming \(A\leftarrow(A-A^\top)/2\);
- use a stable factorization or structured solve;
- rescale before forming the solve;
- reject or fallback when the estimated condition number exceeds a defined threshold;
- verify \(\|X_{\mathrm{new}}^\top X_{\mathrm{new}}-I\|\) and retry with a safer method.

Thus the strongest architecture is:

1. **Cayley** for the fast structured path;
2. **polar or Householder QR** as a certified fallback;
3. post-update orthogonality verification;
4. deterministic failure status rather than silent emission of an invalid manifold point.

The available literature treats Cayley, QR, and polar mappings as valid Stiefel retractions, and reports efficient Cayley implementations, but that does **not** establish a universal theorem for unscaled steps of \(10^{10}\) in finite precision.[2][7][14]

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte size alone establishes no memory-ordering guarantee. Correct snapshot isolation requires a precise publication protocol and a lifetime/reclamation protocol.

The minimum valid protocol is:

1. The writer initializes the immutable descriptor payload.
2. The writer publishes the descriptor pointer, generation, or sequence value with **release** semantics.
3. A reader loads that same publication atomic with **acquire** semantics.
4. The reader pins its read-side critical section before dereferencing the snapshot.
5. The writer retires the old descriptor only after every relevant reader has passed through a quiescent state or otherwise confirmed that it no longer holds the old snapshot.

Acquire/release synchronization applies only when the acquire observes, or is otherwise ordered through, the corresponding release on the **same atomic synchronization object**.[5] A release store followed by an acquire load makes preceding writes visible to operations after the acquire; this applies in both C++20 and Rust’s atomic model.[1][4][11]

A suitable abstract publication invariant is:

\[
\text{publish}_{\mathrm{release}}(p,g)
\;\prec_{\mathrm{sw}}\;
\text{load}_{\mathrm{acquire}}(p,g)
\;\prec\;
\text{all reader dereferences}.
\]

For QSBR, reclamation additionally requires:

\[
\forall r\in R:\quad
\text{reader }r\text{ has quiesced after retirement epoch }e
\]

before memory associated with epoch \(e\) is reclaimed. Release/acquire ordering makes prior accesses visible and ordered, but it does not by itself prevent use-after-free. RCU verification work specifically distinguishes release/acquire ordering from the separate requirement that readers complete before reclamation.[6]

### Required descriptor guarantees

A V1350 descriptor can claim snapshot isolation only if it specifies:

- which field is the publication atomic;
- whether the descriptor is immutable after publication;
- alignment and atomicity of every concurrently accessed field;
- generation or epoch semantics;
- reader pin/enter and exit operations;
- writer retirement and grace-period detection;
- ABA protection, normally with a generation, epoch, or hazard mechanism;
- behavior on wraparound;
- memory reclamation rules;
- host/device visibility rules when GPU memory is involved.

The 88-byte layout should therefore be treated as an ABI constraint, not as a synchronization mechanism. Padding must not be mistaken for atomicity, and a packed descriptor must not contain concurrently modified non-atomic fields.

The exact guarantee should be stated as:

> A reader that successfully acquires publication value \(v\) and remains inside the read-side critical section observes one immutable descriptor version associated with \(v\); that version is not reclaimed until the applicable RCU/QSBR grace period completes.

It should **not** claim that acquire/release alone provides serializability, global sequential consistency, or safe reclamation.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no automatic semantic equivalence across these five environments. They differ in execution, memory, compilation, and synchronization models.

A conformance claim must distinguish at least four layers:

| Layer | Required invariant |
|---|---|
| **Numerical** | Same mathematical result within a declared tolerance, including behavior near rank deficiency and extreme scaling |
| **Memory** | No data race, invalid lifetime transition, or publication-before-initialization |
| **Ordering** | Explicitly mapped acquire/release, fence, stream, event, or barrier semantics |
| **ABI/layout** | Identical field offsets, widths, alignment, endianness, and version interpretation |

### C++20 and Rust

C++20 and Rust provide closely corresponding atomic orderings. Rust documents that its memory orderings follow C++20 semantics, including release-to-acquire visibility when the acquire reads from the release sequence.[1][4] The mapping is therefore plausible for host-side PMTP publication, provided both sides use the same atomic object and compatible representation.

### CUDA

CUDA requires an explicit distinction between:

- host atomics and device atomics;
- block, device, and system scope;
- stream ordering;
- event synchronization;
- unified-memory or mapped-memory visibility.

A host-side C++ release store cannot automatically be assumed to publish data to a GPU kernel. The architecture must define a CUDA-specific handoff using documented system-scope atomics, fences, mapped memory, events, or explicit copies.

### Triton

Triton kernels expose lower-level GPU operations through compiler-generated code. A source-level acquire/release intention is not sufficient unless the generated operation and scope are verified. The implementation needs a supported atomic/fence mapping and litmus tests for publication, read-after-publish, and reclamation ordering.

### XLA

XLA transformations may fuse, reorder, duplicate, or eliminate operations unless the graph contains supported ordering constructs. A mutable RCU-style pointer protocol should not be represented as ordinary array dataflow and assumed to retain host-style atomic semantics. XLA conformance requires an explicit custom call, token/effect mechanism, supported synchronization primitive, or a design in which snapshots are immutable values passed through dataflow.

### Required cross-silicon test suite

The kernels should be certified using:

- layout and ABI tests for all descriptor fields;
- randomized orthogonality tests over dimensions, precisions, and extreme scales;
- near-singular and rank-deficient retraction tests;
- acquire/release litmus tests;
- delayed-reader and delayed-writer QSBR tests;
- reclamation stress tests;
- ABA and generation-wrap tests;
- CUDA stream/event and host-device visibility tests;
- Triton-generated-code inspection and runtime tests;
- XLA compilation, fusion, replication, and multi-device tests;
- C++20/Rust interoperability tests;
- deterministic failure and fallback tests.

Conformance should be expressed as a refinement relation:

\[
\text{implementation behavior}
\subseteq
\text{specified abstract behavior}
\]

under declared tolerances, memory scopes, device capabilities, and failure modes. “Runs on all five platforms” is not conformance.

## Arbitration

The strongest synthesis is:

1. **Retraction:** use a scale-aware structured Cayley implementation as the fast path, with polar/Householder fallback and explicit orthogonality certification. No unconditional finite-precision guarantee exists for raw steps \(\ge 10^{10}\).
2. **Descriptor synchronization:** use release publication, acquire observation, immutable snapshots, explicit reader pinning, and grace-period reclamation. Acquire/release establishes visibility; QSBR/RCU establishes lifetime safety.
3. **Portability:** specify one abstract memory and numerical contract, then provide platform-specific lowerings. C++20 and Rust can share a host atomic contract; CUDA, Triton, and XLA require separate scope and effect mappings.
4. **Architectural guarantee:** guarantee only what is verified: bounded numerical error under stated conditioning assumptions, snapshot consistency for pinned readers, reclamation only after a completed grace period, and ABI equivalence across targets.
5. **Non-guarantees:** do not claim exact orthogonality in floating point, universal stability at arbitrary step magnitude, acquire/release-based reclamation by itself, or automatic semantic equivalence across CUDA/XLA/Triton.

Without the six Tribunal reports, kernel definitions, precision targets, memory scopes, descriptor schema, and test evidence, any stronger “definitive” arbitration would be unsupported.