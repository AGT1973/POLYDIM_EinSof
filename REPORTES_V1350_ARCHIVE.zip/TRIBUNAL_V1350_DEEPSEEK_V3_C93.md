# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 93)

# POLYDIM V1350 — High Tribunal Audit, Cycle 93

**Presiding note.** The Tribunal treats the six artifacts as *claimed* implementations. Where source is not in evidence, we audit the *specification as stated* and flag every claim that is not falsifiable from the description alone. Verdicts are graded **PASS / CONDITIONAL / FAIL** with explicit proof obligations.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor is declared as:

```
struct PmtpTensorDescriptor {   // 88 bytes, packed
    char     tag[4];            // "<4s"
    uint16_t h0, h1;            // "HH"
    uint64_t q0,q1,q2,q3,q4;    // "QQQQQ"  (5×8 = 40)
    uint8_t  b0, b1;            // "BB"
    uint8_t  _pad[6];           // "6x"
    uint64_t r0,r1,r2,r3;       // "4Q"     (4×8 = 32)
};
```

**Byte accounting (little-endian, `struct` with `=` or `<`):**

| Field | Bytes |
|---|---|
| `4s` | 4 |
| `HH` | 4 |
| `QQQQQ` | 40 |
| `BB` | 2 |
| `6x` | 6 |
| `4Q` | 32 |
| **Total** | **88** |

✅ **Arithmetic is exact.** Alignment is *not* guaranteed under native `struct` — the format string must be prefixed with `<` (or `=` with `packed`) in Python, `#[repr(C, packed)]` in Rust, `#pragma pack(1)` in C++, and `__attribute__((packed))` in CUDA. **Any of the six targets that omits the packing attribute is a Rule 22 violation** even though the byte count matches, because the compiler will insert padding and the wire format will drift to 96 or 104 bytes.

**Tribunal demand:** each target must ship a `static_assert(sizeof(PmtpTensorDescriptor)==88)` (C++/CUDA), `const _: () = assert!(size_of::<PmtpTensorDescriptor>()==88);` (Rust), and a `struct.calcsize("<4sHHQQQQQBB6x4Q")==88` assertion (Python). Absent these, **CONDITIONAL**.

**Zero 1D tokens.** The descriptor carries no variable-length payload — all fields are fixed-width scalars. This satisfies the "no 1D token stream" rule *provided* the orchestrator never serializes a `bytes`/`Vec<u8>`/`std::string` into the `tag[4]` slot. The `4s` tag is a fixed 4-byte magic; any target that writes a NUL-terminated string longer than 4 bytes is in violation. **Flag for TARGET 1 and TARGET 5** (Python/JAX paths are the usual offenders via `str.encode()`).

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Verdict |
|---|---|---|
| 1 orchestrator | none if `HardwareProbe` is a pure capability query | PASS if probe is read-only |
| 2 C++ AVX-512 | Intel/AMD ISA, but portable via `__builtin_cpu_supports` | CONDITIONAL — must ship scalar fallback |
| 3 Rust SIMD | `std::simd` is portable; `core::arch` is not | CONDITIONAL — same |
| 4 CUDA | **hard NVIDIA lock** (cuSOLVER, CUDA Graphs) | **FAIL unless a HIP/ROCm sibling exists** |
| 5 XLA | **hard Google lock** (TPU) + AWS Trainium | **FAIL unless PJRT plugin is vendor-neutral** |
| 6 Triton | ROCm + CUDA dual — this is the *only* target that satisfies Rule 27 by construction | PASS |

**Tribunal ruling:** Rule 27 is a *contract*, not a *preference*. TARGET 4 and TARGET 5 as described **violate Rule 27**. The orchestrator must be able to dispatch to a non-NVIDIA, non-Google backend without recompilation. If TARGET 4's Cayley retraction is only expressible via `cusolverDnDsyevd`, the architecture is vendor-locked at the *algorithmic* level, not merely the *build* level. **Remedy:** specify a `SymmetricEigensolver` trait with a LAPACK reference implementation and a `cusolver` fast path.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon `HardwareProbe`

**Degeneracy at `step → ∞`:** the orchestrator does not perform arithmetic on `step`; it dispatches. The only risk is **integer overflow in the 12/12 conformance counter** if the probe accumulates into a `uint8`. Demand `uint32` or wider.

**Degeneracy at `step → 0`:** if the probe uses `step` as a timeout or a polling interval, `step < 1e-300` will busy-spin. Demand a floor: `poll_interval = max(step, 1e-6)`.

### 1.2 `PmtpSlabAllocator`

The name implies a slab (bump) allocator over PMTP regions. **Critical audit point:** slab allocators are *not* thread-safe by default. If the orchestrator dispatches to six kernels concurrently, the slab head pointer must be atomic (`std::atomic<uint64_t>` / `AtomicU64` / `threading.Lock`). **Demand:** a lock-free CAS loop with ABA mitigation, or an explicit `GIL`-held Python path.

**88-byte alignment:** the descriptor is 88 bytes, not a power of two. Slab slots must be padded to 96 or 128 bytes to avoid cache-line straddling. **Demand:** `SLAB_SLOT = 128` with `static_assert(88 <= SLAB_SLOT)`.

### 1.3 12/12 physical conformance checks

Without the check list, the Tribunal can only demand that each check be **independently falsifiable** and that the aggregate be a *conjunction*, not a *disjunction*. A 12/12 score that is computed as `sum(passed) == 12` is correct; `any(passed)` is a Rule 22 violation (it collapses 12 bits into 1).

**Verdict: CONDITIONAL** — pending packing assertion, atomic slab head, and 12-bit conjunction proof.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's algorithm:

```
s = 0; c = 0
for x, y in zip(a, b):
    t = s + x*y
    if |s| >= |x*y|: c += (s - t) + x*y
    else:            c += (x*y - t) + s
    s = t
return s + c
```

**Error bound (Neumaier 1974):** for `n` terms with unit roundoff `u = 2^-53` (FP64),

```
|result - exact| <= (u + O(n u^2)) * Σ|x_i y_i|
```

i.e. **the compensated sum is accurate to within 1 ulp of the exact sum**, independent of `n`, provided no overflow. This is the correct asymptotic condition number: **κ_compensated = 1 + O(n u)**, versus **κ_naive = n** for the uncompensated sum.

**Degeneracy at `step → ∞`:** if `step` scales the inputs, `x*y` can overflow to `±inf`. Neumaier's branch `|s| >= |x*y|` becomes `inf >= inf` → true, and `c += (s - t) + x*y` evaluates `inf - inf = NaN`. **This is a hard degeneracy.** Remedy: pre-scale by `1/step` and post-scale by `step`, or clamp `step` to `sqrt(DBL_MAX)/max|a|`.

**Degeneracy at `step → 0`:** subnormal inputs. The audit mentions `-12, -14` — presumably exponents `2^-12` and `2^-14`. On x86-64 with AVX-512, subnormals are handled in hardware but with a **~100× throughput penalty** on some microarchitectures (Skylake-X, Ice Lake). On ARM64, subnormals are full-speed. **Demand:** a `FTZ/DAZ` policy declaration. If FTZ is enabled, `2^-14` inputs flush to zero and the compensated sum silently loses the correction term. **This is a Rule 22 violation** (silent token loss).

### 2.2 Zero-copy PMTP validation

Zero-copy requires that the 88-byte descriptor's `q0..q4` and `r0..r3` fields are **raw pointers** into a shared mapping. Validation must check:
1. `tag == b"PMTP"` (or the declared magic).
2. Pointer alignment: `q_i % 64 == 0` for AVX-512.
3. Bounds: `q_i + r_i <= slab_end`.
4. **No TOCTOU:** the descriptor must be `const` and the slab `mmap`'d `PROT_READ` for the consumer.

**Verdict: CONDITIONAL** — Neumaier is correct in the normal range; overflow and FTZ paths are unproven.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier

**This is the single most important audit point in the entire submission.**

Rust's default `panic=unwind` **unwinds across the FFI boundary**, which is **undefined behavior** in C++/CUDA callers unless the boundary is `extern "C-unwind"` (stabilized in Rust 1.71). The claim that `panic=unwind` is a "safety barrier" is **backwards**: `panic=abort` is the safe default for FFI, and `panic=unwind` requires `catch_unwind` at every `extern "C"` entry point.

**Tribunal ruling:** TARGET 3 **FAILS** the FFI hardening requirement as stated. Remedy:

```rust
#[no_mangle]
pub extern "C" fn pmtp_dot(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(v) => v,
        Err(_) => -1,  // sentinel; caller must check
    }
}
```

or declare the boundary `extern "C-unwind"` and require the C++ side to compile with `-fexceptions` and a matching personality routine. **The latter is not portable to CUDA device code.**

### 