# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 162)

# POLYDIM V1350 — HIGH TRIBUNAL AUDIT (Cycle 162)

**Presiding Sages:** Numerical Analysis, Systems/FFI, Heterogeneous Compute
**Verdict class:** Adversarial SOTA — findings are graded **CRITICAL / MAJOR / MINOR / PASS**.

---

## 0. Preliminary: what the audit can and cannot assert

You have supplied **architectural claims**, not source. I therefore audit the *claims as stated* against the mathematics they imply. Where a claim is under-specified (e.g. "12/12 physical conformance checks"), I mark it **UNVERIFIABLE-AS-STATED** and give the exact predicate that would make it verifiable. I do **not** fabricate line numbers.

Throughout: `step` ≡ the scalar step size entering the retraction/solve; `M` ≡ the Woodbury mass/preconditioner matrix; `B` ≡ the RHS; `K` ≡ the Stiefel half-dimension so the ambient space is `R^(2K×2K)`.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let me actually count this. This is the single most falsifiable claim in the whole submission, so it gets the strictest treatment.

| Field | Format | Size (bytes) |
|---|---|---|
| magic | `4s` | 4 |
| two u16 | `HH` | 4 |
| five u64 | `QQQQQ` | 40 |
| two u8 | `BB` | 2 |
| pad | `6x` | 6 |
| four u64 | `4Q` | 32 |
| **Total** | | **88** |

**PASS.** 4+4+40+2+6+32 = 88. Alignment: the struct begins 8-aligned; `4sHH` = 8 bytes → first `Q` at offset 8 ✓; five `Q` end at 48; `BB` at 48–50; `6x` pad 50–56; `4Q` at 56–88. **No internal padding inserted by the compiler**, so `sizeof == 88` holds under both `#pragma pack` and natural alignment on LP64. This is a genuinely well-constructed layout — the `6x` is doing real work.

**Caveat (MAJOR):** `struct.calcsize('<4sHHQQQQQBB6x4Q')` returns 88, but `struct.calcsize('@4sHHQQQQQBB6x4Q')` (native) may differ on 32-bit or big-endian. **Rule 22 compliance requires the `<` prefix be enforced at the FFI boundary, not merely present in the Python source.** Recommend a compile-time `static_assert(sizeof(PmtpDescriptor)==88)` in C++/Rust and a runtime `assert(calcsize==88)` in Python.

### 1.2 Multi-silicon HardwareProbe

**MAJOR — vendor-lock risk (Rule 27).** A "probe" that enumerates CUDA/ROCm/TPU/Trainium is fine *only if* the orchestrator's dispatch table is data-driven. If `HardwareProbe` returns an enum that the orchestrator `match`es on with hard-coded branches per vendor, you have **soft vendor-lock**: adding a new accelerator requires editing the orchestrator. **Required predicate:** the probe must emit a capability record (ISA, memory model, fp64 throughput, subnormal handling) and the orchestrator must select kernels by *capability*, not by *vendor string*.

### 1.3 `PmtpSlabAllocator`

**MAJOR — fragmentation under adversarial step.** A slab allocator sized for the 88-byte descriptor plus payload must guarantee that the *descriptor* never straddles a slab boundary (else zero-copy validation in TARGET 2 fails). **Required invariant:** `slab_stride ≡ 0 (mod 88)` **and** `slab_stride ≡ 0 (mod 64)` for cache-line alignment. These are jointly satisfiable (lcm = 2816) but the claim doesn't state it.

### 1.4 "12/12 physical conformance checks"

**UNVERIFIABLE-AS-STATED.** A conformance check is only meaningful if it is a *decidable predicate over observable state*. Demand the 12 predicates be published as a table with (name, predicate, failure mode). Without that, "12/12" is a marketing integer.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška gives a **forward error bound**

```
|fl(x·y) − x·y| ≤ (2u + O(nu²)) · Σ|xᵢyᵢ| + O(u²)·|x·y|
```

where `u` = unit roundoff (`2⁻⁵³` for FP64). The **condition number** of the dot product is

```
κ(x·y) = Σ|xᵢyᵢ| / |Σxᵢyᵢ|
```

**Asymptotic claim:** Neumaier is *componentwise backward stable* with error `γ₂ₙ = 2nu/(1−2nu)`. For `n = 2K` with `K` up to ~10⁴, `γ₂ₙ ≈ 2·10⁴·1.1·10⁻¹⁶ ≈ 2.2·10⁻¹²`. **This is the correct order** and is the reason Neumaier is the right choice here — naive summation would give `γₙ` with the same constant but *no* compensation, so the *observed* error on ill-conditioned `κ ~ 10¹²` inputs would be `O(1)`.

**CRITICAL — the compensation is defeated if the compiler contracts.** `-ffast-math`, `-Ofast`, or `#pragma omp simd reduction(+:...)` **without** `-ffp-contract=off` will fuse the `c` correction into an FMA and destroy Neumaier's invariant. **Required:** `#pragma STDC FP_CONTRACT OFF` at TU scope, or `-ffp-contract=off` in the build. This is the single most common way "compensated summation" silently becomes naive summation.

### 2.2 Subnormal audits at −12, −14

**Interpretation:** exponents `2⁻¹²` and `2⁻¹⁴` are **not subnormal** in FP64 (subnormal threshold is `2⁻¹⁰²²`). So either:
- (a) these are **FP32** subnormal probes (FP32 subnormal threshold `2⁻¹²⁶`; `2⁻¹²` is normal), or
- (b) they are **scaled** probes testing the *dynamic range* of the compensated sum, or
- (c) they are **decimal exponents** `10⁻¹²`, `10⁻¹⁴`.

**MAJOR — ambiguity is itself a finding.** If the intent is subnormal *flush-to-zero* detection, the correct probes are `2⁻¹⁰²³` (smallest subnormal) and `2⁻¹⁰²²` (smallest normal) for FP64, or `2⁻¹⁴⁹`/`2⁻¹²⁶` for FP32. **Demand:** publish the exact bit patterns and the expected `is_subnormal()` result. AVX-512 `vaddpd` does **not** FTZ by default; `vaddps` with `MXCSR.FTZ=1` does. If the audit relies on FTZ being *off*, it must explicitly clear `MXCSR.FTZ` and `MXCSR.DAZ`.

### 2.3 Zero-copy PMTP validation

**MAJOR.** "Zero-copy" + "validation" is a tension: validation requires *reading* the descriptor, which is fine, but if validation is done on the host while the descriptor lives in device memory, you have a copy. **Required predicate:** validation must be a *device-side* kernel that reads the 88-byte descriptor in-place and writes a single status word. Otherwise the claim is false.

### 2.4 `step → ∞` degeneracy

For the C++ core (dot products only), `step` doesn't enter. **PASS** for this target on that axis.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

**CRITICAL — this is backwards.** `panic = unwind` across an `extern "C"` boundary is **undefined behavior** in Rust (the C ABI has no unwind tables). The *correct* configuration for FFI safety is:

- `panic = "abort"` in `[profile.release]`, **or**
- `extern "C-unwind"` (Rust 1.71+) on both sides, **or**
- `catch_unwind` at every FFI entry point with a `Result`-to-error-code translation.

Claiming `panic = unwind` *is* the safety barrier is a **category error**. The barrier is `catch_unwind` + `abort`-on-unwind-across-boundary. **Recommendation:** `#[no_mangle] pub extern "C" fn ...` wrapped in `std::panic::catch_unwind(AssertUnwindSafe(|| ...))`, returning a sentinel on `Err`.

### 3.2 Packed 88-byte descriptor

**PASS** if `#[repr(C, packed(8))]` is used and a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` is present. **MAJOR** if `#[repr(C)]` alone is used — Rust may insert padding. Demand the `const _` assertion.

### 3.3 Safe SIMD + Neumaier

**PASS** in principle. `std::simd` (nightly) or `wide`/`packed_simd` crates. **MINOR:** Rust does not expose `FP_CONTRACT` control; LLVM may contract `a*b+c` into FMA. Use `f64::mul_add` explicitly *or* `-C llvm-args=-ffp-contract=off`. Same trap as C++.

### 3.4 `step → ∞` / `step → 0`

Same as TARGET 2 — dot products only. **PASS.**

---

## TARGET 4 — `kernel_cuda_v1350.cu` — **the numerically dangerous one**

### 4.1 Stiefel Cayley retraction in `R^(2K×2K)`

The Cayley retraction on the Stiefel manifold `St(n,p)` is

```
Y(τ) = (I − (τ/2) A)⁻¹ (I + (τ/2) A) Y,   A = G Yᵀ − Y Gᵀ  (skew)
```

where `G` is the Euclidean gradient. **Condition number of the solve:**

```
κ(I − (τ/2