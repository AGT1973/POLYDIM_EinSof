# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 124)

**POLYDIM V1350 – MULTI‑FILE ADVERSARIAL STATE‑OF‑THE‑ART AUDIT (CYCLE 124)**  
*High Tribunal of Mathematical & Systems Sages – PhD‑level Technical Review*  

---

## Executive Summary  

| Component | Numerical Stability (step → ∞ / step → 0) | Rule 22 (88‑byte PMTP) | Rule 27 (Vendor‑Lock) | Condition‑Number Insight | FFI Hardening (top‑3) |
|-----------|------------------------------------------|------------------------|------------------------|---------------------------|----------------------|
| **kernel_orchestrator_v1350.py** | No intrinsic arithmetic; only descriptor handling – safe if sub‑normal flushing is enforced. | ✔︎ 88‑byte descriptor matched to format `<4sHHQQQQQBB6x4Q>` – exact size. | ✔︎ Pure‑Python, no vendor‑specific calls. | N/A (metadata only). | 1️⃣ Validate struct‑pack alignment; 2️⃣ Reject non‑canonical endianness; 3️⃣ Harden against malformed descriptor lengths. |
| **kernel_cpp_v1350.cpp** | AVX‑512 & OpenMP kernels exhibit **catastrophic cancellation** when `|step| ≥ 10¹⁰` (overflow) and **sub‑normal underflow** for `|step| ≤ 10⁻¹²`. | ✔︎ All IPC uses the 88‑byte descriptor; binary packing verified. | ✘ AVX‑512/Intel‑specific – locks to Intel silicon for peak performance. | Condition number of compensated dot‑product ≤ `(1+γ·n)·κ(A)` with γ≈2⁻⁵³. | 1️⃣ Enforce `-ffast-math` off; 2️⃣ Insert `__builtin_ia32_stmxcsr` flush‑to‑zero; 3️⃣ Guard OpenMP reductions with explicit reduction clauses. |
| **kernel_rust_v1350.rs** | Safe‑SIMD implementation respects IEEE‑754; **sub‑normal support** is optional – compiled with `-C target-feature=+sse2` disables FTZ, leading to *denormals‑are‑zero* (DAZ) failures for `|step| < 2⁻¹⁴`. | ✔︎ Rust `#[repr(C,packed)]` matches the 88‑byte layout; zero‑length “1‑D token” enforced by type system. | ✔︎ No vendor‑specific intrinsics – uses `std::simd` which maps to any SIMD ISA at runtime. | Condition number of Neumaier sum = `κ_sum ≤ (1 + n·u)`. | 1️⃣ Replace `panic=unwind` with `abort` for FFI boundary; 2️⃣ Add `#[no_mangle]` + `extern "C"` safety checks; 3️⃣ Verify alignment of the descriptor with `align_of::<PmtpTensorDescriptor>()`. |
| **kernel_cuda_v1350.cu** | Woodbury solve **blows up** for `|step| → ∞` because scaling factor `M/scale` → ∞; for `|step| → 0` the retraction matrix becomes ill‑conditioned (`σ_min → 0`). | ✔︎ CUDA kernels serialize the descriptor via `cudaMemcpy` – size preserved. | ✘ CUDA Graphs and cuSOLVER are NVIDIA‑exclusive → vendor lock. | Woodbury condition number: `κ_W ≤ (1 + ‖U‖·‖V‖/σ_min(A))·κ(A)`.  For `scale = step`, `σ_min(A) ∝ step` → `κ_W ∝ 1/step`. | 1️⃣ Use `cudaMemAdvise` to enforce read‑only on the descriptor; 2️⃣ Insert `cudaDeviceSynchronize` after each Graph launch; 3️⃣ Wrap all kernel launches with `cudaErrorCheck` macros. |
| **kernel_xla_v1350.py** | HLO‑fusion operates on FP64; **overflow** for `|step| ≥ 10¹⁰` is caught by XLA’s `NanGuardMode`; **underflow** for `|step| ≤ 10⁻¹²` is silently flushed to zero – leads to loss of orthogonality in the Lyapunov solver. | ✔︎ XLA HLO passes the 88‑byte token as a `TensorShape` constant; no extra padding. | ✘ Relies on Google TPU or AWS Trainium HLO back‑ends – implicit vendor lock if HLO is not compiled for generic CPU. | Lyapunov equation condition number ≈ `κ_L ≈ κ(A)·κ(Aᵀ)`. Scaling `step` multiplies `A` → `κ_L ∝ step`. | 1️⃣ Enable `jit_compile=False` fallback to CPU XLA; 2️⃣ Add explicit `tf.debugging.check_numerics` in JAX trace; 3️⃣ Verify that all external calls use `jax.lib.xla_bridge.get_tpu_devices()` only after runtime detection. |
| **kernel_triton_v1350.py** | SRAM tiling introduces **partial sums** that suffer from **catastrophic cancellation** when `step` magnitude exceeds `2^{53}`; sub‑normal `step` leads to *denormals‑slow‑down* on AMD GPUs unless `flush-to-zero` is set. | ✔︎ Triton kernel arguments include an 88‑byte struct encoded via `cdef struct`; Triton runtime enforces no extra data. | ✘ Uses both ROCm (AMD) and CUDA (NVIDIA) APIs; the Triton JIT selects the first available – de‑facto lock to the present vendor. | Condition number of the projected Clifford rotation: `κ_proj ≤ (1 + ‖b‖²)·κ(G)`, where `G` is the Gram matrix of the basis. Scaling `step` inflates `‖b‖` → `κ_proj ∝ step`. | 1️⃣ Insert `torch.backends.cuda.matmul.allow_tf32 = False` and `torch.backends.cudnn.allow_tf32 = False`; 2️⃣ Use `triton.testing.assert_allclose` with `rtol=1e‑12`; 3️⃣ Enforce `@annotate` on FFI functions with explicit size checks. |

> **Bottom‑line:**  
- **Rule 22** is satisfied by every component (88‑byte PMTP descriptor is never padded, never carries a “1‑D token”).  
- **Rule 27** is **violated** by three components that tie performance to a single silicon vendor (AVX‑512, cuSOLVER, XLA/TPU). The remaining three are vendor‑agnostic or provide fall‑backs.  
- Numerical degeneration is **systematic** in the high‑step regime for the Woodbury, Lyapunov, and Clifford‑projection kernels, and **sub‑normal** handling is either disabled or inadvertently flushed to zero in the Rust, CUDA, and Triton kernels.  

---

## 1. Numerical Degeneracy Analysis  

### 1.1. General Model  

All six kernels ultimately compute updates of the form  

\[
X_{t+1}= \Phi(step,\,X_t) \;,
\]

where `step` is a scalar controlling the magnitude of a linear or bilinear map. The **worst‑case error** `e(t)` can be bounded by  

\[
|e(t+1)| \le (1 + \kappa_\Phi\,u)\,|e(t)| + \mathcal{O}(u\,\|X_t\|) \tag{1}
\]

with `u` the unit‑in‑the‑last‑place (ULP) of the working precision and `κ_Φ` the condition number of the specific transformation `Φ`.  

The two asymptotic regimes are:  

| Regime | Typical transformation | Dominant source of error |
|--------|------------------------|--------------------------|
| **step → ∞** (`|step| ≥ 10¹⁰`) | Scaling of matrices (`M/scale`, `step/scale`) | **Overflow** of intermediate products, loss of significance when subtracting near‑equal large numbers. |
| **step → 0** (`|step| ≤ 10⁻¹²`) | Sub‑normal multiplication, retracting onto manifolds (Stiefel, sphere) | **Underflow** → denormals, flushing‑to‑zero (FTZ) causing loss of orthogonality or bias. |

Below we specialize the analysis per kernel.

---

### 1.2. kernel_cpp_v1350.cpp – AVX‑512/ OpenMP Dot‑Products  

*Neumaier compensated sum* guarantees bound  

\[
| \varepsilon_{\text{Neumaier}} | \le u\bigl(\|x\|_1 + |c|\bigr) \tag{2}
\]

but **AVX‑512 intrinsics** (`_mm512_mul_pd`) perform *fused* multiply‑add without sub‑normal tracking unless the MXCSR `FTZ` and `DAZ` bits are cleared. When `|step|` falls below `2^{-14}` the product underflows to a denormal; the default `FTZ=1` causes it to become zero, breaking the compensation term `c`.  

*Proof sketch:* let `x_i