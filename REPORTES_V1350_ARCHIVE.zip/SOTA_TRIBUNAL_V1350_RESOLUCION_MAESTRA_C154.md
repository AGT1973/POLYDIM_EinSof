# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 154

The requested **definitive arbitration cannot be made as stated**: the prompt provides no reports from the eight Tribunal models, no definitions or implementations for the six V1350 kernels, and no reproducible conformance data. Publicly searchable material also does not establish a “POLYDIM V1350” specification or an “88-byte PMTP descriptor.” The following is therefore a standards- and mathematics-based synthesis, not a verification of those proprietary claims.

## 1. Stiefel retraction under \(\lvert\text{step}\rvert \ge 10^{10}\)

Let \(X\in\mathrm{St}(n,p)\), \(X^\top X=I\), and let \(\Omega^\top=-\Omega\). A Cayley update has the form

\[
Y=\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
  \left(I+\frac{\alpha}{2}\Omega\right)X .
\]

In exact arithmetic, \(I-\frac{\alpha}{2}\Omega\) is nonsingular for every real \(\alpha\), because a real skew-symmetric matrix has purely imaginary eigenvalues. The Cayley transform is consequently orthogonal, so it preserves \(Y^\top Y=I\) exactly in exact arithmetic. The literature reports favorable local conditioning for canonical Cayley and polar-light retractions, with stated absolute condition-number bounds of 2 and 3 under their respective hypotheses.[1]

That result **does not imply numerical stability for an unscaled implementation at \(\alpha\ge 10^{10}\)**. At such magnitudes:

- forming \(I\pm \alpha\Omega/2\) can create severe scale disparity;
- subtractive cancellation and loss of significance can dominate;
- iterative fixed-point forms may overflow, stagnate, or converge to insufficient accuracy;
- the computed orthogonality defect is governed by the linear solver, scaling, precision, and backward error.

The mathematically superior implementation is therefore:

1. construct the skew-symmetric generator without forming avoidable large products;
2. apply power-of-two or norm-based scaling;
3. solve the Cayley linear system with a backward-stable factorization or iterative-refinement path;
4. reorthogonalize or project only when the measured defect exceeds a specified tolerance;
5. use a fallback polar or Householder-QR path if conditioning, overflow, or residual tests fail.

For comparison, the polar retraction

\[
R_{\mathrm{polar}}(X+\Delta)
=(X+\Delta)\bigl(I+\Delta^\top\Delta\bigr)^{-1/2}
\]

is intrinsically defined by a positive-definite \(p\times p\) factor, while QR uses a factorization of \(X+\Delta\). Both require careful rank and finite-value handling. QR is often cheaper; polar decomposition generally gives a more symmetric projection. Neither provides an unconditional guarantee under arbitrary finite-precision extreme steps. The standard descriptions give QR and polar retractions as distinct valid choices, not a universal ordering in which one dominates in every regime.[2]

**Arbitration:** a Cayley retraction is the best *exact-arithmetic structure-preserving* choice for large steps, but a **scaled, residual-checked Cayley solver with certified fallback** is the only defensible SOTA design. An unscaled Cayley kernel cannot be advertised as stable merely because the exact transform is orthogonal.

A valid architectural guarantee would be conditional:

\[
\|Y^\top Y-I\| \le \tau_{\mathrm{orth}}
\]

provided that all inputs are finite, the solve satisfies a stated backward-error bound, scaling does not overflow, and the fallback succeeds. No unconditional guarantee for all \(\lvert\alpha\rvert\ge10^{10}\) follows from the mathematics alone.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte layout is an ABI property, not a memory-ordering proof. Acquire and release operations provide ordering relationships:

- a **release** publication prevents preceding writes from being reordered after the publication;
- a matching **acquire** observation prevents subsequent reads from being reordered before the observation.[5]

Thus, a writer can safely publish an immutable descriptor snapshot approximately as:

```cpp
descriptor_fields_are_initialized();
publish_ptr.store(new_snapshot, std::memory_order_release);
```

and a reader can obtain the initialized snapshot with:

```cpp
auto p = publish_ptr.load(std::memory_order_acquire);
consume_immutable_snapshot(*p);
```

However, this alone does **not** establish complete RCU/QSBR safety. Snapshot isolation additionally requires:

- immutable contents after publication, or separately synchronized mutations;
- a lifetime protocol preventing reclamation while any reader may still dereference the object;
- reader quiescent-state registration and reporting;
- a grace-period condition before reclamation;
- correct handling of pointer, generation, epoch, and validity fields;
- avoidance of torn multiword updates.

For a descriptor larger than the machine’s atomic word size, the descriptor itself should not be published by copying 88 bytes concurrently. Publish an atomic pointer, handle, index, or versioned indirection. If a lock-free multiword representation is required, it needs an explicit seqlock/transactional protocol and documented retry semantics; acquire/release on one field does not make the other bytes atomic.

**Arbitration:** Acquire/Release is **necessary for ordinary publication**, but **insufficient as a standalone guarantee of RCU/QSBR snapshot isolation**. The exact guarantee should be stated as:

> A reader that acquires a published descriptor and remains within the registered read-side critical section observes one fully initialized immutable version; that version is not reclaimed until the corresponding grace period has completed.

That guarantee depends on the complete QSBR implementation, not on the descriptor’s 88-byte size.

CUDA, XLA, Triton, C++, and Rust also do not share one universal memory model. Host C++ and Rust atomics do not automatically order device memory; kernel launch, stream/event, collective, and runtime boundaries must be specified separately. A host-side release/acquire pair cannot by itself prove visibility among GPU threads or across devices.

## 3. Multi-silicon conformance

“Conformance across CUDA, XLA, Triton, C++20, and Rust” is not a single binary property. It has at least four layers:

| Layer | Required invariant |
|---|---|
| Numerical | Same mathematical result within a declared tolerance and NaN/Inf policy |
| Memory | Same publication, lifetime, visibility, and race-freedom contract |
| ABI | Same field offsets, alignment, endianness, padding, and versioning |
| Execution | Same synchronization, collective, stream, and failure semantics |

The implementations should share a language-neutral behavioral specification, while each backend supplies a proof or test artifact for its own execution model. Conformance testing should include:

- extreme step magnitudes, including \(10^{10}\) and larger;
- ill-conditioned and rank-deficient inputs;
- randomized orthogonality and residual tests;
- adversarial descriptor publication and reclamation schedules;
- CPU/GPU and multi-device visibility tests;
- compiler optimization and sanitizer runs;
- exact layout checks using generated offsets and sizes;
- differential tests across CUDA, XLA, Triton, C++20, and Rust;
- explicit tolerances by datatype, device, and kernel variant.

The strongest defensible claim is **conditional conformance**:

> For every supported backend, device, datatype, and synchronization mode listed in the support matrix, the implementation satisfies the common numerical, ABI, and memory-contract tests within declared tolerances.

A claim of universal bitwise identity or universal memory-order equivalence across these ecosystems would be unjustified without backend-specific specifications and evidence.

## Definitive arbitration

- **Cayley:** preferred geometric kernel, but only with scaling, stable solves, residual checks, and polar/QR fallback. Exact orthogonality is not a finite-precision guarantee.
- **Householder/QR:** strong practical fallback and often cheaper, but its stability depends on the QR algorithm, pivot/sign conventions, rank behavior, and implementation.
- **Polar:** strongest projection interpretation and useful fallback, but it also requires a stable inverse-square-root computation and finite-input checks.
- **PMTP descriptor:** 88-byte size says nothing about atomicity. Acquire/release correctly publishes an immutable snapshot only when paired with a complete lifetime and grace-period protocol.
- **RCU/QSBR:** reclamation safety, not merely visibility ordering, is the decisive requirement.
- **Cross-silicon support:** must be specified as a contract with backend-specific synchronization mappings and measurable tolerances, not asserted from source-level similarity.

Accordingly, no exact unconditional architectural guarantee can be certified from the supplied information. The SOTA architecture is a **contract-driven implementation**: scaled Cayley plus verified fallback for Stiefel updates; atomic indirection plus QSBR grace periods for descriptors; and a generated ABI, memory-model mapping, and differential conformance suite for every backend.