# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 156

No auditable arbitration is possible from the material supplied. The search record contains no identifiable specifications, source code, benchmarks, proofs, or individual reports from the eight named models for “POLYDIM V1350,” its six kernels, or the “PMTP 88-byte Descriptor.” The discoverable PolyDiM material refers to a C++ library for polytopal discretization methods, not to the architecture described in the query.[1][2] Therefore, any “definitive” result or exact guarantee would be fabricated.

The strongest technically defensible synthesis, conditional on standard numerical-analysis and memory-model assumptions, is:

## 1. Extreme-step Stiefel retraction

For a point \(X\) on the Stiefel manifold,
\[
\mathrm{St}(n,p)=\{X\in\mathbb{R}^{n\times p}:X^\top X=I\},
\]
a Cayley update based on a skew-symmetric generator \(A^\top=-A\),
\[
X_{+}=\left(I-\frac{\tau}{2}A\right)^{-1}
       \left(I+\frac{\tau}{2}A\right)X,
\]
is algebraically norm-preserving in exact arithmetic because the Cayley transform is orthogonal whenever the inverse exists.

That does **not** establish stability for \(|\tau|\ge 10^{10}\). In finite precision:

- the solve becomes poorly scaled as \(\tau\|A\|\) grows;
- forming \(I\pm \tau A/2\) can cause overflow, cancellation, or loss of conditioning;
- the result can drift from \(X^\top X=I\);
- a mathematically defined update is not automatically a numerically reliable one.

Householder QR is generally the safer baseline for orthogonalization because it is backward stable under conventional assumptions. Polar decomposition can provide a geometrically natural closest-orthogonal-factor projection, but its stability depends on the chosen algorithm and conditioning. No universal ordering—Cayley always superior, QR always superior, or polar always superior—can be asserted without the kernels, precision, scaling, conditioning, and error measurements.

A defensible guarantee would require:

\[
\|Q^\top Q-I\|\le c\,u\,\kappa_{\mathrm{alg}}(n,p,\tau,A),
\]
together with explicit bounds preventing overflow and specifying the norm, floating-point format, solver, and conditioning domain. For extreme steps, the architecture should use scaled formulations, iterative refinement or a bounded-step policy, and an orthogonality check with a QR/polar fallback. Without those conditions, **no unconditional stability guarantee exists**.

## 2. PMTP descriptor and RCU/QSBR isolation

An 88-byte size alone says nothing about memory ordering or snapshot correctness. Acquire/release semantics can establish a publication edge such as

\[
\text{writer initializes descriptor}
\;\xrightarrow{\text{release}}\;
\text{publishes pointer/version},
\]
followed by

\[
\text{reader acquires pointer/version}
\;\Rightarrow\;
\text{reader observes prior initialization}.
\]

That is insufficient by itself for safe reclamation. RCU/QSBR snapshot isolation additionally requires:

- immutable or versioned data for the duration of a reader’s snapshot;
- reader registration and quiescent-state reporting;
- a grace-period rule proving that all preexisting readers have exited;
- release publication of the replacement object;
- acquire observation by readers;
- reclamation only after the grace period;
- prevention of ABA, torn multiword state, and wraparound-version errors.

The descriptor must therefore have a specified layout, alignment, atomic fields, ownership rules, version width, endian convention, and reclamation protocol. If the 88 bytes contain fields read non-atomically while writers update them concurrently, acquire/release does not make the object safe. If the descriptor is copied across devices, host-language atomics and device memory ordering must also be mapped explicitly; C++20, Rust, CUDA, XLA, and Triton do not share one interchangeable memory model.

The exact guarantee should be stated conditionally:

> For every reader that enters the protocol before publication and reports quiescence according to the specified QSBR rules, the reader observes one internally consistent immutable snapshot, and reclamation occurs only after all such readers have passed a grace period.

Anything stronger—especially “acquire/release alone guarantees RCU isolation”—is incorrect.

## 3. Multi-silicon and multi-language conformance

CUDA, XLA, Triton, C++20, and Rust differ in execution, aliasing, synchronization, and floating-point semantics. Source-level similarity does not imply semantic equivalence. Exact conformance requires a reference specification that defines:

- mathematical outputs and allowed tolerances;
- NaN, infinity, signed-zero, overflow, and underflow behavior;
- reduction order and permitted nondeterminism;
- atomic scopes and synchronization domains;
- alignment and ABI rules;
- descriptor serialization and endianness;
- lifetime, aliasing, and reclamation obligations;
- supported shapes, strides, precisions, and architectures.

A practical conformance claim should be separated into levels:

| Level | Meaning |
|---|---|
| Bitwise | Identical bits for all supported inputs and executions |
| Numerical | Results satisfy a stated error bound, such as backward error or ulp tolerance |
| Memory-model | All permitted executions satisfy the publication, snapshot, and reclamation rules |
| Performance | Throughput/latency meets stated targets under a fixed benchmark protocol |

Bitwise conformance across all five ecosystems is unlikely without tightly controlling compiler flags, instruction selection, reduction order, and hardware behavior. Numerical and memory-model conformance are realistic, but only after formalizing the contracts and testing each supported silicon target.

## Arbitration result

The only justified arbitration outcome is:

1. **Cayley:** exact orthogonality in exact arithmetic under its algebraic assumptions; no proven finite-precision stability at \(|\mathrm{step}|\ge10^{10}\) without additional safeguards.
2. **PMTP:** acquire/release is necessary for publication ordering but insufficient alone for RCU/QSBR snapshot isolation or reclamation safety.
3. **Cross-platform conformance:** cannot be guaranteed from kernel names or descriptor size; it requires a formal semantic specification, architecture-specific implementations, litmus tests, numerical validation, and reclamation proofs.

The available evidence does not identify the eight tribunal reports or support a model-by-model vote. Accordingly, there is no evidentiary basis for declaring a SOTA winner or issuing “exact architectural guarantees” for the six kernels.