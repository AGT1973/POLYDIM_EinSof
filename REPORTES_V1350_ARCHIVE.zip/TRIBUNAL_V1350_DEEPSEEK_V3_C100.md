# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 100)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 100 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has reviewed the six artifacts as *specifications* (the actual source files were not attached to this docket). Findings below are therefore stated as **conditional verdicts**: they hold *if* the implementation matches the described contract, and each is paired with the falsifying test that would overturn it. Where the description is silent, we flag the gap rather than assume compliance.

---

## §0. Cross-Cutting Findings (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Format `<4sHHQQQQQBB6x4Q`:

| Field | Type | Bytes | Cumulative |
|---|---|---|---|
| magic | 4s | 4 | 4 |
| version, flags | HH | 4 | 8 |
| dims (4×) | QQQQ | 32 | 40 |
| strides (4×) | QQQQ | 32 | 72 |
| dtype, rank | BB | 2 | 74 |
| pad | 6x | 6 | 80 |
| aux (4×) | 4Q | 32 | **112** |

**Verdict: FAIL on the stated size.** The format string as written yields **112 bytes**, not 88. To reach 88 the aux tail must be `2Q` (16 bytes) → 96, or the dims/strides must be `3Q` each → 88 exactly. **The Tribunal demands the canonical layout be re-derived and frozen in a single header** (`pmtp_descriptor.h`) consumed by all six kernels; divergence here is the single largest latent FFI bug in the stack.

**Falsifying test:** `static_assert(sizeof(PmtpTensorDescriptor)==88)` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>()==88);` in Rust, `struct.calcsize("<4sHHQQQQQBB6x4Q")==88` in Python. If any of these fails, Rule 22 is violated at the ABI boundary before any math runs.

### 0.2 Rule 22 — Zero 1D tokens

The rule forbids scalar/1-D payloads in inter-agent messages; everything must ride the 88-byte PMTP envelope. Audit:

- **T1 (orchestrator):** descriptor is the only IPC unit — **PASS** *if* §0.1 is fixed.
- **T2 (C++):** zero-copy PMTP validation implies the descriptor is memory-mapped, not serialized — **PASS**.
- **T3 (Rust):** `#[repr(C, packed)]` on the descriptor is mandatory; `repr(Rust)` would reorder fields and break the ABI — **CONDITIONAL PASS**, verify attribute.
- **T4 (CUDA):** CUDA Graphs capture kernel launches, not descriptors; the descriptor must be a `__grid_constant__` or device-mapped host pointer — **CONDITIONAL**.
- **T5 (XLA):** `@jax.jit` traces Python objects; the 88-byte descriptor must be passed as a `jnp.uint8[88]` array, never as a Python tuple — **CONDITIONAL**.
- **T6 (Triton):** Triton kernels take tensors, not structs; the descriptor must be unpacked host-side into scalar args — **RISK**: this is the most likely Rule 22 violation in the stack.

### 0.3 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Verdict |
|---|---|---|
| T1 | none (probe only) | **PASS** |
| T2 | AVX-512 → Intel/AMD only | **PARTIAL** — needs scalar fallback path |
| T3 | portable | **PASS** |
| T4 | cuSOLVER `DnDsyevd` → NVIDIA only | **FAIL** — no ROCm/oneAPI equivalent declared |
| T5 | XLA → Google TPU / AWS Trainium | **FAIL** — two vendors, but no CPU/GPU fallback |
| T6 | Triton → NVIDIA + AMD | **PASS** (dual-vendor) |

**Tribunal ruling:** T4 and T5 violate Rule 27 as stated. Required remediation: a `PmtpBackend` trait with at least one reference CPU implementation, and a documented `DnDsyevd` → `syevd` (cuSOLVER) / `rocsolver_dsyevd` / `LAPACKE_dsyevd` dispatch table.

---

## §1. TARGET 1 — `kernel_orchestrator_v1350.py`

**Claims:** multi-silicon probe, `PmtpSlabAllocator`, 88-byte descriptor, 12/12 conformance checks.

### 1.1 Numerical degeneracy
Orchestrator is control-plane; the only numerical surface is the conformance checker. **Risk:** if the 12 checks include tolerance comparisons, they must use *relative* tolerance with a subnormal floor, e.g.

```
|a-b| <= atol + rtol*max(|a|,|b|),  atol = 2^-1022 * 8
```

Otherwise `step → 0` produces false-positive conformance.

### 1.2 Slab allocator
`PmtpSlabAllocator` must guarantee 64-byte alignment (AVX-512) and 128-byte (cache-line pair for CUDA `__grid_constant__`). **Demand:** `alignof(slab) >= 128` and a `static_assert` in the C++ consumer.

### 1.3 Verdict
**CONDITIONAL PASS** subject to §0.1 and §1.1.

---

## §2. TARGET 2 — `kernel_cpp_v1350.cpp`

**Claims:** C++20, AVX-512, OpenMP, Neumaier compensated dot, subnormal audits at −12/−14, zero-copy PMTP.

### 2.1 Neumaier dot — error bound
For vectors `x, y ∈ R^n`, Neumaier's variant gives

```
|fl_Neumaier(x·y) − x·y| ≤ (2u + O(u²)) · Σ|xᵢyᵢ| + O(u²)·|x·y|
```

with `u = 2^-53` (FP64). This is **one ulp better** than Kahan and is *unconditionally* bounded — no cancellation blow-up. **PASS** on the algorithm choice.

### 2.2 Subnormal audit at −12, −14
These are exponents, i.e. magnitudes `2^-12 ≈ 2.4e-4` and `2^-14 ≈ 6.1e-5`. **These are not subnormal** — FP64 subnormals live below `2^-1022`. The Tribunal suspects the audit is checking *scaled* quantities (e.g. `step·B` after Woodbury scaling). **Demand clarification:** if the intent is to detect underflow in the Woodbury solve, the audit threshold must be `2^-1022`, and the test must assert `fpclassify(x) == FP_SUBNORMAL`.

### 2.3 `step → ∞` degeneracy
Neumaier is *not* scale-invariant in the presence of overflow: if `|step| ≥ 10^10` and `B` has entries `O(1)`, then `step·B` can reach `10^10`, and `(step·B)ᵀ(step·B)` reaches `10^20` — still inside FP64 range (`~1.8e308`), but the *condition number* of the Gram matrix squares. **Recommendation:** normalize `B` before the Woodbury step; carry `scale` as a separate FP64 scalar and re-apply after.

### 2.4 Verdict
**CONDITIONAL PASS** — algorithm sound; subnormal thresholds mislabeled; overflow path needs explicit scaling.

---

## §3. TARGET 3 — `kernel_rust_v1350.rs`

**Claims:** Rust 2021, safe SIMD, `panic=unwind` FFI barrier, Neumaier, packed 88-byte descriptor.

### 3.1 FFI hardening — the critical path
`panic=unwind` across an FFI boundary is **undefined behavior** unless the panic is caught. The correct pattern is:

```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> i32 {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(()) => 0,
        Err(_) => -1,
    }
}
```

**Demand:** every `extern "C"` entry point wraps its body in `catch_unwind` and returns a status code. `panic=abort` is *safer* for FFI but loses the barrier semantics; the Tribunal prefers `catch_unwind` + `abort` on the *second* panic (poisoned state).

### 3.2 Packed descriptor
`#[repr(C, packed)]` disables alignment; SIMD loads from packed fields are UB-adjacent on some targets. **Recommendation:** `#[repr(C, align(64))]` with explicit padding to 128 bytes, and a `bytemuck::Pod` derive for zero-copy.

### 3.3 `step → 0`
Rust's `f64` follows IEEE-754; subnormals are preserved unless `-C target-feature=+fz` (flush-to-zero) is set. **Demand:** the build must *not* enable FTZ/DAZ. Verify with `std::f64::MIN_POSITIVE / 2.0 != 0.0`.

### 3.4 Verdict
**CONDITIONAL PASS** — FFI barrier must be `catch_unwind`, not bare `panic=unwind`.

---

## §4. TARGET 4 — `kernel_cuda_v1350.cu`

**Claims:** Stiefel Cayley retraction in `R^(2K×2K)`, cuSOLVER `DnDsyevd`, globally scaled Woodbury `(M/scale)W = (step/scale)B`, CUDA Graphs.

### 4.1 Cayley retraction — correctness
For `Y ∈ St(n,p)` and skew `A = XᵀV − VᵀX`, the Cayley retraction is

```
R_X(V) = (I − A/2)^{-1} (I + A/2) X
```

This is **second-order** accurate and stays on the manifold to machine precision. **PASS** on the retraction choice.

### 4.2 `DnDsyevd` — the wrong routine?
`cusolverDnDsyevd` computes **eigenvalues and eigenvectors of a symmetric matrix**. The Cayley retraction requires a **linear solve** `(I − A/2) Z = (I + A/2) X`, not an eigendecomposition. Using `syevd` here is either (a) a mislabel, or (b) an implicit "solve via spectral decomposition" — which is `O(n³)` with a *much* worse constant than `get