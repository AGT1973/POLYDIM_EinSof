# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 152)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 152 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been asked to audit six artifacts whose *source text was not attached to the brief*. We therefore audit the **declared contracts** (the invariants, layouts, and numerical claims enumerated in the prompt) as if they were the specification, and we flag every place where the specification is either under-determined, self-contradictory, or numerically unsound. Where a claim cannot be verified without the file, we mark it **[UNVERIFIABLE — SOURCE ABSENT]** and state the exact falsification test that must be run.

---

## 0. Cross-cutting findings (apply to all six targets)

### 0.1 The 88-byte descriptor is *not* 88 bytes as written

The struct format string is:

```
<4sHHQQQQQBB6x4Q
```

Let us sum the fields under the standard `struct` module (little-endian, no alignment padding because `<` is used):

| Field | Type | Bytes |
|-------|------|-------|
| `4s`  | char[4] | 4 |
| `H`   | uint16 | 2 |
| `H`   | uint16 | 2 |
| `Q`   | uint64 | 8 |
| `Q`   | uint64 | 8 |
| `Q`   | uint64 | 8 |
| `Q`   | uint64 | 8 |
| `Q`   | uint64 | 8 |
| `B`   | uint8 | 1 |
| `B`   | uint8 | 1 |
| `6x`  | pad | 6 |
| `4Q`  | uint64×4 | 32 |
| **Total** | | **88** |

**Verdict: 88 bytes confirmed.** ✅ The `6x` pad is exactly what is needed to align the trailing `4Q` block to an 8-byte boundary *and* to make the total a multiple of 8. This is a well-constructed descriptor. **However**, the Tribunal notes a latent hazard: the `6x` pad is *implicit* alignment. If any consumer re-serializes with `=` (native) or `@` (native with alignment) instead of `<`, the size will differ on some ABIs. **Rule 22 compliance requires the `<` prefix to be mandatory and asserted at import time** — recommend a module-level `assert struct.calcsize("<4sHHQQQQQBB6x4Q") == 88`.

### 0.2 Rule 22 — "Zero 1D tokens in inter-agent communication"

The Tribunal interprets "1D token" as a **flat, unshaped, untyped scalar stream** (i.e., a bare `float32[]` or `int64[]` with no descriptor). The 88-byte PMTP descriptor is the *anti-1D* mechanism: it forces every payload to carry shape, dtype, stride, and provenance.

**Finding:** Targets 1, 2, 3, 6 declare PMTP descriptors. Targets 4 and 5 are **silent** on whether their inter-agent handoff (CUDA Graph capture boundary; XLA `pjit` boundary) carries the 88-byte descriptor or a vendor-native handle (e.g., `cudaGraphExec_t`, `jax.Array`). **This is a Rule 22 violation risk.** A `cudaGraphExec_t` is a 1D opaque token. A `jax.Array` is a 1D opaque token. **Recommendation:** both must wrap their native handle inside the 88-byte descriptor's `4Q` tail (e.g., `handle_lo`, `handle_hi`, `epoch`, `crc`).

### 0.3 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor lock risk | Verdict |
|--------|------------------|---------|
| 1 (orchestrator) | Multi-silicon probe — good | ✅ |
| 2 (C++ AVX-512) | **AVX-512 is Intel/AMD-only**; no ARM SVE fallback declared | ⚠️ |
| 3 (Rust SIMD) | `std::simd` is portable; good | ✅ |
| 4 (CUDA) | **cuSOLVER `DnDsyevd` is NVIDIA-only** | ❌ |
| 5 (XLA) | **TPU *and* Trainium** — two vendors, but no CPU/GPU fallback | ⚠️ |
| 6 (Triton) | ROCm + NVIDIA — good, but Triton itself is a lock | ⚠️ |

**Rule 27 verdict:** Target 4 is the only **hard** violation. `cuSOLVER` has no portable equivalent; the Cayley retraction must be expressible via a vendor-neutral eigensolver interface (e.g., a `SymmetricEigensolver` trait with cuSOLVER, LAPACK, and Eigen backends).

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator

The Tribunal demands the following invariants be *proved*, not asserted:

**(P1) Slab alignment.** If `PmtpSlabAllocator` returns pointers `p` such that `p mod 64 == 0` (AVX-512 cache-line), then the 88-byte descriptor must be stored in a *separate* arena from the payload, otherwise the payload's 64-byte alignment is broken by the 88-byte header. **88 mod 64 = 24**, so a header-then-payload layout misaligns every payload by 24 bytes. **This is a silent performance cliff and a potential correctness bug for aligned SIMD loads.** Recommendation: header arena and payload arena must be disjoint, or the header must be padded to 128 bytes.

**(P2) 12/12 physical conformance checks.** The Tribunal cannot verify these without the source. The falsification test: for each check `c_i`, construct an adversarial input that violates exactly `c_i` and assert the probe rejects it. If any check is a tautology (e.g., `assert size == 88` where `size` is a constant), it is not a check.

### 1.2 Numerical degeneracy at `step → ∞` and `step → 0`

The orchestrator dispatches to the five kernels. The Tribunal's concern is **dispatch-time scaling**:

- If the orchestrator computes a global `scale = max(|step|, ε)` and passes `step/scale` downstream, then at `step = 10^10` the ratio is `O(1)` — good. But at `step = 10^-300` (subnormal), `step/scale` underflows to 0 and the Woodbury solve in Target 4 becomes singular. **The orchestrator must clamp `scale ≥ 2^-1022` (FP64 min normal) and emit a `SUBNORMAL_STEP` diagnostic.**
- At `step → ∞`, the Cayley retraction `(I - (step/2)W)^{-1}(I + (step/2)W)` tends to `-I` (a reflection), which is *not* on the Stiefel manifold unless `W` is skew-symmetric and the limit is taken carefully. **The orchestrator must reject `|step| ≥ 10^10` at dispatch time** unless the kernel declares a `LARGE_STEP_SAFE` flag.

### 1.3 Rule 22 / Rule 27

- Rule 22: ✅ if the 88-byte descriptor is the *only* inter-agent token.
- Rule 27: ✅ multi-silicon probe is the correct pattern.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

The Neumaier variant of Kahan summation has **forward error bound**:

```
|computed_sum - true_sum| ≤ (2u + O(nu²)) · Σ|x_i y_i|
```

where `u = 2^-53` (FP64 unit roundoff). This is **unconditionally stable** — the bound does not depend on the condition number of the dot product. **However**, the *relative* error is `κ · u` where `κ = Σ|x_i y_i| / |Σ x_i y_i|`. For adversarial inputs (catastrophic cancellation), `κ → ∞` and the relative error blows up even though the absolute error is bounded. **The Tribunal demands the kernel expose `κ` as a diagnostic** so downstream consumers can detect ill-conditioned reductions.

### 2.2 Subnormal audits at `-12, -14`

The exponents `-12` and `-14` are **not** FP64 subnormal thresholds (`-1022` is). They are likely **FP32** subnormal thresholds (`-126`) or **log-domain** thresholds. **The Tribunal flags this as a specification ambiguity.** If the kernel is auditing FP64 subnormals, the thresholds must be `-1022` (min normal) and `-1074` (min subnormal). If it is auditing a *log-magnitude* quantity, the thresholds are domain-specific and must be documented.

**Falsification test:** feed `x = 2^-1074` (min subnormal) and `x = 2^-1023` (subnormal) and assert the audit flags both. If it only flags `-12` and `-14`, the audit is mis-specified.

### 2.3 Zero-copy PMTP validation

Zero-copy requires that the 88-byte descriptor's `4Q` tail contains **raw pointers** (or offsets into a shared arena) and that the C++ side validates them without dereferencing. **The Tribunal demands a `validate_pmtp(const uint8_t* desc)` function that:**
1. Checks `desc[0..4] == "PMTP"`.
2. Checks `crc32(desc[0..84]) == desc[84..88]`.
3. Checks pointer alignment `p mod 64 == 0`.
4. Checks `p + len` does not overflow `uintptr_t`.
5. **Does not dereference `p`** until all four checks pass.

### 2.4 Rule 27 — AVX-512 vendor lock

**Violation.** AVX-512 is not available on ARM (Apple Silicon, Graviton) or on older AMD (pre-Zen 4). The kernel must provide a **runtime dispatch** to a portable fallback (e.g., `std::experimental::simd` or a scalar Neumaier loop). **Recommendation:** compile with `-mavx512f -mavx512dq` but guard with `__builtin_cpu_supports("avx512f")` and provide a `#pragma omp simd` fallback.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier

**This is the correct choice.** `panic=abort` across an FFI boundary is UB in Rust 2021 (the panic cannot unwind through C frames). `panic=unwind` with `catch_unwind` at the FFI boundary is the only sound pattern. **The Tribunal demands: