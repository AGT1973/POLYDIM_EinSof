# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 156)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 156 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been asked to audit six artifacts whose *source text was not attached to this docket*. We therefore audit the **specification as stated in the prompt**, flag every claim that cannot be verified without the file body, and refuse to certify anything we cannot see. This is the only intellectually honest posture. Where the prompt asserts a property (e.g. "12/12 physical conformance checks"), we treat it as a *claim under audit*, not as evidence.

---

## 0. Cross-cutting findings (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens / 88-byte PMTP

The 88-byte descriptor is specified as `<4sHHQQQQQBB6x4Q`.

Let us count bytes with `struct` semantics (native alignment assumed, `<` = little-endian, no padding):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `H H` | 4 |
| five `Q` | `Q×5` | 40 |
| two `B` | `B B` | 2 |
| pad | `6x` | 6 |
| four `Q` | `Q×4` | 32 |
| **Total** | | **88** |

✅ **Byte count is arithmetically correct: 4+4+40+2+6+32 = 88.**

**But the Tribunal raises three adversarial objections:**

1. **`<` disables alignment padding, so the struct is *packed*.** This is fine for wire format, but any C++/Rust/CUDA consumer that declares the same layout with `#pragma pack` or `#[repr(C, packed)]` must guarantee **unaligned loads**. On AVX-512, a `_mm512_load_si512` on a packed `Q` field at offset 8 is UB if the pointer is not 64-byte aligned. The prompt claims "zero-copy PMTP validation" — zero-copy + packed + SIMD is a **latent SIGSEGV / #GP fault** unless every consumer uses `_mm512_loadu_si512` or `memcpy` into an aligned staging buffer. **Demand: grep every consumer for `load_si512` vs `loadu_si512`.**

2. **`6x` pad is a *silent* ABI hazard.** If any language binding (Python `ctypes`, JAX FFI, Triton host stub) re-declares the struct without the explicit pad, the total becomes 82 bytes and every subsequent field shifts. **Recommendation:** replace `6x` with an explicit `6s` named `_reserved` and add a `static_assert(sizeof(...) == 88)` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` in Rust, and a `ctypes.sizeof` check in Python.

3. **"Zero 1D tokens" is not provable from the descriptor alone.** A 1D token would be any payload whose shape rank is 1. The descriptor has no explicit `rank` field visible in the format string — the two `H` fields are unnamed in the prompt. If one of them is `rank`, then Rule 22 compliance is *enforceable at parse time*; if not, it is **unenforceable**. **Demand: name the two `H` fields and confirm one is `rank` with a `rank >= 2` invariant check on ingest.**

**Verdict on Rule 22:** *Conditionally compliant.* Byte count ✅. Enforcement mechanism ❌ (unverifiable). Packed-SIMD interaction ⚠️.

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Lock-in risk |
|---|---|---|
| T1 orchestrator | Multi-silicon probe | Low if probe is table-driven |
| T2 C++ AVX-512 | Intel-specific ISA | **High** — AVX-512 is absent on Zen 4 consumer, all Apple Silicon, all ARM |
| T3 Rust SIMD | `std::simd` portable | Low |
| T4 CUDA | cuSOLVER `DnDsyevd` | **Total** — no HIP/ROCm path mentioned |
| T5 XLA | GCP TPU + AWS Trainium | **Dual-vendor** but both proprietary |
| T6 Triton | ROCm + CUDA | Medium — Triton abstracts, but SRAM tiling is arch-specific |

**Rule 27 verdict:** T2 and T4 **violate** a strict "no vendor lock" reading. T2 must ship an AVX2/NEON fallback path; T4 must ship a `hipSOLVER` shim or a CPU fallback. T5's dual-vendor story is acceptable only if the HLO is emitted through a vendor-neutral IR (StableHLO), not `@jax.jit` directly.

### 0.3 Numerical degeneracy — the central mathematical question

The prompt asks about `|step| ≥ 10^10` and `step → 0` (subnormals). Let us treat this rigorously.

Let the update be `W ← W − step · G` (or a retraction `R_W(−step·G)`). Define the **relative perturbation**

  ε = |step| · ‖G‖_F / ‖W‖_F.

- **step → 0:** ε → 0. The update is *lost* to rounding if ε < u ≈ 2.2×10⁻¹⁶ (FP64). Worse, if `step · G` underflows into the **subnormal range** (|x| < 2⁻¹⁰²²), the Neumaier compensation in T2/T3 **cannot recover** the lost bits because subnormals have reduced mantissa precision. The prompt's "subnormal audits (−12, −14)" presumably refer to exponent thresholds — **but a −12 exponent is 2⁻¹² ≈ 2.4×10⁻⁴, which is nowhere near subnormal.** Either the audit is mislabeled or it is checking something else. **Demand: clarify what −12/−14 denote.**

- **step → ∞ (|step| ≥ 10¹⁰):** ε ≫ 1. The update **overshoots** and the iterate leaves any compact sublevel set. For a Stiefel retraction (T4), the Cayley transform `Cayley(A) = (I − A/2)⁻¹(I + A/2)` with `A = step · (WᵀG − GᵀW)` has `‖A‖ ~ step · ‖skew‖`. The **condition number** of `(I − A/2)` scales as `κ ≈ ‖A‖/2` for large `‖A‖`. At `step = 10¹⁰`, `κ ~ 5×10⁹` — the linear solve loses ~9 decimal digits. **The Woodbury scaling `(M/scale) W = (step/scale) B` is precisely the right mitigation**, but only if `scale` is chosen as `scale = max(‖M‖, |step|·‖B‖)` *at runtime*, not as a compile-time constant. **Demand: show the runtime scale selection code.**

**Asymptotic condition number for the Cayley solve:**
  κ₂(I − A/2) ≤ (1 + ‖A‖/2) / (1 − ‖A‖/2) for ‖A‖ < 2, and grows linearly as ‖A‖/2 for ‖A‖ ≫ 2.
  At `step = 10¹⁰` with `‖skew(WᵀG)‖ = O(1)`, κ ~ 5×10⁹ → **9 digits lost in FP64**. This is a **hard numerical degeneracy** unless the Woodbury path is taken.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

**Claims:** Multi-silicon `HardwareProbe`, `PmtpSlabAllocator`, 88-byte descriptor, 12/12 conformance checks.

**Audit:**

- **`HardwareProbe`:** If it probes via `cpuid`/`sysctl`/`nvidia-smi`/`rocm-smi`/`tpu-info`, it is a **side-channel** that can be spoofed in containers. Rule 27 requires the probe to be *advisory*, not *authoritative* — the kernel must still run correctly (slower) if the probe lies. **Demand: confirm the probe result is a hint, not a dispatch gate.**
- **`PmtpSlabAllocator`:** Slab allocation of 88-byte descriptors implies **alignment to 88** or to a cache line. 88 is not a power of two; a slab of N descriptors has stride 88, so descriptor `k` starts at `88k`. For AVX-512 loads this is **never 64-byte aligned** except when `88k ≡ 0 mod 64`, i.e. `k ≡ 0 mod 8`. **Recommendation: pad the slab stride to 128 bytes** (wasting 40 bytes/descriptor) to guarantee alignment, or use `loadu`.
- **12/12 conformance checks:** Unverifiable without the file. **Demand: enumerate the 12 checks.** A check that cannot be named cannot be audited.

**Verdict:** *Cannot certify.* Structural concerns on alignment and probe authority.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

**Claims:** C++20, AVX-512, OpenMP, Neumaier compensated dot, subnormal audits (−12, −14), zero-copy PMTP.

**Audit:**

- **Neumaier dot product:** The algorithm is
  ```
  s = 0; c = 0
  for x, y:
      t = s + x*y
      if |s| >= |x*y|: c += (s - t) + x*y
      else:            c += (x*y - t) + s
      s = t
  return s + c
  ```
  This is **not** correctly rounded but has error bound `|result − exact| ≤ 2u|Σ|x_i y_i|| + O(u²)`. For **subnormal inputs**, `x*y` may underflow to 0 *before* the compensation branch, so `c` cannot recover the lost product. **The Neumaier scheme is not subnormal-safe.** If the prompt's "subnormal audits" claim otherwise, that claim is **false**. **Demand: show the audit code; if it only checks exponent range, it does not check subnormal correctness.**
- **AVX-512 + OpenMP:** `#pragma omp parallel for` over a dot product requires a **reduction clause** with a compensated accumulator. OpenMP's `reduction(+:s)` is **not** Neumaier-compensated. **Demand: show the manual reduction tree with per-thread `(s, c)` pairs merged in a deterministic order.** Otherwise the result is **non-reproducible** across thread counts — a Rule 22 violation if tokens are compared bitwise.
- **Zero