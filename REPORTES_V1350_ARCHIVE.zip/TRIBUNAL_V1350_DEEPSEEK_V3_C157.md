# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 157)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 157 · Multi-File Adversarial SOTA Review

**Preliminary note on evidentiary basis.** The audit brief describes six artifacts by *specification*, not by source. I will audit the specifications as stated, flag every place where the specification is under-determined, and refuse to certify claims that cannot be discharged from the description alone. Where a claim is *provable from the stated structure*, I prove it. Where it is *not*, I mark it **UNVERIFIABLE-AS-SPECIFIED** rather than fabricate a verdict. This is the only intellectually honest posture for a tribunal.

---

## §0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Layout `<4sHHQQQQQBB6x4Q`:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | 4s | 4 | 0 |
| H | H | 2 | 4 |
| H | H | 2 | 6 |
| Q | Q | 8 | 8 |
| Q | Q | 8 | 16 |
| Q | Q | 8 | 24 |
| Q | Q | 8 | 32 |
| Q | Q | 8 | 40 |
| B | B | 1 | 48 |
| B | B | 1 | 49 |
| pad | 6x | 6 | 50 |
| Q | Q | 8 | 56 |
| Q | Q | 8 | 64 |
| Q | Q | 8 | 72 |
| Q | Q | 8 | 80 |
| **total** | | **88** | |

**Verdict:** size is exactly 88 bytes **iff** the compiler honors `Q` = 8-byte alignment with no trailing padding. Under `#pragma pack(1)` (C/C++) and `#[repr(C, packed)]` (Rust) this holds. Under default `#[repr(C)]` in Rust, the struct's *alignment* is 8, so `size_of` = 88 (already a multiple of 8) — **OK**. Under C++ default layout, same. **The 6-byte pad is load-bearing**: without it, the trailing `4Q` block would begin at offset 50, misaligning every `Q` and forcing the compiler to insert 6 bytes anyway — so the explicit pad is *correct and necessary*, not decorative.

**Rule 22 compliance (Zero 1D tokens):** the descriptor is a *fixed-width, self-describing, alignment-stable* record. It contains no variable-length fields, no pointers, no length-prefixed strings. **This satisfies the "no 1D token stream" requirement at the wire level.** However — see §0.3 — Rule 22 is a *communication* rule, not a *struct* rule; the descriptor being 88 bytes does not by itself prove the *inter-agent channel* carries no 1D tokens.

### 0.2 Rule 27 — Silicon Contract / vendor-lock

| Target | Vendor-lock risk | Assessment |
|---|---|---|
| 1 orchestrator | none (probe-only) | **PASS** if probe is capability-based, not `#ifdef VENDOR` |
| 2 C++ AVX-512 | **HIGH** | AVX-512 is Intel/AMD-specific; ARM SVE, Apple AMX, RISC-V V excluded |
| 3 Rust SIMD | medium | `std::simd` is portable; if it uses `core::arch::x86_64::*` intrinsics, **FAIL** |
| 4 CUDA | **CRITICAL** | cuSOLVER `DnDsyevd` is NVIDIA-only; no HIP/ROCm path stated |
| 5 XLA | **CRITICAL** | `@jax.jit` + TPU HLO is Google-locked; Trainium path is a *second* lock, not a portability layer |
| 6 Triton | **PASS (best)** | Triton compiles to both ROCm and CUDA — this is the only genuinely portable kernel |

**Tribunal finding:** Rule 27 is **violated by Targets 2, 4, 5** as specified. Target 6 is the only component that honors the contract. This is a *systemic* violation, not a per-file bug: the architecture claims multi-silicon but three of six kernels are single-vendor.

### 0.3 Rule 22 — the real test

Rule 22 says *inter-agent communication* must carry zero 1D tokens. The 88-byte descriptor is a *2D tensor header* (shape + strides + dtype + flags). **But**: the orchestrator (Target 1) is described as doing "12/12 physical conformance checks" — if any of those checks *serializes a status string* or *emits a log line* across the agent boundary, Rule 22 is violated. The brief does not state the channel format. **UNVERIFIABLE-AS-SPECIFIED.** Recommendation: mandate that all inter-agent messages are `PmtpTensorDescriptor`-framed, with status encoded in the `BB` flag bytes, never as text.

---

## §1. Target 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe
A probe that enumerates CUDA / ROCm / TPU / Trainium / AVX-512 must be **capability-query based**, not `try: import torch; except:`. The latter is a vendor-lock smell. **Recommendation:** probe via `cpuid` leaf 7 (AVX-512F/BW/DQ/VL), `rocm-smi --showproductname`, `nvidia-smi -q`, `/dev/accel*` for TPU, and `/sys/class/neuron*` for Trainium. Return a *bitmask*, not a string.

### 1.2 PmtpSlabAllocator
"Slab" implies fixed-size 88-byte records. **Numerical degeneracy risk:** if the slab is `mmap`'d without `MAP_HUGETLB`, TLB pressure at 10^10 descriptors is catastrophic. **Asymptotic:** at N descriptors, TLB misses scale as N/512 (4 KiB pages) vs N/2·10^6 (2 MiB huge pages) — a 4096× reduction. **Recommendation:** mandate huge pages for slabs > 10^6 entries.

### 1.3 12/12 physical conformance checks
The brief asserts 12/12 pass. **Tribunal cannot certify without the check list.** A conformance check that is *not falsifiable* (e.g., "descriptor is 88 bytes" checked by `sizeof`) is a tautology. **Demand:** each of the 12 checks must be a *property test* with a stated failure mode. Example admissible check: "for all d in slab, `d.magic == b'PMTP'` and `d.H*d.W*itemsize(d.dtype) == d.nbytes`."

---

## §2. Target 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

Neumaier's variant of Kahan:

```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
    else:                c += (x_i*y_i - t) + s
    s = t
return s + c
```

**Theorem (Neumaier 1974).** For n terms, the compensated sum satisfies
$$|\hat{s} - s| \le \big(2u + O(nu^2)\big)\sum_i |x_i y_i|$$
where $u = 2^{-53}$ for FP64. This is **independent of n to first order** — the key advantage over naive summation ($O(nu)\sum|x_i y_i|$).

**Degeneracy at step → ∞ (|step| ≥ 10^10):** the *compensation term* `c` is itself a sum of rounding residuals. If `x_i*y_i` overflows to ±Inf, Neumaier's branch `|s| >= |x_i*y_i|` becomes `Inf >= Inf` → **true**, and `c += (s - t) + x_i*y_i` = `(Inf - Inf) + Inf` = **NaN**. **This is a real degeneracy.** Mitigation: pre-scale inputs by `1/scale` where `scale = max|step|`, then rescale the result. The brief mentions "globally scaled Woodbury solve (M/scale)" in Target 4 — **the same scaling must be applied in Target 2**, and the brief does not state that it is.

**Degeneracy at step → 0 (subnormals):** the brief cites "subnormal audits (-12, -14)". These are presumably exponents (2^-12, 2^-14) or ULP counts. **Critical fact:** on x86 with default MXCSR, subnormals are *gradual* (no FTZ/DAZ). But if the kernel sets `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON)`, subnormals flush to zero and Neumaier's compensation **silently loses the residual** — the error bound above is void. **Recommendation:** explicitly clear FTZ/DAZ in the kernel prologue and assert `_MM_GET_FLUSH_ZERO_MODE() == _MM_FLUSH_ZERO_OFF`.

### 2.2 AVX-512 + OpenMP
AVX-512 downclocking on Skylake-X is a *performance* degeneracy, not numerical. But **AVX-512 masked loads with `_mm512_maskz_loadu_pd`** can read past the array end if the mask is wrong — a *memory-safety* degeneracy. **Recommendation:** use `_mm512_maskz_loadu_pd` only with masks derived from `n - i`, never from a constant.

### 2.3 Zero-copy PMTP validation
"Zero-copy" means the 88-byte descriptor is read *in place* from the slab. **Risk:** if the descriptor is read via `reinterpret_cast<PmtpTensorDescriptor*>(ptr)` and `ptr` is not 8-byte aligned, UB. **Recommendation:** `assert(reinterpret_cast<uintptr_t>(ptr) % 8 == 0)` at every entry point.

---

## §3. Target 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier
**This is the single most important line in the brief.** Rust's default `panic=unwind` is **UB across an FFI boundary** unless the panic is caught. The correct pattern is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(_) => 0,
        Err(_) => -1,
    }
}
```

**If the kernel uses `extern "C"` without `catch_unwind`, it is UB.** The brief says "panic=