# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 131)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 131 · Multi-File Adversarial SOTA Review

**Presiding note:** The Tribunal treats the six "targets" as *specifications under audit*, not as verified artifacts. Where a claim is unverifiable from the description alone (e.g., "12/12 physical conformance checks"), the Tribunal flags it as **UNSUBSTANTIATED** and demands the underlying test vector. We proceed component-by-component, then synthesize cross-cutting findings.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor layout `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly (little-endian, standard `struct` alignment disabled by `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major | `H` | 2 |
| version_minor | `H` | 2 |
| flags | `Q` | 8 |
| n_rows | `Q` | 8 |
| n_cols | `Q` | 8 |
| stride | `Q` | 8 |
| dtype_code | `Q` | 8 |
| rank | `B` | 1 |
| retract_kind | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

✅ **Byte count is arithmetically correct.** However, the Tribunal raises three structural objections:

**(a) Endianness lock-in.** `<` forces little-endian. On a big-endian host (IBM POWER9, some s390x), the descriptor is silently misread. Rule 27 (Silicon Contract) is *violated at the wire level* unless the orchestrator performs an explicit `byteswap` on `sys.byteorder == 'big'`. **Recommendation:** mandate `>!`-style canonical network order, or add a `flags` bit `PMTP_FLAG_BIGENDIAN` and require the consumer to honor it.

**(b) `dtype_code` as `Q` (64-bit) is over-wide.** A 64-bit dtype enum admits 2⁶⁴ values; the actual dtype space is O(10). This wastes 7 bytes that could carry a `checksum` or `epoch`. Not a bug, but a **density inefficiency** in a hot-path descriptor.

**(c) `6x` padding is *not* guaranteed to be zero.** Python's `struct.pack` writes `\x00` for `x`, but a C/Rust producer using `#[repr(C)]` with `_pad: [u8;6]` may leave uninitialized bytes. **Rule 22 compliance requires byte-exact determinism** — an uninitialized pad byte breaks hash-based dedup. **Recommendation:** add a `PMTP_PAD_MUST_BE_ZERO` conformance check (this is likely one of the "12/12" checks; demand the test).

### 1.2 `PmtpSlabAllocator` — numerical degeneracy at step extremes

The allocator itself is not numerical, but it *feeds* the kernels. The Tribunal's concern: **does the allocator's slab size depend on `step`?** If slab size scales as `O(step²)` (e.g., for Woodbury workspace), then:

- `step → 10^10` ⇒ slab request ≈ 10²⁰ bytes ⇒ **integer overflow in `size_t` on 32-bit**, and **OOM on 64-bit**.
- `step → 0` ⇒ slab request → 0 ⇒ **zero-size allocation**, which is UB in C (`malloc(0)`) and returns `None` in some Python allocators.

**Demand:** the allocator must clamp `slab_bytes = max(MIN_SLAB, min(MAX_SLAB, f(step)))` with `MIN_SLAB ≥ 4096` and `MAX_SLAB ≤ 2^40`. Without this, Rule 22's "zero 1D tokens" is moot because the process dies before emitting a token.

### 1.3 "12/12 physical conformance checks"

**UNSUBSTANTIATED.** The Tribunal demands the test matrix. A credible 12-check suite for a multi-silicon probe would include: (1) endianness, (2) pad-zero, (3) magic, (4) version monotonicity, (5) dtype∈enum, (6) rank≤MAX_RANK, (7) stride≥n_cols·dtype_size, (8) reserved==0, (9) alignment mod 64, (10) checksum, (11) slab bounds, (12) NUMA affinity. If any of these is absent, the "12/12" claim is **theater**.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

Neumaier's variant of Kahan–Babuška:

```
s = 0; c = 0
for i: t = s + x_i*y_i
       if |s| ≥ |x_i*y_i|: c += (s - t) + x_i*y_i
       else:               c += (x_i*y_i - t) + s
       s = t
return s + c
```

**Theorem (Neumaier 1974; Higham 2002 §4.3):** For `n` terms with unit roundoff `u`, the compensated sum satisfies

  |ŝ − s| ≤ (2u + O(nu²)) · Σ|x_i y_i|.

This is **independent of n to first order** — the key win over naive summation (which has `nu·Σ|x_i y_i|`). For IEEE-754 binary64, `u = 2⁻⁵³ ≈ 1.11e-16`.

**Degeneracy at step → ∞:** If `step ≥ 10^10` and the dot product is `⟨step·v, w⟩`, then `Σ|x_i y_i| ≈ step·Σ|v_i w_i|`. The *relative* error stays `O(u)`, but the *absolute* error grows as `step·u·Σ|v_i w_i|`. If the downstream consumer compares this against a tolerance `τ` that does **not** scale with `step`, the comparison is **ill-posed**. **Recommendation:** all tolerance checks must be *relative*: `|ŝ − s| ≤ τ_rel · Σ|x_i y_i|`.

**Degeneracy at step → 0 (subnormals):** The audit mentions "subnormal audits (−12, −14)". These are almost certainly **exponent thresholds** (2⁻¹², 2⁻¹⁴) below which the kernel switches to a subnormal-safe path. The Tribunal's concern:

- On x86-64 with AVX-512, subnormal arithmetic is **not** flushed to zero by default (MXCSR FTZ/DAZ bits are 0), but **some BLAS libraries set FTZ=1** for performance. If the kernel links against such a BLAS, the compensated sum's `c` term can be **silently zeroed**, destroying the compensation.
- **Demand:** the kernel must explicitly clear FTZ/DAZ via `_mm_setcsr(_mm_getcsr() & ~0x8040)` at entry, and restore at exit. This is a **Rule 27 (Silicon Contract)** obligation: the kernel must not inherit vendor-default FP modes.

### 2.2 Zero-copy PMTP validation

"Zero-copy" implies the C++ kernel reads the 88-byte descriptor **in place** from shared memory. Two hazards:

1. **Alignment:** `reinterpret_cast<const PmtpDescriptor*>(ptr)` requires `ptr % alignof(PmtpDescriptor) == 0`. If `alignof` is 8 (due to `Q` fields) but the producer aligned to 4, this is **UB on ARM** (which traps) and **silent misread on x86**. **Recommendation:** use `memcpy` into a stack-local `PmtpDescriptor` — the compiler will elide it, and correctness is guaranteed.
2. **Torn reads:** if the producer writes the descriptor concurrently, a zero-copy reader can observe a **half-updated** descriptor. **Recommendation:** require a seqlock or `std::atomic<uint64_t>` version stamp in `flags`.

### 2.3 AVX-512 / OpenMP portability

AVX-512 is **not** universal: it is absent on all AMD Zen 1–3 (Zen 4 has it), on Intel Alder Lake E-cores, and on ARM. If the kernel is compiled with `-mavx512f` unconditionally, it **SIGILLs** on those hosts. **Rule 27 violation.** **Recommendation:** runtime dispatch via `__builtin_cpu_supports("avx512f")` with a scalar fallback.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the single most dangerous claim in the audit.** `panic = unwind` across an FFI boundary is **UB** unless the boundary is `extern "C-unwind"` (stabilized in Rust 1.71) **and** the foreign side is compiled with compatible unwind tables. The default `extern "C"` is `nounwind`; a panic crossing it is **abort-or-UB** depending on the panic strategy.

**Concrete hardening recommendations:**

1. Every `extern "C"` function that can panic must be wrapped:
   ```rust
   #[no_mangle]
   pub extern "C" fn pmtp_dot(...) -> c_int {
       match std::panic::catch_unwind(|| inner_dot(...)) {
           Ok(v) => v,
           Err(_) => PMTP_ERR_PANIC,
       }
   }
   ```
2. Set `panic = "abort"` in `[profile.release]` **unless** `catch_unwind` is used at every boundary. Mixing `unwind` with `extern "C"` is a **latent CVE**.
3. The `catch_unwind` payload must be `UnwindSafe`; raw pointers are not, so wrap in `AssertUnwindSafe` **only** if the kernel is stateless across the panic point.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust's `#[repr(C, packed)]` removes padding but makes **every field access a potential unaligned read**. On x86 this is slow; on ARM it is **UB** (or traps). The Tribunal recommends:

- Use `#[repr(C)]` with explicit `_pad: [u8; 6]` and a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` static assertion.
- If `packed` is mandatory (wire format), access fields via `read_unaligned` and never take references to fields (references to packed fields are UB).

### 3.3 Neumaier in Rust — same FTZ caveat

Rust does not expose MXCSR directly; use `core::arch::x86_64::_