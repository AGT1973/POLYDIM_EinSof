# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 153

The supplied material does **not contain the eight Tribunal models’ reports, the six kernel specifications, test logs, or formal proofs**. Therefore, no defensible model-by-model arbitration or “exact” V1350 architectural guarantee can be asserted. The strongest valid synthesis is a set of **conditional guarantees** that the implementation must satisfy.

## 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

A large scalar step is not, by itself, a stability guarantee or a failure proof. For a tangent update \(U+\alpha \Delta\), the relevant issue is the conditioning and solvability of the retraction’s linear system, not merely the magnitude of \(\alpha\).

For the canonical Cayley retraction, the inverse can become singular or ill-defined when the relevant orthogonal factor has an eigenvalue at \(-1\). Recent analysis reports bounded forward condition numbers for canonical Cayley and polar-light retractions under their stated regularity assumptions, while also explicitly identifying the \(-1\) eigenvalue exclusion.[2] QR and polar methods have different failure modes: QR requires a robust rank-revealing or Householder implementation, while polar methods require a well-conditioned nonsingular factor.

**Arbitrated finding:**

- No method should claim unconditional stability for arbitrary \(|\mathrm{step}|\ge 10^{10}\).
- A Cayley implementation may be preferable when its shifted system remains well-conditioned and is solved with a backward-stable factorization.
- Householder QR is generally the safer fallback when the update is badly scaled or the Cayley denominator approaches singularity.
- Polar retraction is mathematically attractive but requires reliable treatment of rank deficiency and matrix-function convergence.
- “Stable at extreme step” must mean a tested bound such as
  \[
  \|Q^\mathsf{T}Q-I\|\le \varepsilon_{\text{orth}},
  \]
  together with a residual bound for the defining equation and no silent overflow, NaN, or loss of rank.

The correct architecture is therefore a **guarded hybrid**:

1. Scale or normalize the tangent update before forming the retraction.
2. Estimate conditioning or monitor factorization residuals.
3. Use Cayley only inside its nonsingular, well-conditioned region.
4. Fall back to Householder QR or a polar method when the guard fails.
5. Return an explicit diagnostic status rather than claiming success after numerical breakdown.

A claim that Cayley is universally superior to Householder or polar QR at \(10^{10}\)-scale steps is unsupported.

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

Acquire/release operations are necessary but are not, by themselves, a complete RCU or QSBR protocol. Correct publication requires ordering descriptor initialization before publication; correct consumption requires an acquire operation before dereferencing the published contents. RCU documentation describes this as publishing updates with a release-style operation and reading the new version with an acquire-style dereference.[1]

The required publication pattern is conceptually:

```cpp
// Writer
initialize_descriptor_and_payload(new_desc);
published.store(new_desc, std::memory_order_release);

// Reader
auto p = published.load(std::memory_order_acquire);
consume_descriptor_and_payload(p);
```

For replacement and reclamation, the protocol additionally needs:

- Atomic publication of the pointer or version.
- A reader-side critical-section protocol.
- A grace-period mechanism.
- Delayed reclamation until every reader that could have observed the old version has quiesced.
- Correct handling of ABA, descriptor reuse, alignment, and lifetime.

QSBR is especially dependent on explicit quiescent-state reporting; reclamation is not safe merely because the pointer was atomically replaced.[4] RCU requirements similarly include ordering and grace-period guarantees, not just a single acquire/release pair.[9]

**Arbitrated guarantee:**

- **Release publication + acquire observation** guarantees that a reader observing the published pointer sees the writer’s preceding initialization, assuming the same atomic object provides the synchronization.
- It does **not** guarantee reclamation safety.
- It does **not** guarantee a globally coherent multi-field snapshot if fields are independently mutable.
- It does **not** make an 88-byte object atomic as a whole.
- It does **not** remove the need for cache/device synchronization on GPUs or heterogeneous systems.

The descriptor should therefore be treated as an immutable, versioned object after publication. If updates are needed, construct a new descriptor, publish one atomic pointer/version, and reclaim the old object only after an RCU/QSBR grace period. The 88-byte size should not be presented as an atomicity property.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no evidence in the gathered material establishing conformance across all five execution environments. Such conformance cannot be inferred from mathematical equivalence or from a C++20 memory-order declaration.

The systems have distinct semantic layers:

- **C++20 and Rust** provide host-language memory models, but Rust’s guarantees depend on the chosen atomic and unsafe-code discipline.
- **CUDA** requires explicit reasoning about device scopes, block/system visibility, stream ordering, and host–device synchronization.
- **Triton** exposes compiler- and target-dependent atomic and barrier behavior; source-level similarity to CUDA does not prove identical ordering.
- **XLA** uses compiler-managed execution and may reorder or fuse operations unless the required dependency, token, collective, or backend-specific mechanism is expressed.

A valid conformance claim requires a formal contract specifying:

- Numeric precision and permitted error bounds.
- Orthogonality and factorization residual tolerances.
- Overflow, underflow, NaN, and singularity behavior.
- Atomic scope and memory-order semantics.
- Snapshot linearization point.
- Reclamation and grace-period rules.
- Alignment, endianness, descriptor layout, and ABI.
- Determinism requirements.
- Supported device architectures and compiler versions.

The same litmus tests must then be run on every backend, including:

- Writer publication followed by reader acquisition.
- Reader snapshot during concurrent replacement.
- Delayed reader and grace-period reclamation.
- ABA and descriptor reuse.
- Extreme-step retraction with adversarial spectra.
- NaN/Inf and near-singular inputs.
- Cross-backend bitwise or tolerance-based numerical comparison.

## Definitive arbitration

Given the available evidence, the defensible SOTA position is:

1. **Cayley is conditionally stable, not unconditionally stable.** Extreme-step operation requires scaling, conditioning checks, residual verification, and a QR/polar fallback.
2. **Acquire/release is necessary for descriptor publication but insufficient for RCU/QSBR.** Snapshot isolation additionally requires immutable published versions, atomic pointer/version publication, explicit reader participation, and grace-period-protected reclamation.
3. **Cross-silicon conformance is a contract-and-test property, not an architectural assumption.** CUDA, XLA, Triton, C++20, and Rust require backend-specific implementations of the same abstract guarantees.
4. **No exact V1350 guarantee can be certified from the supplied evidence.** In particular, claims of universal \(10^{10}\)-step stability, whole-descriptor atomicity, or automatic five-platform memory-model equivalence would be technically unjustified.

The appropriate V1350 guarantee is consequently a **verified conditional guarantee**: successful operations preserve the Stiefel constraint within a specified tolerance; published descriptors are observed after complete initialization; old versions are not reclaimed before the relevant grace period; and each backend passes the same numerical and concurrency litmus suite under explicitly documented scope and compiler assumptions.