# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 137

A definitive arbitration is **not possible from the supplied record**: the eight model outputs, the six kernel specifications, and the PMTP/V1350 implementation are not included, and the public search evidence does not identify a verifiable “POLYDIM V1350” specification. The defensible SOTA result is therefore a **conditional architectural synthesis**, not a certification of those kernels.

## 1. Cayley retraction under extreme steps

For \(X\in\mathrm{St}(n,p)\) and a skew-symmetric generator \(\Omega^\top=-\Omega\), the Cayley update is typically

\[
Y(\alpha)=
\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
\left(I+\frac{\alpha}{2}\Omega\right)X.
\]

The transform is orthogonal whenever the inverse exists; the cited literature characterizes Cayley as a second-order Stiefel retraction under the canonical metric.[5] However, **orthogonality in exact arithmetic does not imply numerical stability for \(|\alpha|\ge 10^{10}\)**.

The superior arbitration is:

- **Do not claim unconditional Cayley stability** for extreme steps.
- Form the update using a stable solve, never an explicit inverse.
- Scale or factor the skew generator before solving.
- Detect conditioning, overflow, underflow, and loss of orthogonality.
- Fall back to a QR or polar retraction when the Cayley system is ill-conditioned.
- Re-orthogonalize and verify

\[
\|Y^\top Y-I\|
\]

against a precision-appropriate tolerance.

A Householder QR implementation is generally the safest default for robust orthogonalization because it avoids explicitly forming normal equations and is backward stable under standard assumptions. A polar retraction,

\[
R_{\mathrm{polar}}(X,\xi)
=(X+\xi)\left(I+\xi^\top\xi\right)^{-1/2},
\]

has the geometric advantage of selecting the closest orthogonal factor in Frobenius norm; this formulation is documented in the Stiefel-retraction literature.[12][15] Its implementation still requires a stable inverse square root, such as a carefully guarded eigendecomposition, SVD, or converged Newton–Schulz iteration.

**Arbitrated guarantee:** Cayley preserves the Stiefel constraint algebraically when its solve is nonsingular and exact, but it cannot be certified as numerically stable for arbitrary \(|\mathrm{step}|\ge10^{10}\). The only defensible extreme-step guarantee is a **verified hybrid policy**:

\[
\text{Cayley}
\;\longrightarrow\;
\text{QR/polar fallback}
\;\longrightarrow\;
\text{explicit failure if verification fails}.
\]

Any tribunal finding claiming that Cayley is categorically superior to Householder QR or polar decomposition at those step sizes is mathematically overbroad.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering provides a **happens-before relationship only through the same atomic synchronization variable**. In C++20, a release store synchronizes with an acquire load that reads the released value; it does not globally order unrelated atomics or repair an invalid reclamation protocol.[1] Rust adopts the C++20 atomic memory model and gives the equivalent acquire/release guarantees.[2][14]

The correct publication pattern is:

1. Construct the immutable descriptor and all pointed-to state.
2. Publish the descriptor pointer, version, or sequence token with a **release** operation.
3. Reader loads that same publication variable with **acquire**.
4. Reader announces its active epoch, hazard, or QSBR quiescent-state participation according to the reclamation protocol.
5. Writer retires old state only after every relevant reader has passed a grace period.
6. Reclamation must not occur merely because a reader observed a newer version.

For an 88-byte descriptor, the size itself gives no synchronization guarantee. The architecture must specify:

- alignment and atomicity of every field used concurrently;
- whether the descriptor is copied atomically or accessed through an atomic pointer;
- immutable versus mutable fields;
- version or epoch representation;
- publication and retirement variables;
- lifetime and reclamation rules;
- ABA protection;
- behavior under torn reads, wraparound, and failed validation.

**Arbitrated guarantee:** acquire/release can guarantee that a reader which acquires a published pointer observes initialization ordered before the matching release. It **cannot alone guarantee snapshot isolation or safe reclamation**. Those require an explicit RCU/QSBR protocol, reader registration, grace-period advancement, and lifetime control. The strongest valid statement is therefore:

> The descriptor is snapshot-consistent only if readers acquire the publication token before dereferencing immutable state and reclamation is deferred beyond a grace period covering every reader that could hold the prior snapshot.

Sequential consistency is not a substitute for a missing grace-period protocol, although it may simplify reasoning.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

These environments do not share one execution or memory model. Consequently, source-level conformance cannot be inferred from successful compilation.

A valid cross-silicon conformance claim requires separate contracts for:

- numerical semantics and permitted error;
- layout, alignment, endianness, and descriptor ABI;
- atomic scopes and ordering;
- synchronization and stream/event behavior;
- initialization and lifetime;
- NaN, infinity, signed-zero, and overflow behavior;
- deterministic versus nondeterministic reductions;
- supported integer widths and pointer representations;
- compiler lowering and target-specific barriers.

C++20 and Rust can express host-side acquire/release semantics, but device code requires the target API’s own atomic scopes and fences. CUDA, XLA, and Triton may reorder, fuse, vectorize, or distribute operations differently. A host-language memory-order annotation therefore does not automatically establish a device-wide ordering guarantee.

The defensible conformance architecture is:

- one canonical abstract state machine;
- per-backend lowering rules;
- backend-specific barrier mappings;
- litmus tests for publication, validation, and reclamation;
- differential numerical tests against a high-precision reference;
- adversarial tests for extreme steps, stale snapshots, ABA reuse, compiler fusion, and concurrent retirement;
- runtime capability checks;
- explicit “unsupported” outcomes rather than silent semantic degradation.

**Arbitrated guarantee:** multi-silicon conformance can be guaranteed only for the intersection of explicitly specified behaviors and tested backend mappings. It cannot be guaranteed merely because implementations exist in CUDA, XLA, Triton, C++20, and Rust.

## Definitive synthesis

The mathematically strongest architecture is a **verified hybrid design**:

1. Use Cayley only when a scaled, stable solve passes conditioning and residual checks.
2. Use Householder QR as the robust orthogonalization fallback.
3. Use polar retraction when closest-factor geometry or a high-quality orthogonal projection is required and its inverse-square-root computation is certified.
4. Publish immutable PMTP snapshots through a release operation on one canonical atomic publication token.
5. Acquire that same token before reading snapshot data.
6. Protect old snapshots with QSBR/RCU grace periods; acquire/release alone is insufficient.
7. Define separate host and device memory-order mappings.
8. Require numerical, memory-model, ABI, and reclamation litmus tests on every target.
9. Treat any failed residual, stale-generation check, unsupported atomic scope, or reclamation proof as a hard conformance failure.

Thus the exact guarantees that can legitimately be made are:

\[
Y^\top Y=I
\]

only up to verified numerical tolerance after the selected retraction path;

\[
\text{release publication}
\;\mathrel{\mathrm{sw}}\;
\text{matching acquire observation}
\]

for the same atomic publication variable;

and snapshot lifetime safety only after a completed RCU/QSBR grace period.

Claims stronger than these—especially unconditional extreme-step Cayley stability, snapshot isolation from acquire/release alone, or automatic CUDA/XLA/Triton/C++20/Rust equivalence—are not established by the available evidence.