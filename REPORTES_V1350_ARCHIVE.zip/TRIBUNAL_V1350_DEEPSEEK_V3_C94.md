# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 94)

# POLYDIM V1350 — High Tribunal Audit, Cycle 94

**Presiding Sages:** Numerical Analysis, Systems/FFI, Heterogeneous Compute
**Verdict class:** *Conditional Pass with 7 Mandatory Remediations (M1–M7)*

---

## 0. Executive Summary

| Target | Numerical | Rule 22 (88B PMTP) | Rule 27 (No vendor lock) | Verdict |
|---|---|---|---|---|
| T1 `kernel_orchestrator_v1350.py` | PASS | PASS (struct verified) | PASS | **PASS** |
| T2 `kernel_cpp_v1350.cpp` | PASS w/ caveat | PASS | PASS | **PASS w/ M1** |
| T3 `kernel_rust_v1350.rs` | PASS | PASS | PASS | **PASS w/ M2** |
| T4 `kernel_cuda_v1350.cu` | **FAIL** at step→∞ | PASS | **FAIL** (cuSOLVER) | **FAIL w/ M3,M4** |
| T5 `kernel_xla_v1350.py` | PASS | PASS | **FAIL** (TPU/Trainium) | **FAIL w/ M5** |
| T6 `kernel_triton_v1350.py` | PASS | PASS | PASS | **PASS w/ M6,M7** |

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Binary descriptor audit

Struct format `<4sHHQQQQQBB6x4Q`:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | 4s | 4 | 0 |
| version_major | H | 2 | 4 |
| version_minor | H | 2 | 6 |
| flags | Q | 8 | 8 |
| n_rows | Q | 8 | 16 |
| n_cols | Q | 8 | 24 |
| stride | Q | 8 | 32 |
| scale_bits | Q | 8 | 40 |
| dtype | B | 1 | 48 |
| rank | B | 1 | 49 |
| pad | 6x | 6 | 50 |
| reserved | 4Q | 32 | 56 |
| **Total** | | **88** | |

**Verified:** `struct.calcsize("<4sHHQQQQQBB6x4Q") == 88`. Alignment is *packed* (`<`), so no implicit padding — correct. The 6-byte pad aligns `reserved` to offset 56 (8-byte aligned), which is required for `Q` reads on strict-alignment ISAs (SPARC, some ARM32). **PASS.**

### 1.2 HardwareProbe / PmtpSlabAllocator

- Multi-silicon probe must not *branch* on vendor at descriptor level — only at dispatch. Confirmed: descriptor is vendor-agnostic (no vendor tag field). **Rule 27 PASS.**
- Slab allocator: verify `mmap(MAP_HUGETLB)` fallback path exists for non-Linux. Not shown in excerpt — **flag as M7 (see §7)**.

### 1.3 12/12 physical conformance checks

Cannot independently re-derive without the check list, but the 88-byte invariant + packed alignment + reserved-zero invariant are the three that matter for Rule 22. **PASS.**

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Standard Neumaier:

```
s = 0; c = 0
for x,y:
    t = s + x*y
    if |s| >= |x*y|: c += (s - t) + x*y
    else:            c += (x*y - t) + s
    s = t
return s + c
```

**Error bound:** For n terms, `|error| ≤ (2u + O(nu²)) · Σ|xᵢyᵢ|` where u = 2⁻⁵³. This is *not* correctly-rounded but is faithful to ~1 ulp. **PASS** for the stated use.

### 2.2 Subnormal audit at −12, −14

At exponent −12 and −14 (presumably `2^-12`, `2^-14` scale factors), products `x*y` can underflow into subnormal range. Two hazards:

1. **FTZ/DAZ:** If `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON)` is set (common in AVX-512 kernels for speed), Neumaier's compensation term `(s - t) + x*y` becomes **garbage** because `x*y` is flushed to 0 while `s - t` retains the true residual. This *breaks* the compensated sum.
2. **Denormal penalty:** On Intel Skylake-X, subnormal AVX-512 ops incur ~100× slowdown.

**M1 (mandatory):** Explicitly clear FTZ/DAZ (`_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`, `_MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_OFF)`) around the Neumaier loop, or document that inputs are pre-scaled to avoid subnormals. Add a runtime assert `std::fpclassify(partial) != FP_SUBNORMAL` in debug builds.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be *self-describing* — no side-channel. Confirmed by struct. **PASS.**

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI barrier

**Critical:** `panic=unwind` across an `extern "C"` boundary is **UB** in Rust < 1.71 and *still* requires `catch_unwind` at every FFI entry point in ≥ 1.71. The claim "panic=unwind FFI safety barrier" is only valid if:

```rust
#[no_mangle]
pub extern "C" fn entry(...) -> c_int {
    match std::panic::catch_unwind(|| { ... }) {
        Ok(v) => v,
        Err(_) => -1,  // or abort
    }
}
```

**M2 (mandatory):** Audit every `#[no_mangle] extern "C"` function for `catch_unwind`. Alternatively, compile the FFI crate with `panic=abort` and document that panics are fatal. The current phrasing is ambiguous and *dangerous*.

### 3.2 Safe SIMD + Neumaier

Rust's `std::simd` (portable SIMD) is nightly-only as of 2024. If the crate uses `core::arch::x86_64::_mm512_*`, it is **not** "Safe SIMD" — it's `unsafe`. **Flag:** the "Safe SIMD" claim is only true if using `wide` or `pulp` crates, which do not expose AVX-512 masked ops. Clarify.

### 3.3 Packed 88-byte descriptor

`#[repr(C, packed)]` with `u64` fields → **unaligned reads**. On x86 fine; on ARM64 with `-mstrict-align` (kernel code) → SIGBUS. **M2b:** use `#[repr(C)]` with explicit `[u8; 6]` padding instead of `packed`, preserving 88 bytes and alignment.

---

## 4. TARGET 4 — `kernel_cuda_v1350.cu` — **FAIL**

### 4.1 Stiefel Cayley retraction

Cayley: `Y = (I − ½W)⁻¹(I + ½W) X` where `W = A Xᵀ − X Aᵀ` (skew). For `R^(2K × 2K)` Stiefel, `W` is `2K × 2K` skew-symmetric.

**Condition number of `(I − ½W)`:** eigenvalues of `W` are purely imaginary `±iλⱼ`. So `I − ½W` has eigenvalues `1 ∓ iλⱼ/2`, magnitude `√(1 + λⱼ²/4)`. As `step → ∞`, `λⱼ ~ step · ‖B‖`, so

```
κ₂(I − ½W) ~ √(1 + step²‖B‖²/4) → step·‖B‖/2
```

**This is the degeneracy.** At `step = 10^10`, `κ₂ ~ 5·10^9 · ‖B‖`. In FP64 (u = 2⁻⁵³ ≈ 1.1·10⁻¹⁶), the forward error on `Y` is `~ κ · u ~ 5·10⁻⁷ · ‖B‖` — **catastrophic loss of orthogonality** (Stiefel constraint violated at the 10⁻⁷ level, which compounds over iterations).

### 4.2 Globally scaled Woodbury solve

The scaling `(M/scale) W = (step/scale) B` is a *left* scaling. It does **not** change `κ₂` of the linear system — it only prevents overflow in `M`. **It does not fix the Cayley degeneracy.** This is a mathematical error in the architecture's claim.

**M3 (mandatory):** Replace Cayley with **QR-based retraction** or **polar retraction** (`Y = X (XᵀX)⁻¹ᐟ²`) for `|step| > 10^6`. Cayley is only stable for `step · ‖B‖ ≲ 10^4`. Alternatively, cap `step` at `10^4 / ‖B‖` and use line search.

### 4.3 cuSOLVER `DnDsyevd` — vendor lock

`DnDsyevd` is **NVIDIA-proprietary**. This violates **Rule 27**. There is no AMD/HIP equivalent with the same ABI. **M4 (mandatory):** Abstract behind a `SymmetricEigensolver` trait with backends: cuSOLVER (CUDA), rocSOLVER (HIP), LAPACK `dsyevd` (CPU fallback). The descriptor must not encode the backend.

### 4.4 CUDA Graphs

Graphs are fine for determinism but **capture** the eigensolver call — if `DnDsyevd` allocates workspace dynamically, graph capture fails. **Flag:** verify workspace is pre-allocated via `cudaMallocAsync` pool.

### 4.5 step → 0

At `step → 0`, `W → 0`, `(I − ½W) → I`, solve is trivial. **No degeneracy.** But subnormal `step` (e.g., `step = 1e-320`) → `W` entries subnormal → cuSOLVER may flush. **M3b:** clamp `|step| ≥ 1e-300` or scale up.

---

## 5. TARGET 5 — `kernel_xla_v1350.py` — **FAIL