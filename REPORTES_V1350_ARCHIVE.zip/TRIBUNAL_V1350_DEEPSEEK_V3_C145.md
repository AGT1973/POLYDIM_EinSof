# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 145)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 145 · Six-Component Adversarial SOTA Review

**Presiding note.** The Tribunal treats each target as a *claim of correctness* under adversarial perturbation. We do not accept "it compiles" or "it runs on my machine" as evidence. We require: (i) algebraic invariants, (ii) conditioning bounds, (iii) FFI/ABI proofs, (iv) silicon-portability arguments. Where the artifact is described but not shown, we audit the *specification* and flag unverifiable claims explicitly.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor: `<4sHHQQQQQBB6x4Q`

Let us count bytes under **native alignment = 1** (struct format `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major | `H` | 2 |
| version_minor | `H` | 2 |
| flags | `Q` | 8 |
| n_rows | `Q` | 8 |
| n_cols | `Q` | 8 |
| stride | `Q` | 8 |
| scale_bits | `Q` | 8 |
| rank | `B` | 1 |
| dtype | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

✅ **Byte count is exact: 88.** This is the *only* defensible way to hit 88 — any `=` (native) alignment would pad `4sHH` to 8 and blow the budget. **Rule 22 compliance is structurally enforced by the `<` prefix.**

### 1.2 Degeneracy audit — `step → ∞` and `step → 0`

The descriptor carries `scale_bits: Q` (raw IEEE-754 bits, presumably). Two failure modes:

**(a) `step → ∞` (`|step| ≥ 10^10`).** If `scale = step` is stored verbatim and downstream kernels compute `W = (step/scale)·B`, then `step/scale = 1` exactly — *provided* `scale` is bit-identical to `step`. But if `scale` is computed as `step * (1 + ε)` for any ε, catastrophic cancellation in `step - scale` yields relative error `ε·step/|step-scale|`. **Recommendation:** store `scale` as the *exact* bit pattern of `step` (which the `Q` field permits), and require downstream kernels to assert `scale_bits == step_bits` before division.

**(b) `step → 0` (subnormal).** If `step` is subnormal (e.g., `2^-1074`), then `step/scale` underflows to 0 if `scale` is normal, or produces a subnormal quotient with **≤ 1 bit of precision**. The Woodbury solve `(M/scale) W = (step/scale) B` then loses all rank information. **Recommendation:** the orchestrator must reject `|step| < 2^-1000` (well above the subnormal threshold `2^-1022`) with a hard `E_DEGENERATE_STEP` error, or promote to a scaled representation `(step, exponent)` pair.

### 1.3 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe:** must not branch on vendor string alone. Require capability bits (AVX-512 F/BW/VL, AMX, SVE2, `sm_90a`, `gfx942`). Vendor-string dispatch is a **Rule 27 violation** (see §7).
- **Slab allocator:** 88-byte descriptors are *not* cache-line aligned (64 B). Two descriptors share a 128-B line, causing false sharing if two threads mutate adjacent descriptors. **Recommendation:** pad to 128 B in the slab, keep 88 B on the wire. This preserves Rule 22 (wire format) while fixing the cache pathology.

### 1.4 12/12 physical conformance checks

Without the check list we can only state the *necessary* conditions: magic, version, byte-count, alignment, endianness, scale-bits finiteness, rank ≤ min(n_rows, n_cols), stride ≥ n_cols, dtype ∈ {FP32, FP64, BF16, FP8}, reserved-zero, checksum. **Any check that reads `reserved` as anything other than zero is a forward-compat hazard.**

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant:
```
s = x[0]*y[0]; c = 0
for i in 1..n-1:
    t = s + x[i]*y[i]
    if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
    else:                  c += (x[i]*y[i] - t) + s
    s = t
return s + c
```
**Error bound (Neumaier 1974):** `|result - exact| ≤ (2u + O(nu²)) · Σ|x_i y_i|`, where `u = 2^-53` for FP64. This is **not** the Kahan bound (`2u + O(nu²)` on `Σ|x_i y_i|` too, but Kahan fails when `|s| < |x_i y_i|`). Neumaier is the correct choice for AVX-512 because the branch is data-dependent and **must be masked**, not branched, to avoid SIMD divergence.

**Adversarial case:** if `x[i]*y[i]` overflows to `+inf` and `s` is finite, then `t = inf`, `s - t = -inf`, `c += -inf + inf = NaN`. **Recommendation:** pre-scale inputs by `2^-⌈log2(max|x|·max|y|)⌉` when `max|x|·max|y| > 2^900`.

### 2.2 Subnormal audits at `-12, -14`

These are almost certainly **exponent thresholds** (i.e., `2^-12`, `2^-14` relative to some reference). Two interpretations:

- **Interpretation A (flush-to-zero):** values below `2^-12` (FP32) or `2^-14` (FP16) are flushed. This is **non-conformant with IEEE-754** unless the user explicitly opts in. AVX-512 `FTZ`/`DAZ` bits in `MXCSR` must be *cleared* for a "subnormal audit" to be meaningful.
- **Interpretation B (audit thresholds):** the kernel *counts* subnormals below these thresholds and reports them. This is the defensible reading.

**Recommendation:** the audit must record `(count_subnormal, count_zero, count_inf, count_nan)` per tile, and the orchestrator must reject tiles where `count_subnormal / n > 10^-3` (heuristic) unless the caller sets `ALLOW_SUBNORMAL`.

### 2.3 Zero-copy PMTP validation

Zero-copy requires:
1. The 88-byte descriptor is **POD** and **trivially copyable** (`static_assert(std::is_trivially_copyable_v<PmtpDescriptor>)`).
2. The data pointer is **not** dereferenced across a trust boundary without a length check.
3. **TOCTOU:** if the descriptor is validated, then the pointer is used, an attacker can swap the descriptor between check and use. **Recommendation:** copy the 88 bytes into a stack-local `alignas(64)` struct, validate the copy, then use the copy's pointer. This is the only TOCTOU-safe pattern.

### 2.4 OpenMP + AVX-512

`#pragma omp parallel for` over rows with `collapse(2)` is fine, but **`schedule(static)` is mandatory** for deterministic reduction order. `schedule(dynamic)` makes Neumaier sums non-reproducible. **Rule 22 implication:** if two agents exchange partial sums, non-determinism breaks bit-exact inter-agent agreement.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the single most important claim in the entire audit.** Rust's default `panic = unwind` is **not** an FFI safety barrier — it is a **UB generator** if a panic crosses an `extern "C"` boundary. The correct pattern is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(desc: *const PmtpDescriptor) -> i32 {
    let result = std::panic::catch_unwind(|| {
        // ... kernel body ...
    });
    match result {
        Ok(v) => v,
        Err(_) => -1, // E_PANIC
    }
}
```

**Without `catch_unwind`, `panic = unwind` across FFI is undefined behavior** (Rust Reference, "Behavior considered undefined"). The claim "panic=unwind FFI safety barrier" is **only true if every `extern "C"` function wraps its body in `catch_unwind`**. The Tribunal demands proof of this pattern in the source.

**Alternative:** `panic = abort` is *safe* across FFI (no unwinding), but loses the ability to recover. For a kernel that must not crash the host, `catch_unwind` + `panic = unwind` is correct — *if and only if* the wrap is present.

### 3.2 Safe SIMD

Rust 2021 stable does not expose AVX-512 intrinsics without `#![feature(stdarch_x86_avx512)]` (nightly) or `std::simd` (nightly). If the kernel claims "Safe SIMD" on stable, it is either:
- Using `core::arch::x86_64::*` inside `unsafe` blocks (not "safe"), or
- Using `wide`/`simba` crates (portable, but not AVX-512-specific).

**Recommendation:** the claim must be restated as "safe *interface*, unsafe *implementation*" with a documented `unsafe` audit.

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` gives 88 bytes but **unaligned field access is UB** for references. Use `#[repr(C)]` with explicit `[u8; 6]` padding and `#[repr(align(1))]` on the outer struct, or use `zerocopy::FromBytes`. **Never** take `&desc.field` on a packed struct.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in `R^(2K × 2K)`

The Cayley retraction on the Stiefel manifold `St(n, p) = {Y ∈ R^{n×p} : YᵀY = I_p}` is:
```
Y(α) = (I - (α/2) A)^{-