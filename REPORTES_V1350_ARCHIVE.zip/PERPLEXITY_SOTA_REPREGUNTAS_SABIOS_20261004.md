# 🚀 CONSULTA DIALÉCTICA SOTA PERPLEXITY (TIEMPO 1, TIEMPO 2 Y PASO 6)
**Fecha:** 2026-10-04 09:31:04
**Motor:** Perplexity Sonar-Pro (API Paga)
**Protocolo:** `polydim-virtual-hardening-loop` (Pasos 4, 5 y 6)

---



================================================================================
# 🚀 TEMA SOTA: Householder Parallel Transport Antipodal Singularity & SOTA Alternatives at D >= 10^5
================================================================================
### ⏱️ TIEMPO 1: ASYMPTOTIC D >= 10^5 RESEARCH (Latencia: 28.01s)

For \(y=-x\) on \(S^{D-1}\), **no single-valued “parallel transport from \(x\) to \(y\)” exists without choosing a geodesic**: infinitely many minimizing great-circle geodesics connect antipodal points. Consequently, the denominator \(1+\langle x,y\rangle\) is not merely a numerical nuisance—it reflects a genuine geometric nonuniqueness. Among the listed methods, the best \(O(D)\) solution is to **supply an explicit tangent direction \(u\perp x\)**, define the chosen great circle, and transport by a Householder/reflection or equivalent rank-2 rotation. This avoids the antipodal breakdown, but cannot provide a geodesic-independent answer.

## 1. Exact transport on a chosen great circle

Let \(x\in S^{D-1}\), choose a unit vector \(u\in T_xS^{D-1}\) with

\[
u^\top x=0,\qquad \|u\|=1,
\]

and define the selected antipodal geodesic

\[
\gamma(t)=\cos(t)x+\sin(t)u,\qquad 0\le t\le \pi.
\]

Then \(\gamma(0)=x\), \(\gamma(\pi)=-x\), and for any \(v\in T_xS^{D-1}\), the exact parallel transport to \(-x\) is

\[
P_{x\to -x}^{(u)}v
=
v-2(u^\top v)u.
\]

Thus transport is the **Householder reflection across the hyperplane orthogonal to \(u\)**:

\[
P_u=I-2uu^\top.
\]

It maps \(T_xS^{D-1}\) to \(T_{-x}S^{D-1}\), preserves norms exactly in exact arithmetic, and costs:

- \(u^\top v\): \(O(D)\),
- rank-one update: \(O(D)\),
- storage: \(O(D)\).

For multiple vectors, applying the same transformation to a \(D\times k\) block costs \(O(Dk)\), with no need to form the dense matrix \(I-2uu^\top\).

The result depends on \(u\). Choosing a different \(u\in T_xS^{D-1}\) gives a different transported vector in general. This dependence is unavoidable at antipodes.

## 2. Comparison of the candidate methods

| Method | Antipodal behavior | Cost for one vector | Accuracy/stability | Assessment |
|---|---:|---:|---|---|
| Householder using \(y-x\) or \(x+y\) | Breaks when \(y=-x\) because the defining vector vanishes | \(O(D)\) | Excellent away from degeneracy; undefined at antipodes | Best generic formula only for non-antipodal pairs |
| Householder using an explicitly chosen \(u\perp x\) | No breakdown | \(O(D)\) | Exact geometrically; backward stable with normalized \(u\) | **Best practical antipodal method** |
| Cayley/Klein rotation | Requires a selected 2-plane or axis at the antipode | \(O(D)\) if implemented as rank-2 action | Stable when the plane is explicitly specified; singular if inferred from \(x,y\) alone | Equivalent in substance to chosen-plane transport |
| Givens 2D embedding | No breakdown if a tangent direction/2-plane is supplied | \(O(D)\) to identify/apply; often \(O(1)\) after sparse-coordinate setup | Very stable; orthogonal 2D rotation | Good implementation primitive, not a way to resolve nonuniqueness |
| Schild’s ladder | Requires midpoint/geodesic constructions; antipodal geodesics are nonunique | At least \(O(D)\) per geometric operation, with larger constants | Approximate; convergence depends on step size and geodesic computations | Unnecessary for the exact sphere case |
| Pole ladder | Exact on Riemannian symmetric spaces when geodesics and midpoints are exact; sphere is such a space | More operations than a direct rank-2 map | Strong theoretical properties, but midpoint/log/exp operations become ambiguous at antipodes | Useful for general manifolds, not optimal here |

### Householder

The common non-antipodal formula uses a reflector based on \(x+y\), for example

\[
H=I-2\frac{(x-y)(x-y)^\top}{\|x-y\|^2},
\]

or equivalent variants depending on the desired endpoint mapping. Such formulas become ill-conditioned or undefined when the relevant vector vanishes. No algebraic rearrangement can remove the underlying ambiguity at \(y=-x\).

The correct remedy is not to replace the denominator with a small constant. Instead:

1. detect near-antipodality;
2. choose or receive a tangent direction \(u\);
3. normalize \(u\);
4. apply \(v\leftarrow v-2u(u^\top v)\).

For floating-point robustness, compute the norm of \(u\) with a scaled norm or a stable BLAS norm, and reorthogonalize \(u\) against \(x\) if it was generated numerically.

### Cayley–Klein rotations

A Cayley transform represents an orthogonal transformation through a skew-symmetric generator. In the relevant two-dimensional plane, the antipodal transport is simply a rotation by \(\pi\), or equivalently a reflection on the tangent component. However, constructing that plane from \(x\) and \(y\) alone fails at \(y=-x\), because \(x\) and \(y\) span only one line.

Therefore Cayley/Klein methods do not remove the degeneracy. They are stable once an additional tangent vector or oriented 2-plane is specified, but then they are computationally equivalent to applying a rank-2 orthogonal transformation. For one transported vector, they generally offer no advantage over the Householder form.

### Givens rotations

A Givens implementation can rotate the selected plane \(\operatorname{span}\{x,u\}\). At \(t=\pi\),

\[
x\mapsto -x,\qquad u\mapsto -u,
\]

while all components orthogonal to that plane remain unchanged. On tangent vectors this produces the same transport map

\[
v\mapsto v-2(u^\top v)u.
\]

Givens rotations are attractive when the selected direction is sparse or when the computation is already organized as a sequence of coordinate-plane rotations. They have excellent local numerical behavior, but they still require an externally selected \(u\). They solve numerical implementation, not geometric nonuniqueness.

### Schild’s ladder and pole ladder

Schild’s ladder approximates parallel transport through geodesic parallelograms. Its convergence has been studied as a function of the number of rungs, with quadratic convergence available under suitable assumptions.[1] Pole ladder is a related construction that is cheaper when transporting several vectors and is exact on Riemannian symmetric spaces when geodesics and midpoints are computed exactly.[4][5]

The unit sphere is a Riemannian symmetric space, so pole ladder has particularly strong theoretical behavior away from cut-locus ambiguities. However, at antipodal endpoints, the required logarithm/geodesic choice and midpoint constructions are themselves nonunique. Consequently:

- pole ladder does not supply a canonical antipodal transport;
- it may inherit the same ambiguity through the chosen geodesic;
- it performs substantially more work than the direct rank-2 formula;
- it is valuable mainly when the manifold is general and closed-form transport is unavailable.

The literature describes pole ladder as exact in symmetric spaces and quadratically convergent more generally, while Schild’s ladder is an approximation whose accuracy depends on discretization.[4][5][8]

## 3. Absolute forward stability

“Absolute forward stability” needs to be separated into two meanings.

### Stability for a fixed chosen geodesic

Once \(u\) is specified and normalized, the map

\[
P_u=I-2uu^\top
\]

is orthogonal. In exact arithmetic,

\[
\|P_uv\|=\|v\|.
\]

Its floating-point implementation uses one dot product and one rank-one update. Standard floating-point error is \(O(\varepsilon D)\) in a straightforward implementation, with improved constants using pairwise or compensated dot products. The map is well-conditioned: perturbations in \(v\) are not amplified by the orthogonal transformation.

This is the strongest stability available for the chosen geodesic.

### Stability with respect to the endpoint pair alone

No method can be absolutely forward stable as a function of \((x,y)\) at \(y=-x\), because the mathematical transport map is not single-valued there. An arbitrarily small perturbation of \(y\) can select different limiting great circles and hence different transport operators.

Thus the correct statement is:

> **Householder transport with an explicit tangent-direction tie-break is forward stable for the selected geodesic, but no endpoint-only algorithm can be continuous and single-valued at antipodal pairs.**

## 4. Recommended \(O(D)\) algorithm

Given \(x\), \(y=-x\), and \(v\in T_xS^{D-1}\):

```text
Input: x, v, and an auxiliary nonzero vector a
Require: ||x|| ≈ 1, xᵀv ≈ 0

1. u ← a − x (xᵀa)
2. u ← u / ||u||
3. optionally: u ← u − x (xᵀu); normalize again
4. α ← uᵀv
5. w ← v − 2 α u
6. return w
```

The auxiliary vector \(a\) must not be nearly parallel to \(x\). For deterministic behavior in very high dimensions, choose the coordinate basis vector least aligned with \(x\), then project it:

\[
j=\arg\min_i |x_i|,\qquad
u=\frac{e_j-x_jx}{\|e_j-x_jx\|}.
\]

This selection costs \(O(D)\), and the complete transport remains \(O(D)\). If a prescribed geodesic direction is available from the application, use it instead; that is preferable to an arbitrary tie-break.

For \(y\) only *near* \(-x\), use a threshold such as

\[
1+x^\top y \le \tau
\]

and switch to a supplied or deterministic \(u\). The threshold should be chosen relative to machine precision, dimension, and the desired error tolerance rather than as a universal constant.

## 5. Final ranking

For \(D\ge 10^5\), one vector, and a known or selectable antipodal geodesic:

1. **Explicit-direction Householder:** lowest practical cost, \(O(D)\), minimal memory, orthogonal and forward stable.
2. **Givens 2D embedding:** equally valid and stable, especially for sparse or structured implementations; usually no mathematical advantage.
3. **Cayley/Klein rotation:** stable after a 2-plane is supplied, but generally more algebra than necessary.
4. **Pole ladder:** theoretically exact on the sphere under exact constructions, but computationally excessive and still dependent on a geodesic choice at the cut locus.
5. **Schild’s ladder:** approximate and more expensive; not competitive with the closed-form sphere transport.

The key qualification is unavoidable: **there is no antipodal algorithm that is simultaneously endpoint-only, single-valued, continuous, and geometrically exact.** The optimal SOTA-style design is therefore an \(O(D)\) direct orthogonal transport with an explicit geodesic-selection policy, not a singularity-free formula based solely on \(x\) and \(y\).

**Citas:** https://arxiv.org/pdf/2007.07585v1, https://en.wikipedia.org/wiki/Schild's_ladder, https://inria.hal.science/hal-00870489/file/Lorenzi-PoleLadder2013.pdf, https://juliamanifolds.github.io/ManifoldsBase.jl/stable/vector_transports/, http://arxiv.org/pdf/2103.04611

### ⏱️ TIEMPO 2: STRICT SILICON RESTRICTIONS & MEMORY LAYOUT (Latencia: 31.40s)

For unit vectors \(x,y\in S^{D-1}\), the **minimal parallel transport** of a tangent vector \(v\in T_xS^{D-1}\) to \(T_yS^{D-1}\) can be implemented with **\(O(1)\) auxiliary storage** and one streaming pass over the coordinates. For the non-antipodal case,

\[
c=x^\top y,\qquad \alpha=\frac{v^\top y}{1+c},
\]

and

\[
\boxed{\operatorname{PT}_{x\to y}(v)=v-\alpha(x+y)}.
\]

This formula is exact in real arithmetic, preserves tangentness and norm, and avoids constructing any \(D\times D\) matrix.

## Mathematical derivation

The geodesic from \(x\) to \(y\), for \(x\neq -y\), lies in the two-dimensional plane spanned by \(x\) and \(y\). Let

\[
u=\frac{y-cx}{\sqrt{1-c^2}},\qquad \theta=\arccos(c),
\]

so that

\[
y=\cos\theta\,x+\sin\theta\,u.
\]

Parallel transport leaves unchanged the component of \(v\) orthogonal to both \(x\) and \(y\). Its component in the geodesic plane is transported by the corresponding planar rotation. Decompose

\[
v=a\,u+w,\qquad w\perp x,\;w\perp y.
\]

Since \(v\perp x\),

\[
v^\top y=a\sin\theta,
\]

and therefore

\[
a=\frac{v^\top y}{\sin\theta}.
\]

After transport, the \(u\)-component becomes

\[
a(-\sin\theta\,x+\cos\theta\,u).
\]

Substituting \(u=(y-cx)/\sin\theta\) and simplifying gives

\[
\operatorname{PT}_{x\to y}(v)
=v-\frac{v^\top y}{1+x^\top y}(x+y).
\]

The denominator becomes zero at the antipode, where the minimizing geodesic is not unique and parallel transport is therefore not uniquely determined without an additional convention.

## Proof of tangentness

Define

\[
z=v-\frac{v^\top y}{1+c}(x+y).
\]

Then

\[
y^\top z
= y^\top v-\frac{v^\top y}{1+c}(y^\top x+y^\top y).
\]

Because \(y^\top x=c\) and \(y^\top y=1\),

\[
y^\top z
=v^\top y-\frac{v^\top y}{1+c}(c+1)=0.
\]

Thus \(z\in T_yS^{D-1}\).

## Proof of norm preservation

Write \(a=(v^\top y)/(1+c)\). Since \(v^\top x=0\),

\[
\|z\|^2
=\|v-a(x+y)\|^2
=\|v\|^2-2a\,v^\top y+a^2\|x+y\|^2.
\]

Now

\[
\|x+y\|^2=2(1+c),
\]

and \(a(1+c)=v^\top y\). Hence

\[
\|z\|^2
=\|v\|^2-2\frac{(v^\top y)^2}{1+c}
+2\frac{(v^\top y)^2}{1+c}
=\|v\|^2.
\]

The transport is therefore an isometry.

## Antipodal handling

Use the requested branch criterion

\[
|1+c|<10^{-12}.
\]

This must be evaluated using the computed dot product, preferably in a numerically stable accumulation format. At the antipode, the result is mathematically underdetermined: there are infinitely many minimizing geodesics from \(x\) to \(-x\), and each can yield a different transport map.

A deterministic convention is required. Options include:

- **Reject the operation** and return an error/status code.
- **Require an externally supplied transport direction** \(q\), with
  \[
  q^\top x=0,\qquad \|q\|=1,
  \]
  and transport along the chosen great circle.
- **Choose a deterministic coordinate axis** \(e_k\) least aligned with \(x\), then project and normalize:
  \[
  q=\frac{e_k-(e_k^\top x)x}
  {\|e_k-(e_k^\top x)x\|}.
  \]

The last choice is deterministic but introduces a coordinate-dependent discontinuity when the selected axis changes. It is not equivalent to a continuous extension of the non-antipodal formula, because no such unique extension exists.

For \(y=-x\), transport along \(q\) can be represented by the Householder-like map

\[
z=v-2(v^\top q)q.
\]

This preserves norm and produces a vector tangent at \(-x\), because \(v,q\perp x\). It corresponds to a \(180^\circ\) rotation in the plane selected by \(q\), while leaving the orthogonal tangent subspace unchanged.

## One-pass, zero-allocation implementation

The non-antipodal computation requires:

1. \(c=x^\top y\),
2. \(b=v^\top y\),
3. the output update
   \[
   z_i=v_i-\frac{b}{1+c}(x_i+y_i).
   \]

If \(x\), \(y\), and \(v\) are already available as caller-owned arrays, the implementation needs only scalar temporaries. There is no need to store \(x+y\), a projection vector, or a transport matrix.

A practical implementation uses two passes:

- **Pass 1:** accumulate \(x^\top y\) and \(v^\top y\).
- **Pass 2:** write the result in place or into a caller-provided output buffer.

This is \(O(D)\) time and \(O(1)\) auxiliary memory. A single pass is possible only if the output can be delayed or if the required scalar coefficient is known beforehand; otherwise the coefficient depends on the complete reduction.

For \(D=10^6\), the arrays themselves necessarily occupy \(O(D)\) storage. “Zero dynamic allocations” therefore means no allocations inside the operation—not that the input, output, or caller-owned buffers disappear.

## SIMD layout and alignment

For `float32`:

- AVX2 processes 8 values per vector.
- AVX-512 processes 16 values per vector.
- A 64-byte cache line contains 16 `float32` values.
- A 128-byte boundary contains 32 `float32` values.

Use a structure-of-arrays layout with contiguous, unit-stride buffers:

```text
x[0 .. D)
y[0 .. D)
v[0 .. D)
out[0 .. D)
```

Do not use an array of per-coordinate structs; that prevents efficient streaming loads and wastes bandwidth.

A 128-byte alignment request is reasonable for a conservative ABI or for isolating separately owned buffers, but it is not itself a cache-line size guarantee. On common x86 systems, cache lines are generally 64 bytes; the relevant guarantee is that independently modified regions do not share a cache line. If thread-level false sharing is possible, place each thread’s mutable state in a separately aligned and padded object whose stride is at least the platform’s destructive-interference size.

For a single-threaded streaming kernel, cache-line isolation between `x`, `y`, `v`, and `out` is usually not beneficial: the operation is bandwidth-bound, and all arrays are intentionally read or written together. Isolation matters primarily when different threads write adjacent regions or when independent control/state variables are modified concurrently.

Use:

```cpp
#include <cstddef>
#include <cstdlib>
#include <new>

struct alignas(128) AlignedBlock {
    float* data;
};
```

However, `alignas(128)` on a pointer object does not align the pointed-to allocation. The allocation itself must be aligned, for example with `std::aligned_alloc`, a platform allocator, or a custom allocator. The size passed to `std::aligned_alloc` must be a multiple of the requested alignment.

In C++20, a safer abstraction is a caller-owned aligned span:

```cpp
struct FloatSpan {
    const float* ptr;
    std::size_t n;
};
```

Validate at the API boundary that:

- pointers are non-null,
- lengths match,
- pointers satisfy the required alignment,
- ranges do not overlap in an unsupported way,
- \(D\) is handled correctly when it is not a multiple of the SIMD width.

## C++20 AVX-512 kernel

The following sketch uses AVX-512 single-precision FMA. It assumes:

- `x`, `y`, and `v` are 64-byte aligned,
- `out` is 64-byte aligned,
- \(D\) is known,
- the inputs are valid unit/tangent data within the desired numerical tolerance.

```cpp
#include <immintrin.h>
#include <cmath>
#include <cstddef>
#include <cstdint>

struct PTResult {
    bool antipodal;
    bool valid;
};

PTResult parallel_transport_avx512(
    const float* __restrict x,
    const float* __restrict y,
    const float* __restrict v,
    float* __restrict out,
    std::size_t D)
{
    __m512 sum_xy = _mm512_setzero_ps();
    __m512 sum_vy = _mm512_setzero_ps();

    std::size_t i = 0;

    for (; i + 16 <= D; i += 16) {
        const __m512 X = _mm512_load_ps(x + i);
        const __m512 Y = _mm512_load_ps(y + i);
        const __m512 V = _mm512_load_ps(v + i);

        sum_xy = _mm512_fmadd_ps(X, Y, sum_xy);
        sum_vy = _mm512_fmadd_ps(V, Y, sum_vy);
    }

    alignas(64) float tx[16];
    alignas(64) float tv[16];

    _mm512_store_ps(tx, sum_xy);
    _mm512_store_ps(tv, sum_vy);

    float c = 0.0f;
    float b = 0.0f;

    for (int k = 0; k < 16; ++k) {
        c += tx[k];
        b += tv[k];
    }

    for (; i < D; ++i) {
        c = std::fma(x[i], y[i], c);
        b = std::fma(v[i], y[i], b);
    }

    const double cd = static_cast<double>(c);
    const double bd = static_cast<double>(b);

    if (std::abs(1.0 + cd) < 1.0e-12) {
        return {true, false};
    }

    const float a = static_cast<float>(bd / (1.0 + cd));

    i = 0;
    for (; i + 16 <= D; i += 16) {
        const __m512 X = _mm512_load_ps(x + i);
        const __m512 Y = _mm512_load_ps(y + i);
        const __m512 V = _mm512_load_ps(v + i);

        const __m512 S = _mm512_add_ps(X, Y);
        const __m512 Z = _mm512_fnmadd_ps(_mm512_set1_ps(a), S, V);

        _mm512_store_ps(out + i, Z);
    }

    for (; i < D; ++i) {
        out[i] = std::fma(-a, x[i] + y[i], v[i]);
    }

    return {false, true};
}
```

Important engineering points:

- `_mm512_load_ps` and `_mm512_store_ps` require suitable alignment. Use unaligned variants if the API cannot guarantee it.
- The reduction shown is fast but not maximally reproducible. Different vector widths, thread partitions, or compiler reassociation can change the last bits.
- For higher accuracy, accumulate partial products in `double`, use compensated summation, or use a fixed reduction tree. That increases cost and may reduce SIMD throughput.
- The \(10^{-12}\) antipodal threshold is much smaller than ordinary `float32` resolution around \(1\). If the threshold is a contractual requirement, compute the dot product and branch criterion in `double`, preferably from `double` inputs or a compensated accumulation. A `float32` dot product alone cannot reliably resolve every distinction at that scale.

## AVX2 variant

The same algorithm applies with eight-lane vectors:

```cpp
__m256 sum_xy = _mm256_setzero_ps();
__m256 sum_vy = _mm256_setzero_ps();

for (std::size_t i = 0; i + 8 <= D; i += 8) {
    __m256 X = _mm256_load_ps(x + i);
    __m256 Y = _mm256_load_ps(y + i);
    __m256 V = _mm256_load_ps(v + i);

    sum_xy = _mm256_fmadd_ps(X, Y, sum_xy);
    sum_vy = _mm256_fmadd_ps(V, Y, sum_vy);
}
```

The output update is

```cpp
__m256 S = _mm256_add_ps(X, Y);
__m256 Z = _mm256_fnmadd_ps(_mm256_set1_ps(a), S, V);
```

Use a scalar tail or masked operations for the remaining coordinates.

## Rust `cdylib` interface

Expose a C-compatible function with caller-owned buffers and a status code. Avoid returning heap-owned objects across the ABI.

```rust
#[repr(C)]
pub struct PtStatus {
    pub code: i32, // 0 success, 1 antipodal, 2 invalid input
}

#[no_mangle]
pub extern "C" fn parallel_transport_f32(
    x: *const f32,
    y: *const f32,
    v: *const f32,
    out: *mut f32,
    d: usize,
) -> PtStatus {
    if x.is_null() || y.is_null() || v.is_null() || out.is_null() {
        return PtStatus { code: 2 };
    }

    // SAFETY: caller guarantees valid, non-overlapping buffers of length d.
    let x = unsafe { core::slice::from_raw_parts(x, d) };
    let y = unsafe { core::slice::from_raw_parts(y, d) };
    let v = unsafe { core::slice::from_raw_parts(v, d) };
    let out = unsafe { core::slice::from_raw_parts_mut(out as *mut f32, d) };

    let mut c = 0.0f64;
    let mut b = 0.0f64;

    for i in 0..d {
        c += (x[i] as f64) * (y[i] as f64);
        b += (v[i] as f64) * (y[i] as f64);
    }

    if (1.0 + c).abs() < 1.0e-12 {
        return PtStatus { code: 1 };
    }

    let a = b / (1.0 + c);

    for i in 0..d {
        out[i] = (v[i] as f64 - a * ((x[i] as f64) + (y[i] as f64))) as f32;
    }

    PtStatus { code: 0 }
}
```

For SIMD Rust builds, select the target features explicitly:

```rust
#[target_feature(enable = "avx2,fma")]
unsafe fn kernel_avx2(/* ... */) {
    // AVX2 implementation
}
```

or:

```rust
#[target_feature(enable = "avx512f,fma")]
unsafe fn kernel_avx512(/* ... */) {
    // AVX-512 implementation
}
```

Runtime feature detection is required if the library must run on machines with differing instruction sets. Do not unconditionally execute AVX-512 from a generic entry point.

## Subnormals, FTZ, and DAZ

On Intel x86, FTZ and DAZ are controlled through `MXCSR`. FTZ replaces subnormal results with zero, while DAZ treats subnormal inputs as zero.[1] Intel documents that enabling these modes can accelerate SSE and AVX computations involving denormals.[1]

This creates a numerical-policy choice:

- **Strict IEEE-like behavior:** leave FTZ/DAZ disabled and preserve subnormals.
- **Throughput-oriented behavior:** enable FTZ/DAZ, accepting that tiny inputs and results become zero.

For this transport formula, FTZ/DAZ can alter:

- the dot products \(x^\top y\) and \(v^\top y\),
- the coefficient \(a\),
- individual output coordinates,
- the antipodal classification near the threshold.

Therefore, if “exact antipodal branch” means exact agreement with a reference implementation, FTZ/DAZ must be fixed and documented. They must not be silently changed by one library call and restored inconsistently across threads.

A scoped MXCSR policy is preferable:

```cpp
#include <immintrin.h>

class MxcsrScope {
    unsigned old_;

public:
    explicit MxcsrScope(bool flush_subnormals) : old_(_mm_getcsr()) {
        unsigned now = old_;

        if (flush_subnormals) {
            now |= (1u << 15); // FTZ
            now |= (1u << 6);  // DAZ
        } else {
            now &= ~(1u << 15);
            now &= ~(1u << 6);
        }

        _mm_setcsr(now);
    }

    ~MxcsrScope() {
        _mm_setcsr(old_);
    }
};
```

The setting is thread-local processor state, so every worker thread must establish the policy independently

**Citas:** https://www.intel.com/content/www/us/en/docs/fortran-compiler/developer-guide-reference/2025-2/set-the-ftz-and-daz-flags.html, https://builders.intel.com/docs/networkbuilders/intel-avx-512-fp16-instruction-set-for-intel-xeon-processor-based-products-technology-guide-1710148129.pdf, https://www.intel.com/content/www/us/en/docs/fortran-compiler/developer-guide-reference/2023-1/set-the-ftz-and-daz-flags.html, https://www.intel.com/content/www/us/en/docs/dpcpp-cpp-compiler/developer-guide-reference/2025-1/set-the-ftz-and-daz-flags.html, https://builders.intel.com/docs/networkbuilders/intel-avx-512-fp16-instruction-set-for-intel-xeon-processor-based-products-technology-guide-1651874188.pdf

### 🔬 PASO 6: REPREGUNTA DE PROFUNDIZACION SOTA (Latencia: 26.10s)

Para el caso antipodal \(y=-x\), la mejora científica clave no es “estabilizar” el término \(1+x^\top y\), sino **especificar la curva**. La unicidad y la isometría exacta se obtienen eligiendo \(u\in T_xS^{D-1}\), \(\|u\|=1\), y usando la geodésica \(\gamma(t)=\cos t\,x+\sin t\,u\). La traslación paralela resultante es

\[
\mathcal P_u(v)=v-2u(u^\top v),
\]

es decir, una reflexión de Householder aplicada únicamente al subespacio tangente.

## 1. Formulación riemanniana exacta

En la esfera unidad,

\[
T_xS^{D-1}=\{v\in\mathbb R^D:x^\top v=0\},
\]

y la geodésica seleccionada entre \(x\) y \(-x\) es

\[
\gamma(t)=\cos(t)x+\sin(t)u,\qquad t\in[0,\pi].
\]

Su velocidad es

\[
\dot\gamma(t)=-\sin(t)x+\cos(t)u.
\]

Para \(v\in T_xS^{D-1}\), descompóngase

\[
v=(u^\top v)u+v_\perp,
\]

donde \(v_\perp\perp x\) y \(v_\perp\perp u\). El campo paralelo a lo largo de \(\gamma\) es

\[
V(t)=(u^\top v)\dot\gamma(t)+v_\perp.
\]

En efecto, \(V(t)\in T_{\gamma(t)}S^{D-1}\), tiene norma constante y satisface la ecuación de paralelismo

\[
\nabla_{\dot\gamma(t)}V(t)=0.
\]

En \(t=\pi\),

\[
\dot\gamma(\pi)=-u,
\]

por lo que

\[
V(\pi)=-(u^\top v)u+v_\perp
      =v-2(u^\top v)u.
\]

Así,

\[
\boxed{\mathcal P_u=I-2uu^\top}.
\]

Esta expresión coincide con la traslación paralela de Levi-Civita a lo largo de la geodésica elegida, no simplemente con un transporte tangente arbitrario.

## 2. Isometría exacta

Para \(v,w\in T_xS^{D-1}\),

\[
\mathcal P_u(v)^\top\mathcal P_u(w)
=
v^\top w.
\]

La razón algebraica es

\[
\mathcal P_u^\top=\mathcal P_u,\qquad
\mathcal P_u^2=I.
\]

Por tanto,

\[
\|\mathcal P_u(v)\|_2=\|v\|_2
\]

en aritmética exacta. Además,

\[
(-x)^\top\mathcal P_u(v)
=
-x^\top\bigl(v-2u(u^\top v)\bigr)=0,
\]

de modo que el resultado pertenece exactamente al espacio tangente en \(-x\).

La literatura de optimización riemanniana caracteriza la traslación paralela como una isometría inducida por la conexión de Levi-Civita.[2] Para una subvariedad euclídea, como la esfera, el transporte puede describirse mediante la eliminación infinitesimal de la componente normal, que conduce a la ecuación anterior.[1]

## 3. Relación con la fórmula no antipodal

Si \(y\neq -x\), sea

\[
c=x^\top y,\qquad
s=\sqrt{1-c^2},\qquad
u=\frac{y-cx}{s}.
\]

Entonces \(u\perp x\), \(\|u\|=1\), y \(y=\cos\theta\,x+\sin\theta\,u\), con

\[
\cos\theta=c,\qquad \sin\theta=s.
\]

La traslación paralela a lo largo de la geodésica mínima puede escribirse como

\[
\mathcal P_{x\to y}(v)
=
v-\frac{u^\top v}{1+c}(x+y).
\]

Equivalentemente,

\[
\boxed{
\mathcal P_{x\to y}(v)
=
v-\frac{(y-cx)^\top v}{1+c}(x+y)
}
\]

porque \(y-cx=su\) y \(x+y=(1+c)x+su\).

Esta fórmula es válida cuando \(c\neq-1\). En el límite antipodal, \(c\to-1\), tanto \(u\) como la geodésica dejan de estar determinados por \(x\) e \(y\) solamente. La singularidad no puede eliminarse mediante aritmética de punto flotante sin introducir información geométrica adicional.

## 4. Formulación como rotación de rango dos

La misma operación puede expresarse como una rotación en el plano \(\operatorname{span}\{x,u\}\), dejando fijo su complemento:

\[
R(t)
=
I+(\cos t-1)(xx^\top+uu^\top)
+\sin t(ux^\top-xu^\top).
\]

Esta matriz satisface

\[
R(t)x=\gamma(t),\qquad R(t)u=\dot\gamma(t),
\]

y \(R(t)z=z\) para todo \(z\perp x,u\). En \(t=\pi\),

\[
R(\pi)=I-2xx^\top-2uu^\top.
\]

Para \(v\perp x\),

\[
R(\pi)v=v-2u(u^\top v),
\]

por lo que la restricción de \(R(\pi)\) al espacio tangente coincide con \(\mathcal P_u\). Esta representación es útil cuando se desea transportar simultáneamente el punto y varios vectores.

## 5. Implementación numéricamente robusta

No debe formarse la matriz densa \(I-2uu^\top\). Para un vector:

```text
alpha = dot(u, v)
w = v - 2 * alpha * u
```

Para un bloque \(V\in\mathbb R^{D\times k}\):

```text
a = uᵀ V
W = V - 2 u a
```

Los costes son

\[
O(D)\quad\text{para un vector},\qquad
O(Dk)\quad\text{para un bloque},
\]

con almacenamiento adicional \(O(D)\) para \(u\), aparte del almacenamiento de los vectores transportados.

Para mejorar la estabilidad:

- Normalizar \(u\) una sola vez con una rutina estable de norma euclídea.
- Verificar o corregir la ortogonalidad mediante
  \[
  u\leftarrow u-x(x^\top u),\qquad
  u\leftarrow u/\|u\|.
  \]
- Si \(v\) debería ser tangente pero contiene ruido numérico, proyectar antes:
  \[
  v\leftarrow v-x(x^\top v).
  \]
- Usar acumulación de producto escalar de alta precisión o FMA cuando esté disponible.
- No renormalizar automáticamente \(w\) si se pretende medir la calidad isométrica: la renormalización puede ocultar errores del transporte.

## 6. Qué significa realmente “error de isometría \(10^{-16}\)”

En aritmética IEEE-754 de doble precisión, \(\varepsilon_{\mathrm{mach}}\approx2.22\times10^{-16}\). No puede garantizarse un error absoluto uniforme de exactamente \(10^{-16}\) para dimensiones arbitrarias y datos mal condicionados: el producto escalar y la resta tienen errores dependientes de \(D\), del escalamiento y de la cancelación.

Una cota práctica para el transporte implementado es

\[
\frac{\bigl|\|\widehat w\|_2^2-\|v\|_2^2\bigr|}
{\max(1,\|v\|_2^2)}
=
O(D\varepsilon_{\mathrm{mach}})
\]

en el peor caso ingenuo, aunque puede acercarse a unos pocos ulps con BLAS optimizado, FMA y datos bien escalados.

Para evaluar correctamente:

\[
E_{\mathrm{norm}}
=
\frac{\left|\|\widehat w\|_2-\|v\|_2\right|}
{\max(1,\|v\|_2)},
\]

y para dos vectores:

\[
E_{\mathrm{ip}}
=
\frac{
|\widehat w^\top\widehat z-v^\top z|
}{
\max(1,|v^\top z|)
}.
\]

La propiedad geométrica exacta es

\[
\mathcal P_u^\top\mathcal P_u=I,
\]

mientras que una implementación de punto flotante solo puede satisfacerla aproximadamente:

\[
\widehat{\mathcal P}_u^\top\widehat{\mathcal P}_u
=
I+O(\varepsilon_{\mathrm{mach}}).
\]

## 7. Elección estable de \(u\)

Si \(u\) es un dato externo, debe comprobarse:

\[
|x^\top u|\le \tau_{\perp},\qquad
\left|\|u\|_2-1\right|\le\tau_{\mathrm{norm}}.
\]

Si hay que construirlo, una opción robusta es seleccionar un vector canónico \(e_j\) poco alineado con \(x\):

\[
j=\arg\min_i |x_i|,
\]

y proyectarlo:

\[
\widetilde u=e_j-x(x^\top e_j),\qquad
u=\frac{\widetilde u}{\|\widetilde u\|}.
\]

Esto evita que la proyección sea casi nula. La elección es determinista, pero introduce una convención; otra elección produce otra geodésica y, por tanto, otro transporte válido.

## 8. Distinción entre transporte paralelo y vector transport

Absil et al. introducen el concepto más general de **vector transport**, asociado a una retracción, para evitar la necesidad de calcular siempre la conexión exacta.[3] Un vector transport puede no ser una isometría. Para algoritmos como gradiente conjugado riemanniano, esto puede ser suficiente, pero no debe confundirse con la traslación paralela exacta.

En el caso antipodal de la esfera:

- **Traslación paralela exacta:** requiere escoger \(u\) y usa \(I-2uu^\top\).
- **Transporte por proyección:** puede ser barato, pero no es generalmente isométrico.
- **Transporte por una retracción:** puede ser válido algorítmicamente, pero solo aproxima el transporte paralelo.
- **Transporte geodésico independiente del camino:** no existe en \(y=-x\), porque el camino no está determinado.

La formulación SOTA, por tanto, es parametrizar explícitamente el transporte como

\[
\boxed{
\mathcal P(x,-x;u)\,v
=
v-2u(u^\top v),
\quad
u^\top x=0,\quad
\|u\|=1
}
\]

y tratar \(u\) como parte de la entrada geométrica, no como un detalle numérico. Esto proporciona el coste óptimo \(O(D)\), una isometría exacta en aritmética real y un error de implementación limitado esencialmente a redondeos de nivel máquina.

**Citas:** https://math.mit.edu/~edelman/publications/geometry_of_algorithms.pdf, http://assets.press.princeton.edu/chapters/absil/Absil_Chap5.pdf, https://perso.uclouvain.be/pa.absil/Talks/ICIAM070717_oom_05.pdf, https://www.math.fsu.edu/~gallivan/talks/iccopt2010.pdf, https://perso.uclouvain.be/pa.absil/Grenoble2008/OOM_slides_beamer03_nonotesnooverl.pdf



================================================================================
# 🚀 TEMA SOTA: Subnormal-Immune Spherical Metric and Fast Unit Projections at D >= 10^6
================================================================================
### ⏱️ TIEMPO 1: ASYMPTOTIC D >= 10^5 RESEARCH (Latencia: 22.49s)

For \(D\ge 10^6\), the safest default is **scaled sum-of-squares**—the algorithm used by LAPACK’s `dnrm2`—rather than a raw SIMD sum of \(v_i^2\). It avoids both overflow and underflow in the squaring step, including when every component is subnormal. Compensated summation improves rounding accuracy, but by itself does **not** prevent underflow or overflow.

## Recommended projection

Define

\[
r=\|v\|_2,\qquad
\pi(v)=\frac{v}{r+\varepsilon}.
\]

A robust implementation should:

1. Reject or separately handle non-finite input.
2. Compute \(r\) with a scaled norm.
3. Use a denominator policy that cannot become zero.
4. Avoid assuming that \(r\le 10^{-15}\) is numerically invalid: it is representable in binary64 and should normally produce a finite result.

For finite \(v\) and \(\varepsilon>0\), the denominator is finite and strictly positive unless the addition itself overflows. If \(\varepsilon\) is ordinary—for example \(10^{-12}\) or \(10^{-15}\)—overflow is not a concern.

## Why naïve reductions fail

The direct computation

\[
\sqrt{\sum_i v_i^2}
\]

is unsafe:

- \(v_i^2\) can overflow even when the final norm is finite.
- \(v_i^2\) can underflow to zero for small normal or subnormal \(v_i\).
- A large partial sum can become `Inf`; later operations can produce `NaN`.
- A vector of \(10^6\) values near \(10^{-308}\) has a norm around \(10^{-305}\), although every individual square underflows in binary64.
- SIMD reassociation changes rounding and can make results non-reproducible.

The LAPACK/Blue approach instead represents the norm as

\[
r=s\sqrt{q},
\]

where \(s\) is a scale, usually the largest absolute component, and

\[
q=\sum_i \left(\frac{|v_i|}{s}\right)^2.
\]

Every normalized magnitude is in \([0,1]\), so the squares cannot overflow. The result is formed only once, after accumulation.

LAPACK documents `dnrm2` as computing \(\sqrt{x^Tx}\), and its implementation is specifically designed to guard against underflow and overflow.[2][4] Blue’s algorithm similarly uses scaling and multiple accumulation regions to preserve accuracy across the floating-point range.[1]

## Comparison of the main techniques

| Technique | Overflow/underflow protection | Accuracy | SIMD suitability | Recommendation |
|---|---:|---:|---:|---|
| Raw \(\sum v_i^2\) | Poor | Poor to moderate | Excellent | Do not use as the primary norm |
| Pairwise SIMD reduction | No intrinsic range protection | Better than linear summation | Excellent | Use only after scaling |
| Neumaier compensation | Improves summation error | High | Moderate | Useful inside scaled accumulation |
| `TwoSum` / double-double accumulation | Very high summation accuracy | Very high | Lower unless specialized hardware exists | Use when reproducibility or ulp-level accuracy matters |
| Blue’s algorithm | Strong range protection | High | Moderate | Robust scalar/reference implementation |
| LAPACK-style scaled `dnrm2` | Strong range protection | High | Good with careful vectorization | Best general-purpose baseline |
| Fast SIMD raw reduction | Weak range protection | Variable | Excellent | Acceptable only with explicit scaling and finite checks |

`TwoSum` and Neumaier compensation address **roundoff in addition**. They do not stop \(v_i^2\) from underflowing or overflowing. Therefore, the correct ordering is:

\[
\text{scale first} \;\rightarrow\; \text{square normalized values} \;\rightarrow\; \text{compensate if needed}.
\]

IEEE 754-2019 also standardizes augmented operations related to `TwoSum`/`TwoProduct`, which can support higher-precision and reproducible reductions where available.[7]

## Robust scaled algorithm

A practical binary64 algorithm is:

```text
scale = 0
ssq   = 1
comp  = 0

for x in v:
    ax = abs(x)

    if x is NaN:
        return NaN

    if x is +Inf or -Inf:
        return +Inf

    if ax != 0:
        if scale < ax:
            t = scale / ax
            ssq = 1 + ssq * t * t
            scale = ax
        else:
            t = ax / scale
            y = t * t - comp
            z = ssq + y
            comp = (z - ssq) - y
            ssq = z

return scale * sqrt(ssq)
```

For a simpler and usually adequate version, omit `comp`:

```text
scale = 0
ssq = 1

for x in v:
    ax = abs(x)

    if isnan(x):
        return NaN
    if isinf(x):
        return +Inf

    if ax != 0:
        if scale < ax:
            ssq = 1 + ssq * (scale / ax) * (scale / ax)
            scale = ax
        else:
            t = ax / scale
            ssq += t * t

if scale == 0:
    norm = 0
else:
    norm = scale * sqrt(ssq)
```

The exact initialization and update ordering should be implemented carefully; production LAPACK code is preferable to reimplementing all edge cases.

For \(D=10^6\), a fully compensated accumulator is often unnecessary unless the application requires reproducibility or very small relative error. A good performance design is:

- vectorized scan for `max(abs(v))`;
- vectorized accumulation of \((v_i/s)^2\);
- pairwise tree reduction;
- optional Neumaier compensation per SIMD lane or per block;
- scalar combination of block results.

If strict reproducibility is required, use deterministic block sizes and a fixed reduction tree. Parallel reductions otherwise produce different answers depending on thread scheduling.

## Handling subnormal values

Subnormal values such as \(10^{-308}\) are not inherently dangerous for a scaled norm. If

\[
s=\max_i |v_i|\approx 10^{-308},
\]

then

\[
|v_i|/s
\]

is approximately order one, so the squaring occurs in a safe range. The final multiplication \(s\sqrt{q}\) remains around \(10^{-305}\) for \(10^6\) similar values and is representable as a subnormal or normal binary64 number, depending on the result.

The important caveat is hardware configured with **flush-to-zero (FTZ)** or **denormals-are-zero (DAZ)**. On such systems, input subnormals may be treated as zero, and no arithmetic algorithm can recover information that the hardware has discarded. IEEE-compatible handling is therefore required when subnormal preservation matters. A BLAS/LAPACK numerical-exception discussion explicitly notes that platforms may not implement subnormals and that direct squaring can underflow even when the norm itself is nonzero.[6]

Recommended policy:

- Disable FTZ/DAZ for correctness-sensitive norm computation.
- If FTZ/DAZ must remain enabled, document that sufficiently small inputs are intentionally quantized to zero.
- Do not “fix” subnormals by adding an arbitrary floor to every element; that changes the vector and can dominate the norm.

## Preventing NaN and Inf propagation

“Completely prevent” propagation is possible only by defining behavior for non-finite inputs. There are two distinct cases.

### Finite input

For finite \(v\), a scaled norm should return a finite norm unless the mathematically correct norm exceeds the target format’s maximum. In binary64, if individual entries are finite but the true norm exceeds approximately \(1.8\times 10^{308}\), the result must overflow to `Inf`.

The projection can avoid an invalid \(0/0\) operation with:

```text
if norm == 0:
    return zero_vector
denom = norm + eps
return v / denom
```

If \(\varepsilon>0\), the zero-vector result is mathematically zero. Alternatively, explicitly return zeros when `norm <= threshold`.

### NaN or Inf input

You must choose a policy:

- **Strict IEEE policy:** return NaN if any input is NaN; return a vector containing NaN if the norm is infinite and the corresponding operation is undefined.
- **Sanitizing policy:** map non-finite elements to zero or reject the vector and return an error/status.
- **Robust-service policy:** validate the input first and never call the projection on invalid data.

Silently replacing NaNs or infinities with zero hides data corruption and is generally inappropriate for scientific or optimization code.

A safe API should return both a value and a status:

```text
enum NormStatus {
    OK,
    ZERO_NORM,
    NAN_INPUT,
    INF_INPUT,
    OVERFLOW
}
```

## Choosing \(\varepsilon\)

A fixed \(\varepsilon=10^{-15}\) is much larger than the smallest binary64 normal and is safe as a denominator regularizer. However, its meaning depends on the scale of \(v\):

- If \(\|v\|_2\gg\varepsilon\), the projection is approximately unit length.
- If \(\|v\|_2\ll\varepsilon\), the output magnitude is approximately \(\|v\|_2/\varepsilon\), not one.
- If exact unit output is required for every nonzero vector, use a branch:
  \[
  \pi(v)=
  \begin{cases}
  0,& r=0,\\
  v/r,& r>0.
  \end{cases}
  \]
  This still requires a policy for underflow and non-finite inputs.

For numerical robustness, avoid computing a denominator with a potentially underflowing or invalid expression such as `norm + eps` when `eps` itself may be zero or subnormal. Validate:

```text
if !(eps > 0) or !isfinite(eps):
    error
```

## Practical SOTA recommendation for \(D\ge 10^6\)

Use a **two-pass, block-parallel scaled norm**:

1. First pass: deterministic maximum of absolute values.
2. Second pass: SIMD computation of \((v_i/s)^2\).
3. Accumulate each block with pairwise reduction; use Neumaier compensation if accuracy is important.
4. Combine block sums deterministically.
5. Compute \(r=s\sqrt{q}\).
6. Check finiteness and apply an explicit zero/small-norm policy.
7. Perform the projection only after validation.

This provides most of the speed of SIMD reductions while retaining the range safety of Blue/LAPACK scaling. Use `TwoSum` or double-double arithmetic only when the application requires reproducibility, tight error bounds, or accumulation across exceptionally adverse dynamic ranges; it is not a substitute for scaling.

The principal limitation is hardware behavior: if the processor or runtime flushes subnormals to zero, exact preservation of \(10^{-308}\)-scale components is impossible without changing the execution environment or emulating the arithmetic.

**Citas:** https://kar.kent.ac.uk/67205/1/remark.pdf, https://gensoft.pasteur.fr/docs/lapack/3.9.0/de/da4/group__double__blas__level1_ga4b25c539b862414e6f91ebb30b391d7c.html, https://www.allisone.co.jp/note/mathematics/numerical-analysis/basic/overflow-underflow.html, https://www.netlib.org/lapack/explore-html/d1/d2a/group__nrm2_gab5393665c8f0e7d5de9bd1dd2ff0d9d0.html, https://jonathanschilling.github.io/L-BFGS-B/md_docs_spec_04_numerics.html

### ⏱️ TIEMPO 2: STRICT SILICON RESTRICTIONS & MEMORY LAYOUT (Latencia: 24.51s)

`-O3 -ffast-math` can enable reassociation, horizontal-reduction vectorization, reciprocal/approximate transformations, and assumptions that NaNs, infinities, signed-zero distinctions, and often subnormals are irrelevant. Consequently, it can improve throughput substantially but can invalidate the error guarantees of compensated summation and alter behavior near a zero norm.[2][12][14]

## Interaction with FTZ/DAZ

- **FTZ (flush-to-zero)** converts underflowed results to zero.
- **DAZ (denormals-are-zero)** treats subnormal input operands as zero.
- On x86 these modes are controlled through the floating-point control state, generally affecting the thread rather than an individual arithmetic instruction.[12]
- Fast-math configurations may enable or assume FTZ/DAZ; Clang documents an explicit `-mdaz-ftz` option for setting both modes.[14]

For a norm computation,

\[
s = \sum_i x_i^2,\qquad n=\sqrt{s},
\]

FTZ/DAZ can change \(s\), \(n\), and the classification of a vector as “zero norm” when values are sufficiently small. A mathematically nonzero vector may therefore enter the fallback path. This is not merely a performance detail: it changes the numerical result and potentially the selected basis vector.

If preserving gradual underflow matters, compile the sensitive kernel without fast-math assumptions and explicitly control the floating-point environment. Conversely, if inputs are scaled and subnormal values are outside the accepted domain, FTZ/DAZ can be a reasonable throughput choice—but it must be part of the kernel’s documented numerical contract.

## Compensated summation and auto-vectorization

Kahan or Neumaier summation depends on a specific sequence of operations and on preserving the compensation term. Fast-math permits the compiler to treat floating-point operations as associative and to reorder them; this can:

- reassociate additions;
- combine or eliminate compensation updates;
- vectorize the reduction using several partial sums;
- contract multiply-add operations;
- assume no NaNs or infinities.

Thus, a source-level Kahan loop compiled under unrestricted `-ffast-math` is **not evidence that Kahan summation remains intact**. The resulting code may be faster, but its error behavior can approach an ordinary vectorized reduction.[12][14]

For a compensated reduction, use a constrained compilation region, for example:

- disable reassociation and contraction for the reduction;
- use explicit SIMD lanes followed by a controlled scalar or pairwise reduction;
- inspect generated assembly;
- test against a high-precision reference over normal, subnormal, near-cancellation, and zero-input cases.

GCC specifically identifies `-ffast-math` as an enabler for floating-point reduction vectorization.[2]

A practical split is:

1. vectorize the independent products or partial sums;
2. keep compensation in separate lanes;
3. reduce those lanes with a specified order;
4. compile that reduction under strict floating-point semantics.

This preserves more control than applying `-ffast-math` to the entire function.

## `VREDUCEPD` versus norm reduction

`VREDUCEPD` is generally **not the instruction expected for summing a norm**. It performs per-lane floating-point reduction of each value by removing an integer or fractional component according to an immediate control field; it is primarily useful for argument reduction in functions such as trigonometric, exponential, or power implementations.[1][7][8]

A norm kernel normally requires:

```asm
vmulpd      zmm..., zmm..., zmm...       ; x*x
vaddpd      zmm_sum, zmm_sum, zmm...     ; vector accumulation
; horizontal reduction, or store/secondary reduction
vsqrtpd     zmm_norm, zmm_sum
```

With FMA enabled, the product and accumulation commonly appear as:

```asm
vfmadd231pd zmm_sum, zmm_x, zmm_x
```

The exact operand ordering is assembler-dependent, but semantically this performs:

\[
\text{sum} \leftarrow \text{sum} + x \cdot x.
\]

A `VREDUCEPD` appearing in the generated code would normally indicate some separate range-reduction operation, not a replacement for the sum of squares.

## Expected zero-norm fallback pattern

For a normalized vector \(u=x/\|x\|\) with a fallback basis vector \(e_k\) when the norm is zero, a robust AVX-512 implementation should:

1. compute the norm;
2. compare it with zero or with a chosen threshold;
3. create a mask;
4. compute the normal result only for valid lanes;
5. merge the fallback value for invalid lanes.

Conceptually:

```cpp
norm2 = dot(x, x);
valid = norm2 > threshold;        // threshold may be exactly zero
inv = rsqrt_or_divide(norm2);     // masked or otherwise protected
u = x * inv;
u = blend(valid, u, basis);
```

A representative *shape* of assembly is:

```asm
vfmadd231pd  zmm_acc, zmm_x, zmm_x    ; accumulate x*x
...
vaddpd       zmm_norm2, ...
vsqrtpd      zmm_norm, zmm_norm2
vcmppd       k1, zmm_norm2, zmm_zero, ... ; validity mask
vdivpd       zmm_u, zmm_x, zmm_norm
vmovapd      zmm_basis, ...
vmovapd      zmm_u{k1}, zmm_basis       ; merge fallback where mask is false
```

Depending on mask polarity, the final instruction may instead be written as a masked move of the computed result into lanes selected by `k1`. The essential verified property is not the mnemonic spelling but the dataflow:

- no unmasked divide by zero is allowed to produce an observable invalid result;
- the fallback is selected exactly for zero or invalid norm lanes;
- the mask is derived from the same precision and FTZ/DAZ policy used by the norm computation.

A more defensive form masks the divide itself:

```asm
vdivpd       zmm_u {k1}{z}, zmm_x, zmm_norm
vmovapd      zmm_u {~k1}, zmm_basis
```

The `{z}` form prevents inactive lanes from retaining stale values. If the fallback is a single basis vector rather than one basis vector per lane, it can be loaded or broadcast once. If each input vector has its own fallback index, the basis construction may require masked blends or permutes.

## What should be verified in assembly

For C++20 or Rust, verify the compiler output under the exact target flags, because `-O3 -ffast-math` alone does not guarantee AVX-512. Typical requirements include a target such as `-march=...` or an explicit AVX-512 feature set.

Check for:

- `vfmadd231pd` or equivalent FMA instructions in the sum-of-squares loop;
- `vaddpd` or another valid reduction sequence;
- `vsqrtpd`, reciprocal-square-root approximation plus refinement, or division;
- `vcmppd`/`vcmpsd` producing a mask;
- masked moves, masked arithmetic, or blends implementing the fallback;
- absence of an unconditional divide whose zero result is later merely ignored;
- no unexpected scalarization in the hot loop;
- no `vreducepd` unless the algorithm genuinely needs argument reduction.

The compiler is free to use `vfmadd132pd`, `vfmadd213pd`, or `vfmadd231pd`; these differ in operand encoding, not in the fundamental fused multiply-add operation. Likewise, horizontal reduction may use extracts, permutations, `vaddpd`, or scalar reductions depending on the compiler and target microarchitecture.

## Recommended numerical policy

For a high-throughput \(D=10^7\) kernel, separate **performance policy** from **accuracy policy**:

- Use AVX-512 and FMA for the ordinary path.
- Decide explicitly whether subnormal preservation is required.
- Do not combine unrestricted fast-math with a claim of strict Kahan/Neumaier guarantees.
- Use a nonzero threshold if “effectively zero” is preferable to an exact-zero test.
- Compile and inspect the norm/fallback routine separately from any compensated reduction.
- Validate outputs under both FTZ/DAZ enabled and disabled if deployment environments can differ.

The key correction is that `VFMADD` is directly relevant to the norm accumulation, whereas `VREDUCEPD` is an argument-reduction instruction and should not be expected in a standard spherical-projection normalization kernel.[1][7][8]

**Citas:** https://builders.intel.com/docs/networkbuilders/intel-avx-512-fp16-instruction-set-for-intel-xeon-processor-based-products-technology-guide-1710148129.pdf, https://gcc.gnu.org/projects/tree-ssa/vectorization.html, https://builders.intel.com/docs/networkbuilders/intel-avx-512-instruction-set-for-packet-processing-technology-guide-1645717553.pdf, https://builders.intel.com/docs/networkbuilders/intel-avx-512-instruction-set-for-packet-processing-technology-guide-1617440657.pdf, https://www.intel.com/content/www/us/en/developer/articles/technical/intel-avx-512-instructions.html

### 🔬 PASO 6: REPREGUNTA DE PROFUNDIZACION SOTA (Latencia: 25.10s)

La mejora SOTA no consiste en elegir simplemente entre “IEEE estricto” y `fast-math`, sino en **separar la corrección numérica crítica del resto del pipeline**. Para una proyección \(L_2\) en dimensión muy alta, la política recomendada es: norma escalada y manejo explícito de excepciones en la frontera numérica; vectorización y operaciones relajadas únicamente en regiones donde se haya demostrado que no alteran invariantes relevantes.

## 1. Qué significa realmente “cumplimiento IEEE 754-2019”

IEEE 754-2019 no exige que todas las expresiones de un programa produzcan un único resultado bit a bit bajo cualquier compilador. El cumplimiento depende de respetar, entre otros aspectos:

- formato y redondeo especificados;
- propagación de `NaN` e infinitos;
- ceros con signo;
- excepciones y banderas de estado;
- operaciones y modos de redondeo aplicables;
- ausencia de transformaciones algebraicas no permitidas.

Por tanto, estas transformaciones pueden cambiar la semántica observable:

\[
(a+b)+c \ne a+(b+c),
\]

\[
\frac{x}{y} \ne x\cdot \frac{1}{y},
\]

y, en general, el reordenamiento de una reducción. LLVM identifica explícitamente `reassoc` como una transformación que puede cambiar de forma importante el resultado, mientras que `contract` permite fusionar multiplicación y suma en FMA.[14][5]

Además, `fast-math` suele habilitar supuestos como:

- ausencia de `NaN` e infinitos;
- ignorar ceros con signo;
- reciprocales aproximadas;
- contracción FMA;
- reassociación;
- aproximación de funciones matemáticas.

Los compiladores documentan estos efectos como optimizaciones que pueden cambiar el resultado numérico.[6][9]

**Consecuencia:** `fast-math` no es una versión “más rápida de IEEE”; es un contrato distinto, válido sólo si el algoritmo y sus datos toleran esas relajaciones.

## 2. Algoritmo recomendado para la norma

Para entradas finitas, una implementación robusta debe usar una variante escalada:

\[
m=\max_i |v_i|.
\]

Si \(m=0\), entonces \(r=0\). En otro caso:

\[
r=m\sqrt{\sum_i \left(\frac{v_i}{m}\right)^2}.
\]

El escalado mantiene los cuadrados normalizados en \([0,1]\), evitando el desbordamiento intermedio. Esta es la idea empleada por `dnrm2` de LAPACK.[4][8]

Una implementación de mayor calidad puede mantener un estado \((s,q)\), donde \(s\) es la escala actual y \(q\) la suma escalada:

```text
scale = 0
sumsq = 1

for x in v:
    a = abs(x)
    if a == 0:
        continue
    if scale < a:
        t = scale / a
        sumsq = 1 + sumsq * t * t
        scale = a
    else:
        t = a / scale
        sumsq += t * t

r = scale * sqrt(sumsq)
```

Debe tratarse el vector cero por separado; de lo contrario, la inicialización requiere cuidado. Para máxima robustez también puede utilizarse una variante de tres rangos —pequeño, medio y grande— con acumuladores escalados independientes. Este enfoque se ha estudiado para cómputo vectorizado y recursivo de normas de Frobenius.[10]

### Mejora importante para subnormales

La afirmación “el escalado evita siempre el underflow” requiere una precisión: evita el underflow catastrófico de los cuadrados cuando el cociente \(a/m\) es representable y la aritmética conserva subnormales, pero una plataforma con **flush-to-zero** puede convertir esos cocientes o productos pequeños en cero.

Por ello, en modo IEEE estricto:

- desactivar FTZ/DAZ;
- conservar subnormales;
- no asumir que `x*x` es seguro aunque `x` sea finito;
- probar explícitamente entradas subnormales.

En modo de rendimiento, FTZ/DAZ puede ser aceptable para entrenamiento si se ha comprobado que las magnitudes subnormales no contienen señal útil. No debe usarse sin más para inferencia reproducible, validación científica o cálculo de métricas.

## 3. Suma compensada: útil, pero no suficiente

La suma de cuadrados puede mejorar su error de redondeo mediante:

- suma de Neumaier o Kahan;
- reducción por pares;
- árboles de reducción balanceados;
- acumulación en mayor precisión;
- acumuladores supercalares con combinación final exacta o reproducible.

Sin embargo, la compensación **no corrige** un cuadrado que ya se convirtió en `0`, `Inf` o `NaN`. El orden correcto es:

1. proteger el rango dinámico mediante escalado;
2. elegir una reducción numéricamente estable;
3. aplicar compensación o acumulación de precisión extendida si se necesita más exactitud.

Para una reducción paralela, la suma por pares suele ser preferible a una suma lineal porque reduce el crecimiento típico del error y se adapta mejor a SIMD/GPU. No obstante, sigue sin ser bitwise reproducible si el árbol cambia entre ejecuciones.

## 4. Reproducibilidad frente a velocidad

Hay tres niveles prácticos de garantía:

| Nivel | Política | Ventaja | Coste |
|---|---|---|---|
| IEEE estricto | Orden fijo, redondeo respetado, subnormales conservados, sin reassociación | Máxima auditabilidad | Menor rendimiento |
| Determinista | Árbol de reducción fijo y kernel estable, con SIMD permitido | Mismo resultado entre ejecuciones compatibles | Requiere controlar hardware y compilador |
| Fast-math | Reasociación, FMA y reciprocales permitidos; posibles FTZ/DAZ | Máximo rendimiento | Resultados dependientes de plataforma y menos garantías |

Una reducción reproducible puede construirse con:

- particionado fijo de elementos;
- árbol fijo de combinación;
- acumuladores por bins o superaccumuladores;
- punto final en precisión suficientemente alta;
- control de FMA y del modo de redondeo.

Las operaciones “augmented” —que devuelven el resultado redondeado y el error residual— se han propuesto precisamente para implementar sumas y productos reproducibles con mayor eficiencia y exactitud.[1]

La reproducibilidad bit a bit entre CPU y GPU, sin embargo, no debe prometerse sólo por fijar el orden lógico: también influyen el soporte de FMA, el tratamiento de subnormales, la precisión interna, las bibliotecas matemáticas y el compilador.

## 5. Política recomendada para la proyección

La expresión

\[
\pi(v)=\frac{v}{r+\varepsilon}
\]

es razonable, pero conviene definir con precisión la semántica de \(\varepsilon\).

### Caso A: \(\varepsilon\) absoluto

\[
d=r+\varepsilon.
\]

Es simple y evita división por cero si \(\varepsilon>0\). Pero introduce una escala artificial: para vectores pequeños, la salida se aproxima a \(v/\varepsilon\), no a una normalización de longitud cercana a uno.

### Caso B: regularización dependiente de escala

Una alternativa:

\[
d=\max(r,\varepsilon)
\]

produce una saturación más directa. Otra opción es una regularización cuadrática:

\[
d=\sqrt{r^2+\varepsilon^2},
\]

aunque \(r^2\) puede ser problemático si se calcula sin protección adicional.

Para evitar cualquier dependencia de una suma potencialmente mal redondeada, puede usarse:

```text
if not all_finite(v):
    reject_or_handle_nonfinite()

r = scaled_norm(v)

if r == 0:
    return zero_policy(v)

denom = r + epsilon
if not isfinite(denom) or denom == 0:
    return denominator_failure_policy(v)

return v / denom
```

Si \(r\) es del orden de \(10^{-15}\), eso no implica invalidez numérica: es perfectamente representable en binary64. El tratamiento debe depender del objetivo de la aplicación, no de un umbral fijo elegido por intuición.

## 6. Qué operaciones pueden relajarse con seguridad

Una estrategia eficaz es aplicar precisión selectiva:

### Mantener estrictas

- cálculo de \(m=\max |v_i|\);
- cambios de escala;
- detección de cero, `NaN` e infinito;
- acumulación de magnitudes extremas;
- decisión de políticas de denominador;
- métricas usadas para validación, ranking o stopping criteria.

### Relajar potencialmente

- transformaciones posteriores a la normalización;
- capas cuyo error ya está dominado por cuantización o ruido estocástico;
- productos matriciales con tolerancia explícita al error;
- rutas de entrenamiento donde se ha establecido un presupuesto de error.

El uso de FMA suele mejorar la precisión local de expresiones como

\[
a\cdot b+c,
\]

pero puede reducir la reproducibilidad frente a una implementación que redondea después de la multiplicación. Por ello, `contract` debe ser una decisión explícita, no un efecto accidental del compilador.[5][6]

## 7. Recomendación SOTA para CPU/GPU

Para una implementación de producción:

1. **Entrada:** validar finitud; decidir si `NaN`/infinito se rechaza, propaga o enmascara.
2. **Norma:** usar `dnrm2` o una implementación equivalente escalada.
3. **Reducción:** usar árbol fijo si se exige determinismo; compensación o acumulación extendida si se exige menor error.
4. **Subnormales:** conservarlas en la ruta estricta; permitir FTZ/DAZ sólo en una ruta fast-math documentada.
5. **Compilación:** desactivar al menos `reassoc`, `no-nans`, `no-infs` y `no-signed-zeros` para el kernel crítico.
6. **Vectorización:** permitir SIMD sólo con un esquema de reducción que mantenga el rango seguro.
7. **Denominador:** especificar la política para \(r=0\), \(r\) subnormal y \(\varepsilon\le 0\).
8. **Validación:** comparar contra una referencia de alta precisión usando vectores extremos, subnormales, ceros, magnitudes mixtas y entradas no finitas.
9. **Contrato de error:** medir error relativo de \(r\), error absoluto de \(\pi(v)\), longitud resultante y estabilidad de rankings o decisiones posteriores.
10. **Dos rutas:** ofrecer un modo `strict/reproducible` y otro `fast/approximate`, sin mezclar sus supuestos.

La solución más equilibrada para IA de alta dimensión suele ser un **kernel híbrido**: norma escalada y determinista en binary64 o acumulación ampliada, seguido de operaciones vectoriales SIMD relajadas donde el presupuesto de error lo permita. Activar `fast-math` para toda la función puede eliminar precisamente las garantías que el escalado y el manejo de extremos intentan preservar.

**Citas:** https://hal.science/hal-02137968v2/document, https://www.allisone.co.jp/note/mathematics/numerical-analysis/basic/overflow-underflow.html, https://lists.llvm.org/pipermail/llvm-dev/2020-January/138652.html, https://www.allisone.co.jp/note/mathematics/numerical-analysis/basic/overflow-underflow_en.html, https://llvm.org/devmtg/2019-04/slides/TechTalk-Berg-LLVM_numerics_improvements.pdf



================================================================================
# 🚀 TEMA SOTA: Stiefel Manifold Optimizers: NorMuon vs Dion vs Cayley-SMW Retractions at D >= 10^6
================================================================================
### ⏱️ TIEMPO 1: ASYMPTOTIC D >= 10^5 RESEARCH (Latencia: 21.33s)

No method in the listed 2024–2026 optimizer family can **guarantee** \(\varepsilon_{\mathrm{iso}}\le 10^{-6}\) on \(\mathrm{St}(D,K)\) without an explicit accuracy-controlled orthogonalization or retraction. **NorMuon, Dion-3, and Moonlight are approximate update-scaling/orthogonalization schemes, not strict Stiefel retractions.** Among the candidates, a **Cayley retraction implemented with Sherman–Morrison–Woodbury (SMW)** is the appropriate choice for a strict isometry guarantee, provided the linear solves and residuals are computed to the required tolerance.

## Comparison

| Method | Main operation | Approximate or exact? | Strict \(\varepsilon_{\mathrm{iso}}\le10^{-6}\) guarantee? | Cost for \(D\gg K\) |
|---|---|---:|---:|---:|
| **NorMuon** | Newton–Schulz polar-like update plus row-wise normalization | Approximate | **No** | Several matrix multiplications; row scaling is cheap |
| **Dion-3** | Distributed/subsampled or amortized orthogonal updates | Approximate | **No, absent an explicit residual-certified correction** | Potentially lowest training overhead, but error depends on approximation |
| **Moonlight** | Newton–Schulz update with \(s(D,K)=\rho\sqrt{\max(D,K)}\) | Approximate | **No** | Similar NS cost; scaling itself is negligible |
| **Cayley + SMW** | Retraction through a skew-symmetric low-rank update | Accuracy-controlled | **Yes, if solved/residual-checked accurately** | Approximately \(O(DK^2+K^3)\) for rank-\(K\) structure |

NorMuon applies row-wise normalization after approximate Newton–Schulz orthogonalization; its purpose is balanced neuron-wise update magnitudes, not preservation of \(X^\top X=I\).[1] Moonlight similarly uses Newton–Schulz orthogonalization with a dimension-dependent scale \(\sqrt{\max(D,K)}\), but this scale controls update magnitude rather than making the iterate exactly Stiefel.[11] Dion-3 is designed around amortized/distributed orthogonal updates and, in reported descriptions, can orthogonalize only a fraction of rows, which makes it unsuitable as a strict manifold retraction without a subsequent correction.[2][13]

## Why the approximate methods cannot certify the constraint

For \(X\in\mathrm{St}(D,K)\), the relevant error is typically

\[
\varepsilon_{\mathrm{iso}}
=
\left\|X^\top X-I_K\right\|_2.
\]

A finite Newton–Schulz iteration produces an approximation to a polar factor. Its residual depends on the input spectrum, iteration count, numerical precision, and stopping rule. A fixed number of iterations—such as the commonly used five-step style associated with Muon/NorMuon implementations—does not imply a uniform \(10^{-6}\) bound over all \(D\), \(K\), momentum spectra, or conditioning regimes.[1][4]

Post-NS row normalization does not repair this: it changes row magnitudes, whereas the Stiefel constraint is a **column Gram-matrix** constraint. Moonlight’s \(\rho\sqrt{\max(D,K)}\) factor likewise changes the step scale, not the orthogonality residual.[11]

Dion-3 may reduce computation through batching, sharding, or subsampling, but those mechanisms make the update less—not more—amenable to a worst-case isometry certificate unless followed by a residual-controlled projection.[2][13]

## Cayley–SMW option

For \(X\in\mathrm{St}(D,K)\) and a tangent-like direction \(A\), form a skew-symmetric operator, for example

\[
\Omega = AX^\top-XA^\top,
\qquad \Omega^\top=-\Omega,
\]

and apply a Cayley transform

\[
Q=(I-\tfrac{\tau}{2}\Omega)^{-1}(I+\tfrac{\tau}{2}\Omega),
\qquad
X_{+}=QX.
\]

In exact arithmetic, \(Q\) is orthogonal, so \(X_+^\top X_+=I_K\). Since \(\Omega\) has rank at most \(2K\), the inverse action can be reduced with Sherman–Morrison–Woodbury to operations involving \(D\times K\) factors and a small \(K\times K\) system. The dominant work is generally

\[
O(DK^2+K^3),
\]

with memory approximately \(O(DK)\), rather than \(O(D^3)\) or a full \(D\times D\) factorization.

The guarantee is conditional on implementation accuracy. In floating-point arithmetic, use:

- a stable small-system solve;
- iterative refinement if needed;
- a residual check such as \(\|X_+^\top X_+-I\|_2\);
- acceptance/retry or correction when the residual exceeds \(10^{-6}\).

Thus, the strict requirement is not guaranteed merely by saying “Cayley”; it is guaranteed by **Cayley–SMW plus tolerance-controlled solves and verification**.

## Practical decision

- **If strict isometry is mandatory:** choose **Cayley–SMW**, with residual certification. It is the lowest-cost option among the listed approaches that can provide a defensible \(10^{-6}\) constraint without a full SVD.
- **If approximate orthogonality is acceptable:** Dion-3 is the likely lowest-overhead candidate because its design emphasizes amortization, distributed batching, and partial/subsampled orthogonalization.[2][13]
- **If using Muon-style optimization with adaptive row magnitudes:** NorMuon is more appropriate than plain Moonlight for update balancing, but neither should be described as a strict Stiefel projection.[1][4]
- **For \(D=10^5\)–\(10^7\), \(K=16\)–\(64\):** avoid full SVD. Use a low-rank Cayley formulation, exploit \(K\ll D\), and certify \(\|X^\top X-I\|_2\le10^{-6}\) after every accepted retraction.

**Citas:** https://huggingface.co/papers/2510.05491, https://paper.dou.ac/p/2608.11612v1, https://ar5iv.labs.arxiv.org/html/2607.16169, https://www.emergentmind.com/topics/normuon-optimizer, https://arxiv.org/pdf/2609.39114

### ⏱️ TIEMPO 2: STRICT SILICON RESTRICTIONS & MEMORY LAYOUT (Latencia: 36.89s)

For \(X\in\mathbb{R}^{D\times K}\), \(D\gg K\), the main design rule is: **keep \(X\), the tangent/update \(U\), and the output in \(O(DK)\) global memory, while treating all \(K\times K\) workspaces as tiled, reused temporaries**. Newton–Schulz is usually the better GPU choice when the retraction is a polar-style orthogonalization; Cayley–SMW is attractive when the update is naturally represented by a low-rank skew-symmetric operator and \(K\) is small.

## 1. Cost and storage comparison

Let \(G=X^{T}X\) or another compact \(K\times K\) Gram matrix.

| Method | Core operation | Arithmetic profile | Temporary storage | Main numerical issue |
|---|---|---:|---:|---|
| **Gram Newton–Schulz** | \(X\leftarrow X\,p(G)\), usually after scaling \(G\) | Several \(K\times K\) products plus \(D\times K\) by \(K\times K\) products per iteration | \(O(K^2)\) compact matrices plus \(O(DK)\) input/output | Requires scaling and sufficient iterations for ill-conditioned \(G\) |
| **Cayley–SMW** | \((I-\alpha A)^{-1}\) applied to \(X\), with \(A\) low rank or structured | Factorization/inversion of a compact \(r\times r\) matrix, where \(r\) is the effective update rank | \(O(r^2)\) compact matrices plus \(O(DK)\) vectors/matrices | More implementation complexity; stability depends on the compact system |

A direct Cayley implementation can require inversion of an \(N\times N\) matrix, whereas Sherman–Morrison–Woodbury reduces this to a compact system. For a rank-\(2M\) skew-symmetric representation, the inverse can be reduced to a \(2M\times2M\) system rather than an ambient \(N\times N\) inverse.[1] Similar Stiefel-manifold constructions reduce a \(2n\times2n\) Cayley inverse to a compact matrix whose dimension depends on the low-rank factor.[13]

### Gram Newton–Schulz

For a polar retraction,

\[
R(X)=X(X^{T}X)^{-1/2}.
\]

Compute

\[
G=X^{T}X,
\]

scale it so that its spectrum lies in a suitable interval, and approximate \(G^{-1/2}\) by Newton–Schulz iterations. A common form is

\[
Y_{j+1}
=\frac12 Y_j(3I-GY_j^2),
\]

with \(Y_0\) chosen from a norm estimate or a simple scalar scaling.

The expensive \(D\)-dependent work is the multiplication by \(X\) and the final application of the compact factor. The iteration itself is only \(K\times K\), so for \(K\) small it is often compute-bound and easy to keep in registers or shared memory.

Advantages:

- Regular matrix-matrix operations.
- High arithmetic intensity.
- Straightforward batching over many independent \(X\) blocks.
- Good fit for Triton tiles, CUDA WMMA, and AVX-512 microkernels.
- No explicit factorization pivoting.

Disadvantages:

- Several iterations may be needed.
- Poor initial scaling can cause slow convergence or overflow.
- The approximate inverse square root may be less accurate than a robust eigendecomposition or QR for badly conditioned inputs.
- Storing multiple Newton–Schulz iterates can unnecessarily increase register pressure.

### Cayley–SMW

A Cayley update is commonly written as

\[
Q=(I-\tfrac{\eta}{2}A)^{-1}(I+\tfrac{\eta}{2}A),
\qquad A^{T}=-A.
\]

Applying \(Q\) to \(X\) requires solving with \(I-\frac{\eta}{2}A\). If

\[
A=UV^{T}-VU^{T},
\]

then the inverse can be expressed through SMW using a compact system whose dimension is proportional to the rank of \(A\). The operation becomes:

1. Form a small matrix \(C\).
2. Factor or solve \(C\).
3. Compute projections such as \(V^{T}X\) and \(U^{T}X\).
4. Apply low-rank corrections to \(X\).

This is particularly attractive when the effective rank \(r\) is much smaller than \(K\), since the \(D\)-dependent work is a small number of tall-skinny matrix products.

Advantages:

- Can preserve orthogonality more directly through a Cayley transform.
- Compact inverse dimension depends on update rank, not ambient \(D\).
- Potentially fewer iterations than Newton–Schulz.
- Useful when the tangent is already stored in low-rank factors.

Disadvantages:

- More synchronization and dependency points.
- Compact solve may require LU/QR or a carefully stabilized symmetric solve.
- If the update rank is comparable to \(K\), SMW loses much of its advantage.
- A generic SMW implementation can require more temporary projections than Newton–Schulz.

## 2. Recommended choice by regime

| Regime | Preferred method |
|---|---|
| \(D\gg K\), moderate conditioning, many independent matrices | **Gram Newton–Schulz** |
| \(K\) small and fixed, e.g. \(K\le 32\) or \(64\) | Either; Newton–Schulz is simpler |
| Effective update rank \(r\ll K\) | **Cayley–SMW** |
| Need a direct orthogonality-preserving update from a skew tangent | **Cayley–SMW** |
| Poorly conditioned \(X^{T}X\) | Stabilized Newton–Schulz, QR, or compact eigensolve |
| Tensor-core-oriented implementation | **Newton–Schulz** |
| Very low-rank sparse/structured tangent | **Cayley–SMW** |

The key crossover is not only \(K\), but the ratio \(r/K\). If \(r\) is close to \(K\), Cayley–SMW still avoids \(D\times D\) work but may not beat a compact Gram iteration. If \(r\ll K\), the low-rank projections can dominate favorably.

## 3. GPU memory layout

Use a row-major logical layout with contiguous \(K\)-vectors:

\[
X[d,k],\qquad U[d,k].
\]

For a warp or Triton program processing a tile \(B_M\times B_K\):

- Make \(k\) the contiguous dimension.
- Load \(X[d:d+B_M,\;0:K]\) coalesced.
- Accumulate \(G=X^{T}X\) in FP32 or higher.
- Keep the compact matrix in registers when \(K^2\) is small enough.
- Otherwise place it in shared memory/LDS and synchronize once per phase.
- Stream the \(D\) dimension in tiles rather than materializing duplicated \(D\times K\) intermediates.

The basic memory target is:

\[
\text{global storage}
=
O(DK) \text{ for inputs/outputs}
+
O(K^2) \text{ for compact factors}.
\]

Avoid materializing:

- \(D\times D\) projectors.
- Batched \(D\times K\times K\) intermediates.
- Separate copies of every Newton–Schulz iterate.
- Full Cayley matrices.
- Expanded SMW correction matrices of shape \(D\times D\).

A two-pass implementation is usually preferable:

1. **Pass 1:** compute \(G=X^{T}X\), or the compact SMW system and required projections.
2. **Compact phase:** solve, factor, or iterate on the \(K\times K\) or \(r\times r\) matrix.
3. **Pass 2:** stream \(X\) again and write the retracted output.

This uses \(O(DK)\) memory while accepting an additional global-memory read. The additional read is often cheaper than storing a large intermediate and reducing occupancy.

## 4. Triton/CUDA strategy

### Newton–Schulz kernel decomposition

A robust implementation is usually split into kernels rather than fusing everything:

1. `gram_kernel`: compute \(G=X^{T}X\).
2. `small_matrix_kernel`: scale and perform Newton–Schulz iterations.
3. `apply_kernel`: compute \(Y=XH\), where \(H\approx G^{-1/2}\).

For very small fixed \(K\), kernels 1 and 2 can be fused, but full fusion is risky. Holding \(X\), \(G\), \(H\), and several intermediate products live simultaneously can create high register pressure.

Use only two compact Newton–Schulz buffers:

\[
Y \leftarrow Y_{\text{new}},
\]

with ping-pong storage. Do not retain all iterates.

A compact update can be organized as:

\[
T=Y^2,\qquad
S=3I-GT,\qquad
Y_{\text{new}}=\tfrac12 YS.
\]

If registers are limited, store \(T\) or \(S\) in shared memory instead of keeping all three compact matrices live. For larger \(K\), use tiled GEMM-like operations rather than one thread owning the entire \(K\times K\) matrix.

### Cayley–SMW kernel decomposition

A practical sequence is:

1. Compute compact quantities such as \(U^{T}U\), \(U^{T}V\), \(V^{T}V\).
2. Build the compact SMW matrix.
3. Factor it once.
4. Stream \(X\), computing \(U^{T}X\), \(V^{T}X\), and the correction.
5. Write the output directly.

Do not store all \(D\times r\) projections unless they are reused by multiple subsequent operations. If each projection is used once, calculate it tile-by-tile and immediately apply the correction.

GPU memory hierarchy guidance is consistent across Triton and CUDA: registers are fastest but smallest, on-chip shared memory/LDS is larger but shared, and global memory is much larger but high latency.[3] Reused data should be staged on-chip, while global-memory loads and stores should be minimized.[3]

### Avoiding register spilling

Register spilling is particularly likely when:

- \(B_M\) or \(B_K\) is too large.
- `num_warps` is excessive.
- Multiple compact matrices are live.
- The pipeline uses many stages.
- A fused kernel contains both reductions and matrix application.

Triton documentation and optimization guidance note that additional pipeline stages can increase register use and cause spills, especially for fused matrix kernels.[2] Register spills may fall back to local memory, which is substantially slower than registers or shared memory.[4]

Practical controls:

- Reduce `BLOCK_SIZE` before increasing warps.
- Tune `num_warps` and `num_stages` independently.
- Use `tl.constexpr` for fixed dimensions and compile-time constants.
- Split reduction, compact solve, and application into separate kernels.
- Keep only the current tile of \(X\) live.
- Avoid storing masks or index tensors unnecessarily.
- Use FP32 accumulators but lower-precision inputs where accuracy permits.
- Inspect generated register count and spill loads/stores rather than relying only on runtime.

A useful optimization objective is not maximum occupancy by itself. A slightly lower occupancy kernel with no spills often outperforms a nominally high-occupancy kernel that repeatedly accesses local memory. GPU SRAM/shared-memory allocation should also be bounded per program; an excessively large tile can reduce the number of resident warps.

On CUDA platforms that support compiler-directed shared-memory register spilling, shared memory can reduce the cost of spills compared with local-memory spills, but it should be treated as a fallback, not as the primary storage strategy.[8] It consumes the same scarce on-chip capacity needed for tiles and can reduce occupancy.

## 5. Shared-memory/SRAM sizing

For a \(B_M\times K\) tile in FP32,

\[
S_X=4B_MK\ \text{bytes}.
\]

If storing two \(K\times K\) compact matrices,

\[
S_{\text{small}}=8K^2\ \text{bytes}.
\]

If storing \(X\), an output tile, and two compact matrices,

\[
S_{\text{tile}}
\approx 8B_MK+8K^2.
\]

For FP16/BF16 inputs with FP32 accumulation, the \(X\) tile can be half as large, but compact factors should generally remain FP32 unless error analysis supports lower precision.

Choose \(B_M\) so that:

- The tile fits comfortably within the per-block shared-memory budget.
- Enough blocks remain resident to hide latency.
- The compact matrix does not force \(X\) out of registers unnecessarily.
- Shared-memory bank conflicts are avoided through padding or a transposed layout.

For \(K\) not divisible by the warp width or vector width, pad the compact matrix to a convenient stride. Padding is usually cheaper than inducing bank conflicts or uncoalesced loads.

## 6. CPU/OpenMP/AVX-512 layout

On CPU, use a blocked \(D\)-major layout:

\[
X[d,k]
\]

with \(k\) contiguous if the dominant operation is \(XH\), or a packed micro-panel layout if repeatedly forming \(X^{T}X\).

The Gram matrix is

\[
G_{ij}=\sum_{d=0}^{D-1}X_{di}X_{dj}.
\]

For AVX-512:

- Vectorize across \(d\) when \(D\) is large.
- Accumulate several \(G_{ij}\) elements in vector registers.
- Use OpenMP over blocks of rows \(d\), followed by a compact reduction.
- Pack \(X\) into panels so each column or small group of columns is contiguous for the chosen microkernel.
- Keep the \(K\times K\) compact matrix in L1 or registers where possible.

A practical CPU sequence is:

1. Parallel blocked Gram computation.
2. Single-threaded or small-team compact \(K\times K\) iteration/factorization.
3. Parallel blocked application \(Y=XH\).

Do not parallelize the tiny compact solve across many threads unless \(K\) or the batch count is large. The compact phase is often latency-sensitive and cache-resident.

For \(D\gg K\), the Gram reduction is bandwidth- and FMA-intensive, while the compact solve is negligible. For many small independent matrices, parallelize across instances first; for one very tall matrix, parallelize across \(D\)-blocks.

## 7. Numerical safeguards

### Newton–Schulz

Before iteration, estimate a scale such as

\[
\alpha \approx \|G\|_2
\]

or use a cheaper norm bound, then iterate on \(G/\alpha\). Rescale the result appropriately. Monitor:

\[
\|I-HGH\|,\qquad
\|Y^{T}Y-I\|.
\]

For mixed precision:

- Form \(G\) in FP32.
- Perform compact iterations in FP32.
- Apply \(H\) using tensor-core or vectorized lower-precision inputs if the resulting orthogonality error is acceptable.
- Use one or two refinement steps if needed.

### Cayley–SMW

Avoid explicitly forming an inverse. Factor the compact matrix and solve against the required right-hand sides. Check for near-singularity as \(\eta\) grows. If the compact system is ill-conditioned, reduce the step size or use a stabilized factorization.

Because Cayley updates are norm-preserving in exact arithmetic for skew-symmetric \(A\), they can have attractive long-run behavior; in finite precision, however, the quality of the compact solve and the low-rank factorization determines the actual orthogonality error.

## 8. Recommended implementation policy

For a general-purpose GPU implementation:

- Use **Gram Newton–Schulz** as the default for \(D\gg K\).
- Use two compact buffers and at most one \(D\times K\) output buffer.
- Split the Gram, compact iteration, and application phases when register pressure is high.
- Autotune \(B_M\), `num_warps`, and `num_stages` against both runtime and spill metrics.
- Keep compact matrices in registers only for small \(K\); otherwise use shared memory.
- Recompute one-use projections rather than storing \(O(DK)\) intermediates.
- Accumulate Gram products and compact iterations in FP32.
- Use **Cayley–SMW** when the tangent is already available as \(U,V\) with \(r\ll K\), or when exact Cayley structure is more important than implementation simplicity.

For CPU:

- Use AVX-512 blocked Gram accumulation.
- Keep \(K\times K\) factors in L1/register-friendly packed form.
- Parallelize the tall dimension and reduce compactly.
- Apply the resulting compact transform in a second streaming pass.
- Prefer Cayley–SMW when low-rank factors substantially reduce the number of \(D\)-scale projections; otherwise Newton–Schulz generally maps more directly to optimized GEMM-like kernels.

[1]  
[2]  
[3]  
[4]  
[8]  
[13]

**Citas:** http://proceedings.mlr.press/v130/likhosherstov21a/likhosherstov21a-supp.pdf, https://gitee.com/HAYPO/triton/wikis/pages/export?doc_id=6440604&type=pdf, https://rocm.docs.amd.com/en/docs-6.1.0/how-to/llm-fine-tuning-optimization/optimizing-triton-kernel.html, https://www.spheron.network/blog/openai-triton-kernel-gpu-cloud-2026/, http://proceedings.mlr.press/v130/likhosherstov21a/likhosherstov21a.pdf

### 🔬 PASO 6: REPREGUNTA DE PROFUNDIZACION SOTA (Latencia: 26.55s)

La mejora SOTA clave es separar **velocidad de convergencia del optimizador**, **estabilidad de la ortogonalización** y **garantía de factibilidad en la variedad de Stiefel**. Gram Newton–Schulz con reinicio \([2,3,2]\) puede mejorar mucho la estabilidad práctica, pero por sí solo no demuestra \(\varepsilon_{\mathrm{iso}}\le 10^{-6}\); para esa garantía hace falta una etapa final certificada —por ejemplo, polar/QR o Cayley con resolución residual controlada—.

## 1. Convergencia de Newton–Schulz y dependencia de \(\kappa(M)\)

Para \(X\in\mathbb R^{D\times K}\), la ortogonalización polar busca

\[
Q=X(X^\top X)^{-1/2},
\qquad Q^\top Q=I.
\]

La iteración Newton–Schulz clásica para la inversa cuadrada del Gram es

\[
Y_{t+1}
=\frac12Y_t(3I-MY_t^2),
\qquad M=X^\top X,
\]

o, en una formulación equivalente sobre \(X\),

\[
X_{t+1}
=\frac12X_t(3I-X_t^\top X_t).
\]

Si el escalado inicial coloca el espectro en la región de convergencia, el error idealmente presenta **convergencia cuadrática**: aproximadamente,

\[
e_{t+1}\lesssim C e_t^2.
\]

La condición suficiente clásica para la versión normalizada es que el error inicial satisfaga

\[
\|I-X_0^\top X_0\|_2<1.
\]

También existen variantes con región espectral ampliada; para ciertas formulaciones hermíticas, la convergencia queda garantizada cuando el radio espectral está por debajo de \(\sqrt 3\).[2][11][13]

El problema práctico es que el escalado requerido depende de

\[
\kappa(M)
=
\frac{\lambda_{\max}(M)}{\lambda_{\min}(M)}
=
\left(\frac{\sigma_{\max}(X)}{\sigma_{\min}(X)}\right)^2.
\]

Cuando \(\kappa(M)\) es grande:

- la singularidad menor se corrige lentamente;
- las componentes asociadas a \(\lambda_{\max}\) pueden sobrepasar la región estable;
- los errores de redondeo y de GEMM se amplifican;
- el número de iteraciones necesario para alcanzar una tolerancia fija deja de ser pequeño.

Por tanto, el número de pasos no debe fijarse solamente como “3, 5 o 6 iteraciones”. Debe depender de una estimación de \(\kappa(M)\), de la norma espectral y del residuo observado.

Una regla práctica es usar una fase de **escalado adaptativo**:

\[
\widehat X_0=\frac{X}{\alpha},
\qquad
\alpha\ge \|X\|_2,
\]

y, si es posible, estimar también \(\sigma_{\min}(X)\). Para matrices muy mal condicionadas, una sola normalización por \(\|X\|_F\) puede ser insuficiente para alcanzar precisión de ingeniería.

## 2. Qué aporta realmente el reinicio Gram NS \([2,3,2]\)

La inestabilidad específica de Gram Newton–Schulz aparece al iterar sobre

\[
R_t=X_tX_t^\top
\]

o sobre el Gram equivalente de dimensión pequeña. En aritmética finita, errores de diagonalización pueden producir autovalores espurios negativos. Tras varias iteraciones, esos autovalores pueden divergir hacia \(-\infty\), mientras que el factor polinómico \(Q_t\) puede crecer descontroladamente.[12]

El esquema de reinicio \([2,3,2]\) debe interpretarse como:

1. ejecutar dos iteraciones;
2. reconstruir el Gram desde el resultado actual;
3. ejecutar tres iteraciones;
4. reiniciar de nuevo;
5. ejecutar dos iteraciones adicionales.

El reinicio no es simplemente una aceleración: actúa como **mecanismo de contención espectral**. Al volver a construir el Gram, se evita que una deriva numérica acumulada permanezca dentro del polinomio durante demasiados pasos.

Los resultados reportados para Gram Newton–Schulz indican que reiniciar después de la segunda iteración mantiene los autovalores espurios de \(R_t\) por encima de aproximadamente \(-0.4\) y la condición de los factores intermedios \(Q_t\) por debajo de aproximadamente \(100\) en los experimentos considerados.[12][15] El mismo patrón identifica el reinicio tras dos pasos como la opción más estable entre varias alternativas probadas.[12][15]

Sin embargo, estos límites son **empíricos o dependientes del esquema concreto**, no un certificado universal de precisión Stiefel. En particular,

\[
\kappa(Q_t)\lesssim 100
\]

no implica

\[
\|X_t^\top X_t-I\|_2\le 10^{-6}.
\]

El reinicio controla el crecimiento patológico, pero no convierte automáticamente el algoritmo en una retraction exacta.

## 3. Mejora científica recomendada: NS adaptativo y certificado

La versión más sólida sería reemplazar el número fijo \([2,3,2]\) por un protocolo híbrido:

### Fase A: escalado espectral

Estimar \(\|X\|_2\) mediante una o varias iteraciones de potencia y definir

\[
X_0=\frac{X}{\alpha},
\qquad
\alpha=(1+\delta)\widehat{\sigma}_{\max}(X),
\]

con \(\delta>0\) como margen de seguridad.

### Fase B: Gram NS con reinicios

Aplicar bloques cortos, preferiblemente de longitud dos, reconstruyendo el Gram en cada reinicio:

\[
G_j=X_j^\top X_j.
\]

Un bloque puede utilizar coeficientes de Newton–Schulz o de Polar Express, pero debe monitorizar:

\[
r_j=\|G_j-I\|_2,
\]

o una cota computable como

\[
r_j\le \|G_j-I\|_F.
\]

Si \(r_j\) aumenta, si aparecen autovalores negativos significativos o si el estimador de \(\kappa(G_j)\) crece, se debe reiniciar inmediatamente o volver a escalar.

### Fase C: parada basada en residuo

No detenerse tras un número fijo de iteraciones. Detenerse solamente si

\[
\|X_t^\top X_t-I\|_2
\le \tau_{\mathrm{iso}},
\]

donde \(\tau_{\mathrm{iso}}\) debe ser mucho menor que \(10^{-6}\), por ejemplo

\[
\tau_{\mathrm{iso}}
\le
\frac{10^{-6}}{c_{\mathrm{backward}}},
\]

con \(c_{\mathrm{backward}}\) una constante que incorpore errores de multiplicación, acumulación y posterior uso del parámetro.

En GPU, conviene evaluar también el residuo en precisión superior —por ejemplo, FP32 para una actualización FP16/BF16—, porque medir el certificado en la misma precisión baja puede ocultar una violación de la tolerancia.

## 4. Relación entre \(\kappa(M)\) y la garantía final

Para el problema \(M=X^\top X\), si

\[
\lambda_{\min}(M)>0,
\]

la estabilidad del cálculo de \(M^{-1/2}\) depende de la separación espectral y de \(\kappa(M)\). Una matriz con \(\kappa(M)\) elevada puede producir una salida visualmente “casi ortogonal” pero con un residuo muy superior a \(10^{-6}\).

En consecuencia, el algoritmo debería registrar al menos:

\[
\widehat{\lambda}_{\min}(M),\qquad
\widehat{\lambda}_{\max}(M),\qquad
\widehat{\kappa}(M),
\qquad
\|X^\top X-I\|_2.
\]

Una política razonable sería:

- si \(\widehat{\kappa}(M)\) es moderada, usar Gram NS con reinicios;
- si \(\widehat{\kappa}(M)\) es alta, aumentar el número de bloques o realizar una corrección polar/QR;
- si \(\widehat{\lambda}_{\min}(M)\) es cercana al umbral numérico, declarar que no existe una garantía fiable de ortogonalización;
- después de la corrección, verificar explícitamente el residuo.

La condición de la matriz no debe confundirse con la condición del problema de optimización. Para la convergencia del entrenamiento, una función suave y fuertemente convexa tiene, en el caso euclídeo, complejidad típica \(O(\kappa)\) para descenso de gradiente y \(O(\sqrt\kappa)\) para métodos acelerados; en problemas sobre Stiefel, estas cotas dependen además de la geometría, la retraction, la curvatura y el transporte.[9] La mejora de la ortogonalización no garantiza por sí misma una tasa acelerada de convergencia del objetivo.

## 5. Cayley + SMW: mejora para una garantía estricta

Para una garantía de isometría, la alternativa más defendible sigue siendo una retraction Cayley. Si \(X^\top X=I\) y \(A^\top=-A\), entonces

\[
Y=(I-A)^{-1}(I+A)X
\]

preserva exactamente la ortogonalidad en aritmética exacta, porque la transformación Cayley es ortogonal.

Cuando \(A\) tiene estructura de bajo rango, la inversión puede reducirse mediante Sherman–Morrison–Woodbury. La forma típica es

\[
Y
=
X+2U(I-Z^\top U)^{-1}Z^\top X,
\]

con \(U,Z\) construidas a partir de \(X\) y del desplazamiento tangente.[9]

La mejora SOTA no debe limitarse a aplicar SMW, porque la fórmula puede deteriorar la factibilidad por inestabilidad numérica.[3] Debe incluir:

- resolución de \((I-Z^\top U)w=Z^\top X\) con pivotado o factorización estable;
- estimación de \(\kappa(I-Z^\top U)\);
- cálculo del residuo lineal
  \[
  r_{\mathrm{lin}}
  =
  (I-Z^\top U)w-Z^\top X;
  \]
- iteración de refinamiento si el residuo excede la tolerancia;
- comprobación posterior
  \[
  \|Y^\top Y-I\|_2\le 10^{-6}.
  \]

Si la comprobación falla, debe ejecutarse una corrección final por QR o polar. Así, SMW se usa como acelerador, no como supuesto certificado.

## 6. Propuesta SOTA combinada

La arquitectura más robusta para \(D\gg K\) sería:

\[
\boxed{
\text{NS Gram con reinicio }[2,3,2]
\;\longrightarrow\;
\text{test de }\kappa(M)
\;\longrightarrow\;
\text{Cayley-SMW}
\;\longrightarrow\;
\text{certificación}
}
\]

Concretamente:

1. aplicar NS Gram en bloques cortos, comenzando por \([2,3,2]\);
2. reconstruir el Gram después de cada bloque;
3. estimar \(\kappa(M)\) y el residuo de ortogonalidad;
4. aceptar la salida NS solo si el residuo certificado es menor que \(10^{-6}\);
5. en caso contrario, aplicar Cayley-SMW con solves residuales;
6. si SMW no alcanza la tolerancia, usar QR/polar como etapa final;
7. no declarar éxito sin verificar \(Y^\top Y-I\).

El coste conserva la ventaja de \(D\gg K\): los productos principales son del orden de \(O(DK^2)\), mientras que los sistemas SMW tienen dimensión proporcional a \(K\) y cuestan aproximadamente \(O(K^3)\). La garantía, no obstante, proviene de la **verificación residual y la corrección final**, no del simple uso de NS, del reinicio \([2,3,2]\) ni de la fórmula SMW.

**Citas:** https://www.emergentmind.com/topics/newton-schulz-iterations, https://webhomes.maths.ed.ac.uk/~dhigham/Publications/P29.pdf, https://www.tandfonline.com/doi/full/10.1080/02331934.2022.2142471, https://www.emergentmind.com/topics/iterative-newton-schulz-orthogonalization, http://proceedings.mlr.press/v130/likhosherstov21a/likhosherstov21a-supp.pdf

