# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 77

The public evidence gathered does **not substantiate a real, publicly documented “POLYDIM V1350,” Cycle 77, six-kernel suite, or the claimed six-model tribunal outputs**. The search results identify PolyDiM as a PDE discretization library, not this architecture, and identify standard RCU/QSBR references but no PMTP descriptor specification.[1][2][3] Therefore, no defensible arbitration can declare the requested “exact architectural guarantees” as established facts.

A mathematically and architecturally sound synthesis would be:

## 1. Cayley–Stiefel retraction under extreme steps

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), \(X^\top X=I\), a Cayley update typically has the form

\[
X_{+}
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)X,
\]

where \(A^\top=-A\) is constructed from the search direction.

- In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists, so it preserves \(X^\top X=I\).
- In floating-point arithmetic, \(|\alpha|\ge 10^{10}\) is **not automatically stable**. Conditioning depends on \(A\), scaling, factorization, precision, and whether the implementation forms \(I\pm \alpha A/2\) explicitly.
- A Cayley formulation is not categorically superior to Householder or polar-QR retraction for extreme steps. Householder products are often backward stable; polar retraction can provide excellent geometric accuracy but may require a stable SVD or Newton–Schulz-style iteration.
- Any claim of unconditional stability for extreme steps is false without bounds on \(\kappa(I-\alpha A/2)\), overflow behavior, residuals, and the chosen arithmetic.

**Definitive guarantee:** the implementation may guarantee only a computed residual such as

\[
\frac{\|X_{+}^{\top}X_{+}-I\|}{u\,\mathrm{poly}(n,p,\|\alpha A\|)}
\le C,
\]

under explicitly stated solver and scaling assumptions. It cannot guarantee exact manifold preservation in finite precision merely from the Cayley formula.

**Recommended kernel policy:** scale the generator, solve rather than invert, use pivoted or rank-revealing factorizations where appropriate, detect non-finite values, and fall back to Householder or polar-QR when the Cayley system becomes ill-conditioned.

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

An 88-byte size has no inherent memory-ordering meaning. Acquire/release semantics arise from the synchronization protocol, not from descriptor layout.

For an immutable snapshot publication pattern:

```cpp
// Writer
new_snapshot->fields = ...;
publish_ptr.store(new_snapshot, std::memory_order_release);

// Reader
auto p = publish_ptr.load(std::memory_order_acquire);
read_snapshot(p);
```

release publication plus acquire consumption can establish visibility of prior initialization for the accessed snapshot. But this alone does **not** guarantee safe reclamation.

A complete RCU/QSBR design needs:

- immutable or versioned snapshots;
- a release publication operation;
- acquire observation by readers;
- reader-side registration and quiescent-state reporting;
- a grace-period mechanism;
- reclamation only after every reader that could have observed the old version has passed through a quiescent state;
- protection against ABA, stale handles, and descriptor reuse.

QSBR specifically relies on readers reporting quiescent states; reclamation is safe only after all relevant readers have done so.[2][3][4] A descriptor containing an acquire or release field does not itself create an RCU grace period.

**Definitive guarantee:** under a correctly implemented C++20 memory model protocol, readers that acquire a published immutable snapshot observe the writer’s prior initialization, and reclamation after a completed grace period does not race with protected readers. The 88-byte representation is merely an ABI/storage constraint.

For CUDA, XLA, and Triton, host-language C++ memory-order terms cannot be transferred automatically to device code. Device publication must use the target backend’s documented atomic, fence, stream, event, or collective semantics. Cross-device visibility additionally requires explicit synchronization and suitable memory scope.

## 3. Multi-silicon conformance

Source-level portability across CUDA, XLA, Triton, C++20, and Rust is not equivalent to semantic conformance. These systems have different execution and memory models:

- C++20 defines the host-language atomic model.
- Rust exposes atomic operations subject to the target platform and compiler guarantees.
- CUDA adds scoped device/system atomics, fences, streams, and unified or separate memory behavior.
- Triton compilation and supported atomic operations depend on backend and target GPU.
- XLA represents operations through an intermediate computation graph and may reorder, fuse, replicate, or lower them differently across devices.

Consequently, the architecture should define a **portable semantic contract**, not promise identical implementation behavior:

1. **Numerical contract:** precision, tolerance, determinism class, NaN/Inf handling, and orthogonality residual limits.
2. **Memory contract:** publication, observation, quiescence, reclamation, and permitted memory scopes.
3. **ABI contract:** exact byte size, alignment, field offsets, endianness, versioning, and padding initialization.
4. **Concurrency contract:** allowed races, ownership, progress guarantees, and failure behavior.
5. **Backend contract:** required lowering primitives and a conformance test for each target.

A valid conformance claim requires executable tests on every supported backend and silicon family. The tests should include:

- \(|\alpha|\) from ordinary values through at least \(10^{10}\);
- ill-conditioned and rank-deficient generators;
- repeated snapshot publication and reclamation;
- delayed readers and adversarial scheduling;
- descriptor alignment and byte-layout checks;
- mixed precision and NaN/Inf cases;
- device-to-host and device-to-device visibility;
- deterministic replay where determinism is promised.

## Arbitration

The strongest defensible SOTA position is therefore:

- **Cayley:** geometrically elegant and potentially stable, but not unconditionally stable for extreme steps; use conditioning-aware fallback logic.
- **Householder/polar-QR:** preferable as robustness baselines unless measured evidence demonstrates a Cayley advantage for the target dimensions, precision, and step distribution.
- **PMTP descriptor:** 88 bytes can be an ABI guarantee, never a memory-barrier guarantee.
- **RCU/QSBR:** acquire/release publication is necessary in the relevant protocol but insufficient without grace-period tracking and safe reclamation.
- **Multi-silicon:** exact semantic conformance is possible only through an explicitly specified contract and backend-specific validation; it cannot be inferred from common source code or descriptor size.

Thus, the requested unconditional claims—extreme-step stability, snapshot isolation from descriptor barriers alone, and automatic conformance across all five execution environments—should be rejected unless the missing V1350 specifications, tribunal reports, formal proofs, and cross-silicon test results are supplied.