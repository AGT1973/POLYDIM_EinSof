# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 121)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 121 · Multi-File Adversarial SOTA Review

**Preliminary note on evidentiary basis.** The audit brief supplies *architectural claims* (file names, descriptor layouts, algorithm names) but no source listings, no test vectors, no CI artifacts, and no numerical traces. Under Tribunal rules, I must therefore (a) audit the *claims as stated*, (b) flag every place where a claim is **unfalsifiable as presented**, and (c) issue **conditional verdicts** with the exact evidence required to upgrade them. I will not fabricate line numbers or invent code I have not seen.

---

## 0. Cross-cutting findings (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Claimed layout: `<4sHHQQQQQBB6x4Q`

Let me actually sum the bytes:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

✅ **Arithmetic is correct.** 88 bytes, natural alignment 8, no implicit padding under `struct` default rules *provided* the compiler is told `packed` or the natural alignment already matches (it does: 4+4 = 8, then 40, then 2+6 = 8, then 32). **This is a genuinely well-formed descriptor.** Credit where due.

**But three adversarial observations:**

1. **Endianness is unspecified.** `4sHHQQQQQBB6x4Q` is host-endian. A PMTP descriptor crossing an x86↔TPU↔Trainium boundary (Targets 1, 5) will silently byte-swap. **Rule 22 compliance is therefore conditional on an explicit `>4sHHQQQQQBB6x4Q` (network order) or a documented `htole`/`letoh` shim.** Demand: a `static_assert` / `const_assert` on `sys.byteorder` or a `bswap` in the Rust/C++ FFI.

2. **`6x` padding is a covert channel.** Six bytes of uninitialized memory in a struct that is *hashed, compared, or memcmp'd* is a **timing/information-leak vector** and a **false-negative equality bug**. If any component does `memcmp(desc_a, desc_b, 88)`, two logically identical descriptors with different padding will compare unequal. Demand: `memset(desc, 0, 88)` before every fill, or replace `6x` with `6s` reserved-zero and assert.

3. **No version field beyond the two `H`.** If those `H` are `(major, minor)`, fine — but the brief doesn't say. A 16-bit minor is 65 536 revisions; a 16-bit major is 65 536 breaking changes. **Demand: explicit `(u16 major, u16 minor)` naming and a `POLYDIM_DESC_VERSION` constant checked at every FFI boundary.**

### 0.2 Rule 22 — "Zero 1D tokens in inter-agent communication"

The brief asserts this rule but does not define "1D token." I will interpret it charitably as: **no scalar/rank-1 payloads cross agent boundaries; all inter-agent messages are the 88-byte PMTP descriptor or a fixed-rank tensor.** Under that reading:

- **Target 1 (Python orchestrator):** Python's `int`/`float` are arbitrary-precision and *not* 88 bytes. Any `json.dumps({"step": 1e10})` violates Rule 22. **Demand: the orchestrator's IPC layer must be a `struct.pack('<4sHHQQQQQBB6x4Q', ...)` with zero JSON.**
- **Target 3 (Rust):** `#[repr(C, packed)]` on the descriptor is mandatory; `#[repr(Rust)]` reorders fields and breaks the 88-byte contract. **Demand: `const _: () = assert!(core::mem::size_of::<PmtpTensorDescriptor>() == 88);`**
- **Target 5 (XLA/JAX):** JAX's `jax.jit` traces Python scalars into `ShapedArray` — a rank-0 array is a **1D token by the strict reading**. **Demand: all JAX inputs be `jax.ShapeDtypeStruct` with `shape != ()`.**

**Verdict on Rule 22: UNVERIFIABLE as presented.** The descriptor *can* satisfy it; nothing in the brief proves it *does*.

### 0.3 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Lock-in risk |
|---|---|---|
| 1 Python orchestrator | none (if `ctypes`/`cffi` only) | **LOW** |
| 2 C++ AVX-512 | Intel/AMD ISA | **MEDIUM** — AVX-512 is absent on Zen 2, Ice Lake-SP only on Intel server, and **disabled by default on Alder Lake P-cores**. Needs runtime dispatch. |
| 3 Rust SIMD | portable via `std::simd` (nightly) or `wide` | **LOW** if `core::arch` is feature-gated |
| 4 CUDA | **NVIDIA-only** | **CRITICAL** — cuSOLVER `DnDsyevd` has no ROCm equivalent with the same name; HIP has `hipSolver` but the brief claims cuSOLVER specifically. |
| 5 XLA | Google TPU **or** AWS Trainium | **HIGH** — two incompatible backends; "pure FP64" is **not supported on TPU v4/v5** (bf16/fp32 only; fp64 is emulated or absent). |
| 6 Triton | AMD ROCm + NVIDIA | **LOW** — Triton is genuinely portable, but `tl.dot` precision differs. |

**Rule 27 verdict: FAILS on Targets 4 and 5 as stated.** Target 4 is hard-locked to NVIDIA; Target 5's "pure FP64 on TPU" is a **factual impossibility** on current TPU generations (TPU v5e/v5p have no fp64 ALUs; fp64 is software-emulated at ~1/64 throughput or unavailable). **Demand: Target 5 must either (a) drop the TPU claim, (b) rename to "fp64-emulated," or (c) restrict to Trainium (which does have fp64 via Neuron).**

---

## 1. Target 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy

**step → ∞ (|step| ≥ 10¹⁰):**
- Python `float` is IEEE-754 binary64. `step = 1e10` is exactly representable. `step² = 1e20` is representable. `step⁴ = 1e40` **overflows to `inf`** (max ≈ 1.8e308, so 1e40 is fine — but `step⁸ = 1e80` is fine too; the danger is `step^k` for k ≥ 39). **The real risk is not overflow but catastrophic cancellation in any `(1 + step²)`-style expression when step is large and the result is subtracted from something O(1).**
- **Demand: the orchestrator must clamp `step` to `[1e-8, 1e8]` before dispatch, or route through `math.fma` (Python 3.13+) / `numpy.float64` with explicit `np.errstate(over='raise')`.**

**step → 0 (subnormals):**
- Python's `float` **does** support subnormals (down to ~5e-324). But `step = 1e-320` squared is `1e-640` → **flushes to zero**. Any `1/step` → `inf`. **Demand: `if abs(step) < 1e-300: raise NumericalDegeneracy` or use `decimal.Decimal` for the orchestrator's bookkeeping (not for the kernel).**

### 1.2 HardwareProbe / PmtpSlabAllocator

- "Multi-silicon HardwareProbe" — **unfalsifiable without source.** Demand: a `probe_report()` returning `{vendor, isa, fp64_native, subnormal_slow}` as an 88-byte descriptor, not a dict.
- "PmtpSlabAllocator" — slab allocation of 88-byte descriptors is **pathological**: 88 is not a power of two, so a slab of 88-byte objects wastes 8 bytes per 128-byte cache line (6.25% overhead) and **straddles cache lines**. **Demand: either pad to 96 or 128 bytes, or use a `Vec<[u8; 88]>` with explicit `align(8)` and accept the straddle.** The brief's claim of "12/12 physical conformance checks" is **unverifiable** — demand the 12 checks be enumerated and each mapped to a `assert` in source.

### 1.3 Rule 22 / Rule 27

- Rule 22: **at risk** if the orchestrator uses `pickle` or `json` for IPC. Demand: `struct.Struct('<4sHHQQQQQBB6x4Q')` as the *only* serialization primitive.
- Rule 27: **compliant** if `ctypes`/`cffi` only. **Demand: no `import torch`, no `import cupy` at module top level.**

---

## 2. Target 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — the real math

Neumaier's algorithm (improved Kahan) for `sum = Σ aᵢbᵢ`:

```
s = 0; c = 0
for i:
    t = s + a[i]*b[i]
    if |s| >= |a[i]*b[i]|:  c += (s - t) + a[i]*b[i]
    else:                   c += (a[i]*b[i] - t) + s
    s = t
return s + c
```

**Error bound:** `|result - exact| ≤ (2u + O(nu²)) Σ|aᵢbᵢ|` where `u = 2⁻⁵³`. This is **not** correctly-rounded; it is *compensated*. For a dot product of length n, the naive bound is `nu Σ|aᵢbᵢ|`; Neumaier gives `~2u Σ|aᵢbᵢ|` **independent of n**. ✅ Good.

**Adversarial degeneracy:**
- **step → ∞:** if `a[i] = step`, `b[i] = step`, then `a[i