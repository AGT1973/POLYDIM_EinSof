# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 128)

# POLYDIM V1350 — High Tribunal Audit, Cycle 128

**Presiding Sages:** Numerical Analysis, Systems/FFI, HPC Portability, Formal Methods.
**Verdict posture:** Adversarial. Claims are treated as unproven until the artifact is shown. Where the artifact is not in front of us, we audit the *specification as stated* and flag every place where the spec is under-determined.

---

## 0. Preliminary: What we can and cannot certify

We have **no source files** in this prompt — only the architectural claims. Therefore:

- We can **certify consistency of the stated invariants** (88-byte layout, Rule 22, Rule 27).
- We can **falsify** any claim whose stated form is mathematically impossible or numerically degenerate.
- We **cannot** certify the 12/12 conformance checks, the Neumaier subnormal audits, or the CUDA/XLA/Triton kernels without the code. Any "PASS" below is conditional on the artifact matching the description.

This is the correct epistemic stance for a Tribunal. Anything else is theater.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us actually count bytes, because this is the kind of thing that silently breaks Rule 22.

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Arithmetic checks out: 4+4+40+2+6+32 = 88.** ✅

**But** — `struct` with native alignment is *not* 88 bytes. `<` forces little-endian and **standard size, no alignment**, so the layout is exactly 88. Good. However:

- **Endianness lock-in.** `<` is little-endian. On a big-endian host (IBM POWER, some s390x), the descriptor is byte-swapped relative to native. If the orchestrator ever runs on such a host, Rule 22's "88-byte PMTP" is satisfied in *size* but violated in *semantics*. **Recommendation:** declare the wire format explicitly as LE and require `struct.unpack_from('<...')` on every host, or add a magic-byte endianness tag.
- **`6x` padding is a landmine.** If any future field is added, the pad must be re-derived. Encode the invariant as a test: `assert struct.calcsize(fmt) == 88`.
- **`4s` magic** — is it `b'PMTP'`? If not, cross-language parsers (Rust `#[repr(C, packed)]`, C++ `#pragma pack(1)`) will disagree. The Rust and C++ targets must use **packed** structs, not `repr(C)` with natural alignment, or the 88-byte contract silently becomes 96/104 bytes.

### 1.2 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe** is fine as a *capability* query, but Rule 27 (Silicon Contract) requires that the probe **not** be a hard dependency. If `HardwareProbe` raises on unknown silicon, the orchestrator becomes vendor-locked by accident. **Recommendation:** probe must return a *capability set*, never raise; unknown → `{scalar_fallback}`.
- **Slab allocator**: if slabs are page-aligned and the descriptor is 88 bytes, then `88 * N` slabs will straddle cache lines at N where `88*N mod 64 != 0`. For N=8, 88*8=704 = 11 cache lines exactly. For N=1, 88 bytes spans 2 lines. **Recommendation:** pad slab stride to 128 bytes (2 lines) for SIMD-friendly access, and keep the *wire* descriptor at 88.

### 1.3 Rule 22 compliance

Rule 22 says **zero 1D tokens in inter-agent communication**. The 88-byte descriptor is a *fixed-width record*, which is the correct shape. But:

- If any field is a **variable-length string** (e.g., a device name in the `4s` magic slot), Rule 22 is violated. The `4s` must be a fixed enum, not a name.
- The `4Q` tail — if these are pointers, they are **host-endian and host-width**. On a 32-bit host, `Q` is still 8 bytes in `<` mode, but the *value* cannot hold a 32-bit pointer meaningfully. **Recommendation:** the `4Q` must be **offsets into a shared arena**, not raw pointers, or the descriptor is not portable.

**Verdict T1:** Layout arithmetic ✅. Endianness and pointer-width hazards ⚠️. Cannot certify 12/12 without code.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:

```
s = 0; c = 0
for x, y:
    t = s + x*y
    if |s| >= |x*y|: c += (s - t) + x*y
    else:            c += (x*y - t) + s
    s = t
return s + c
```

**Error bound:** For n terms, Neumaier gives `|error| <= (2u + O(nu²)) * Σ|x_i y_i|` where `u = 2^-53` (FP64). This is **not** correctly-rounded, but it is **faithful** for well-scaled inputs.

**Degeneracy at step → ∞ (|step| ≥ 10^10):**

- If `step` multiplies the dot product, `x*y` can overflow to `inf` for `|x|,|y| ~ 10^154`. Neumaier's compensation term `(s - t) + x*y` becomes `inf - inf = NaN`. **The compensation is not overflow-safe.** This is a real, documented failure mode.
- **Proof of failure:** take `x = [1e200, 1e200]`, `y = [1e200, -1e200]`. True dot = 0. Neumaier: `t1 = 1e400 → inf`, `c += (0 - inf) + inf = NaN`. Result NaN. **Falsified for extreme step.**
- **Mitigation:** pre-scale by `2^-k` where `k = max exponent`, or use `fma`-based TwoProd with exponent tracking. The spec's claim of "subnormal audits (-12, -14)" suggests the authors know this — but subnormal audits do **not** cover overflow. **Demand:** an explicit overflow audit at `|step| ≥ 10^10`.

**Degeneracy at step → 0 (subnormals):**

- Subnormals below `2^-1022` lose precision gradually. Neumaier's compensation term itself becomes subnormal and the `(s - t)` subtraction can flush to zero under FTZ/DAZ (which AVX-512 can enable via MXCSR). **If FTZ is on, Neumaier degenerates to naive summation.** The "-12, -14" audits must explicitly test with FTZ/DAZ **off** and **on**, and document the behavior.
- **Recommendation:** pin MXCSR to `FTZ=0, DAZ=0` in the kernel entry, restore on exit. This is a per-thread register; OpenMP threads each need it.

### 2.2 AVX-512 / OpenMP

- **AVX-512 downclocking** on Skylake-X/Ice Lake is real; on Sapphire Rapids it's largely gone. Rule 27 (no vendor lock) is **violated** if the kernel *requires* AVX-512. **Recommendation:** runtime dispatch via `__builtin_cpu_supports("avx512f")` with an AVX2 fallback. Otherwise the "multi-silicon" claim in T1 is contradicted by T2.
- **OpenMP `#pragma omp simd reduction(+:s,c)`** — Neumaier's `c` is **not associative**; a parallel reduction over `c` is **not** the same as sequential Neumaier. The error bound changes. **Demand:** either serialize the compensation or use a tree-reduction with a proven bound (e.g., Ogita-Rump-Oishi `Dot2` with `TwoSum`).

### 2.3 Zero-copy PMTP validation

- "Zero-copy" + "validation" is a contradiction unless validation is **read-only and in-place**. If validation writes a checksum into the 88-byte descriptor, it's not zero-copy. **Demand:** clarify. If validation is a `memcmp` against a known-good descriptor, fine.

**Verdict T2:** Neumaier is **not** overflow-safe; the `step → ∞` claim is **falsified** as stated. Subnormal handling depends on MXCSR, which is not mentioned. AVX-512 requirement risks Rule 27.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

This is **backwards**. The Rust reference is explicit:

> **Unwinding across an FFI boundary is undefined behavior** (pre-1.71) and **aborts** (post-1.71 with `C-unwind` being the only sanctioned path).

`panic=unwind` does **not** make FFI safe. It makes the *Rust side* unwind, and if that unwind crosses into C/C++, you get UB or abort. The correct barrier is:

- `extern "C"` functions must **catch** panics: `std::panic::catch_unwind` at every FFI entry, returning an error code.
- Or use `extern "C-unwind"` **only** if the other side is also unwind-aware (C++ with matching ABI, which is fragile).
- Or `panic=abort` at the FFI boundary crate.

**The spec's claim is a category error.** This is the single most serious finding in the audit.

### 3.2 Safe SIMD

- Rust's `std::simd` is still nightly (`portable_simd`). If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" is only true if wrapped in a proven-safe abstraction. **Demand:** the `unsafe` block count and a safety comment per block.
- **Packed 88-byte descriptor:** Rust `#[repr(C, packed)]` gives 88 bytes, but **taking a reference to a packed field is UB** (unaligned reference). Must use `read_unaligned` / `write_unaligned`. If the code does `&desc.field`, it's UB. **Demand:** grep for `&` on packed fields.

