# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 98

The requested arbitration cannot be validated as a factual “Cycle 98” result: no public, authoritative record of **POLYDIM V1350**, its six kernels, or the six model reports was found. The available search results identify **PolyDiM** as a C++ library for polytopal discretization, not the described V1350 architecture.[1] Accordingly, the synthesis below is a mathematically grounded design ruling, not a claim about unpublished tribunal outputs.

## Arbitration ruling

| Question | Definitive ruling | Guarantee level |
|---|---|---|
| Cayley–Stiefel retraction at \(|\mathrm{step}|\ge 10^{10}\) | **No unconditional stability guarantee.** Use adaptive scaling, robust linear solves, and a fallback to polar/Householder QR. | Conditional numerical guarantee only |
| PMTP 88-byte descriptor | Acquire/release operations can establish publication and reclamation ordering, but **do not alone guarantee snapshot isolation**. RCU/QSBR grace-period and lifetime rules are also required. | Conditional memory-model guarantee |
| CUDA/XLA/Triton/C++20/Rust conformance | **No exact cross-platform guarantee** follows from source-level similarity. It requires a formally specified semantic subset, capability matrix, and differential conformance tests. | Contractual/tested guarantee only |

## 1. Stiefel retraction under extreme steps

For a Stiefel point \(X\in\mathrm{St}(n,p)\), \(X^\top X=I\), a Cayley update is commonly expressed as

\[
X_{+}
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)X,
\qquad A^\top=-A .
\]

In exact arithmetic, the Cayley transform is orthogonality-preserving whenever the inverse exists. That does **not** imply stable floating-point behavior for \(|\alpha|\ge 10^{10}\). At extreme scale:

- the matrices \(I\pm \alpha A/2\) can become badly scaled;
- forming \(A\) or \(\alpha A\) can overflow or lose relative accuracy;
- the solve may suffer severe conditioning and cancellation;
- finite-precision orthogonality error can become large even though the exact transform is orthogonal.

Therefore, the superior ruling is:

1. **Do not advertise unconditional Cayley stability for extreme steps.**
2. Compute the transform through a scaled or factored solve, never by explicitly forming a dense inverse.
3. Monitor
   \[
   \delta_{\mathrm{orth}}=\|X_+^\top X_+-I\|
   \]
   and the solve residual.
4. If thresholds are exceeded, reduce the step or fall back to a numerically robust orthogonalization path.

Householder QR is generally the strongest default for backward stability and rank-revealing orthogonalization. Polar decomposition can provide a geometrically natural nearest-Stiefel projection, but its implementation quality depends on the chosen algorithm and conditioning. The correct SOTA architecture is thus a **hybrid**:

\[
\text{Cayley proposal}
\;\longrightarrow\;
\text{residual/orthogonality test}
\;\longrightarrow\;
\begin{cases}
\text{accept},\\
\text{scaled retry},\\
\text{polar or Householder-QR fallback}.
\end{cases}
\]

The exact guarantee should be stated as:

> If the scaled linear solve meets its residual bound and the post-update orthogonality error is below the configured tolerance, the kernel returns a numerically certified approximate Stiefel point. Otherwise it returns a failure/status code or invokes the fallback; it must not silently claim stability.

No algorithm can guarantee bounded floating-point error for arbitrary \(10^{10}\)-scale steps without assumptions on matrix norms, precision, conditioning, overflow handling, and tolerances.

## 2. PMTP 88-byte descriptors and RCU/QSBR

An 88-byte layout is an ABI and storage-size property, not a synchronization proof. A sound descriptor must specify:

- field offsets, widths, alignment, and endianness;
- which fields are immutable after publication;
- ownership and reclamation state;
- version or sequence information;
- permitted atomic access widths;
- padding and false-sharing policy.

For publication of a fully initialized immutable snapshot, the essential ordering is:

```text
writer:
    initialize descriptor and payload
    release-store published pointer/version

reader:
    acquire-load published pointer/version
    read descriptor and payload
```

The release/acquire pair ensures that the reader observes writes sequenced before publication, provided the reader accesses the object through the corresponding synchronization protocol. However:

- acquire/release does not prevent reclamation while a reader still uses the object;
- it does not create a consistent multi-field snapshot if fields can mutate independently;
- it does not make non-atomic concurrent writes valid;
- it does not replace an RCU grace period or QSBR quiescent-state protocol.

For RCU/QSBR, the required ordering is conceptually:

\[
\text{publish}_{\mathrm{release}}
\prec
\text{reader acquire}
\prec
\text{reader quiescent state}
\prec
\text{reclaim}.
\]

QSBR systems require readers to report quiescent states, and reclamation is safe only after every potentially active reader has passed through the relevant grace period.[2][3] The Linux RCU documentation likewise treats reclamation as a protocol involving reader tracking and grace periods, not merely a single atomic load.[4]

The exact architectural guarantee should therefore be:

> A descriptor snapshot is immutable after release publication; readers acquire a published generation and retain it through their read-side critical section; reclamation occurs only after the RCU/QSBR grace-period condition is satisfied.

If mutable metadata must be updated in place, use either:

- atomic fields with explicitly defined ordering;
- a seqlock/versioned snapshot with retry on inconsistency;
- copy-update-publish and deferred reclamation.

An 88-byte descriptor can be portable only if its ABI is explicit. It cannot be declared “RCU-safe” solely because its size or alignment is fixed.

## 3. CUDA, XLA, Triton, C++20, and Rust

These systems do not share one universal execution or memory model:

- C++20 defines language-level atomics and object-lifetime rules;
- Rust adds ownership and aliasing guarantees, but unsafe code and foreign-function interfaces can bypass them;
- CUDA has device-scoped, block-scoped, and system-scoped synchronization semantics;
- Triton exposes compiler-controlled GPU programming abstractions whose lowering and supported atomics depend on backend/version;
- XLA uses an intermediate representation and compiler transformations; source ordering is not by itself a device-level memory-order proof.

Thus, “same kernel” must mean **same specified observable contract**, not identical instructions or identical timing.

A defensible conformance contract should define:

- numerical domain and permitted precision;
- NaN, infinity, signed-zero, and overflow behavior;
- reduction associativity and reproducibility requirements;
- tensor layout and aliasing rules;
- memory visibility scope;
- atomic ordering and synchronization scope;
- error/status behavior;
- descriptor ABI and lifetime rules;
- supported dimensions, strides, and alignment;
- tolerance bounds for numerical outputs.

The implementation should be divided into:

1. **Reference semantics**  
   A C++20 or mathematical specification defining the state transition.

2. **Backend-specific lowering**  
   CUDA, Triton, XLA, and Rust bindings implement that contract, not one another’s incidental behavior.

3. **Differential tests**  
   Compare outputs, orthogonality residuals, descriptor generations, reclamation safety, and failure codes across backends.

4. **Litmus tests**  
   Test publication, acquire/release visibility, reader critical sections, and reclamation under adversarial scheduling.

5. **Capability gating**  
   A backend that cannot meet a guarantee must reject the configuration rather than silently weaken it.

The exact guarantee should be:

> For every backend-capability profile accepted by the runtime, the implementation satisfies the declared numerical, memory-ordering, ABI, and lifetime contract within stated tolerances. Unsupported profiles are rejected explicitly.

Bitwise identity across all five environments should **not** be promised unless the implementation enforces deterministic operation order, identical precision, identical reduction trees, and compatible compiler behavior. Mathematical equivalence within a specified error bound is the realistic SOTA target.

## Definitive architecture

The mathematically and architecturally strongest synthesis is a **verified adaptive pipeline**:

1. **Manifold update**
   - Attempt a scaled Cayley retraction.
   - Check solve residual and Stiefel defect.
   - Retry with scaling or fall back to polar/Householder QR.
   - Return explicit diagnostics.

2. **Snapshot publication**
   - Construct an immutable PMTP descriptor and payload.
   - Publish by release store.
   - Read by acquire load.
   - Keep the snapshot alive through an RCU/QSBR read-side section.
   - Reclaim only after a completed grace period.

3. **Portable execution**
   - Define one backend-neutral semantic contract.
   - Map synchronization scopes explicitly for each backend.
   - Use capability negotiation and conformance tests.
   - Reject unsupported precision, atomicity, layout, or lifetime combinations.

The guarantees should be phrased narrowly and exactly:

- **Geometry:** output is an approximate Stiefel point only when the reported residual bound passes.
- **Numerics:** extreme-step Cayley updates are handled adaptively; no unconditional stability claim is valid.
- **Memory visibility:** release publication plus acquire observation orders initialization before reader access.
- **Lifetime:** RCU/QSBR grace-period completion, not acquire/release alone, authorizes reclamation.
- **Portability:** cross-silicon conformance is guaranteed only for explicitly specified and tested capability profiles.
- **Failure behavior:** numerical instability, unsupported atomics, invalid layout, or incomplete reclamation conditions produce explicit failure/status results rather than silent degradation.