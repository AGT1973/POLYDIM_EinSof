# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 110

The six-model findings cannot be independently reconciled from the material provided: the actual Claude, Qwen, Kimi, Gemini, DeepSeek, and Perplexity reports, the six V1350 kernel specifications, and benchmark/conformance data are absent. A definitive arbitration therefore requires separating **mathematically provable guarantees** from claims that would require implementation evidence.

## 1. Cayley–Stiefel retraction versus Householder/Polar QR

For \(X\in\mathrm{St}(n,p)\), where \(X^{\mathsf T}X=I\), a Cayley update has the form

\[
Y=(I-\tfrac{\alpha}{2}W)^{-1}(I+\tfrac{\alpha}{2}W)X,
\qquad W^{\mathsf T}=-W.
\]

In exact arithmetic, the Cayley factor is orthogonal whenever the inverse exists; consequently,

\[
Y^{\mathsf T}Y=X^{\mathsf T}X=I.
\]

The Cayley map is a valid Stiefel retraction and is a second-order, structure-preserving approximation to the matrix exponential.[13][14]

However, **this does not establish stability for \(|\text{step}|\ge 10^{10}\)**. At such scales:

- forming \(\alpha W\) can overflow or lose all meaningful low-order bits;
- solving \(I-\frac{\alpha}{2}W\) can be ill-conditioned;
- finite-precision orthogonality error can become large even though the exact transform is orthogonal;
- iterative Cayley solvers require a contraction condition such as
  \[
  0<\alpha<\min\left\{1,\frac{2}{\|W\|}\right\},
  \]
  so an unrestricted extreme step violates the usual convergence guarantee.[13]

Householder QR is generally the strongest **direct orthogonalization** primitive for numerical robustness: it avoids explicitly forming normal equations and uses normwise stable reflectors. Polar retraction is geometrically attractive and gives the nearest orthonormal factor in the Frobenius norm, but its implementation still requires a stable SVD, eigensolver, or equivalent matrix-function computation.

### Arbitration

The mathematically defensible ranking is:

1. **Householder QR with scaling and reorthogonalization** — preferred emergency fallback for extreme steps.
2. **Stable polar decomposition** — preferred when nearest-point geometry is required and a reliable SVD/eigensolver is available.
3. **Cayley retraction** — preferred for ordinary bounded steps when its skew structure and lower-cost update are valuable, but not as an unconditional extreme-step method.

The definitive guarantee should therefore be:

> For \(|\text{step}|\ge 10^{10}\), the kernel must not promise Cayley stability merely from skew symmetry. It must scale the step, detect overflow/conditioning failure, and fall back to Householder QR or a stable polar factor, followed by an explicit residual check
> \[
> \|Y^{\mathsf T}Y-I\|\le \tau_{\mathrm{orth}}.
> \]

A kernel that silently applies an unscaled Cayley solve at that magnitude has **no defensible SOTA stability guarantee**.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release semantics provide ordering only through the relevant atomic synchronization object. A release publication followed by an acquire load of the same atomic makes prior writes visible to the acquiring thread.[1][3][4]

For a descriptor publication protocol, the minimum sound pattern is conceptually:

```cpp
// Writer:
descriptor->fields = fully_initialized_value;
published.store(pointer_or_version, std::memory_order_release);

// Reader:
auto p = published.load(std::memory_order_acquire);
consume_descriptor(p);
```

The 88-byte size is not itself a memory-model guarantee. Correctness additionally requires:

- atomic publication of the descriptor pointer, index, or version;
- immutable fields after publication, or separately synchronized mutation;
- cache-line/layout rules that prevent unintended tearing or false sharing;
- a lifetime protocol preventing reclamation while a reader may still dereference the descriptor;
- a QSBR/RCU grace-period proof before reuse or destruction;
- versioning or sequence validation if readers may observe a descriptor being replaced.

### Arbitration

**Acquire/release is sufficient for publication visibility, but insufficient by itself for RCU/QSBR snapshot isolation.**

The exact guarantee should be stated as:

> A reader that enters a read-side critical section, performs an acquire load of the released publication token, and exits according to the QSBR/RCU protocol observes a fully initialized descriptor version and cannot access storage reclaimed before its grace period ends.

This guarantee fails if any of the following are omitted:

- the reader enters QSBR before loading the snapshot;
- the publication token is not the synchronization location used by the writer;
- reclamation occurs without a completed grace period;
- descriptor fields are concurrently mutated non-atomically;
- the protocol assumes acquire/release provides a global snapshot across multiple independent atomics.

If the descriptor contains multiple related values, publish them through one immutable object or a single versioned snapshot. Acquire/release should not be advertised as providing a transactional multi-field snapshot.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single common execution or memory model shared identically by these environments. C++20 and Rust define language-level atomic semantics; CUDA adds device, block, and system scopes; Triton exposes compiler- and target-dependent lowering; XLA is an optimizing tensor compiler whose operation-level guarantees depend on its backend and synchronization primitives.

Therefore, “multi-silicon conformance” cannot mean bit-identical behavior across all five systems without a narrowly defined contract. The conformance target must distinguish:

- **functional conformance:** identical mathematical result within stated tolerances;
- **memory-safety conformance:** no use-after-reclamation, races, or invalid aliasing;
- **ordering conformance:** required publication and grace-period happens-before edges;
- **numerical conformance:** bounded orthogonality and residual errors;
- **performance conformance:** optional and architecture-specific, never a correctness guarantee.

The portable core should use:

- immutable, versioned descriptors;
- explicit ownership and lifetime rules;
- acquire/release publication at the host-language boundary;
- backend-specific device fences and atomic scopes where descriptors cross host/device or device/device domains;
- deterministic fallback behavior for unsupported atomic widths, alignment, or memory scopes;
- numerical tolerances expressed relative to precision, matrix dimensions, and backend.

### Arbitration

The strongest portable architectural guarantee is not “all platforms implement the same barriers.” It is:

> Every backend must implement the same abstract protocol: publish an immutable descriptor, acquire a specific publication token, enter and exit a reader-protection epoch, and reclaim only after the corresponding grace period. Backend-specific fences may realize this protocol, but cannot weaken its happens-before and lifetime requirements.

C++20 and Rust can express the host-side release/acquire contract directly.[1][3][4] CUDA, Triton, and XLA require an explicit mapping of that contract to their supported atomic scopes, fences, and compiler barriers. That mapping must be validated separately on each target family; it cannot be inferred from source-level portability alone.

## Definitive SOTA synthesis

The six kernels should be specified as a **verified hybrid**, not as unconditional Cayley-plus-acquire/release implementations:

1. **Numerical update**
   - Use scaled Cayley only within a validated step and conditioning range.
   - For extreme steps or failed residual checks, use Householder QR.
   - Optionally use stable polar retraction where nearest-point geometry is required.
   - Guarantee orthogonality only through a checked residual bound, not through algebraic form alone.

2. **Descriptor publication**
   - Keep the PMTP descriptor immutable after publication.
   - Publish one pointer/version token with release semantics.
   - Read it with acquire semantics.
   - Require QSBR/RCU read-side protection before dereference.
   - Reclaim only after a proven grace period.
   - Treat 88 bytes as a layout constraint, not a synchronization guarantee.

3. **Cross-backend contract**
   - Define one abstract state machine for publication, observation, retirement, and reclamation.
   - Map it separately to C++20, Rust, CUDA, Triton, and XLA.
   - Require target-specific tests for atomic scope, alignment, visibility, lifetime, and compiler reordering.
   - Report numerical tolerances and memory-order guarantees independently.

Thus, the mathematically superior arbitration is **adaptive QR-backed Stiefel retraction plus immutable versioned descriptors protected by release/acquire publication and QSBR/RCU reclamation**. No stronger claim—especially unconditional Cayley stability at \(|\text{step}|\ge10^{10}\), or snapshot isolation from acquire/release alone—is justified by the available evidence.