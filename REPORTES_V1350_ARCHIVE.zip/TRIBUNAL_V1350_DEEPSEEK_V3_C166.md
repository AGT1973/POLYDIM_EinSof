# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 166)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 166 · Multi-File Adversarial SOTA Review

**Presiding note:** The Tribunal treats the six artifacts as *specifications*, not as verified source. Where the prompt asserts a property (e.g., "12/12 conformance checks"), the Tribunal audits the *claim* against the mathematical contract it implies. Findings are graded **CRITICAL / MAJOR / MINOR / PASS**.

---

## 0. Cross-Cutting Invariants (Rule 22 & Rule 27)

### Rule 22 — Zero 1D tokens, 88-byte PMTP descriptor

The struct format `<4sHHQQQQQBB6x4Q` decodes as:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version | `H` | 2 | 4 |
| flags | `H` | 2 | 6 |
| n_rows | `Q` | 8 | 8 |
| n_cols | `Q` | 8 | 16 |
| stride | `Q` | 8 | 24 |
| dtype | `Q` | 8 | 32 |
| device | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| layout | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| aux[4] | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**PASS** on byte count. **MAJOR** on semantics:

- `Q` (unsigned 64-bit) for `n_rows/n_cols/stride` **forbids negative strides**, which are required for transposed views in BLAS-style zero-copy. This is a latent Rule-22 violation: a transposed tensor must be materialized (a 1D token in disguise) or the descriptor must be re-encoded with a sign bit stolen from `flags`.
- `rank` and `layout` as `B` (u8) cap rank at 255 and layout at 256 — fine for V1350, but the `6x` pad is *unused*; the Tribunal recommends repurposing 1 byte as `stride_sign` and 1 byte as `endianness` to make the descriptor self-describing across the multi-silicon boundary.
- **Endianness is not encoded.** A descriptor produced on a big-endian host (POWER10, some Trainium control planes) will be silently misread by an x86 AVX-512 consumer. This is a **CRITICAL** inter-agent hazard under Rule 22's "zero ambiguity" intent.

**Recommendation:** bump to `<4sHHQQQQQBBBB4x4Q` (still 88 bytes) with `endianness`, `stride_sign`, `reserved0`, `reserved1`.

### Rule 27 — Silicon Contract / vendor lock

| Target | Vendor lock risk | Verdict |
|---|---|---|
| T1 orchestrator | None if `HardwareProbe` is table-driven | **PASS** (conditional) |
| T2 C++/AVX-512 | Intel/AMD-specific ISA | **MAJOR** — needs `#if defined(__AVX512F__)` fallback to AVX2/NEON |
| T3 Rust SIMD | `std::simd` is nightly; portable_simd unstable | **MAJOR** — pin to `core::arch` with runtime dispatch |
| T4 CUDA | cuSOLVER `DnDsyevd` is NVIDIA-only | **CRITICAL** — no ROCm/HIP path |
| T5 XLA | `@jax.jit` is portable, but "TPU/Trainium HLO" is vendor-shaped | **MAJOR** — HLO is portable, *scheduling* is not |
| T6 Triton | ROCm + CUDA dual-target is the *only* component that satisfies Rule 27 | **PASS** |

**Tribunal ruling:** Rule 27 is **violated by T4** and **conditionally violated by T2/T3/T5**. Only T6 is contract-clean.

---

## 1. Numerical Degeneracy: `step → ∞` and `step → 0`

### 1.1 `step → ∞` (|step| ≥ 10¹⁰)

**T4 (CUDA, Woodbury):** The scaled solve is
$$(M/\text{scale})\,W = (\text{step}/\text{scale})\,B.$$
For this to be well-posed, `scale` must be chosen so that `step/scale` and `M/scale` are both O(1). If `scale = ‖M‖_F`, then `step/scale → ∞` as `step → 10¹⁰` unless `scale` is *also* scaled by `step`. **The prompt's formulation is under-specified.**

**Proof of degeneracy:** Let `M = I`, `B = I`, `scale = 1`. Then `W = step · I`. The Cayley retraction
$$Y = (I - \tfrac{1}{2}W)^{-1}(I + \tfrac{1}{2}W)$$
has `‖Y‖ → 1` as `step → ∞` (correct, orthogonal), but the *intermediate* `W` overflows FP64 at `step > 2^53 ≈ 9·10¹⁵`. At `step = 10¹⁰`, `W` is representable but the Woodbury update `(A + UCVᵀ)⁻¹` loses ~`log10(step) ≈ 10` digits of precision. **Condition number of the Woodbury solve scales as `κ ≈ step²`.**

**Fix:** Reformulate as a *scaled* Cayley:
$$Y = (I - \tfrac{1}{2}\tilde W)^{-1}(I + \tfrac{1}{2}\tilde W), \quad \tilde W = \frac{W}{\|W\|_F + \epsilon},$$
then rescale the tangent step *after* retraction. This keeps `κ(W) = O(1)` uniformly in `step`.

**T5 (XLA, Lyapunov):** Continuous Lyapunov `A X + X Aᵀ = -Q` with `A` from a Stiefel tangent. As `step → ∞`, `A` becomes stiff; the Bartels–Stewart algorithm's Schur decomposition has `κ ≈ exp(‖A‖·t)`. **CRITICAL** — no step-clamping is described.

**T6 (Triton, Clifford bivector):** Rotations `R = exp(θ B)` with `θ = step`. For `step ≥ 10¹⁰`, `θ mod 2π` must be computed in *extended precision* (double-double) before `exp`. Otherwise catastrophic cancellation in `θ - 2π⌊θ/2π⌋` destroys the rotation. **MAJOR.**

### 1.2 `step → 0` (subnormals)

**T2 (C++):** The prompt claims "subnormal audits (-12, -14)". These are almost certainly the *exponent thresholds* for `float` (min normal 2⁻¹²⁶, min subnormal 2⁻¹⁴⁹) — but the numbers -12 and -14 suggest **log10 thresholds** (i.e., `1e-12`, `1e-14`). **Ambiguity is a MAJOR finding.** If the audit is `|x| < 1e-14 → flush to zero`, then:

- Neumaier compensation is *defeated* by FTZ/DAZ flags. The compensated sum `s + c` relies on subnormals to carry the residual. **Flushing subnormals to zero silently converts Neumaier into naive summation.**
- **Proof:** Let `a = 1.0`, `b = 1e-16`, `c = -1.0`. Neumaier: `s = 1.0`, `c = 1e-16` (representable as subnormal in FP64? No — 1e-16 is normal in FP64). In FP32, `1e-16` is subnormal. With FTZ, `c = 0`, and the result is `0` instead of `1e-16`. **Relative error = 100%.**

**Recommendation:** Disable FTZ/DAZ (`_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`) in the Neumaier kernels, or use Kahan–Babuska with explicit scaling.

**T3 (Rust):** `panic=unwind` across FFI is **undefined behavior** in Rust 2021 unless every `extern "C"` boundary is wrapped in `catch_unwind`. The prompt asserts "panic=unwind FFI safety barrier" — this is **only safe if** the barrier is `std::panic::catch_unwind` at every entry point. **MAJOR** — demand explicit `#[no_mangle] pub extern "C" fn ... { catch_unwind(|| ...).unwrap_or(ERR) }`.

**T4 (CUDA):** `DnDsyevd` on a `2K × 2K` matrix with `K` large: the divide-and-conquer recursion depth is `O(log K)`, and the deflation criterion uses `|λ_i - λ_j| < tol · ‖A‖`. For `step → 0`, the Stiefel tangent is near-zero, `A ≈ 0`, and `‖A‖ → 0`, so `tol · ‖A‖ → 0` faster than the eigenvalue gaps → **spurious deflation**. **MAJOR.**

---

## 2. Asymptotic Condition Numbers

| Component | Operation | κ asymptotics | Verdict |
|---|---|---|---|
| T2 | Neumaier dot | `κ = O(1)` (compensated) | **PASS** if FTZ off |
| T3 | Neumaier sum | `κ = O(1)` | **PASS** |
| T4 | Woodbury solve | `κ ≈ step²` | **CRITICAL** |
| T4 | Cayley retraction | `κ ≈ 1 + ‖W‖²` | **MAJOR** |
| T5 | Lyapunov (Bartels–Stewart) | `κ ≈ exp(‖A‖)` | **CRITICAL** |
| T6 | Clifford rotation | `κ ≈ 1/sin(θ mod 2π)` | **MAJOR** near `θ = kπ` |

**Proof sketch for T4 Woodbury:** The Woodbury identity
$$(A + UCV)^{-1} = A^{-1} - A^{-1}U(C^{-1} + VA^{-1}U)^{-1}VA^{-1}$$
has condition number bounded by `κ(A) · κ(C^{-1} + VA^{-1}U)`. With `C = step · I`, `κ(C) = 1`, but `C^{-1} = I/step → 0`, so the inner solve becomes *ill-conditioned in the opposite direction*: `C^{-1} + VA^{-1}U ≈ VA^{-1}U`, and `κ(VA^{-1}U