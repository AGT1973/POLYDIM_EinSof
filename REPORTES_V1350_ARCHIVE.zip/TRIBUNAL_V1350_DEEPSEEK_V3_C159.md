# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 159)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 159 · Multi-File Adversarial SOTA Review

**Preliminary note on evidentiary basis.** The audit brief enumerates six targets and their claimed properties, but no source files, headers, or build artifacts were attached to this docket. The Tribunal therefore proceeds in **two registers**:

- **(A) Claim-level audit** — what the stated architecture *implies* mathematically and systemically, and where the claims are internally inconsistent or under-specified.
- **(B) Verification demands** — the exact artifacts, invariants, and proofs required before any of the six targets can be certified.

Findings are graded **[BLOCKER]**, **[MAJOR]**, **[MINOR]**, **[INFO]**.

---

## 0. Cross-cutting findings (apply to all six targets)

### 0.1 Rule 22 — "Zero 1D tokens, 88-byte PMTP" **[BLOCKER — under-specified]**

The 88-byte descriptor is declared as `<4sHHQQQQQBB6x4Q`. Let us actually count:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `H H` | 4 |
| five `Q` | `Q Q Q Q Q` | 40 |
| two `B` | `B B` | 2 |
| pad | `6x` | 6 |
| four `Q` | `Q Q Q Q` | 32 |
| **Total** | | **88** |

Struct size is correct **only if** the platform's `Q` is 8-byte aligned and the compiler does not insert padding between `4sHH` (offset 8) and the first `Q` (offset 8 — OK) or between `BB` (offset 56) and `6x` (offset 58 → 64 — OK). On x86-64 SysV this is fine. On **aarch64 with `-mabi=lp64` it is also fine**, but on **32-bit ARM or any ABI where `Q` is 4-byte aligned**, the struct silently becomes 92 bytes. The Rust `#[repr(C, packed)]` and C++ `#pragma pack` must be *explicitly* asserted, and a `static_assert(sizeof(...) == 88)` / `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` must exist in **every** target. The brief does not state this is present.

**"Zero 1D tokens"** is not defined in the brief. Two plausible readings:

1. **No scalar/1-D tensor payloads cross the FFI boundary** — all inter-agent messages are 88-byte descriptors pointing into shared PMTP slabs. This is a *strong* claim and is the only one consistent with "88-byte PMTP."
2. **No 1-D index vectors** in the wire format — all indices are packed into the descriptor's `Q` fields.

If (1): the descriptor must carry `(slab_id, offset, ndim, shape[≤4], dtype, stride_hash, checksum)`. Five `Q` + four `Q` = 9 × 64 bits = 576 bits of payload. That is *tight* for a 4-D tensor with strides. **Demand:** the exact field-by-field layout and a proof that any tensor expressible by the orchestrator fits.

If (2): the claim is vacuous without a definition of "token."

### 0.2 Rule 27 — Silicon Contract / vendor lock **[MAJOR]**

The six targets span: CPU (C++/AVX-512), CPU (Rust/SIMD), NVIDIA (CUDA), Google TPU + AWS Trainium (XLA/PJRT), AMD ROCm + NVIDIA (Triton). **This is not vendor-neutral by construction** — it is a *federation* of vendor-specific backends behind a common descriptor. That is acceptable **iff**:

- The 88-byte descriptor is the *only* inter-backend contract (no `cudaStream_t`, no `PjRtBuffer*`, no `hipStream_t` leaks into the descriptor or into any shared header).
- The orchestrator dispatches by capability bits in the descriptor, not by `#ifdef __CUDACC__`.
- A **null backend** exists that satisfies the descriptor contract on any POSIX host.

**Demand:** a `backend_capability_matrix.md` and a conformance test that runs the orchestrator against a stub backend with zero vendor SDKs linked. If the orchestrator `#include`s `<cuda_runtime.h>` anywhere, Rule 27 is violated.

### 0.3 Numerical degeneracy at `|step| → ∞` and `step → 0` **[BLOCKER]**

This is the deepest issue and it recurs in Targets 4, 5, 6. Let me treat it once, rigorously.

Let the update be a retraction `R_X(step · G)` on a manifold `M` (Stiefel, sphere, or Clifford group). Three regimes:

**(i) `step → 0`, subnormal regime.** If `step` is a subnormal `f64` (`|step| < 2^-1022`), then `step · G` underflows to zero for any `‖G‖ < 1`, and the retraction becomes the identity. Worse: Neumaier compensation *cannot* recover information that has already been flushed to zero by the multiply. The compensated sum `(s, c)` of terms `{step·g_i}` is exact **given the terms**, but the terms themselves are already denormalized.

- **Asymptotic condition number:** for the Cayley retraction `R_X(V) = (I - V/2)^{-1}(I + V/2) X` with `V = step·G`, the map `step ↦ R_X` has derivative `dR/dstep|_{step=0} = G X` (the tangent projection). The *relative* condition number of computing `R_X` in `f64` is `κ ≈ ‖G‖ / |step|` in the subnormal regime — i.e., **unbounded**. Any implementation that does not clamp `step` to `[step_min, step_max]` with `step_min ≥ 2^-1000` (say) is numerically unsound.
- **Demand:** explicit `step_min` and `step_max` constants, a `static_assert` that `step_min > DBL_MIN`, and a unit test that feeds `step = 5e-324` (smallest subnormal) and asserts the retraction returns `X` unchanged *by design*, not by accident.

**(ii) `|step| → ∞` (`≥ 1e10`).** For the Cayley retraction, `V = step·G` has `‖V‖ ~ step·‖G‖`. The Woodbury solve `(M/scale) W = (step/scale) B` is the *correct* mitigation: it factors out the scale so the linear solve sees a well-conditioned `M/scale`. But:

- If `scale` is chosen as `‖step·B‖_F` and `step = 1e10`, then `step/scale` is `O(1)` **only if** `‖B‖_F` is also `O(1)`. If `B` is itself tiny (e.g., a gradient that has decayed), `scale` underflows and the ratio is ill-defined.
- **Asymptotic condition number of the Woodbury solve:** `κ(M/scale) = κ(M)`, unchanged — good. But the *accuracy* of `W` depends on `κ(M) · u` where `u = 2^-53`. If `M` is the Stiefel Hessian, `κ(M)` can be `O(step^2)` in the worst case (the Hessian of the Cayley retraction grows quadratically in `step`). **Demand:** a proof that `κ(M/scale) ≤ κ_max` for all `step ∈ [step_min, step_max]`, or an explicit adaptive `scale` schedule.
- **CUDA Graphs interaction:** if `step` is a kernel argument baked into a captured graph, changing `step` requires graph re-instantiation. If the implementation instead passes `step` via device memory, the graph is reusable — but then the `scale` computation must also be on-device. **Demand:** state which.

**(iii) Neumaier compensation under extreme scale.** Neumaier's algorithm is exact for the *sum* but the *products* `a_i · b_i` are rounded. For `step = 1e10` and `g_i = 1e-10`, the product is `O(1)` — fine. For `step = 1e10` and `g_i = 1e-300`, the product underflows. **Demand:** a scaling pre-pass that normalizes `G` to `‖G‖_∞ = 1` before the dot product, with the scale tracked separately. This is standard but must be *stated*.

### 0.4 FFI hardening (cross-cutting) **[MAJOR]**

The Rust target claims `panic=unwind` as an "FFI safety barrier." This is **backwards**. `panic=unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is `extern "C-unwind"` (stabilized in Rust 1.71) and the other side is prepared to unwind. The correct hardening is:

- `panic = "abort"` in the `[profile.release]` for the FFI crate, **or**
- `extern "C-unwind"` on every exported symbol **and** a C++ side compiled with `-fexceptions` and a `catch(...)` at the boundary, **or**
- `std::panic::catch_unwind` at every `extern "C"` entry point, converting panics to error codes.

**Demand:** the exact `Cargo.toml` profile, the exact `extern` ABI string on every exported symbol, and a fuzz test that triggers a panic inside the Rust kernel and asserts the C++ side sees a clean error, not a `SIGABRT` or UB.

---

## 1. Target 1 — `kernel_orchestrator_v1350.py`

**Claims:** Multi-silicon `HardwareProbe`, `PmtpSlabAllocator`, 88-byte descriptor, 12/12 physical conformance checks.

**Findings:**

- **[MAJOR] `HardwareProbe` in Python is a lie by construction.** Python cannot probe AVX-512, AMX, or `cuSOLVER` availability without shelling out to `lscpu`, `nvidia-smi`, or `ctypes`-loading vendor libs. If it does the latter, Rule 27 is at risk. **Demand:** the probe must be a *pure capability query* against the descriptor contract (e.g., "does backend X accept an 88-byte descriptor with dtype=D and ndim=N?"), not a hardware enumeration.
- **[MAJOR] `PmtpSlabAllocator` in Python.** If this allocates via `mmap` and hands raw pointers to C++/Rust/CUDA, the lifetime is managed by the Python GC — a classic use-after-free vector. **Demand:**