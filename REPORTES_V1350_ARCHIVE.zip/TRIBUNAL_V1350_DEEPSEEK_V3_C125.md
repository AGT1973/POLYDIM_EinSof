# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 125)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 125 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been asked to audit six artifacts whose *source text was not attached to the brief*. We therefore audit against the **declared contract** (the bullet specifications you supplied) and against the **mathematical claims those contracts imply**. Where a claim is unverifiable without source, the Tribunal marks it **UNVERIFIED — conditional pass**, and issues the falsification test that would settle it. We do not rubber-stamp.

---

## 0. Notation and standing assumptions

- `step ∈ ℝ` is the optimizer step scalar; `scale > 0` is the Woodbury global scale.
- `M ∈ ℝ^{2K×2K}` is the (skew-symmetric) generator; `W = M/scale`, `B` the RHS.
- `ε_m ≈ 2.22e-16` (FP64), `ε_s ≈ 1.19e-7` (FP32), `σ_min` smallest singular value.
- Subnormal thresholds: FP64 `≈ 4.94e-324`, FP32 `≈ 1.40e-45`.
- Rule 22 = *zero 1-D tokens in inter-agent traffic; every payload is an 88-byte PMTP descriptor*.
- Rule 27 = *no vendor lock; every silicon path must be substitutable behind the same ABI*.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly (little-endian, native alignment, `=` prefix implied by the `6x` pad):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Verdict: 88 bytes confirmed.** Struct is *naturally aligned* only if the `6x` pad is honored; without `=` (standard size) Python's `struct` will insert alignment padding and the size will drift to 96 on some ABIs. **Recommendation:** force `struct.Struct("=4sHHQQQQQBB6x4Q")` and assert `size == 88` at import time. This is a **hard Rule 22 gate**.

### 1.2 Numerical degeneracy at `|step| ≥ 1e10`

The orchestrator itself does not do arithmetic, but it *dispatches* `step` into every backend. Two failure modes:

1. **Descriptor overflow.** If `step` is packed into a `Q` (unsigned 64-bit) as a *fixed-point* value, `1e10 · 2^k` overflows for `k ≥ 34`. If packed as IEEE-754 bits, fine — but then the C++/Rust/CUDA readers must agree on endianness and on whether the field is `double` or `uint64`. **UNVERIFIED** without source; demand a `static_assert(sizeof(double)==8)` on every consumer.
2. **Dispatch asymmetry.** If the orchestrator clamps `step` for one backend but not another, the six kernels will disagree on the *same* logical step. This is a **Rule 22 violation in spirit** (semantic divergence across agents).

**Falsification test:** feed `step ∈ {1e10, 1e15, 1e300, inf, nan}` through the orchestrator and assert bit-identical `step` bytes arrive at all six backends.

### 1.3 12/12 physical conformance checks

Without the checklist we cannot verify. The Tribunal demands the 12 checks be published as a machine-readable manifest with a **Merkle root** over the check IDs, so that "12/12" is auditable rather than asserted.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška:

```
s = 0; c = 0
for i: t = s + x_i*y_i
       if |s| ≥ |x_i*y_i|: c += (s - t) + x_i*y_i
       else:               c += (x_i*y_i - t) + s
       s = t
return s + c
```

**Error bound (Neumaier 1974):** for `n` terms with `Σ|x_i y_i| = S`,

```
|fl(dot) − dot| ≤ (2ε + O(nε²)) · S
```

i.e. the *relative* error is bounded by `2ε` **independent of n**, provided no intermediate overflows. This is the key property: **condition number of the compensated sum is O(1) in n**, versus O(n) for naive summation.

**Degeneracy at `step → ∞`:** if `step` multiplies the dot product *after* accumulation, no issue. If it multiplies *inside* the loop, `x_i·y_i·step` can overflow to `inf` and Neumaier's branch logic (`|s| ≥ |x_i y_i|`) becomes `inf ≥ inf` → **undefined branch selection**. **Mitigation:** factor `step` out of the loop; accumulate in the unscaled domain.

**Degeneracy at `step → 0` (subnormals):** Neumaier's compensation term `c` is itself a sum of differences of the same magnitude as `s`. When `s` is subnormal, `s - t` loses all bits and `c` becomes 0 — the compensation **silently degrades to naive summation**. This is the classic "subnormal audit" failure. The declared audits at `-12, -14` (presumably `2^-12`, `2^-14` scaling) are *above* the subnormal threshold for FP64 (`2^-1022`), so they do **not** exercise the true subnormal regime. **Demand:** add audits at `2^-1020`, `2^-1022`, `2^-1074`.

### 2.2 Zero-copy PMTP validation

"Zero-copy" + "validation" is a tension: validation normally requires reading, which is a copy. The only way to have both is **memory-mapped validation** (e.g. `mmap` + `mprotect(PROT_READ)` + checksum over the mapped region). **UNVERIFIED**; demand the syscall trace.

### 2.3 AVX-512 / OpenMP

- **AVX-512 downclocking** on Skylake-X: sustained 512-bit FMA can drop core frequency ~15–20%. If the kernel is latency-bound, this is a *net loss*. Demand a roofline plot.
- **OpenMP `reduction(+:s,c)`** on Neumaier is **not associative** — the reduction tree will produce different results across thread counts. This breaks **bit-reproducibility**, which is a Rule 22 concern if the orchestrator compares outputs across backends. **Mitigation:** use a deterministic reduction (fixed tree) or accept non-reproducibility and document it.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier

This is the **correct** choice for FFI: `panic=abort` across an FFI boundary is UB in C++ callers (no destructors run, `longjmp` semantics undefined). `panic=unwind` + `catch_unwind` at the boundary is the only sound pattern. **Pass**, with the caveat that `catch_unwind` requires `UnwindSafe`; raw pointers are `!UnwindSafe` by default, so the kernel must wrap them in `AssertUnwindSafe`. **Demand:** grep for `AssertUnwindSafe` and verify every FFI entry point has it.

### 3.2 Safe SIMD

Rust's `std::simd` is still nightly-only as of 2024. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe` — "Safe SIMD" is then a misnomer. **UNVERIFIED**; demand the `#![feature(portable_simd)]` gate or the `unsafe` block inventory.

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` will produce 88 bytes **only if** the field order matches the Python `struct` format exactly. Rust does not have a `6x` pad primitive; the kernel must declare `_pad: [u8; 6]`. **Demand:** a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` at module scope. This is the single most common Rule 22 violation in mixed-language codebases.

### 3.4 Neumaier in Rust

Same subnormal caveat as C++. Additionally, Rust's `f64::mul_add` (FMA) is **not** the same as `a*b + c` — if the kernel uses FMA inside Neumaier, the compensation term is wrong (FMA has no rounding error to compensate). **Demand:** verify the kernel uses plain `*` and `+`, not `mul_add`.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction

For `Y ∈ St(n,p)`, the Cayley retraction is

```
Y(α) = (I − (α/2) A)^{-1} (I + (α/2) A) Y,   A = G Yᵀ − Y Gᵀ  (skew)
```

where `G` is the gradient. The **condition number** of the solve is

```
κ(I − (α/2) A) = (1 + (α/2)‖A‖₂) / (1 − (α/2)‖A‖₂)
```

**Degeneracy at `step → ∞`:** if `α = step` and `step ≥ 2/‖A‖₂`, the matrix `I − (α/2)A` becomes **singular** (eigenvalue crosses zero). The Cayley retraction is then **undefined**. This is a *hard* failure, not a numerical one. **Mitigation:** clamp `α < 2/‖A‖₂ − δ`, or use a line search. The declared "globally scaled Woodbury solve (M/scale)" suggests the kernel *does* scale — but the scaling must be **adaptive to ‖A‖₂**, not a fixed constant.

**Degeneracy at `step → 0`:** `Y(α) → Y`, fine. But `A = G Yᵀ − Y Gᵀ` is computed in FP64; if `G` is subnormal, `A` is subnormal, and `DnDsyevd` on a subnormal matrix has **no guaranteed accuracy** (LAPACK's error bounds assume `‖A‖ ≳