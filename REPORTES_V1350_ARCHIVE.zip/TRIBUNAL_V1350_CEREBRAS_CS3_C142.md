# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 142)

## High Tribunal of Mathematical and Systems Sages  
**POLYDIM V1350 – Multi‑File Adversarial SOTA Audit – Cycle 142**  
*Prepared by the Tribunal’s Computational‑Numerics Division (CND) and Secure‑Systems Sub‑Committee (SSC).*

---

### Executive Summary  

| Component | Numerical‑Degeneracy (|step| → ∞) | Numerical‑Degeneracy (|step| → 0) | Rule 22 (88‑byte PMTP) | Rule 27 Silicon‑Contract | Main FFI‑Hardening Gaps |
|-----------|------------------------------|-----------------------------------|------------------------|--------------------------|------------------------|
| **kernel_orchestrator_v1350.py** | **Potential overflow** in the 64‑bit *scale* field of the descriptor; no saturation guard. | Sub‑normal *step* is stored in a `float64` field; conversion to integer‑indexed buffer offsets may under‑flow to zero, breaking alignment. | **Compliant** – descriptor is packed to exactly 88 B; the orchestrator enforces a “zero‑1‑D‑token” policy by forbidding scalar‑only payloads. | **No vendor lock** – pure Python 3.11, using only the `struct` module; however, the `HardwareProbe` probes only Intel‑specific MSRs, which may constitute a soft lock. | Lack of validation on raw bytes received from external agents; no `mmap`‑guard pages. |
| **kernel_cpp_v1350.cpp** | AVX‑512‑wide dot‑product saturates at `FLT_MAX` when `step·⟨x,y⟩` exceeds 2⁶³; compensated Neumaier sum cannot rescue overflow. | Sub‑normal inputs trigger *denorm‑flush‑to‑zero* (FTZ) on many Intel micro‑architectures, silently dropping contributions and biasing the compensated sum. | **Compliant** – the binary descriptor is emitted via `#pragma pack(push,1)` and verified with static‑assert `sizeof(PmtpTensorDescriptor)==88`. | **Hard lock** – the binary only links against Intel‑specific `libimf` and requires AVX‑512; any non‑Intel CPU will fall back to a non‑functional stub, violating the “no‑lock” spirit of Rule 27. | Missing `[[likely]]/[[unlikely]]` annotations for error paths; no `nullptr` checks on `pmpt_desc` pointer before reinterpret_cast. |
| **kernel_rust_v1350.rs** | `u128`‑wide accumulator in the Neumaier routine overflows only beyond 2¹²⁸; however, the *scale* field is `f64`; the Rust SIMD wrapper casts `step` to `f64` before multiplication, exposing the same overflow risk as C++. | Rust’s `#![deny(subnormal)]` is **not** set; the `std::simd` lane for `f64` obeys the hardware FTZ mode, again dropping contributions. | **Compliant** – the `#[repr(C, packed(1))]` struct enforces 88 B layout; a compile‑time `static_assert_eq!(size_of::<PmtpTensorDescriptor>(),88);`. | **Soft lock** – the crate `intel_simd` is gated behind the `target_feature="avx512f"` flag; on non‑Intel platforms the code compiles but panics at runtime. | `unsafe` block around the FFI boundary lacks `assert!(!desc_ptr.is_null())` and does not validate alignment (`align_of::<PmtpTensorDescriptor>() == 1`). |
| **kernel_cuda_v1350.cu** | The Woodbury‑scaled solve `W = (step/scale)·B` inserts `step` into a `double`‑precision matrix; for `|step|≥10¹⁰` the product exceeds the representable range of the *scaled* matrix `M/scale`, causing overflow in cuSOLVER’s `DnDsyevd`. | `step→0` yields a matrix with entries on the order of 10⁻³⁰–10⁻³⁵; cuSOLVER’s eigen‑solver treats these as exact zeros once the absolute tolerance (`eps≈10⁻⁶`) is reached, effectively freezing the subspace. | **Compliant** – the 88‑byte descriptor is transferred via `cudaMemcpy` with `cudaMemcpyHostToDevice` and a `static_assert(sizeof(PmtpTensorDescriptor)==88)`. | **Hard lock** – the kernel is compiled with `-arch=sm_80` and links to `cublas`/`cusolver`. It will not launch on AMD ROCm or on Nvidia GPUs older than Ampere, violating Rule 27. | The kernel uses `cudaLaunchCooperativeKernel` without a preceding `cudaDeviceSynchronize`; any prior error leaves the descriptor in an undefined state. |
| **kernel_xla_v1350.py** | The JIT‑compiled HLO performs a Lyapunov solve `A X + X Aᵀ = -Q`; the continuous‑time solution scales as `step⁻¹`. For `|step|≥10¹⁰` the RHS underflows to sub‑normal values that are flushed to zero on TPUs, producing a singular `X`. | For `step → 0` the HLO attempts to invert a matrix with condition number ≈ |step|⁻¹; the numerical precision (FP64) is insufficient, leading to catastrophic loss of 15+ bits. | **Compliant** – the Python wrapper packs the descriptor with `struct.pack("<4sHHQQQQQBB6x4Q", …)` and checks `len(buf)==88`. | **Soft lock** – the code uses `jax.jit` targeting only Cloud‑TPU (`tpu_client`) or AWS Trainium (`trainium_client`). The compilation path is gated by `jax.devices("tpu")` / `jax.devices("trainium")`; on other accelerators the JIT falls back to a CPU implementation, which is permitted but not performance‑equivalent. | No explicit `xla_bridge` sanity checks; the descriptor is passed to `xla_client` via a raw pointer that can be corrupted if the Python GC moves the buffer. |
| **kernel_triton_v1350.py** | The Triton kernel tiles memory in SRAM at a granularity of `tile_size = 2⁶`; for `|step|≥10¹⁰` the per‑tile scaling factor (`step / scale`) overflows the 32‑bit integer used to compute the tile offset, generating illegal memory accesses. | When `step` falls below the denorm threshold (`≈5e‑324`), the computed `scale_factor` underflows to 0, causing the rotation matrix to become identity; the Clifford bivector rotation collapses, violating algorithmic invariants. | **Compliant** – the descriptor is emitted with `torch.ops.triton.define_ptensor_descriptor` which asserts `size==88`. | **Hard lock** – Triton kernels are compiled with `--arch=sm_80` and `--target=rocm` separately; each binary is exclusive to the respective vendor, so a single deployment cannot run on both without shipping two binaries, a clear vendor‑lock. | The kernel uses `reinterpret_cast<uchar*>` on the descriptor without checking the `magic` field; a corrupted descriptor can lead to out‑of‑bounds reads of the SRAM tile. |

---

## 1. Numerical‑Degeneracy Analysis  

### 1.1 General Model  

All six kernels manipulate a **step‑scaled linear system** of the form  

\[
\mathbf{M}(\text{step}) = \frac{\text{step}}{\text{scale}}\,\mathbf{B},\qquad
\mathbf{W} = \mathbf{M}(\text{step})^{-1}\mathbf{v},
\]

with ancillary operations (Neumaier sums, Woodbury solves, Cayley retractions, Lyapunov solves, Clifford rotations).  

Define  

* \(s = \text{step}\) (real scalar, may be positive or negative)  
* \(\sigma = \text{scale} > 0\) (hardware‑derived normalisation)  
* Condition number of the base matrix \(\mathbf{B}\): \(\kappa(\mathbf{B})\).

The effective condition number of the system is  

\[
\kappa_{\text{eff}}(s) = \kappa(\mathbf{B})\;\frac{|s|}{\sigma}.
\]

When \(|s| \to \infty\) we have \(\kappa_{\text{eff}} \to \infty\); when \(|s| \to 0\) we have \(\kappa_{\text{eff}} \to 0\) (ill‑conditioned *inverse* problem).  

The *critical thresholds* are dictated by the floating‑point format of each component:

| Format | Max finite | Min normal | Min sub‑normal | FTZ threshold |
|--------|------------|------------|----------------|----------------|
| float64 (binary64) | 1.797 × 10³⁰⁸ | 2.225 × 10⁻³⁰⁸ | 4.940 × 10⁻³²⁴ | 1 × 10⁻³⁰⁸ (FTZ mode) |
| float32 (binary32) | 3.402 × 10³⁸ | 1.175 × 10⁻³⁸ | 1.401 × 10⁻⁴⁵ | 1 × 10⁻³⁸ |

All components operate in **FP64**, but the AVX‑512