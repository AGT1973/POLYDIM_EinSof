# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 83)

# POLYDIM V1350 — High Tribunal Audit, Cycle 83

**Presiding Sages:** Numerical Analysis, Systems/FFI, Heterogeneous Compute, Formal Methods.
**Verdict posture:** Adversarial. Claims are treated as unproven until the artifact is shown. Where the artifact is not in evidence, we audit the *specification as stated* and flag unverifiable claims.

---

## 0. Preliminary: what is actually auditable here

You have given us **six named targets and a set of claimed properties**, but no source. The Tribunal therefore rules as follows:

- **Claims of the form "12/12 physical conformance checks pass"** are *self-attested*. Without the check harness, the descriptor layout, and the byte-level dump, we cannot certify. We audit the *design* and enumerate the failure modes that would falsify the claim.
- **Claims of the form "Neumaier compensated dot products"** are auditable in principle (the algorithm is fixed), so we can bound error rigorously.
- **Claims of the form "Stiefel Cayley retraction via cuSOLVER DnDsyevd"** contain a *category error* that we flag immediately (see §4).
- **Claims of the form "pure FP64 on TPU"** are, as of the current public XLA/TPU contract, **false by construction** (see §5).

We proceed target by target.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us actually count the struct, because this is the one place where a byte-level claim is falsifiable by arithmetic alone.

| Field | Format | Size (bytes) |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Arithmetic checks out: 4+4+40+2+6+32 = 88.** Good. But the Tribunal raises three structural objections:

**(a) Alignment / ABI hazard.** With `struct` (not `ctypes.Structure` with explicit `_pack_`), CPython's `struct` module uses **no alignment padding** — it is a packed layout by definition. That is fine for a wire format, but the moment this descriptor is `memcpy`'d into a C++ `struct` with default alignment, the C++ compiler will insert padding to satisfy `alignof(uint64_t)=8`. The `6x` pad you wrote is *inside* the Python layout; the C++ side will want padding *before* the `4Q` block to reach an 8-byte boundary — which it already is (offset 50 → 56 after the 6-byte pad, then 32 bytes of Q). **Offset of the first `Q` in the trailing block is 56, which is 8-aligned. Offset of the leading `Q` block is 8, also aligned.** So the layout is *accidentally* ABI-safe on x86-64 SysV and AArch64 AAPCS. **But this is fragile**: any reordering of `HH`/`BB` breaks it. Recommendation: replace `6x` with an explicit `_reserved: [u8;6]` and add a `static_assert(sizeof(...) == 88)` in every consumer.

**(b) Endianness.** `<` forces little-endian. On a big-endian host (POWER9, some s390x), the descriptor will be silently misinterpreted. If POLYDIM claims multi-silicon portability, this is a **Rule 27 violation** (vendor/ISA lock to LE). Fix: either mandate LE in the contract, or emit a `>` variant and tag the magic.

**(c) Magic collision.** `4s` magic is only 32 bits. With six kernels and versioned descriptors, birthday collisions are a real risk across a fleet. Recommend 8-byte magic or a CRC32C trailer.

### 1.2 `PmtpSlabAllocator` — numerical degeneracy

A slab allocator is not a numerical object, so "step → ∞" does not apply directly. **However**, the *descriptor* carries `Q` fields that are almost certainly `step`, `scale`, `M`, `K`, `D`. If `step` is stored as `Q` (unsigned 64-bit), then:

- **`step → 0`**: unsigned cannot represent subnormals; the smallest nonzero is 1. If the contract intends `step` to be a *float* bit-pattern reinterpreted as `Q`, then `step = 0x0000_0000_0000_0001` is the smallest subnormal `2^-1074`. Any downstream code that does `1.0/step` will overflow to `+inf` and poison the Woodbury solve (see §4).
- **`step → ∞`**: `Q` max is `2^64-1 ≈ 1.8e19`, which exceeds your stated `10^10` threshold by 9 orders of magnitude. If `step` is a float bit-pattern, `0x7FF0_0000_0000_0000` is `+inf` and `0x7FF8...` is NaN. **The descriptor does not carry a type tag.** This is a **Rule 22 violation**: the inter-agent token is ambiguous.

**Recommendation:** add a 1-byte `dtype_tag` (0=f64, 1=f32, 2=u64) and a 1-byte `flags` (bit 0: step_is_reciprocal). This costs 2 bytes; reclaim them by shrinking the `6x` pad to `4x`.

### 1.3 Rule 22 compliance

Rule 22 as stated: *zero 1D tokens in inter-agent communication; 88-byte PMTP.* The descriptor is 88 bytes and is a **flat struct**, not a 1D token stream. **Compliant on its face.** But the Tribunal notes: the `4Q` trailing block is almost certainly a *vector* (e.g., a 4-element scale vector). If any consumer treats it as a 1D array and passes it through a channel that expects scalars, Rule 22 is violated at the *semantic* layer even though the *byte* layer is fine. **Demand:** a schema document mapping each field to its tensor rank.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

Neumaier's variant of Kahan–Babuška is:

```
s = 0; c = 0
for i: t = s + x_i*y_i
       if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
       else:                c += (x_i*y_i - t) + s
       s = t
return s + c
```

**Theorem (Neumaier 1974; Higham 2002, Thm 4.3).** For `n` terms with `|x_i y_i| ≤ M` and unit roundoff `u = 2^-53` (FP64), the computed sum satisfies

  `|ŝ - s| ≤ (2u + O(nu²)) · Σ|x_i y_i| + O(u²) · n · M`

i.e. **the error is essentially independent of `n`** to first order — the catastrophic cancellation term is removed. This is the correct claim to make. **But** the bound is *relative to Σ|x_i y_i|*, not to `|s|`. If the true dot product is `s ≈ 0` due to cancellation (e.g., `x = y = [1, -1, ε, -ε, ...]`), the *relative* error is still `O(u · Σ|x|/|s|)`, which can be `10^16`. **Neumaier does not save you from a genuinely ill-conditioned dot product.** The condition number is

  `κ_dot = Σ|x_i y_i| / |Σ x_i y_i|`

and no summation algorithm can beat `u · κ_dot`. **Demand:** the kernel must expose `κ_dot` as a diagnostic, and the orchestrator must reject `κ_dot > 10^12`.

### 2.2 Subnormal audits at `-12, -14`

You cite exponents `-12` and `-14`. In FP64, the subnormal range begins at `2^-1022 ≈ 2.2e-308`; `2^-12` and `2^-14` are **perfectly normal**. In FP32, subnormals begin at `2^-126`; again `2^-12`, `2^-14` are normal. **So what are `-12` and `-14`?** Two possibilities:

1. **They are decimal exponents** (`1e-12`, `1e-14`), i.e. test magnitudes. Then the audit is checking that the kernel does not lose precision at small-but-normal scales. Fine, but trivial.
2. **They are the exponents of the *smallest* values the kernel is expected to handle**, and the audit is checking that subnormals are flushed to zero (FTZ/DAZ). If so, **this is a Rule 27 hazard**: FTZ/DAZ behavior is controlled by `MXCSR` on x86 and `FPCR` on AArch64, and is **not portable**. A kernel that relies on FTZ for correctness will silently produce different results on a host that does not set it.

**Demand:** the audit must state whether `-12/-14` are decimal magnitudes or binary exponents, and must pin `MXCSR`/`FPCR` explicitly at kernel entry and restore at exit.

### 2.3 AVX-512 + OpenMP — vendor lock

AVX-512 is **Intel-only** on consumer silicon (AMD Zen 4 supports it, but Zen 1–3 do not; Apple Silicon does not; Graviton does not). If the C++ kernel is the *only* CPU path, **Rule 27 is violated**. The Rust and Triton kernels mitigate this, but the orchestrator must dispatch on `cpuid`/`HWCAP` and fall back. **Demand:** a `-march=armv8-a+sve2` or `-mavx2` fallback path, and a runtime feature probe that is *not* `__builtin_cpu_supports` alone (that misses AMD's AVX-512 disable on some SKUs).

### 2.4 Zero-copy PMTP validation

"Zero-copy" means the descriptor is passed by pointer and the payload is `mmap`'d or `io_uring`-registered. **The Tribunal's concern:** zero-copy + `88`-byte descriptor + multi-process orchestration is a **TOCTOU hazard**. If the descriptor is validated in process A and consumed in process B, and the underlying page is writable, an attacker (or a buggy peer) can mutate the descriptor between validation and use. **Demand:** `m