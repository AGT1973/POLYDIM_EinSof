# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 84)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 84 · Multi-File Adversarial SOTA Review

**Presiding note:** The Tribunal treats each target as a *claim of correctness* under adversarial step regimes, cross-language ABI, and vendor-neutrality. Where the source is not in evidence, we audit the *stated contract* and flag every place where the contract is under-specified, unprovable, or falsifiable by a single counterexample. We do not grant "SOTA" on assertion.

---

## 0. Cross-Cutting Findings (apply to all 6 targets)

### 0.1 Rule 22 — Zero 1D tokens / 88-byte PMTP
The 88-byte descriptor `<4sHHQQQQQBB6x4Q` decomposes as:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version | `H` | 2 | 4 |
| flags | `H` | 2 | 6 |
| n_rows | `Q` | 8 | 8 |
| n_cols | `Q` | 8 | 16 |
| stride | `Q` | 8 | 24 |
| offset | `Q` | 8 | 32 |
| scale_bits | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| dtype | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| reserved | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict:** Structurally 88 bytes, **but**:
- `struct.calcsize('<4sHHQQQQQBB6x4Q')` = 4+2+2+8·5+1+1+6+32 = **88** ✅ only if the platform is little-endian and `Q` is 8 bytes (guaranteed by `<`). Good.
- **Rule 22 violation risk:** `6x` padding is *implicit*; a naive `memcpy` from a C++ `#pragma pack(1)` struct with a different field order will silently misalign. The Tribunal demands a `static_assert(sizeof(PmtpTensorDescriptor)==88)` in C++/Rust and a `ctypes.sizeof` assertion in Python. **No target in the brief demonstrates this assertion.**
- **Zero 1D tokens:** The descriptor carries `n_rows, n_cols, stride` — a 1D tensor is representable as `n_cols=1`. The rule "zero 1D tokens" must therefore be enforced at the *orchestrator* level, not the descriptor. **TARGET 1 must reject `n_cols==1` at probe time.** Not shown.

### 0.2 Rule 27 — Silicon Contract / Vendor Lock
| Target | Vendor exposure | Verdict |
|---|---|---|
| 1 orchestrator | Multi-silicon probe (good) | ✅ if probe is *runtime*, not compile-time |
| 2 C++ AVX-512 | Intel/AMD only | ⚠️ **lock** unless scalar fallback exists |
| 3 Rust SIMD | portable via `std::simd`? | ⚠️ if `core::arch` intrinsics used |
| 4 CUDA | NVIDIA-only | ❌ **hard lock** unless HIP/ROCm path |
| 5 XLA | Google TPU + AWS Trainium | ⚠️ dual-vendor, but no CPU fallback shown |
| 6 Triton | AMD ROCm + NVIDIA | ✅ dual-vendor, but no CPU fallback |

**Tribunal ruling:** Rule 27 is satisfied only if **every** target has a documented scalar/portable fallback path selectable at runtime. TARGET 4 (CUDA) as described is a **prima facie Rule 27 violation** unless the orchestrator can route to TARGET 2/3/6 on non-NVIDIA silicon. The brief does not state this routing.

### 0.3 Numerical degeneracy — the universal step limit
Define the update `W ← W − step · G` (or Cayley/Woodbury equivalent). Three regimes:

**(a) step → 0 (subnormal):** For IEEE-754 binary64, subnormals live in `[2⁻¹⁰⁷⁴, 2⁻¹⁰²²)`. If `step < 2⁻¹⁰²²`, then `step · G` underflows to zero for `|G| < 1`, and the update is a **no-op**. Worse, Neumaier compensation *cannot* recover information destroyed by underflow — the low-order term is itself subnormal and loses bits. **Required:** a `step_floor = 2⁻¹⁰⁰⁰` clamp with a logged warning, or a rescaling `W ← W − (step·s)·(G/s)` with `s = 2^⌈log₂|step|⌉`.

**(b) step → ∞ (|step| ≥ 10¹⁰):** The Cayley retraction `Y = (I − (step/2)W)⁻¹(I + (step/2)W)` becomes **ill-conditioned**: `cond(I − (step/2)W) ≈ (step/2)·‖W‖`. For `step = 10¹⁰` and `‖W‖ = O(1)`, `cond ≈ 5·10⁹`, and the FP64 backward error is `≈ cond · ε ≈ 5·10⁹ · 2.2·10⁻¹⁶ ≈ 10⁻⁶`. **The retraction is no longer orthogonality-preserving to machine precision.** The Woodbury scaling `(M/scale)W = (step/scale)B` mitigates this *only if* `scale` is chosen as `scale = max(1, |step|·‖B‖)`. The brief does not specify the scale rule.

**(c) The critical regime:** `step ∈ [10⁻³⁰⁰, 10³⁰⁰]` is where Neumaier + Woodbury + Cayley are jointly stable. Outside it, **every target degenerates**, and the orchestrator must clamp.

**Tribunal demand:** A single `step_clamp(step) → [2⁻¹⁰⁰⁰, 10¹⁰]` with a documented `cond` budget must appear in TARGET 1 and be honored by all backends. Not shown.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe (multi-silicon)
**Claim:** detects AVX-512, CUDA, ROCm, TPU, Trainium.
**Audit:**
- AVX-512 detection via `cpuid` leaf 7 EBX bit 16 is **necessary but not sufficient** — must also check `XCR0` bits 5–7 (opmask, ZMM_Hi256, Hi16_ZMM) and `XGETBV`. A probe that skips `XGETBV` will mis-detect on hypervisors that mask AVX-512.
- CUDA detection via `cudaGetDeviceCount` is fine, but **must** also query `cudaDeviceGetAttribute(cudaDevAttrComputeCapabilityMajor)` — sm_70 vs sm_90 changes the optimal tile.
- TPU/Trainium detection cannot be done from Python alone; requires `libtpu.so` presence + `TPU_NAME` env. **Fragile.**

### 1.2 PmtpSlabAllocator
**Claim:** 88-byte descriptors, 12/12 physical conformance checks.
**Audit:**
- "12/12" is a *count*, not a *proof*. The Tribunal demands the 12 predicates be enumerated. Without them, this is **unfalsifiable**.
- Slab allocation of 88-byte objects: alignment must be ≥ 8 (for `Q` fields). If the slab uses `malloc`-style 16-byte alignment, fine; if packed, **misaligned `Q` loads** on some ARM64 configs trap. Demand `alignas(8)`.

### 1.3 Degeneracy
- Orchestrator must clamp `step` **before** dispatch. If it forwards `step=10¹⁵` to TARGET 4, the Cayley solve will produce `NaN` via `1/0` in the `(I − (step/2)W)⁻¹` factorization. **Critical.**

### 1.4 Rule 22 / 27
- Rule 22: ✅ if descriptor is the *only* inter-agent token. ⚠️ if any backend returns a Python `list` or `dict`.
- Rule 27: ✅ *if* probe is runtime and routing is dynamic. **Demand:** a `route(step, shape, silicon) → backend` function with a documented fallback chain.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot
Neumaier's algorithm:
```
s = 0; c = 0
for x, y in zip(a, b):
    t = s + x*y
    if |s| >= |x*y|: c += (s - t) + x*y
    else:            c += (x*y - t) + s
    s = t
return s + c
```
**Error bound:** `|result − exact| ≤ (2ε + O(nε²)) · Σ|aᵢbᵢ|`. This is **not** exact — it is *compensated*. For `n = 10⁶` and `ε = 2.2·10⁻¹⁶`, the bound is `≈ 4.4·10⁻¹⁰ · Σ|aᵢbᵢ|`. **If `Σ|aᵢbᵢ|` is large and the true sum is small (catastrophic cancellation), the relative error is unbounded.** The Tribunal demands a *condition number* report: `κ = Σ|aᵢbᵢ| / |Σaᵢbᵢ|`. If `κ > 10¹²`, Neumaier is insufficient; use Kahan-Babuška-Neumaier with *two* compensation terms or `long double`/`__float128`.

### 2.2 Subnormal audits (−12, −14)
The brief cites exponents −12 and −14. **These are not subnormal exponents** (subnormals start at −1022 for binary64). The Tribunal suspects these refer to *decimal* exponents in a test vector, i.e., `1e-12` and `1e-14`. **Clarification demanded.** If the intent is to test subnormal *inputs*, the test must use `2⁻¹⁰⁷⁴` and `2⁻¹⁰²²`, not `1e-12`.

### 2.3 Zero-copy PMTP validation
- Zero-copy requires the descriptor's `offset` and `stride` to be honored by the AVX-512 load. If the kernel uses `_mm512_load_ps` (aligned) on an unaligned `offset`, **segfault**. Must use `_mm512_load