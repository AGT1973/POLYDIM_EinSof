# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 164

I cannot produce a definitive arbitration of the eight Tribunal outputs because those findings, the six V1350 kernel specifications, and the PMTP descriptor layout were not provided, and no publicly verifiable V1350 specification appears in the available evidence. The available literature supports only general conclusions about Stiefel retractions and memory-ordering principles—not exact V1350 architectural guarantees.

### 1. Cayley retraction versus Householder/Polar QR at \(|\mathrm{step}|\ge 10^{10}\)

No method is unconditionally stable merely because it preserves orthogonality algebraically.

- **Cayley/Stiefel retraction:** A Cayley update typically has the form  
  \[
  X_{+}=(I-\tfrac12 W)^{-1}(I+\tfrac12 W)X,
  \]
  where \(W\) is skew-symmetric. It preserves orthogonality in exact arithmetic when the inverse exists. However, for extreme steps, the system can become poorly conditioned, overflow can occur in forming \(W\), and the result is highly sensitive to finite-precision scaling and solver accuracy.

- **Polar retraction:**  
  \[
  R_{\mathrm{polar}}(X,\Xi)
  =(X+\Xi)\bigl((X+\Xi)^{T}(X+\Xi)\bigr)^{-1/2}.
  \]
  It is usually the strongest general-purpose choice when \(X+\Xi\) remains numerically meaningful, because it explicitly projects onto the nearest orthonormal frame. The literature identifies polar decomposition as a standard Stiefel retraction and gives its computational cost and formula.[3]

- **Householder/QR:** QR is generally cheaper than polar decomposition and can be robust when implemented with blocked Householder reflectors and rank/conditioning checks. However, its result may depend on sign conventions, pivoting, and backend details. The standard QR retraction is \( \operatorname{qr}(X+\Xi) \).[3]

**Arbitrated guarantee:** none of the three can honestly guarantee finite, accurate output for arbitrary unscaled \(|\mathrm{step}|\ge10^{10}\). A defensible kernel contract is:

1. scale or normalize the tangent/update before factorization;
2. use Householder QR or a stabilized polar path for the primary projection;
3. detect nonfinite input, numerical rank deficiency, failed factorization, and excessive residual;
4. return an explicit status rather than silently claiming stability;
5. verify  
   \[
   \|X_{+}^{T}X_{+}-I\|\le \tau_{\mathrm{orth}}
   \]
   under the selected precision and tolerance.

If exact geometric fidelity is the priority, stabilized polar retraction is preferable. If throughput and broad accelerator support dominate, Householder QR is usually the better default. Cayley should be used only with a bounded-step or condition-number contract, not as an unconditional extreme-step solution.

### 2. PMTP 88-byte descriptors and RCU/QSBR snapshot isolation

An 88-byte size alone proves nothing about memory safety or snapshot isolation. The descriptor must define:

- immutable versus mutable fields;
- ownership and lifetime rules;
- publication order;
- version, generation, or epoch fields;
- alignment and atomicity requirements;
- reclamation eligibility;
- behavior on wraparound, ABA, cancellation, and failed publication.

For a correct RCU/QSBR design, the writer must fully initialize the snapshot before publishing its pointer or generation. Publication requires **release** semantics; readers must acquire the published pointer/version before dereferencing snapshot fields. Reclamation requires a grace-period mechanism proving that no reader can still hold the old snapshot.

A minimal abstract protocol is:

```text
Writer:
    initialize(new_snapshot)
    publish(pointer_or_generation, release)
    wait_until_all_required_readers_pass_a_quiescent_state()
    reclaim(old_snapshot)

Reader:
    enter_read_side_or_publish_quiescent_state()
    p = load(pointer_or_generation, acquire)
    read immutable snapshot through p
    leave_read_side()
```

Acquire/release ordering establishes visibility and ordering; it does **not**, by itself, provide reclamation safety. Sequential consistency is also not a substitute for an incorrect lifetime protocol. QSBR additionally requires every participating reader to report quiescence reliably; a stalled or non-reporting reader can prevent reclamation indefinitely.

**Arbitrated guarantee:** the descriptor can guarantee snapshot isolation only if its ABI specifies a complete publication, reader-registration, epoch/grace-period, and reclamation protocol. Without those fields and rules, “88-byte descriptor with acquire/release” is insufficient to claim RCU correctness.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single common memory or execution model across these environments. Conformance must therefore be defined at the **semantic contract** level, not by assuming that one source-level atomic operation has identical behavior everywhere.

A credible cross-silicon contract should separate:

- **numerical semantics:** precision, rounding, NaN/Inf behavior, signed zero, deterministic versus nondeterministic reductions;
- **layout semantics:** byte offsets, alignment, endianness, padding, and descriptor version;
- **concurrency semantics:** publication, acquisition, quiescence, reclamation, and permitted races;
- **failure semantics:** status codes, poison values, retry behavior, and invalid-input handling;
- **execution semantics:** synchronization scope, stream/queue ordering, barriers, and collective completion.

Recommended implementation rules:

- use a canonical serialized descriptor layout with compile-time size and offset assertions;
- avoid relying on language-ABI padding;
- provide separate host/device implementations where atomic scopes differ;
- use backend-specific lowering for CUDA and Triton;
- treat XLA operations as subject to compiler scheduling unless the required ordering is represented by supported HLO/token or collective semantics;
- use C++20 atomics only with explicitly selected memory orders and documented lifetime rules;
- use Rust atomics and ownership types for host-side safety, while recognizing that unsafe device interfaces still require an external memory model;
- validate every backend against litmus tests and numerical residual tests, not merely compilation.

### Definitive synthesis

The strongest defensible SOTA architecture is therefore:

1. **Retraction:** stabilized polar or Householder QR with scaling, rank checks, residual verification, and explicit failure status. Cayley is conditional, not universally extreme-step stable.
2. **Snapshot protocol:** release publication, acquire consumption, explicit QSBR/RCU grace-period tracking, and reclamation only after a proven grace period. Acquire/release alone is not sufficient.
3. **Portability:** a versioned, canonical descriptor ABI plus a backend-specific conformance suite covering layout, atomics, synchronization, numerical tolerances, and failure behavior.
4. **Guarantee boundary:** guarantee orthogonality, visibility, isolation, and portability only under stated bounds and preconditions; never claim unconditional guarantees for arbitrary \(10^{10}\)-scale updates, stalled readers, failed factorization, compiler-reordered operations, or unspecified device scopes.

The publicly available Stiefel-retraction sources support the distinction between Cayley, polar, and QR methods, including their differing formulas and costs.[1][2][3] They do not substantiate the existence or exact specification of “POLYDIM V1350,” the six kernels, the PMTP 88-byte descriptor, or the eight cited Tribunal reports.