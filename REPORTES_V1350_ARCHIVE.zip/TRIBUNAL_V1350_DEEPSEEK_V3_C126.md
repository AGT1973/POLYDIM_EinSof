# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 126)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 126 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been given six artifacts and asked to render judgment on (i) numerical degeneracy at the extremes of `step`, (ii) Rule 22 (88-byte PMTP, zero 1-D tokens), (iii) Rule 27 (Silicon Contract / vendor-lock), and (iv) to demand proofs, condition-number asymptotics, and FFI hardening. We proceed file-by-file, then render a consolidated verdict. Where the artifacts are described only by their spec (as here), we audit the *specification as stated* and flag every claim that is not self-evidently provable from the description.

---

## 0. Notation and standing assumptions

- `step ∈ ℝ` is the Cayley/retraction step (a.k.a. `τ` in the Stiefel literature).
- `M ∈ ℝ^{2K×2K}` is the (skew-symmetric, by construction) generator; `B` is the right-hand side.
- `scale = ‖M‖_F` (or `‖M‖_2`; the spec is ambiguous — **flag A1**).
- `W` solves `(M/scale) W = (step/scale) B`.
- `ε_mach ≈ 2.22e-16` (FP64), `ε_mach ≈ 1.19e-7` (FP32), `ε_mach ≈ 9.77e-4` (FP16/BF16).
- Subnormal thresholds: FP64 `≈ 2.2e-308`, FP32 `≈ 1.2e-38`, FP16 `≈ 6.1e-5`.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us *count bytes* — the Tribunal does not accept "it fits" without arithmetic.

| Field | Format | Size (bytes) |
|---|---|---|
| magic | `4s` | 4 |
| version_major | `H` | 2 |
| version_minor | `H` | 2 |
| flags | `Q` | 8 |
| n_rows | `Q` | 8 |
| n_cols | `Q` | 8 |
| stride | `Q` | 8 |
| offset | `Q` | 8 |
| dtype | `B` | 1 |
| layout | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

**Verdict:** byte-count is *correct* under CPython's default `struct` alignment (`=` prefix implied by absence of `@`). **However — flag A2:** if the descriptor is ever passed through `struct.pack('@4sHHQQQQQBB6x4Q', …)` on a platform where `Q` requires 8-byte alignment, the compiler will insert padding *before* the first `Q` (after `HH`), yielding **96 bytes**, not 88. The spec must pin `=` (standard size, no alignment) or `!` (network) explicitly. This is a **Rule 22 violation risk** at the ABI boundary.

### 1.2 Multi-silicon HardwareProbe

The probe enumerates CPU/GPU/TPU/Trainium. **Flag A3:** the probe must be *pure* (no side effects on device state) and *idempotent*; otherwise the 12/12 conformance check is not reproducible. Demand a `probe_fingerprint()` returning a stable hash of `(vendor, arch, driver, fp64_ratio, subnormal_support)`.

### 1.3 PmtpSlabAllocator

Slab allocation of 88-byte descriptors implies **alignment to 88** or to a cache line (64 B). 88 is not a divisor of 64, so consecutive descriptors straddle cache lines. **Recommendation:** pad to 128 B (two cache lines) *in the slab*, while keeping the *wire* format at 88 B. This decouples Rule 22 (wire) from performance (memory).

### 1.4 Numerical degeneracy at `step → ∞` / `step → 0`

The orchestrator itself does no arithmetic, but it *routes* `step`. **Flag A4:** the orchestrator must clamp `step` to `[step_min, step_max]` *before* dispatch, with `step_min = 2^-1000` (well above FP64 subnormal) and `step_max = 2^1000`. Otherwise downstream kernels receive `inf`/`0` and the 12/12 conformance check is vacuous.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:

```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
    else:                c += (x_i*y_i - t) + s
    s = t
return s + c
```

**Theorem (Neumaier 1974).** For `n` terms, the compensated sum satisfies
`|ŝ − s| ≤ (2ε + O(nε²)) · Σ|x_i y_i|`.
This is **first-order accurate in ε**, independent of `n` — a strict improvement over naive summation's `nε` bound.

**Asymptotic condition number.** For the dot product `d = xᵀy`, the *relative* condition number is
`κ(d) = (‖x‖₂ ‖y‖₂) / |xᵀy| = 1/|cos θ|`.
As `θ → π/2` (near-orthogonal vectors), `κ → ∞`. Neumaier compensation does **not** fix this — it only removes *summation* error, not *cancellation* error. **Flag B1:** the kernel must expose `κ_estimate = ‖x‖₂‖y‖₂ / (|d| + ε)` and refuse to certify results when `κ > 1/√ε ≈ 6.7e7`.

### 2.2 Subnormal audits at `-12`, `-14`

These are presumably exponents: `2^-12 ≈ 2.44e-4`, `2^-14 ≈ 6.10e-5`. In FP64 these are **normal**, not subnormal. **Flag B2:** the audit labels are misleading. If the intent is FP16 subnormal territory, the exponents should be `-14` (FP16 min normal) and `-24` (FP16 min subnormal). If the intent is FP32, use `-126` and `-149`. **Demand a unit test** that asserts `fpclassify(x) == FP_SUBNORMAL` at the claimed thresholds.

### 2.3 AVX-512 + OpenMP

**Flag B3:** AVX-512 downclocking on Intel Skylake-X/Ice Lake can reduce sustained throughput by 15–40%. The kernel must expose a `--no-avx512` fallback path (AVX2 + FMA) and a runtime `cpuid` dispatch. Otherwise Rule 27 (Silicon Contract) is violated *de facto* by performance vendor-lock.

### 2.4 Zero-copy PMTP validation

Zero-copy implies the 88-byte descriptor is `mmap`'d or `memcpy`'d once. **Flag B4:** validation must include a **CRC-64/XZ** over the 88 bytes, checked *before* any pointer dereference. Otherwise a malformed descriptor yields a wild pointer — a security, not just numerical, defect.

### 2.5 Degeneracy analysis

- **`step → ∞`:** the C++ core computes `M·step`. If `step = 1e10` and `‖M‖ ~ 1`, `‖M·step‖ ~ 1e10` — fine in FP64. If `step = 1e300`, overflow to `inf`. **Require:** `step` clamped to `2^1000` at the FFI boundary.
- **`step → 0`:** `step = 1e-320` is subnormal; multiplication by `M` loses precision. **Require:** `step` clamped to `2^-1000` (normal).

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` FFI safety barrier

**This is the single most important finding of the audit.**

Rust's `panic = unwind` across an `extern "C"` boundary is **undefined behavior** unless the panic is caught at the boundary. The Rust Reference (and RFC 2945, `C-unwind` ABI) is explicit: unwinding into C++ is UB unless the C++ side is compiled with `-fexceptions` and the frame is `noexcept`-aware.

**Concrete hardening (mandatory):**

```rust
#[no_mangle]
pub extern "C" fn poly_kernel_entry(desc: *const u8) -> i32 {
    let result = std::panic::catch_unwind(|| {
        // ... kernel body ...
    });
    match result {
        Ok(v) => v,
        Err(_) => -1, // sentinel; never unwind across FFI
    }
}
```

Additionally:
- Set `panic = "abort"` in `[profile.release]` for the *FFI-facing* crate, **or**
- Use `extern "C-unwind"` (Rust 1.71+) on both sides and compile C++ with `-fexceptions`.

**Flag C1:** the spec's phrase "panic=unwind FFI safety barrier" is *self-contradictory* as written. `panic=unwind` is the *default*; the *barrier* is `catch_unwind`. Demand the spec be rewritten.

### 3.2 Safe SIMD

Rust's `std::simd` is nightly-only. If the kernel uses `core::arch::x86_64::*`, it is `unsafe`. **Flag C2:** "Safe SIMD" is a misnomer unless the kernel uses `wide` or `pulp` crates. Demand a `#![forbid(unsafe_code)]` audit — if it fails, the claim is false.

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` on an 88-byte struct is fine, but **taking a reference to a packed field is UB** (E0793). **Flag C3:** all field access must be by-value (`let x = desc.field;`) or via `read_unaligned`. Demand a `cargo clippy -- -D clippy::cast_ptr_alignment` gate.

### 3.4 Degeneracy

Same as Target 2: clamp `step` at the FFI boundary. Rust's `f64::is_subnormal()` is the correct predicate; use it in a debug assertion.

---

## TARGET 4 — `kernel_cuda_v