# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 70)

# POLYDIM V1350 — High Tribunal Audit, Cycle 70

**Presiding note.** The Tribunal treats the six artifacts as *claimed* implementations. Where source is not in evidence, we audit the *specification as stated* and flag every claim that is not self-certifying. Verdicts are per-target, then consolidated.

---

## 0. Preliminary: what the spec actually commits to

Three invariants recur and must be checked against every target:

- **(I1) 88-byte descriptor** `<4sHHQQQQQBB6x4Q` — let us first verify the struct is even 88 bytes, because if it is not, every downstream "12/12 conformance" claim is vacuous.

```
4s   = 4
H    = 2
H    = 2
Q    = 8
Q    = 8
Q    = 8
Q    = 8
Q    = 8
B    = 1
B    = 1
6x   = 6
4Q   = 32
----------------
sum  = 4+2+2+8+8+8+8+8+1+1+6+32 = 88   ✓
```

Struct size is 88 bytes **iff** the compiler does not insert padding. Under `#pragma pack(1)` / `__attribute__((packed))` / Rust `#[repr(C, packed)]` this holds. Under default alignment, `Q` fields force 8-byte alignment and the two `B` bytes plus `6x` will be re-padded — the struct becomes 96 bytes. **This is the first hard finding.**

> **F1 (Critical, cross-cutting).** The 88-byte claim is *only* true under explicit packing. Any target that declares the descriptor without `packed`/`repr(C,packed)` silently violates Rule 22. The Tribunal requires a static assertion in every language:
> - C/C++: `static_assert(sizeof(PmtpTensorDescriptor)==88);`
> - Rust: `const _: () = assert!(core::mem::size_of::<PmtpTensorDescriptor>()==88);`
> - Python: `assert struct.calcsize("<4sHHQQQQQBB6x4Q")==88` at import time.
> - CUDA: same `static_assert` in the `.cu` TU.
> - Triton/XLA: descriptor is opaque; must be validated at the host boundary.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe
Probing CPU/GPU/TPU/Trainium/ROCm from Python is inherently racy: `torch.cuda.is_available()` can return `True` while the driver is in a wedged state. **Recommendation:** probe must be *idempotent and cached*, and must record a monotonic `probe_epoch` in the descriptor (one of the `Q` fields) so downstream kernels can detect stale topology.

### 1.2 PmtpSlabAllocator
Slab allocation of 88-byte descriptors is a **cache-line pathology**: 88 = 64 + 24, so two descriptors straddle three cache lines. Under concurrent producers (Rule 22 inter-agent traffic) this is a false-sharing generator.

> **F2 (High).** Either (a) pad descriptors to 128 bytes for the *transport* representation while keeping 88 bytes for the *wire* representation, or (b) allocate slabs at 88-byte stride but align the slab base to 128 and accept 40 bytes of tail waste per 128-byte line. The Tribunal prefers (a): wire format stays 88, in-memory format is 128, with an explicit `pack`/`unpack` at the FFI boundary.

### 1.3 12/12 physical conformance checks
Without the check list we can only audit the *claim structure*. A 12/12 pass is meaningless unless the checks are:
1. **Independent** (no check is a linear combination of others),
2. **Falsifiable** (each has a negative control),
3. **Ordered** (cheap checks first, so a failure short-circuits).

Demand: publish the 12 checks with their negative controls. Until then, mark **UNVERIFIED**.

### 1.4 Degeneracy at step → ∞ / step → 0
The orchestrator itself does not do arithmetic, but it *routes* `step`. If `step` is serialized into a `Q` (uint64) field, then:
- `step → ∞` in the mathematical sense is representable only up to `2^64−1`. A float `step` of `1e10` fits, but `1e300` does not. **The descriptor must declare whether `step` is fixed-point (Q) or IEEE-754 (needs a `d` field).** The current layout has no `d` — so `step` is *integer*. This is a silent semantic narrowing.

> **F3 (High).** If the algorithm requires `step ∈ ℝ`, the 88-byte descriptor is *insufficient*. Either add a `d` (double) field — which breaks the 88-byte invariant — or carry `step` out-of-band. The Tribunal notes the spec is internally inconsistent here.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product
Neumaier's variant of Kahan is *not* unconditionally better than Kahan; it is better when the running sum is smaller in magnitude than the addend. The compensation term `c` accumulates the *lost* low-order bits. Asymptotic error:

For a dot product of length `n` with condition number `κ = Σ|xᵢyᵢ| / |Σxᵢyᵢ|`, Neumaier gives

  |fl(Σxᵢyᵢ) − Σxᵢyᵢ| ≤ (2u + O(nu²)) · Σ|xᵢyᵢ|,

i.e. **error is bounded by the absolute sum, not the signed sum** — this is the key win. The *relative* error is `O(u·κ)`, so for `κ → ∞` (catastrophic cancellation) Neumaier still loses all relative accuracy. **Neumaier does not cure cancellation; it only prevents the compensation itself from cancelling.**

> **F4 (Medium).** For the Stiefel/Woodbury path where `κ` can be `10^10+`, Neumaier is insufficient. Require either (a) double-double (Dekker/Knuth) accumulation, or (b) a *reproducible* summation (Demmel–Nguyen) if bitwise determinism is required across AVX-512 lanes.

### 2.2 AVX-512 lane reduction
`_mm512_reduce_add_pd` is **not** associative across microarchitectures (Intel vs AMD Zen4 implement different reduction trees). If the kernel claims bitwise reproducibility, this is a violation.

> **F5 (High).** Either pin to a single microarch (vendor-lock — see Rule 27) or implement a deterministic tree reduction manually.

### 2.3 Subnormal audits at −12, −14
Subnormals (denormals) below `2^-1022` in FP64. The exponents −12 and −14 suggest **FP32** subnormals (`2^-126` region) or a *scaled* representation. If the kernel is FP64, −12/−14 are *normal* numbers and the "subnormal audit" is mislabeled.

> **F6 (Medium).** Clarify the exponent base. If FP32, then AVX-512 `vfmadd` with FTZ/DAZ set will silently flush subnormals — a correctness bug. Require `_MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_ON)` to be *explicitly disabled* and audited.

### 2.4 Zero-copy PMTP validation
Zero-copy means the 88-byte descriptor is `mmap`'d or `memcpy`'d directly into the kernel. This requires:
- The descriptor is **POD** (it is, under packing).
- Endianness is fixed (the `<` in the format string says little-endian — good).
- The producer cannot mutate the descriptor while the consumer reads it. **This requires a seqlock or RCU discipline, not just zero-copy.**

> **F7 (High).** Zero-copy without a memory-ordering protocol is a data race. Demand `std::atomic<uint64_t>` sequence numbers in two of the `Q` fields (producer seq, consumer ack).

### 2.5 step → ∞ / step → 0
In the C++ core, `step` is likely a `double`. At `step = 1e10`, `step² = 1e20` — still finite in FP64 (max ~1.8e308), but `step⁴ = 1e40` is fine, `step⁸ = 1e80` fine, `step¹⁶ = 1e160` fine, `step³² = 1e320` **overflows**. If the Cayley retraction or Woodbury solve involves `step^k` for `k ≥ 32`, overflow is guaranteed.

> **F8 (Critical).** The Woodbury solve `(M/scale) W = (step/scale) B` is *scaled* precisely to avoid this — good. But the scaling factor `scale` must be chosen as `scale = max(|step|, ‖M‖_F, ‖B‖_F)` and must be recomputed per iteration. A *static* scale will fail at `step = 1e10`. Demand a dynamic scale with a documented overflow guard.

At `step → 0`: if `step` is subnormal (`< 2^-1022`), then `step/scale` underflows to zero and the solve returns `W = 0` — a silent wrong answer. **Demand an explicit `if (|step| < 2^-1000) return identity_retraction;` guard.**

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier
This is **backwards**. `panic = unwind` across an FFI boundary is *undefined behavior* in Rust unless the boundary is `extern "C-unwind"` (stabilized 1.71). The correct barrier is `panic = abort` at the FFI edge, or `catch_unwind` at every `extern "C"` entry point.

> **F9 (Critical).** The spec's claim that `panic = unwind` is a "safety barrier" is **false**. It is a safety *hazard*. Demand:
> ```rust
> #[no_mangle]
> pub extern "C" fn kernel_entry(...) -> i32 {
>     match std::panic::catch_unwind(|| { ... }) {
>         Ok(_) => 0,
>         Err(_) => -1,
>     }
> }
> ```
> with `panic = "abort"` in the release profile.

### 3.2 Safe SIMD
Rust's `std::simd` is still nightly-only as of 2024