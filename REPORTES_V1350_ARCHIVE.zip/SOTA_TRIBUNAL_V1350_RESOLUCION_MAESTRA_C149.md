# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 149

I cannot produce a definitive arbitration of the eight Tribunal models because their individual reports, the six kernel specifications, and the V1350 memory-model contract were not provided. Publicly searchable material does not establish an authoritative “POLYDIM V1350” specification; one search result instead points to an unrelated PolyDiM PDE library, while another appears to be an unverified repository document rather than a normative standard. The following is therefore a **conditional engineering synthesis**, not a validated Cycle 149 ruling.

## 1. Cayley–Stiefel retraction under extreme steps

For \(X \in \mathrm{St}(n,p)\), a valid update must preserve

\[
X^{\mathsf T}X = I_p
\]

up to the implementation’s stated floating-point tolerance. A Cayley transform has the form

\[
X_{+}
=
\left(I-\frac{\tau}{2}W\right)^{-1}
\left(I+\frac{\tau}{2}W\right)X,
\qquad W^{\mathsf T}=-W,
\]

or an algebraically equivalent low-rank formulation.

The key arbitration point is:

- **Mathematically**, the Cayley map preserves the Stiefel constraint for every finite \(\tau\) for which the inverse exists.
- **Numerically**, this does not imply stability as \(|\tau|\to\infty\). The matrix solve, low-rank system, overflow behavior, conditioning, and finite-precision representation determine the result.
- A claim of unconditional stability for \(|\tau|\ge 10^{10}\) is unjustified unless the implementation uses a scale-invariant formulation and supplies error bounds or tested condition-number limits.

### Recommended ruling

The Cayley implementation should be accepted over Householder or polar QR for extreme steps **only under these conditions**:

1. The update is evaluated after scaling:
   \[
   \widehat W = W/\alpha,\qquad \widehat\tau=\tau\alpha,
   \]
   with \(\alpha\) selected to avoid overflow and excessive dynamic range.
2. The inverse is never formed explicitly; a stable factorization or orthogonal-solver path is used.
3. The result is checked with
   \[
   \|X_{+}^{\mathsf T}X_{+}-I\| \le \varepsilon_{\mathrm{orth}}
   \]
   and a finite-value check.
4. A fallback is defined for singular or ill-conditioned reduced systems.

For very large steps, the limiting Cayley action approaches a sign-like transformation on the relevant subspace; it does **not** automatically become a better optimizer step. A bounded or trust-region step policy is still required.

Householder QR is generally the strongest **re-orthogonalization fallback** because it avoids explicitly forming \(X^{\mathsf T}X\) and is backward stable. Polar iteration can be competitive, but its guarantee depends on scaling, iteration count, and convergence safeguards. Thus the defensible hierarchy is:

\[
\text{scaled Cayley update}
\;\to\;
\text{orthogonality/error validation}
\;\to\;
\text{Householder QR fallback}.
\]

No architecture can honestly guarantee “stability” for arbitrary \(10^{10}\)-scale inputs without specifying precision, conditioning, overflow policy, and failure behavior.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte layout alone provides **no memory-ordering guarantee**. Correct snapshot isolation requires a protocol, not merely a descriptor size.

A sound publication protocol is:

1. Writer constructs the new immutable descriptor and all referenced payload.
2. Writer performs a **release publication** of the descriptor pointer or generation.
3. Reader performs an **acquire load** of that publication field.
4. Reader enters the applicable RCU/QSBR read-side critical section before dereferencing.
5. Writer retires the old descriptor only after a grace period in which every pre-existing reader has passed through a quiescent state.

In C++ terms, the essential relation is conceptually:

```cpp
published.store(new_descriptor, std::memory_order_release);
auto p = published.load(std::memory_order_acquire);
```

Acquire/release orders visibility; it does not itself provide reclamation. Reclamation requires RCU/QSBR grace-period correctness. Existing QSBR implementations explicitly require readers to register, report quiescent states, and allow the writer to wait until readers have observed the relevant grace-period state.[2][10]

### Exact guarantee that can be made

If the protocol is implemented correctly:

- A reader that acquires generation \(g\) observes a self-consistent immutable snapshot of generation \(g\).
- No object reachable from that snapshot is reclaimed before the reader exits its read-side critical section and the corresponding grace period completes.
- A later publication cannot partially overwrite the reader’s immutable snapshot.

### Guarantees that cannot be inferred

The following do **not** follow from “Acquire/Release” alone:

- atomicity of an 88-byte descriptor;
- immunity to torn reads if the descriptor is copied non-atomically;
- safe reclamation without reader registration/quiescent-state reporting;
- cross-device visibility between CPU, CUDA, XLA, or Triton;
- ordering of ordinary non-atomic fields absent a release/acquire chain.

The practical design should therefore publish a pointer, index, or compact generation atomically and keep the 88-byte object immutable after publication. If the descriptor itself must be atomically replaced, its representation and supported atomic width must be specified separately.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single portable memory model spanning all five environments. “Conformance” must be defined as a layered contract:

| Layer | Required guarantee |
|---|---|
| C++20 | Correct happens-before relations, atomics, lifetime, and reclamation protocol |
| Rust | No data races under Rust’s ownership/atomic rules; unsafe FFI boundaries explicitly specified |
| CUDA | Correct host/device transfer, stream/event synchronization, and device-scope or system-scope atomics where required |
| Triton | Kernel-level synchronization and memory effects supported by the target backend; no assumption that CPU-style RCU applies inside a kernel |
| XLA | Semantics expressed through supported HLO/custom-call/collective mechanisms; compiler scheduling and buffer aliasing must be respected |

A CPU C++ release store does not automatically publish data to a GPU kernel. Conversely, a device fence does not automatically establish a C++ host-thread happens-before edge. The bridge must be explicit: stream/event synchronization, host callbacks, mapped-memory rules, or a documented system-scope atomic protocol.

### Required conformance tests

A credible V1350 conformance suite would need to test:

- orthogonality residuals across precisions and extreme-step ranges;
- NaN, infinity, overflow, and singular reduced-system behavior;
- publication/read races under stress;
- delayed readers crossing multiple descriptor generations;
- reclamation only after QSBR/RCU grace periods;
- host-to-device and device-to-host visibility;
- compiler optimization and aliasing behavior in XLA and Triton;
- identical generation and checksum results across CUDA, XLA, Triton, C++20, and Rust;
- negative tests proving that missing acquire, release, fence, or quiescent-state operations fail the contract.

## Arbitration

The strongest defensible synthesis is:

1. **Cayley** is the preferred constrained-update mechanism when implemented with scaling, stable solves, residual checks, and a Householder fallback. It is not unconditionally stable merely because the exact Cayley transform is orthogonal.
2. **Householder QR** is the preferred numerical recovery path for loss of orthogonality. Polar QR is acceptable only with a specified convergence and conditioning policy.
3. **Acquire/release** is necessary for PMTP publication but insufficient for snapshot reclamation. RCU/QSBR grace periods and immutable post-publication descriptors are mandatory.
4. **88 bytes** is a layout constraint, not an atomicity or isolation guarantee.
5. **Cross-silicon conformance** requires an explicit interop protocol; no universal guarantee can be claimed by translating the same algorithm into five programming systems.
6. The exact architectural guarantee should be stated conditionally:

\[
\boxed{
\text{valid snapshot}
+
\text{safe reclamation}
+
\text{Stiefel residual bound}
+
\text{defined cross-runtime synchronization}
}
\]

Only when all four are specified and tested may V1350 be called conformant. The available evidence is insufficient to rank the eight named Tribunal models or certify any stronger, unconditional SOTA claim.