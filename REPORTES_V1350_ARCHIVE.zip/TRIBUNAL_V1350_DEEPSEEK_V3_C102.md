# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 102)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 102 · Six-Component Adversarial SOTA Review

**Presiding note.** The Tribunal treats every claim as unproven until a bound, a proof sketch, or a falsifying counterexample is supplied. Where the architecture asserts "12/12 conformance," we demand the *witness* for each of the 12. Where it asserts "zero-copy," we demand the *aliasing contract*. Where it asserts "pure FP64," we demand the *ULP budget*.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Layout claimed: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version_major | `H` | 2 | 4 |
| version_minor | `H` | 2 | 6 |
| flags | `Q` | 8 | 8 |
| n_rows | `Q` | 8 | 16 |
| n_cols | `Q` | 8 | 24 |
| stride | `Q` | 8 | 32 |
| dtype | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| ndim | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| aux[4] | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict:** Structurally sound *only if* the compiler honors `alignas(8)` and no implicit padding is inserted between `BB` and `6x`. Under C++20 `[[gnu::packed]]` or Rust `#[repr(C, packed)]` this is exact; under default `#[repr(C)]` on x86-64 the trailing `4Q` will be 8-aligned and the struct will be **88 bytes only if `6x` is honored as explicit padding**. **Recommendation:** add `static_assert(sizeof(...) == 88)` in C++, `const _: () = assert!(size_of::<...>() == 88);` in Rust, and a runtime `struct.calcsize("<4sHHQQQQQBB6x4Q") == 88` in Python. Without these, the "12/12 conformance" claim is unverifiable.

### 0.2 Rule 22 — Zero 1D tokens

Rule 22 forbids 1D token streams in inter-agent communication. The 88-byte descriptor is a **fixed-width record**, not a token stream — compliant *provided* every inter-agent message is a concatenation of whole 88-byte records. **Falsifier to demand:** any code path that emits a variable-length header, a length-prefixed blob, or a JSON envelope violates Rule 22. Audit each FFI boundary for `memcpy(dst, &desc, sizeof(desc))` with `sizeof == 88` and no surrounding framing.

### 0.3 Rule 27 — Silicon Contract / vendor lock

Rule 27 forbids vendor lock. **This is the single largest risk in the architecture.** Targets 4 (CUDA), 5 (XLA/TPU/Trainium), and 6 (ROCm/Triton) are each vendor-anchored. The Tribunal's position: **Rule 27 is satisfied only if the descriptor and the numerical contract are vendor-neutral, and each vendor kernel is a *drop-in* behind a common ABI.** We audit each below.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe
Probing CPU/GPU/TPU/NPU at runtime is fine, but the probe must be **deterministic and side-effect-free**. Risks:
- `torch.cuda.is_available()` initializes CUDA context → violates "probe" semantics and can deadlock under `fork()`.
- TPU probe via `libtpu` may allocate HBM.

**Recommendation:** probe via `/sys/class/...`, `nvidia-smi -L` (subprocess, no context), `rocm-smi`, and `lspci` only. Never import the vendor runtime during probe.

### 1.2 PmtpSlabAllocator
A slab allocator for 88-byte descriptors is correct *only if*:
- Alignment is 8 (not 64) — otherwise 88-byte records waste 24 bytes each.
- Free-list is lock-free or per-thread; otherwise the orchestrator serializes.
- **Degeneracy:** if `step → ∞` causes descriptor churn (one descriptor per step), the slab must be sized `O(steps)` or recycled. If `step ≥ 10^10`, an unbounded slab is a memory bomb.

**Proof obligation:** show `slab_capacity = O(active_tensors)` independent of `step`.

### 1.3 12/12 physical conformance checks
The Tribunal demands the *list*. Without it, "12/12" is a marketing claim. Minimum expected set:
1. `sizeof == 88`
2. `alignof == 8`
3. magic == `b"PMTP"`
4. version in supported range
5. `n_rows * n_cols` fits in `u64`
6. `stride >= n_cols * dtype_size`
7. `dtype ∈ {FP64, FP32, BF16, ...}`
8. `rank <= 4`
9. `ndim <= 4`
10. aux[0] reserved == 0
11. endianness tag matches host
12. checksum over bytes [0,88) matches aux[3]

If any of these is missing, the claim is **unsubstantiated**.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

Neumaier's variant of Kahan gives, for `n` terms with unit roundoff `u = 2^-53` (FP64):

```
|fl(x·y) - x·y| ≤ (2u + O(n u²)) · Σ|x_i y_i| + O(u²) · Σ|x_i y_i|
```

The compensated sum reduces the *summation* error from `O(n u)` to `O(u)` **independent of n**, but the *product* error `x_i y_i` remains `O(u)` per term. **Asymptotic condition number:**

```
κ_dot = (Σ|x_i y_i|) / |Σ x_i y_i|
```

For ill-conditioned dot products (`κ_dot → ∞`), Neumaier does **not** save you — it only removes the accumulation drift. **Falsifier:** construct `x = [1, 1e16, -1e16]`, `y = [1, 1, 1]`. Neumaier returns `1` exactly; naive returns `0`. Good. Now `x = [1e308, 1e308, -1e308, -1e308]` — overflow in the product, Neumaier cannot recover. **Recommendation:** add a scaling pre-pass when `max|x_i y_i| > 1e300`.

### 2.2 Subnormal audits at `-12`, `-14`

Subnormals in FP64 begin at `2^-1022 ≈ 2.2e-308`. "Audit at -12, -14" presumably means exponents `2^-12`, `2^-14` — these are **normal**, not subnormal. **The audit is mislabeled.** If the intent is `1e-12`, `1e-14`, those are also normal. **Falsifier:** the only way to hit subnormals is `|x| < 2.2e-308`. Demand the actual test vectors.

### 2.3 `step → ∞` degeneracy

If `step ≥ 10^10` and the kernel computes `step * B` or `step * grad`, FP64 overflows at `step > 1.8e308`. More insidiously, `step * B` with `B ~ 1e-300` loses precision: the product is fine, but `step + B` (if ever formed) is catastrophic. **Recommendation:** enforce `|step| ≤ 1e8` at the ABI, or use a scaled representation `(step, scale)` with `step = step_scaled * scale`.

### 2.4 `step → 0` degeneracy

If `step < 2^-1022`, it becomes subnormal and loses mantissa bits. If `step < 2^-1074`, it flushes to zero. **Recommendation:** clamp `|step| ≥ 2^-1000` or use a log-domain step.

### 2.5 Zero-copy PMTP validation

"Zero-copy" means the kernel reads the descriptor in-place. **Aliasing contract required:** the caller must guarantee the 88 bytes are not mutated during the kernel's lifetime. Without `restrict` or a documented `const` contract, this is UB under C++20. **Recommendation:** `const PmtpDescriptor* __restrict__`.

### 2.6 AVX-512 / OpenMP
- AVX-512 downclocking on Intel Skylake-X: a real perf hazard. On Ice Lake+ it's fine.
- OpenMP `#pragma omp parallel for` with `schedule(static)` is fine; `schedule(dynamic)` on a 88-byte-record loop is catastrophic.
- **Vendor lock:** none — AVX-512 is x86, OpenMP is portable. **Rule 27: PASS.**

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

**This is a serious bug.** `panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is `extern "C-unwind"` (stabilized in Rust 1.71). If the C++ side calls a Rust `extern "C"` function that panics, the unwind crosses into C++ frames with no landing pads → `std::terminate` at best, UB at worst.

**Recommendation:**
- Either `panic = abort` (safest for FFI), or
- Mark every FFI entry point `extern "C-unwind"` and ensure the C++ side is compiled with `-fexceptions` and has a `catch(...)` at the boundary, or
- Wrap every FFI body in `std::panic::catch_unwind` and convert to an error code.

The claim "panic=unwind FFI safety barrier" is **backwards**: unwind is the *hazard*, not the barrier.

### 3.2 Safe SIMD
Rust's `std::simd` is nightly-only. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" is aspirational unless using `wide` or `pulp` crates. **Demand the actual intrinsics list.**

### 3.3 Packed 88-byte descriptor
`#[repr(C, packed)]` on a struct containing `u64` fields creates **unaligned references** —