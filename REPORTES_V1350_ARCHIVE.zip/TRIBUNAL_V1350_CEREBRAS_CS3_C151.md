# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 151)

# POLYDIM V1350 – MULTI‑FILE ADVERSARIAL SOTA AUDIT  
**Cycle 151 – High Tribunal of Mathematical & Systems Sages**  

**Prepared for:** PolyDim Inc. – Engineering & Security Review Board  
**Date:** 2026‑10‑05  

---

## Executive Summary  

| Component | Numerical‑Degeneracy Risk (|step| → ∞) | Numerical‑Degeneracy Risk (|step| → 0) | Rule 22 (88‑byte PMTP) | Rule 27 (Silicon‑Contract) | Primary FFI Hardening Gaps | Overall Verdict |
|-----------|-----------------------------------|--------------------------------------|------------------------|---------------------------|----------------------------|-----------------|
| `kernel_orchestrator_v1350.py` | **High** – overflow in 64‑bit length fields, loss of precision in 4‑byte counters when step ≫ 2³² | **Medium** – sub‑normal handling of 8‑byte floating points in descriptor (Q) fields; potential under‑flow to zero | **Compliant** – descriptor layout matches 88‑byte spec, but runtime checks miss one *null‑token* path | **Compliant** – pure‑Python, no vendor‑specific ISA | Missing *type‑sanitised* `ctypes` bounds checks; unguarded `struct.pack` on user‑supplied data | **Pass** with hardening |
| `kernel_cpp_v1350.cpp` | **High** – AVX‑512 fused‑multiply‑add (FMA) saturates at 2⁶³ for integer counters; eigenvalue scaling in Woodbury may blow up | **High** – sub‑normal dot‑product terms (Neumaier compensation) can be flushed to zero on some CPUs (Intel Xeon Scalable, AMD EPYC) | **Compliant** – binary descriptor built with `#pragma pack(1)` meets 88‑byte spec; however, compiler may insert padding under non‑standard ABI | **Potential Vendor‑Lock** – reliance on AVX‑512 (Intel‑only) and GNU OpenMP extensions (Linux‑only) | No explicit `#ifdef` for `-fno-omit-frame-pointer` in unwind path; exception‑mask not hardened against malicious payloads | **Conditional Pass** – requires fallback code |
| `kernel_rust_v1350.rs` | **Medium** – SIMD‑wide `f64x8` multiplies overflow at ~1e308, but Rust’s `std::simd` will produce `NaN` – downstream algorithms treat NaN as error | **Medium** – `panic = "unwind"` may unwind through `unsafe` FFI boundaries, exposing undefined behaviour if the unwind handler is corrupted | **Compliant** – `#[repr(C, packed)]` on `PmtpTensorDescriptor` guarantees 88‑byte layout; compile‑time `static_assert!` validates size | **Compliant** – pure‑Rust, no vendor‑specific ISA; only optional `target_feature = "+avx512f"` guard present | Missing `#[no_mangle]` guard on exported symbols; `extern "C"` functions lack `#[deny(unsafe_code)]` in caller crates | **Pass** with additional `#[track_caller]` and `panic=abort` recommendations |
| `kernel_cuda_v1350.cu` | **High** – Woodbury solve `W = (step/scale) B` multiplies `step` (potentially 1e12) with `B` entries (~1e4) → 1e16, exceeding FP64 mantissa (≈15 digits) → catastrophic cancellation | **High** – cuSOLVER `DnDsyevd` may return sub‑normal eigen‑values that are flushed to zero under default `cudaDeviceProp.l2CacheSize`‑driven rounding mode | **Compliant** – descriptor transmitted via `cudaMemcpy` with `cudaMemcpyHostToDevice` respects 88‑byte alignment; however, no runtime assertion on token‑value = 0 | **Potential Vendor‑Lock** – exclusive dependence on NVIDIA CUDA 12.x & cuSOLVER; no AMD‑ROCm fallback | No `cudaMemcpyAsync` with `cudaStreamNonBlocking` guard; possible race‑condition if Graph `cudaGraphExecUpdate` fails | **Conditional Pass** – requires dual‑stack fallback |
| `kernel_xla_v1350.py` | **Medium** – HLO fusion pipelines produce `fp64` accumulation over >10⁹ elements; `step`‑scaled Lyapunov solves may overflow intermediate `int64` counters used for slice indexing | **Low** – TPU/Trainium kernels use bfloat16 for intermediate values, but final FP64 reduction retains sub‑normals; XLA’s `ReducePrecision` may discard them → bias | **Compliant** – JAX’s `@jit` retains exact 88‑byte descriptor as a `DeviceArray` of dtype `uint8`; zero‑token constraint enforced via `jax.lax.cond` | **Potential Vendor‑Lock** – explicit reliance on Google TPU or AWS Trainium custom HLO back‑ends; no CPU‑fallback path | No explicit `jax.checkify` for FFI guard; attacker‑controlled `np.ndarray` can poison JIT cache if `jax.config.update("jax_enable_x64", True)` is disabled | **Pass** with hardened JIT cache |
| `kernel_triton_v1350.py` | **Medium** – SRAM tiling size (`S^(D-1)`) computed as `ceil(step / 2^k)`; for `step≥10¹⁰` tile count overflows 32‑bit index used in Triton kernel launch → undefined behaviour | **Medium** – Triton’s `float16` accumulator can under‑flow for `step→0`; conversion to `float64` later yields large relative error | **Compliant** – Triton kernel arguments packed into a struct of size 88 bytes (`triton.language.experimental.cdiv` ensures alignment) | **Compliant** – Triton code generated for both ROCm & CUDA back‑ends; no vendor‑only intrinsics | No `assert` on `tir.int64` launch bounds; missing `__triton_metadata` verification of descriptor checksum | **Pass** with launch‑bound checks |

**Overall** – All six modules meet the *letter* of Rules 22 & 27 but a number of *implementation‑level* gaps expose them to numerical catastrophes and to a limited degree of vendor lock‑in. The following sections provide formal proofs, asymptotic condition‑number analyses, and concrete hardening recommendations.

---

## 1. Formal Numerical‑Degeneracy Analysis  

### 1.1. Common Mathematical Model  

All kernels ultimately solve a **generalised Lyapunov / Woodbury linear system** of the form  

\[
\mathbf{X}_{k+1}
   = \mathbf{X}_k
   + \alpha_k \, \mathbf{B}_k 
   - \alpha_k \,\mathbf{B}_k\,
     (\mathbf{M}_k/\sigma_k)^{-1}
     \mathbf{B}_k^{\!\top},
\qquad
\alpha_k \triangleq \text{step}_k .
\]

Define  

* \(\mathbf{M}_k \in \mathbb{R}^{m\times m}\) – symmetric positive definite (SPD) mass matrix.  
* \(\sigma_k >0\) – scalar scaling factor (often \(\sigma_k=\|\mathbf{B}_k\|_F\)).  
* \(\mathbf{B}_k \in \mathbb{R}^{m\times n}\) – Jacobian‑type block.  

The **Woodbury identity** yields  

\[
(\mathbf{M}_k/\sigma_k+\alpha_k \mathbf{B}_k\mathbf{B}_k^{\!\top})^{-1}
   = \frac{\sigma_k}{\mathbf{M}_k}
   - \frac{\sigma_k^2\alpha_k}{\mathbf{M}_k}
     \mathbf{B}_k
     \bigl( \mathbf{I}_n + \sigma_k\alpha_k \mathbf{B}_k^{\!\top}\mathbf{M}_k^{-1}\mathbf{B}_k \bigr)^{-1}
     \mathbf{B}_k^{\!\top}
     \mathbf{M}_k^{-1}.
\]

Two regimes are critical:

| Regime | Dominant term | Potential failure mode |
|--------|----------------|------------------------|
| **|step| → ∞** | \(\alpha_k \mathbf{B}_k\mathbf{B}_k^{\!\top}\) dominates | **Overflow** of \(\alpha_k\mathbf{B}_k\) (FP64 ≈ 1e308) or loss of SPD property due to rounding |
| **|step| → 0** | \(\mathbf{M}_k/\sigma_k\) dominates | **Sub‑normal under‑flow** of \(\alpha_k \mathbf{B}_k\) (treated as zero) → *biased* Woodbury term |

We therefore examine the **condition number** of the matrix inside the inverse:

\[
\kappa_k(\alpha) \;=\;
\frac{\lambda_{\max}\bigl(\mathbf{M}_k/\sigma_k + \alpha\mathbf{B}_k\mathbf{B}_k^{\!\top}\bigr)}
     {\lambda_{\min}\bigl(\mathbf{M}_k/\sigma_k + \alpha\mathbf{B}_k\mathbf{B}_k^{\!\top}\bigr)}.
\]

Because \(\mathbf{M}_k\) and \(\mathbf{B}_k\mathbf{B}_k^{\!\top}\) are SPD and commute only in special cases, we use Weyl’s inequality:

\[
\lambda_{\min}(\mathbf{M}_k/\sigma_k) + \alpha \lambda_{\min}(\mathbf{B}_k\mathbf{B}_k^{\!\top})
\;\le\;
\lambda_{\min}(\mathbf{M}_k/\sigma_k + \alpha\mathbf{B}_k\mathbf{B}_k^{\!\top})
\;\le\;
\lambda_{\max}(\dots)  \;\le\;
\lambda_{\max}(\mathbf{M}_k/\sigma_k) + \alpha \lambda_{\max}(\mathbf{B}_k\mathbf{B}_k^{\!\top}).
\]

Thus  

\[
\boxed{
\kappa_k(\alpha) \;\le\;
\frac{ \lambda_{\max}(\mathbf{M}_k)/\sigma_k + \alpha \lambda_{\max}(\mathbf{B}_k\mathbf{B}_k^{\!\top}) }
     { \lambda_{\min}(\mathbf{M}_k)/\