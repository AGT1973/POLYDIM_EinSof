# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 146)

# POLYDIM V1350 — High Tribunal Audit, Cycle 146

**Presiding note.** The six artifacts are audited as *specifications*, not as shipped binaries. Where a claim is unverifiable from the description alone (e.g., "12/12 physical conformance checks"), I mark it **[UNVERIFIED]** and state the falsification test that would settle it. Where the description is internally inconsistent, I mark it **[CONTRADICTION]** and refuse to launder it into a pass.

---

## 0. Cross-cutting invariants (Rules 22 & 27)

### Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor is declared as `<4sHHQQQQQBB6x4Q`. Let me actually count it, because this is the kind of thing that silently rots:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Verdict: 88 bytes confirmed.** Alignment: `4s` at offset 0, `H` at 4 (2-aligned ✓), `Q` at 8 (8-aligned ✓), `B` at 48, pad 50–55, `Q` at 56 (8-aligned ✓). **Structurally sound, no implicit padding, no endianness ambiguity** (little-endian assumed; must be asserted in the magic).

**Rule 22 "zero 1D tokens"** — I read this as: no scalar/1-D tensor may cross the inter-agent boundary; only the 88-byte descriptor plus opaque PMTP slab handles. Audit:

- **T1 (Python orchestrator):** passes if `PmtpSlabAllocator` returns handles, not buffers. **[UNVERIFIED]** — must confirm no `numpy.ndarray` or `list` leaks into the IPC payload.
- **T2/T3 (C++/Rust):** the descriptor is passed by value (88 bytes = 11 × `u64`, fits in 2 cache lines). ✓
- **T4/T5/T6:** CUDA/XLA/Triton must marshal *only* the descriptor + device pointer. Any host-side `torch.Tensor` or `jax.Array` crossing the boundary is a Rule 22 violation. **[UNVERIFIED]** for all three.

**Falsification test:** instrument the IPC layer with a byte-counting shim; assert every inter-agent message is exactly `88 + 8·k` bytes (descriptor + k pointer handles). Any other size ⇒ Rule 22 breach.

### Rule 27 — Silicon Contract / vendor lock

| Target | Vendor lock risk | Assessment |
|---|---|---|
| T1 Python | none | ✓ |
| T2 C++ AVX-512 | **Intel/AMD-specific ISA** | ⚠️ AVX-512 is not universal; needs runtime dispatch to AVX2/NEON fallback |
| T3 Rust SIMD | portable if `std::simd` or `wide` crate | ✓ if not `core::arch::x86_64::*` unconditionally |
| T4 CUDA | **hard NVIDIA lock** | ❌ violates Rule 27 unless a HIP/ROCm twin exists |
| T5 XLA | **hard Google TPU lock** (Trainium is AWS, but the code path is JAX/XLA) | ❌ unless PJRT plugin abstraction is honored |
| T6 Triton | **AMD ROCm + NVIDIA** — dual-vendor ✓ | ✓ (this is the only one that *satisfies* Rule 27 by construction) |

**Tribunal finding:** T4 and T5 are **prima facie Rule 27 violations** as described. The remedy is not to delete them but to require that the orchestrator (T1) treat them as *optional backends* behind a capability probe, with T2/T3/T6 as the portable floor. If T1 hard-imports `cupy` or `jax` at module load, Rule 27 is breached at the orchestrator level too.

---

## 1. Numerical degeneracy: `step → ∞` and `step → 0`

This is the heart of the audit. The recurrence is (from T4's description) a **globally scaled Woodbury solve**:

$$M W = \text{step}\cdot B \quad\Longrightarrow\quad W = \text{step}\cdot M^{-1} B$$

with the "globally scaled" form $(\text{scale}\cdot M)\,W = (\text{step}/\text{scale})\,B$ — i.e., the code computes $W = (\text{step}/\text{scale})\cdot(\text{scale}\cdot M)^{-1}B$. **This is algebraically identical to the unscaled form**, so the scaling is a *conditioning* device, not a *regularization* device. That distinction matters enormously below.

### 1a. `step → ∞` (|step| ≥ 10¹⁰)

**Claim to audit:** does the algorithm remain stable?

- **Woodbury path (T4):** $W = (\text{step}/\text{scale})\,(\text{scale}\cdot M)^{-1}B$. If `scale` is chosen as $\|M\|_\infty$ (a common heuristic), then $\text{scale}\cdot M$ has unit infinity norm and $(\text{scale}\cdot M)^{-1}$ is $O(1)$ in the well-conditioned case. Then $W \sim \text{step}\cdot O(1)$ — **linear growth, no overflow until step ~ 10³⁰⁰**. ✓ *provided* `scale` is recomputed per step and not cached.
- **Failure mode:** if `scale` is a *fixed* constant (e.g., 1.0), then for $\|M\| \gg 1$ the solve $(\text{scale}\cdot M)^{-1}$ is fine but the *product* `step/scale` overflows FP64 at step ≈ 1.8×10³⁰⁸. At step = 10¹⁰ this is safe, but the *next* multiplication by $B$ (if $\|B\| \sim 10^{300}$) overflows. **Recommendation:** clamp `step` to $[10^{-300}, 10^{300}]$ and assert `isfinite(W).all()` after every solve.
- **Stiefel Cayley retraction (T4):** $Y = (I - \tfrac{1}{2}W)^{-1}(I + \tfrac{1}{2}W)X$ where $W = A - A^\top$ is skew-symmetric. As `step → ∞`, $\|W\| \to \infty$ and the Cayley transform approaches a *reflection* (eigenvalues of the Möbius map $\to -1$). The matrix $(I - W/2)$ becomes increasingly ill-conditioned: $\kappa_2(I - W/2) \sim \|W\|/2$. **At step = 10¹⁰, $\kappa \sim 5\times 10^9$** — the solve loses ~10 digits. **This is a real degeneracy.** Remedy: cap the effective step at $\|W\| \le 10^6$ (loses ≤ 6 digits, acceptable in FP64) or use a QR-based retraction that is unconditionally stable.
- **Neumaier compensated dot (T2/T3):** the compensation term $c$ accumulates $O(\epsilon)$ per term. For a dot product of length $n$ with $\|x\|,\|y\| \sim 10^{10}$, the *uncompensated* error is $O(n\epsilon \|x\|\|y\|) \sim 10^{20}\cdot 10^{-16} = 10^4$ — catastrophic. Neumaier reduces this to $O(\epsilon \|x\|\|y\|) \sim 10^4$... wait, no: Neumaier's bound is $O(\epsilon)\cdot\sum|x_i y_i|$, i.e., **relative** error $O(\epsilon)$, so absolute error $\sim 10^{-16}\cdot 10^{20} = 10^4$. **Still large in absolute terms but correct in relative terms.** The audit point: if downstream code compares `dot(x,y) == expected` with an *absolute* tolerance, it will fail. **Must use relative tolerance.**

**Tribunal verdict on step → ∞:** the Woodbury path is safe *if* `scale` is adaptive; the Cayley retraction is **numerically degenerate for |step| > ~10⁶** and must be capped or replaced.

### 1b. `step → 0` (subnormals)

- **Subnormal audit (-12, -14) in T2:** the notation "-12, -14" almost certainly refers to exponents $2^{-12}$ and $2^{-14}$ — i.e., the code checks behavior at the subnormal boundary (FP64 subnormals begin at $2^{-1022}$, FP32 at $2^{-126}$). If the audit is at $2^{-12}$/$2^{-14}$, that's **normal range, not subnormal** — the audit is mislabeled. **[CONTRADICTION]** unless the exponents are decimal ($10^{-12}$, $10^{-14}$), which are also normal. **Either way, the "subnormal audit" does not actually test subnormals.** Remedy: test at $2^{-1022}$, $2^{-1074}$ (FP64), and assert flush-to-zero behavior is *disabled* (`-fno-fast-math`, no `-ffast-math`, no `MXCSR.FTZ`).
- **Woodbury as step → 0:** $W \to 0$, so $M W = \text{step}\cdot B \to 0$. The solve is trivially stable, but the *relative* error in $W$ blows up: $\|W\| \sim \text{step}\cdot\|M^{-1}B\|$, and if $\text{step} < \epsilon_{\text{mach}}\cdot\|M\|/\|B\|$, then $W$ is dominated by rounding noise. **Condition number of the *problem* (not the matrix):** $\kappa_{\text{prob}} = \|M\|\|M^{-1}\| \cdot \|B\|/\|\text{step}\cdot B\| = \kappa(M)/\text{step}$. **As step → 0, $\kappa_{\text{prob}} \to \infty$.** This is the fundamental degeneracy: **the Woodbury step is a *relative* perturbation and cannot be made small without losing all precision.**
- **Cayley as step → 0:** $Y \to X$ (identity retraction), which is correct and stable. ✓
- **Neumaier as step → 0:** no issue; compensation is exact for small terms.

**Tribunal verdict on step → 0:** the Woodbury solve is **conditionally degenerate** — the *problem* condition number scales as $1/\text{step}$. **Recommendation:** floor `step` at $\epsilon_{\text{mach}}^{1/2}\cdot\|M\|/\