# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 86

The public evidence does **not identify a verifiable “POLYDIM V1350” specification or the six tribunal reports**, so no factual arbitration among Claude, Qwen, Kimi, Gemini, DeepSeek, and Perplexity is possible. The defensible synthesis is therefore a set of conditional guarantees—not a claim that any particular model’s findings are correct.

## 1. Cayley Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For \(X\in\mathrm{St}(n,p)\) and a skew-symmetric generator \(A^\top=-A\), the Cayley map is typically

\[
Y=(I-\tfrac12 A)^{-1}(I+\tfrac12 A)X.
\]

In exact arithmetic, the Cayley factor is orthogonal, so it preserves \(Y^\top Y=I\). However, this does **not** imply numerical stability for an extreme step. Large steps can produce:

- overflow or loss of scale while forming \(A\);
- ill-conditioning in the linear solve;
- cancellation in \(I-\tfrac12 A\) and \(I+\tfrac12 A\);
- loss of tangent-model validity;
- sensitivity to finite precision and implementation-dependent solves.

The matrix \(I-\tfrac12 A\) is nonsingular for real skew-symmetric \(A\), but its mathematical nonsingularity is weaker than a finite-precision error guarantee. Recent conditioning analyses report bounded conditioning for canonical Cayley and polar-light retractions under their stated hypotheses, while other comparative work reports lower accuracy for Cayley than for polar retractions in tested settings.[7][11]

### Arbitration

No kernel should claim that Cayley is unconditionally stable for \(|\mathrm{step}|\ge10^{10}\). The strongest defensible design is:

1. **Scale or reject the step before construction.**
2. Use a backward-stable solve for the Cayley system, preferably with factorization and residual verification.
3. Re-orthogonalize or fall back to a polar/QR projection when the residual exceeds tolerance.
4. Compute the acceptance condition from
   \[
   \frac{\|Y^\top Y-I\|}{u\,\kappa_{\mathrm{target}}}
   \]
   or an equivalent explicitly specified bound, where \(u\) is unit roundoff.
5. Make the fallback deterministic across backends.

Householder QR is generally the strongest default for robust orthonormalization; polar retraction offers an attractive geometric projection but requires a matrix inverse square root or equivalent computation. A NeurIPS supplement gives QR and polar operation counts and treats both as standard Stiefel retractions.[5] The mathematically superior guarantee is therefore **not “Cayley always wins,”** but:

> Cayley may be used as a fast primary update, provided that it is residual-checked and has a norm-controlled QR/polar fallback. For extreme steps, unconditional Cayley superiority is unsupported.

A valid architecture should guarantee only:

\[
\|Y^\top Y-I\|\le \tau_{\mathrm{orth}}
\]

when the kernel returns success. It should return a typed failure or fallback status otherwise.

## 2. PMTP 88-byte descriptor and RCU/QSBR barriers

Acquire/release ordering is sufficient for publication of initialized descriptor state **only when the protocol is correctly structured**:

1. The writer initializes the complete immutable descriptor.
2. The writer performs a release store or release exchange of the publication pointer/version.
3. The reader performs an acquire load of that same atomic publication variable.
4. The reader accesses the descriptor only after the acquire.
5. Reclamation is deferred until a valid RCU grace period or QSBR condition has completed.

A release store followed by an acquire load that reads from it establishes the required synchronizes-with relationship in C++ memory ordering.[3] RCU verification work likewise describes release/acquire ordering as ensuring that node initialization precedes reader access, and that reader completion precedes reclamation.[1]

However, **Acquire/Release alone does not establish snapshot isolation**. It does not by itself provide:

- a coherent multi-field snapshot if fields are independently mutable;
- protection against ABA or version reuse;
- safe reclamation;
- ordering across unrelated publication variables;
- atomicity for a descriptor larger than the target machine’s atomic width.

For an 88-byte PMTP descriptor, the robust design is:

- keep the descriptor immutable after publication;
- publish one atomic pointer, index, or generation token;
- acquire-load that token once per snapshot;
- dereference only the corresponding immutable object;
- retire old objects through RCU/QSBR;
- reclaim only after every participating reader has passed a quiescent state;
- use a generation counter or tagged pointer if ABA is possible;
- define explicit reader registration, quiescent-state reporting, and stalled-reader behavior.

The descriptor’s physical size must not be confused with atomicity. An 88-byte copy is not generally an atomic transaction. If in-place mutation is required, use a seqlock/version protocol or an equivalent transactional mechanism, with the required retry and memory-order rules.

### Architectural guarantee

The strongest valid guarantee is:

> A reader that successfully acquires publication token \(g\) observes a fully initialized, immutable descriptor associated with \(g\), and that descriptor remains allocated until the reader exits its RCU read-side critical section or reports the required QSBR quiescent state.

This guarantee fails if readers can be unregistered without synchronization, fail to report quiescence indefinitely, access fields before the acquire, or reclaim based only on a release operation. QSBR implementations explicitly rely on acquire loads and release operations at relevant synchronization points.[2][8]

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or numerical execution model shared identically by all five environments. “Multi-silicon conformance” must therefore mean **observational conformance to a specified contract**, not identical instruction sequences or bitwise results.

The conformance contract should separate:

### Numerical contract

Specify:

- scalar types and accumulator types;
- permitted relative and absolute error;
- orthogonality tolerance;
- overflow, NaN, and Inf behavior;
- deterministic versus nondeterministic reductions;
- fallback behavior;
- accepted status codes.

For example, successful Stiefel output could require

\[
\|Y^\top Y-I\|_2\le \tau_{\mathrm{orth}},
\]

while descriptor reads must satisfy the snapshot-generation invariant.

### Memory contract

Specify:

- which object is the publication atomic;
- release publication and acquire consumption;
- RCU/QSBR reader-entry and reader-exit operations;
- grace-period completion;
- reclamation and ABA policy;
- alignment and representation of the 88-byte descriptor;
- whether host/device visibility is involved.

C++20 can express the abstract atomic ordering, but CUDA, XLA, and Triton require backend-specific lowering and synchronization rules. A host-language acquire/release operation cannot automatically guarantee device-wide visibility, stream ordering, or cross-device coherence.

### Representation contract

Define the descriptor by field offsets, widths, alignment, endianness, and padding. Require compile-time checks in C++20 and Rust, and backend-side validation where the descriptor crosses an ABI boundary. The contract should reject silent layout changes rather than rely on `sizeof` alone.

### Execution contract

Each backend should pass:

- extreme-step tests, including \(\ge10^{10}\);
- rank-deficient and near-singular cases;
- NaN/Inf and overflow tests;
- randomized descriptor publication/read tests;
- delayed-reader and stalled-reader QSBR tests;
- generation/ABA tests;
- cross-backend tolerance and status-equivalence tests.

Bitwise equality should be required only where algorithms, reduction order, and compiler behavior are fixed. Otherwise require numerical and semantic equivalence.

## Definitive arbitration

The strongest technically justified synthesis is:

1. **Cayley:** exact orthogonality in exact arithmetic, but no unconditional finite-precision stability guarantee at extreme step sizes. Use scaling, residual checks, and deterministic Householder-QR or polar fallback.
2. **PMTP:** Acquire/Release correctly orders publication and observation, but does not alone provide snapshot isolation or reclamation safety. Immutable publication plus RCU/QSBR grace-period rules is required.
3. **Conformance:** CUDA, XLA, Triton, C++20, and Rust can conform to one abstract numerical/memory/ABI contract, but not automatically to identical low-level behavior. The contract must explicitly define tolerances, synchronization scope, layout, progress, reclamation, and failure semantics.

Accordingly, any tribunal finding that claims **unconditional Cayley stability at \(|\mathrm{step}|\ge10^{10}\)**, **88-byte atomic snapshotting from Acquire/Release alone**, or **automatic cross-silicon equivalence without backend-specific synchronization and tolerance rules** should be rejected as overstated.