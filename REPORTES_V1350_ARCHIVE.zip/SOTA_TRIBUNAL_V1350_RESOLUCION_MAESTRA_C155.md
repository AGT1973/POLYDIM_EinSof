# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 155

No authoritative public record of the **“POLYDIM V1350” kernels, PMTP 88-byte descriptor, Cycle 155, or the eight Tribunal findings** is available in the gathered material. Therefore, a literal arbitration of those model outputs is not possible without their reports, test vectors, kernel definitions, and hardware/compiler versions. The following is the strongest defensible synthesis from established numerical-linear-algebra and memory-model principles.

## 1. Extreme-step Stiefel retraction

For \(X \in \mathrm{St}(n,p)\), a retraction must preserve

\[
X^\top X = I_p
\]

up to the implementation’s numerical error.

### Arbitration

**Cayley retraction is not unconditionally stable for \(|\text{step}| \ge 10^{10}\).** A typical Cayley map has the form

\[
Y(\alpha)
=
\left(I-\frac{\alpha}{2}W\right)^{-1}
\left(I+\frac{\alpha}{2}W\right)X,
\qquad W^\top=-W.
\]

In exact arithmetic, the transform is orthogonal when the inverse exists. In floating-point arithmetic, however, extreme \(\alpha\) creates several risks:

- overflow in forming \(\alpha W\);
- loss of significance in \(I \pm \alpha W/2\);
- ill-conditioning or poor scaling in the linear solve;
- residual orthogonality caused by solve and rounding errors;
- behavior dominated by the direction \(W\), not by a controlled geodesic step.

The fact that the Cayley transform is mathematically orthogonal does **not** imply that an unscaled floating-point implementation remains stable at arbitrary step magnitude.

**Householder QR is generally the preferred robust baseline** for re-orthogonalization. Householder transformations are backward stable under standard assumptions and avoid explicitly forming \(Q^\top Q\) as the primary operation. They still require safe scaling and rank awareness, but they are the strongest general-purpose choice when the input is badly scaled.

**Polar retraction is the most natural projection onto the Stiefel manifold**, typically

\[
\operatorname{polar}(Z)
=
Z(Z^\top Z)^{-1/2},
\]

or an equivalent SVD-based construction. It offers excellent geometric behavior and is often superior when the objective is the nearest orthonormal factor. Its implementation must nevertheless handle singular or nearly rank-deficient \(Z\), and naïvely forming \(Z^\top Z\) can square the condition number.

### Definitive numerical guarantee

The defensible guarantee is:

> For \(|\text{step}| \ge 10^{10}\), no unscaled Cayley implementation should be certified as stable merely from its exact-arithmetic orthogonality. The kernel must either scale or clamp the step, use a backward-stable factorization, detect non-finite or rank-deficient intermediates, and verify
> \[
> \|Y^\top Y-I\|
> \]
> against a declared tolerance.

A robust arbitration policy is:

1. Compute a scale such as
   \[
   s=\max(1,\|W\|,\|X\|).
   \]
2. Normalize the effective step before constructing the Cayley system.
3. Prefer Householder QR or a stable polar/SVD path when the scaled system is ill-conditioned.
4. Reject or fall back on any non-finite result or excessive orthogonality residual.
5. Treat “exact orthogonality in symbolic arithmetic” as a mathematical property, not an architectural runtime guarantee.

Thus, **Householder QR wins for worst-case numerical robustness**, while **polar wins for geometric projection quality**, and **Cayley is acceptable only with explicit scaling, conditioning checks, and fallback behavior**.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering establishes visibility only through the relevant atomic synchronization variable. If a writer initializes descriptor payload fields and then publishes a pointer or generation value with release semantics, and a reader loads that same publication variable with acquire semantics, the initialization happens-before the reader’s subsequent access.

The essential pattern is:

```cpp
// Writer
descriptor->payload = initialized_value;
descriptor->metadata = initialized_metadata;
published.store(descriptor, std::memory_order_release);

// Reader
auto* p = published.load(std::memory_order_acquire);
consume(p->payload, p->metadata);
```

The same principle applies to Rust atomics: Rust uses the C++20-style acquire/release model. A release store paired with an acquire load on the same atomic location makes earlier writes visible to later reader operations.

### What acquire/release does guarantee

It guarantees:

- publication ordering for fields initialized before the release;
- visibility to a reader whose acquire observes that publication;
- ordering of subsequent reader accesses after the acquire;
- correct message passing for immutable or copy-published snapshots.

### What it does not guarantee

Acquire/release alone does **not** guarantee:

- that a descriptor is never reclaimed while a reader still uses it;
- that all readers observe the same generation;
- atomicity of an 88-byte object as a whole;
- cache coherence across unrelated devices or address spaces;
- synchronization if the reader acquires a different atomic variable;
- safe mutation of payload fields after publication;
- CUDA host/device ordering without the required system/device scope and synchronization mechanism.

For RCU/QSBR, lifetime safety requires a grace-period protocol:

1. Construct a new immutable descriptor.
2. Publish it with release semantics.
3. Readers acquire the publication pointer or generation.
4. Readers enter or report an RCU/QSBR read-side critical section.
5. The writer waits for a grace period covering all preexisting readers.
6. Only then reclaim the old descriptor.

The 88-byte size is therefore an ABI/layout constraint, not a memory-ordering guarantee. The descriptor should have a statically verified layout, explicit alignment, versioning, and immutable-after-publication semantics.

### Definitive memory-model guarantee

The strongest accurate guarantee is:

> PMTP snapshot isolation is guaranteed only when publication uses a release operation, consumption uses an acquire operation on the same synchronization object, descriptor contents are immutable after publication, and reclamation is delayed until an RCU/QSBR grace period completes.

If any one of those conditions is absent, the architecture cannot claim full snapshot isolation.

For heterogeneous execution, the implementation must additionally define the synchronization domain—CPU thread, GPU device, system scope, or host/device interoperation. C++20 and Rust acquire/release semantics do not automatically define CUDA, XLA, or Triton visibility behavior.

## 3. Multi-silicon and multi-language conformance

CUDA, XLA, Triton, C++20, and Rust do not constitute one identical execution or memory model.

### C++20 and Rust

C++20 and Rust provide closely corresponding atomic orderings:

- relaxed;
- acquire;
- release;
- acquire-release;
- sequentially consistent.

That correspondence supports a portable host-side abstract protocol, provided the implementation uses the same atomic object and respects object lifetime and data-race rules.

### CUDA

CUDA adds address-space and scope distinctions, such as block/device/system visibility. Host-side C++20 atomics cannot by themselves establish ordering for GPU threads or GPU-to-CPU communication. A correct CUDA implementation must specify:

- where the descriptor resides;
- which scope applies;
- whether operations are atomic at that scope;
- what kernel, stream, event, or fence operation completes publication;
- whether host and device accesses are concurrent and legally synchronized.

### Triton

Triton exposes GPU-oriented atomic and memory operations, but its guarantees depend on the generated backend, target architecture, address space, and compiler lowering. A Triton kernel cannot be certified from source-level syntax alone; generated code and target-specific behavior must be tested.

### XLA

XLA is an optimizing graph compiler. Operation ordering, aliasing, buffer donation, fusion, asynchronous execution, and device transfers may change the implementation substantially. A source-level acquire/release analogy is insufficient unless the required happens-before relation is represented by an operation that XLA preserves as a semantic barrier.

### Cross-silicon guarantee

The only defensible portable guarantee is an **observational contract**, not identical instruction sequences:

- descriptor layout and endianness are fixed;
- publication and generation fields have specified widths and alignment;
- snapshots are immutable after publication;
- readers never access reclaimed storage;
- numerical kernels satisfy declared residual and non-finite-value bounds;
- synchronization is expressed using a backend-specific primitive proven to implement the abstract publication protocol;
- conformance tests cover weak memory ordering, delayed readers, overlapping publication, reclamation races, extreme steps, NaNs, infinities, rank deficiency, and asynchronous execution.

## Final arbitration

The mathematically superior and architecturally defensible synthesis is:

1. **Retraction kernel:** use a scaled Cayley path only as an optimized path; use Householder QR as the worst-case stability fallback and polar/SVD when nearest-point manifold projection is required. Certify by residual checks, not by symbolic orthogonality.
2. **PMTP descriptor:** treat the 88-byte record as an immutable, versioned snapshot. Publish with release, consume with acquire on the same atomic publication variable, and reclaim only after RCU/QSBR grace-period completion.
3. **Portability:** define one abstract memory and numerical contract, then provide separate verified implementations for CPU C++20/Rust, CUDA, Triton, and XLA. Do not claim that C++20 acquire/release automatically transfers to GPU or compiler graph semantics.
4. **Exact guarantee boundary:** the system may guarantee snapshot consistency, lifetime safety, and bounded orthogonality error only under explicitly stated layout, synchronization-scope, reclamation, scaling, and validation assumptions. It cannot guarantee arbitrary-step Cayley stability, atomicity of an 88-byte descriptor, or identical behavior across all listed backends without those additional mechanisms.