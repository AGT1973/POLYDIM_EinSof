# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 147)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 147 · Multi-File Adversarial SOTA Review

**Tribunal composition:** Numerical Analysis · Systems/FFI · Hardware Portability · Formal Methods
**Verdict class:** *Conditional Pass with Mandatory Remediations* (see §7)

---

## §0. Scope, Notation, and Audit Method

We audit six artifacts against three invariants:

- **I₁ (Numerical):** For all admissible `step ∈ ℝ`, the update map `Φ_step` must remain a contraction on the Stiefel manifold `St(2K, 2K)` with bounded condition number `κ(Φ_step) ≤ C` independent of `|step|`.
- **I₂ (Rule 22):** Every inter-agent payload is a fixed 88-byte PMTP descriptor; no 1-D token streams cross the boundary.
- **I₃ (Rule 27):** No component may impose a vendor lock; every silicon path must degrade to a portable fallback.

We treat each target as a black-box operator with declared internals, then stress it at `step → 0⁺` (subnormal regime) and `step → ∞` (`|step| ≥ 10¹⁰`).

---

## §1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout audit

Declared struct: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version | `H` | 2 | 4 |
| flags | `H` | 2 | 6 |
| n_rows | `Q` | 8 | 8 |
| n_cols | `Q` | 8 | 16 |
| stride | `Q` | 8 | 24 |
| scale_exp | `Q` | 8 | 32 |
| step_bits | `Q` | 8 | 40 |
| dtype | `B` | 1 | 48 |
| rank | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| reserved | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict:** ✅ 88-byte alignment confirmed. `struct.calcsize('<4sHHQQQQQBB6x4Q') == 88` under CPython's default `=` alignment (no native padding because `<` forces standard size). **However**, the `6x` pad is *load-bearing*: any future field insertion between `rank` and `reserved` silently breaks ABI. **Recommendation R1.1:** replace `6x` with an explicit `_pad: bytes[6]` and add a `ctypes.sizeof` assertion at import time.

### 1.2 Multi-silicon HardwareProbe

The probe enumerates `{CUDA, ROCm, XLA-TPU, Trainium, AVX512, NEON, scalar}`. **Degeneracy risk:** if the probe returns an *empty* set (e.g., containerized CI without `/dev/nvidia*` and without `libtpu.so`), the orchestrator must fall through to the scalar path. If it does not, `step` is applied to a `None` backend → `TypeError` at the FFI boundary, not a numerical failure. **R1.2:** enforce `assert backends, "no silicon"` and route to `kernel_cpp_v1350.cpp` scalar fallback.

### 1.3 12/12 physical conformance checks

Without the check list we cannot verify each, but the *cardinality* 12 is suspicious: it matches the number of `(Q, B, H, 4s)` field classes plus reserved words. **R1.3:** publish the 12 checks as a machine-readable manifest so the Tribunal can re-derive them.

### 1.4 `step → ∞` / `step → 0` behavior

The orchestrator only *dispatches*; it does not apply `step`. **No numerical degeneracy at this layer.** But it must **clamp** `step_bits` before dispatch: if `step_bits` encodes `+inf` (exponent `0x7FF`), the downstream Cayley retraction in Target 4 will produce `NaN` via `(I - step/2·A)⁻¹`. **R1.4:** orchestrator must reject `|step| > 10¹⁰` and `|step| < 2⁻¹⁰²²` (subnormal threshold) with a typed error, not silently forward.

---

## §2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:

```
s = x[0]*y[0]; c = 0
for i in 1..n-1:
    t = s + x[i]*y[i]
    if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
    else:                 c += (x[i]*y[i] - t) + s
    s = t
return s + c
```

**Error bound (Neumaier 1974):** `|result − exact| ≤ (2u + O(nu²)) · Σ|xᵢyᵢ|`, where `u = 2⁻⁵³`. This is *not* a true compensated sum (that requires `2Sum`/`Fast2Sum` per term), but it is **backward stable** and adequate for `n ≤ 10⁶`.

**Degeneracy at `step → ∞`:** if `step` multiplies the operands, `Σ|xᵢyᵢ|` scales as `step²`, and the *relative* error stays `O(u)`, but the *absolute* error grows as `step²·u`. For `step = 10¹⁰`, `step² = 10²⁰`, and `u·10²⁰ ≈ 10⁻¹⁶·10²⁰ = 10⁴` — **catastrophic absolute error**. **R2.1:** the C++ kernel must pre-scale by `1/step` (see Target 4's Woodbury trick) so the compensated sum operates on `O(1)` operands.

**Degeneracy at `step → 0`:** subnormal operands `xᵢyᵢ < 2⁻¹⁰²²` flush to zero under `-ffast-math` or `FTZ/DAZ` on AVX-512. The audit mentions "subnormal audits (-12, -14)" — these are likely `fenv` exception flags for *inexact* and *underflow*. **R2.2:** compile with `-fno-fast-math -ffp-contract=off` and set `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`; otherwise the compensated sum loses its correction term entirely.

### 2.2 AVX-512 / OpenMP

**Vendor lock check (Rule 27):** AVX-512 is Intel-proprietary on consumer parts (disabled on Alder Lake E-cores) and absent on AMD Zen 1–3. **This is a soft vendor lock.** **R2.3:** provide a `#pragma omp simd` fallback compiled without `-mavx512f`, selected at runtime via `__builtin_cpu_supports("avx512f")`. The orchestrator's HardwareProbe must expose this.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be `alignas(64)` and the payload to be page-aligned. **R2.4:** add `static_assert(alignof(PmtpDescriptor) == 64)` and `static_assert(sizeof(PmtpDescriptor) == 88)`.

---

## §3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 Safe SIMD + `panic=unwind` FFI barrier

`panic=unwind` across an FFI boundary is **UB** unless every `extern "C"` function is wrapped in `catch_unwind`. **R3.1:** mandate `#[no_mangle] pub extern "C" fn ...` bodies to be `std::panic::catch_unwind(|| { ... }).unwrap_or(ERR_PANIC)`. Alternatively, compile the FFI crate with `panic=abort` and document the abort as a hard fault.

### 3.2 Neumaier sums

Rust's `f64::mul_add` (FMA) is **not** the same as Neumaier; if the kernel uses `mul_add` it is *more* accurate but *not* Neumaier. **R3.2:** clarify which is used; if FMA, the error bound tightens to `O(u)` with no `nu²` term, which is strictly better.

### 3.3 Packed 88-byte descriptor

`#[repr(C, packed)]` on a struct containing `u64` fields causes **unaligned loads** on some targets (ARMv7, some RISC-V). **R3.3:** use `#[repr(C)]` with explicit `_pad: [u8; 6]` and `#[repr(align(8))]`; the 88-byte size is preserved and alignment is safe.

### 3.4 `step → ∞` / `step → 0`

Same as Target 2: the Rust kernel inherits the scaling problem. **R3.4:** mirror R2.1's pre-scaling.

---

## §4. TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction

For `Y ∈ St(n, p)` and tangent `A = Yᵀ·skew(G)`, the Cayley retraction is:

```
Y(step) = (I − step/2 · A)⁻¹ (I + step/2 · A) Y
```

**Condition number of `(I − step/2·A)`:** since `A` is skew-symmetric, its eigenvalues are purely imaginary `±iλⱼ`. Then

```
κ(I − step/2·A) = max_j |1 − i·step·λⱼ/2| / min_j |1 − i·step·λⱼ/2|
                = sqrt(1 + (step·λ_max/2)²) / sqrt(1 + (step·λ_min/2)²)
```

As `step → ∞`, `κ → λ_max/λ_min` (bounded, **good**). As `step → 0`, `κ → 1` (**good**). **The Cayley retraction is unconditionally well-conditioned.** ✅

**But:** the *solve* `(I − step/2·A)⁻¹` via `cuSOLVER DnDsyevd` (symmetric eigensolver) is **wrong**: `I − step/2·A` is **not symmetric** (it's `I` plus a skew matrix). `DnDsyevd` assumes symmetry and will silently