# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 166)

# **High Tribunal of Mathematical and Systems Sages**  
## **POLYDIM V1350 – Multi‑File Adversarial SOTA Audit – Cycle 166**  

**Date:** 2026‑10‑05 **Auditors:** T. S. K. (PhD Computer Science), L. M. R. (PhD Applied Mathematics), A. G. P. (PhD Electrical Engineering)  

---

## Executive Summary  

| Component | Numerical‑Degeneracy Risk (|step| → ∞) | Numerical‑Degeneracy Risk (|step| → 0) | Rule 22 (88‑byte PMTP) | Rule 27 Silicon‑Contract (Vendor‑Lock) | FFI Hardening (Critical) |
|-----------|-------------------------------------------|----------------------------------------|------------------------|---------------------------------------|---------------------------|
| **kernel_orchestrator_v1350.py** | **High** – overflow in `scale = step·B` and loss of integer‑precision in the 88‑byte descriptor when `step` exceeds 2⁶³‑1. | **Medium** – sub‑normal `step` leads to denorm‑flush in Python’s float‑64 → possible underflow to zero. | **Compliant** – descriptor size matches 88 bytes, tokens correctly zero‑padded. | **No lock** – pure Python, uses `ctypes` and `cffi`; vendor‑agnostic. | **Medium** – need explicit `ctypes` arg/return‐type checks and `memoryview` guards. |
| **kernel_cpp_v1350.cpp** | **High** – AVX‑512 fused‑multiply‑add on `step·B` may overflow 64‑bit FP when |step| ≥ 10¹⁰, producing Inf in eigen‑solve; condition number grows O(|step|). | **High** – subnormal `step` propagates into Neumaier summation → rounding error ≈ ε·log n. | **Compliant** – binary descriptor generated via packed struct (`#pragma pack(1)`) yields exactly 88 bytes, zero‑token enforced. | **Vendor‑Lock** – compiled only with Intel ICC/ICX for AVX‑512; fallback disabled. | **Critical** – need `-fno-omit-frame-pointer`, `-D_FORTIFY_SOURCE=2`, and explicit `noexcept` on all FFI entry points. |
| **kernel_rust_v1350.rs** | **Medium** – Rust SIMD (x86_64) falls back to Software‑emulated lanes when |step| ≥ 2⁶⁴, causing silent truncation; Neumaier sum still stable (error ≤ 2ε). | **Low** – Rust’s `f64` subnormals are preserved; however `packed` descriptor may cause unaligned loads on some architectures. | **Compliant** – `#[repr(packed, C)]` guarantees 88‑byte layout; token field is a `u8` set to zero. | **No lock** – compiled with `cargo +stable`, portable to any `target‑cpu`; optional `nightly` for SIMD but gated by feature flag. | **Medium** – use `#[no_mangle] extern "C"` with `#[panic = "abort"]` for FFI; add `C`‑compatible ABI checks. |
| **kernel_cuda_v1350.cu** | **High** – CUDA `cublas`/`cusolver` eigen‑solve suffers catastrophic cancellation when `step` → ∞ because matrix `W = (step/scale) B` loses relative scaling; condition number ≈ |step|·κ(B). | **Medium** – underflow in `step/scale` produces denormals that trigger `flush-to-zero` (default) → zero entries, breaking Woodbury formula. | **Compliant** – binary descriptor passed via `cudaMemcpy` with exact 88‑byte size; token field is enforced zero by host stub. | **Vendor‑Lock** – exclusive to NVIDIA GPUs (Compute Capability ≥ 8.0) – no ROCm fallback. | **Critical** – need explicit `cudaMemcpyAsync` error‑checking, `cudaDeviceSynchronize` before FFI return, and `nvtxRangePop` to bound trace. |
| **kernel_xla_v1350.py** (JAX) | **Medium** – XLA HLO fusion creates a `while` loop that rescales `step`; for |step| ≥ 10¹⁰ the internal 64‑bit accumulators saturate to Inf, breaking the Lyapunov solve. | **Low** – JAX’s bfloat16 subnormals are flushed, but the code forces FP64, so subnormals survive; however `jit` may eliminate them as dead code. | **Compliant** – the descriptor is emitted as a `custom_call` with exact 88‑byte shape; the zero token is stored as a `uint8` constant. | **No lock** – runs on Cloud TPU, Trainium, and CPU; the same JIT graph is selected at runtime. | **Low** – Python‑JAX boundary is safe; still recommend `jax.experimental.checkify` for runtime contracts. |
| **kernel_triton_v1350.py** | **Medium** – Triton kernels tile `S^(D‑1)` projection; when `step` → ∞ the `scale` factor overflows 32‑bit integer tile indices, causing illegal memory accesses. | **Medium** – subnormal `step` collapses the `scale` term → zero‑division guard triggers fallback to scalar path, losing performance but remaining stable. | **Compliant** – Triton passes the descriptor through a `torch.Tensor` of dtype `int64` with explicit `torch.tensor([...], dtype=torch.uint8)` for the token; size verified at compile‑time. | **Partial lock** – Triton kernels are written for AMD ROCm and NVIDIA CUDA; however the build script selects a single backend at install time, preventing cross‑vendor fallback without recompilation. | **Medium** – add `@triton.jit` guard `if not is_supported(): raise RuntimeError`; wrap in `torch.utils.cpp_extension` with `-DTRITON_DEBUG`. |

**Overall Verdict:**  
- **Numerical robustness** is **insufficient** for the extreme step regimes mandated by the specification.  
- **Rule 22** is **satisfied** in all six components.  
- **Rule 27** is **violated** in the CUDA and optional Triton back‑ends, which impose hard vendor lock‑in.  
- **FFI hardening** varies from **low** (pure‑Python/JAX) to **critical** (C++/CUDA).  

The Tribunal therefore **requires remediation** before the architecture may be declared production‑grade.

---

## Detailed Component Audits  

### 1. `kernel_orchestrator_v1350.py`  

| Aspect | Observation | Proof / Analysis |
|--------|------------|------------------|
| **Descriptor Layout** | Defined as `struct PMTPDescriptor: 4s HH Q Q Q Q B B 6x 4Q` → **exactly 88 bytes**. | `struct.calcsize("<4sHHQQQQQBB6x4Q") == 88` (Python `struct`). Zero‑token is the `B` field set to `0`. |
| **Numerical Degeneracy (|step| → ∞)** | `scale = step * B` performed in Python `float` (IEEE‑754 binary64). For `|step| ≥ 2⁶³` the product exceeds `2⁵⁹⁴` → **Infinity**. Upstream kernels treat `Inf` as NaN ⇒ divergence. | **Lemma 1**: binary64 mantissa has 53 bits; multiplication by a scalar > 2⁵⁴ inevitably loses the lower 53 bits of `B`. Hence relative error ≥ 1. |
| **Numerical Degeneracy (|step| → 0)** | Python’s default *flush‑to‑zero* is **off**, so subnormals survive. However `numpy.seterr` defaults to `under='ignore'`, causing silent underflow to zero in many downstream NumPy operations. | **Proposition 2**: Underflow to exact zero removes the *regularization* term, turning a well‑conditioned Woodbury solve into a singular system. |
| **Rule 22** | The descriptor is passed to each native component via `ctypes`/`cffi` with `c_uint8 * 88` buffer; the token byte is explicitly set to zero before the call. | **Corollary 3**: The zero‑token invariant holds by construction; no 1‑D token appears. |
| **Rule 27** | Pure‑Python implementation; no hardware‑specific API locked. | **Conclusion**: No vendor lock. |
| **FFI Hardening** | Current code uses `ctypes.CDLL(...).func.restype = None` without argument validation. | **Recommendation**: Apply `ctypes`‑level checks (`argtypes`, `restype`) and enforce `memoryview` to guarantee 88‑byte alignment. Add `try/except` for `OSError`. |
| **Condition‑Number Estimate** | For the downstream Woodbury solve `W = (step/scale) B`, the relative condition number behaves like  
\[
\kappa_{\text{rel}}(W) \approx |step| \cdot \kappa(B) / \mathrm{scale}.
\]  
Since `scale ∝ step·B`, we get \(\kappa_{\text{rel}} \approx \kappa(B)\) for moderate step, but **blows up linearly** when `scale` saturates (Inf) or underflows (0). | **Proof Sketch**: Derive from Sherman‑Morrison‑Woodbury formula; treat `scale` as scalar multiplier. |

**Action Items**  
1. Clamp `step` to the interval \([2^{-1022}, 2^{1022}]\) before any arithmetic, raising a `ValueError` otherwise.  
2. Enforce `numpy.seterr(over='raise', under='raise')` globally.  
3. Add a deterministic `hash` of the 88‑byte descriptor to guarantee token integrity across processes.

---

### 2. `kernel_cpp_v1350.cpp`  

| Aspect | Observation | Proof / Analysis |
|--------|------------|------------------|
| **AVX‑512 & OpenMP** | Uses `#pragma omp simd` with `__m512d` intrinsics; compiled with `-march=skylake-avx512`. | **Lemma 4**: AVX‑512 executes `vfmadd231pd`