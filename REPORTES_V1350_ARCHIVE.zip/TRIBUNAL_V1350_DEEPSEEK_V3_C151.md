# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 151)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 151 · Multi-File Adversarial SOTA Review

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute
**Verdict posture:** Adversarial. Claims of "12/12 conformance" and "SOTA" are treated as *unproven* until demonstrated.

---

## 0. Preliminary: What the Tribunal Can and Cannot Verify

The audit brief supplies **architectural claims**, not source. Therefore:

- **Structural claims** (88-byte layout, `panic=unwind`, `@jax.jit`, cuSOLVER `DnDsyevd`, CUDA Graphs) are audited as *specifications*.
- **Numerical claims** (Neumaier compensation, subnormal audits at −12/−14, Cayley retraction, Lyapunov solve) are audited as *mathematical objects* — we prove or refute the stated properties under the stated regimes.
- Any claim that cannot be reduced to a theorem or a falsifiable test is flagged **UNVERIFIED**.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us count bytes precisely (little-endian, standard `struct` alignment disabled by `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

✅ **Byte-exact.** 88 = 4+4+40+2+6+32. The `6x` pad is *required* to reach 88 and to align the trailing `4Q` to an 8-byte boundary relative to struct start (offset 56, divisible by 8). This is correct **only** if the struct is never embedded in a larger packed container without re-padding.

**Tribunal finding T1-A (minor):** The `6x` pad is *load-bearing*. Any refactor that removes it silently changes ABI. Recommend a `static_assert(sizeof(...) == 88)` in the C++/Rust mirrors and a `struct.calcsize("<4sHHQQQQQBB6x4Q") == 88` assertion at import time in Python.

### 1.2 Multi-silicon HardwareProbe

Claimed: probes CPU/GPU/TPU/Trainium. **Risk:** probe code that calls `torch.cuda.is_available()`, `jax.devices()`, etc., at import time creates **import-time vendor coupling** — a Rule 27 concern (see §7).

### 1.3 PmtpSlabAllocator

A slab allocator for 88-byte descriptors. **Numerical degeneracy is not applicable here** (it is an allocator), but **Rule 22** is: see §6.

### 1.4 "12/12 physical conformance checks"

**UNVERIFIED.** The brief does not enumerate the 12 checks. The Tribunal cannot certify a count it cannot see. Demand: publish the 12 predicates as executable assertions with pass/fail witnesses.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — correctness

Neumaier's variant of Kahan–Babuška:

```
s = x[0]*y[0]; c = 0
for i in 1..n-1:
    t = s + x[i]*y[i]
    if |s| >= |x[i]*y[i]|:  c += (s - t) + x[i]*y[i]
    else:                   c += (x[i]*y[i] - t) + s
    s = t
return s + c
```

**Theorem (Neumaier 1974):** For IEEE-754 binary64 with round-to-nearest, the compensated sum satisfies

  |fl(Σ xᵢyᵢ) − Σ xᵢyᵢ| ≤ (2u + O(nu²)) · Σ|xᵢyᵢ|,  u = 2⁻⁵³.

This is **first-order accurate in u**, independent of n — a genuine improvement over naive summation's O(nu). ✅

**Caveat the brief omits:** Neumaier compensation does **not** protect against **overflow in the products** `x[i]*y[i]`. If `|x[i]|·|y[i]| > DBL_MAX`, the product is `+inf` and the compensation term becomes `NaN` (`inf − inf`). Under `step → ∞` (|step| ≥ 10¹⁰) with unit-norm vectors this is safe, but with **unnormalized** inputs it is a live degeneracy.

**Tribunal finding T2-A:** Require a pre-scaling pass `x ← x/‖x‖∞`, `y ← y/‖y‖∞` before the dot product, or a documented precondition `‖x‖∞·‖y‖∞ < DBL_MAX/2`.

### 2.2 Subnormal audits at −12, −14

Interpretation: exponents −12 and −14 in some scaled representation. In binary64, subnormals begin at 2⁻¹⁰²². Exponents −12/−14 are **far above** the subnormal threshold — they are ordinary normals. So either:

- (a) the audit is in a **scaled** domain (e.g., log-space or a fixed-point mantissa), or
- (b) the claim is **misleading**.

**Tribunal finding T2-B:** Demand the exact definition of the "−12/−14 subnormal audit." If it refers to `std::fpclassify` on intermediate values, publish the actual bit patterns. If it refers to a scaled exponent, publish the scale.

### 2.3 AVX-512 + OpenMP

**Numerical degeneracy under `step → ∞`:** If `step` enters as a multiplier on a gradient, `step·g` overflows for `step ≥ 10¹⁰` and `|g| ≳ 10²⁹⁸`. In practice gradients are O(1), so `step·g` is fine up to `step ~ 10³⁰⁰`. **But** if `step` is used inside a Cayley/Woodbury denominator (Target 4), the story changes — see §4.

**OpenMP reduction:** `#pragma omp parallel for reduction(+:s,c)` on Neumaier is **incorrect** — the compensation term `c` is not associative. Must use per-thread `(s,c)` pairs and a final Neumaier merge. **Flag if not present.**

### 2.4 Zero-copy PMTP validation

"Zero-copy" implies the 88-byte descriptor is `memcpy`'d or `reinterpret_cast`'d directly. **Rule 22 compliance requires** the descriptor be exactly 88 bytes and contain no 1D token stream. See §6.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

**This is a serious misconfiguration.** The Rust Reference and the `std::panic` docs are explicit:

> Unwinding across an FFI boundary is **undefined behavior** unless the foreign code is compiled with compatible unwinding tables and the boundary is marked `extern "C-unwind"`.

`panic=unwind` **enables** unwinding; it does **not** create a safety barrier. The correct barrier is:

```rust
#[no_mangle]
pub extern "C" fn entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(v)  => v,
        Err(_) => ERR_PANIC,
    }
}
```

**Tribunal finding T3-A (critical):** If the brief's claim is that `panic=unwind` *is* the barrier, this is **false and unsafe**. If the claim is that `panic=unwind` is *enabled* and `catch_unwind` is used at every `extern "C"` boundary, then it is correct — but the brief must say so. Demand the `catch_unwind` wrappers.

### 3.2 Safe SIMD + Neumaier

Rust's `std::simd` (portable SIMD) is stable as of 1.80+ for many ops. Neumaier in SIMD requires **lane-wise** compensation and a final horizontal Neumaier merge — same associativity trap as OpenMP. **Flag if a naive `reduce_add` is used.**

### 3.3 Packed 88-byte `PmtpTensorDescriptor`

Rust `#[repr(C, packed)]` with `#[repr(align(1))]` gives 88 bytes **only if** the field layout matches `<4sHHQQQQQBB6x4Q` exactly. Rust does **not** auto-insert the `6x` pad; it must be an explicit `[u8; 6]` field. **Demand:**

```rust
#[repr(C, packed)]
pub struct PmtpTensorDescriptor {
    magic: [u8; 4],
    a: u16, b: u16,
    q: [u64; 5],
    x: u8, y: u8,
    _pad: [u8; 6],
    r: [u64; 4],
}
const _: () = assert!(std::mem::size_of::<PmtpTensorDescriptor>() == 88);
```

**Tribunal finding T3-B:** Without the explicit `_pad`, the struct is 82 bytes and Rule 22 is violated.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)

The Cayley retraction on the Stiefel manifold St(n,p) is

  Y(τ) = (I − (τ/2) A)⁻¹ (I + (τ/2) A) Y,  A = G Yᵀ − Y Gᵀ (skew),

where G is the Euclidean gradient. **This is a rational approximation to the exponential map**, second-order accurate in τ.

**Numerical degeneracy as τ → ∞:** The Cayley transform `(I − (τ/2)A)⁻¹(I + (τ/2)A)` tends to `−I` as τ → ∞ (for A with no eigenvalue at 2/τ). So `Y(τ) → −Y`. **This is not a degeneracy per se** — it is a well-defined limit — but it means the retraction **stops making progress** for large τ: the step direction reverses. For `|step| ≥ 10¹⁰`, the optimizer will oscillate.

**Tribunal finding T4-A:** The Cayley retraction is **not** a valid retraction for `|τ| ≳ 1/‖A‖₂`. Demand a step-size cap `τ ≤ τ_max = c/‖A‖₂` with `c ∈