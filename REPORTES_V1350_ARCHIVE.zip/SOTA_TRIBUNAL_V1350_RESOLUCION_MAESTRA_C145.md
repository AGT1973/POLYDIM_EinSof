# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 145

The supplied material does **not contain the eight Tribunal reports, definitions of the six V1350 kernels, PMTP layout, or benchmark data**. Therefore, no defensible model-by-model arbitration or claim of “definitive SOTA” can be made. The strongest valid synthesis is a set of **conditional architectural guarantees** that the V1350 implementation must satisfy.

## 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

A Cayley retraction is not automatically stable merely because it preserves orthogonality algebraically. For a skew-symmetric update \(A\), the ideal transform

\[
Q_{\text{new}}
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)Q
\]

is orthogonal in exact arithmetic, but extreme \(\alpha\) creates conditioning, overflow, underflow, cancellation, and solver-accuracy risks in finite precision.

The appropriate arbitration is:

- **Cayley:** potentially excellent for structure preservation, but only with scaling, stable factorization, residual checks, and a bounded fallback path.
- **Householder QR:** generally the strongest default for numerical orthogonalization because Householder transformations are backward stable and avoid explicitly forming \(Q^\top Q\).
- **Polar decomposition:** attractive when the nearest orthogonal factor is required, but its implementation must use a stable SVD, Newton–Schulz variant with safeguards, or an equivalently reliable method. An unguarded inverse-square-root iteration is not sufficient at extreme scale.
- **Naïve normal-equation or explicit-inverse variants:** cannot receive a stability guarantee.

The mathematically superior design is therefore a **hybrid**:

1. Rescale the update so the working norm lies in a safe range.
2. Compute the Cayley transform using a stable solve or structured factorization, never an explicit inverse.
3. Monitor
   \[
   \|Q_{\text{new}}^\top Q_{\text{new}}-I\|
   \]
   and the linear-solve residual.
4. Fall back to Householder QR or a stable polar factor when either tolerance fails.
5. Use compensated or extended-precision accumulation where the target precision makes the orthogonality budget otherwise unattainable.

The exact guarantee should be stated as:

> For finite, representable inputs and a non-failing numerical backend, the kernel returns either an orthogonality-certified factor satisfying the specified residual tolerances or an explicit failure/fallback status. It must not claim unconditional stability for arbitrary \(|\mathrm{step}|\ge 10^{10}\).

No source in the gathered material establishes a V1350-specific winner among Cayley, Householder, and polar QR. General manifold literature supports polar and QR constructions for Stiefel retractions, but that does not prove an implementation-level extreme-step guarantee.[15]

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release operations are necessary but not sufficient by themselves. A correct snapshot protocol requires:

- **Publication:** initialize every descriptor field first, then publish the descriptor pointer or generation with release semantics.
- **Reader acquisition:** load the published pointer/version with acquire semantics before dereferencing descriptor contents.
- **Writer replacement:** publish a new immutable descriptor rather than mutating fields visible to readers.
- **Reclamation:** do not free or reuse the old 88-byte object until the applicable RCU grace period has completed.
- **ABA protection:** use a generation counter, tagged pointer, or equivalent mechanism if addresses can be recycled.
- **Alignment and atomicity:** ensure that any atomically accessed field is naturally aligned and supported by every target ISA.
- **Snapshot scope:** define whether “isolation” means pointer-consistent, generation-consistent, or multi-object transactional consistency. Acquire/release alone does not create a multi-object transaction.

The relevant ordering principle is that release publication makes prior initialization visible to an acquire reader; acquire prevents subsequent dependent accesses from being observed before the publication event.[12] RCU additionally requires correct publication, reader dereference ordering, and grace-period completion before reclamation.[1] QSBR requires every participating reader to report quiescent states; otherwise reclamation can wait indefinitely.[3][9]

A valid guarantee is:

> A reader that successfully acquires generation \(g\) observes a fully initialized, immutable descriptor for \(g\), and that descriptor remains alive until the reader’s RCU/QSBR protection ends.

A stronger claim—“the 88-byte descriptor is snapshot-isolated solely because it uses acquire/release”—is incorrect. The descriptor size has no inherent memory-ordering significance, and field-wise mutation would invalidate the guarantee even if the pointer load is acquire and the publication store is release.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or execution model shared identically by all five environments. Conformance must therefore be specified as a **portable semantic contract**, not inferred from source-level similarity.

Required layers are:

- **C++20:** use atomics with an explicitly documented ordering and a reclamation protocol; avoid treating compiler barriers as hardware synchronization.
- **Rust:** encode ownership and lifetime guarantees where possible, but use carefully justified atomics and unsafe boundaries for lock-free reclamation. Rust’s type system does not automatically prove a custom RCU implementation correct.
- **CUDA:** distinguish device, block, system, and host visibility. A block-level barrier cannot establish system-wide publication, and kernel-launch or stream ordering must be part of the contract.
- **Triton:** establish which operations are atomic, what scope they have, and whether the generated backend preserves the intended ordering.
- **XLA:** treat operations as compiler-scheduled graph nodes; explicit ordering, side effects, token dependencies, collectives, and host/device synchronization must be represented in the HLO/XLA contract. C++-style acquire/release assumptions cannot simply be transplanted into a pure functional graph.

The portable guarantee should be:

> For each backend, the implementation supplies a backend-specific proof that publication, observation, version validation, and reclamation form a happens-before chain equivalent to the abstract PMTP protocol; unsupported scopes or orderings cause compilation-time rejection or a documented fallback, not silent weakening.

Numerical conformance also requires fixed tolerances and explicit policies for:

- NaN and infinity handling;
- signed zero;
- flush-to-zero behavior;
- fused multiply-add differences;
- reduction order;
- deterministic versus nondeterministic atomics;
- tensor layout and alignment;
- integer width and endianness;
- exception and error-status propagation.

## Arbitration of the eight Tribunal models

The names of the models alone provide no evidence about their findings. Without the actual eight reports, scores, test vectors, and assumptions, it is impossible to truthfully say that Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, or Perplexity prevailed on any kernel.

A rigorous arbitration should weight findings in this order:

1. **Executable counterexamples and reproducible tests**
2. **Formal invariants and proof obligations**
3. **Backend-specific memory-model analysis**
4. **Measured numerical residuals across extreme inputs**
5. **Assertions without test artifacts**

Accordingly, the defensible V1350 SOTA position is:

- Use **guarded Cayley with certified fallback**, not unconditional Cayley.
- Use **release publication + acquire observation + immutable descriptors + grace-period reclamation** for PMTP.
- Treat **QSBR progress** as an explicit liveness precondition.
- Define conformance through **backend-specific happens-before and numerical contracts**.
- Guarantee **certified success or explicit failure**, rather than claiming universal stability or universal cross-silicon equivalence.

Anything stronger would require the missing Tribunal outputs and V1350 specification.