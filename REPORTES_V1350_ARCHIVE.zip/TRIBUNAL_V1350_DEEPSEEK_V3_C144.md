# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 144)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 144 · Six-Component Adversarial Review

**Preliminary note on evidentiary basis.** The Tribunal has been handed *component summaries*, not source. Several claims (e.g., "12/12 physical conformance checks", "88-byte descriptor `<4sHHQQQQQBB6x4Q`") are internally checkable; others (Neumaier constants, Cayley retraction, Woodbury scaling) are checkable only against the stated semantics. Where the summary is silent, I flag it as **UNVERIFIED** rather than assume. I do not certify what I cannot see.

---

## 0. Structural pre-check: the 88-byte descriptor

The struct format `<4sHHQQQQQBB6x4Q` decodes as:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | uint16 ×2 | 4 |
| five `Q` | uint64 ×5 | 40 |
| two `B` | uint8 ×2 | 2 |
| pad | `6x` | 6 |
| four `Q` | uint64 ×4 | 32 |
| **Total** | | **88** |

**88 = 4 + 4 + 40 + 2 + 6 + 32.** ✅ Arithmetic is exact. Alignment: the struct is 8-byte aligned (88 = 11×8), so `Q` fields at offsets 8, 16, 24, 32, 40 and 56, 64, 72, 80 are all naturally aligned. **No unaligned `Q` access.** This is the one claim I can fully verify from the summary alone.

**Rule 22 (Zero 1D tokens, 88-byte PMTP) — partial verdict.** The descriptor is 88 bytes and packed. But Rule 22 also forbids *1D token streams* in inter-agent communication. A fixed 88-byte struct is a **2D-shaped record** (fields × bytes), so it satisfies the letter. **However:** the `6x` pad is a *silent channel*. If any component writes non-zero into the pad (e.g., a Rust `#[repr(C)]` struct with uninitialized padding, or a C++ `memcpy` of a partially-initialized struct), the byte-equality check across FFI will fail nondeterministically. **Recommendation:** mandate `memset(0)` on construction in all six kernels, and add a `static_assert(sizeof(...) == 88)` in C++/Rust and a `struct.calcsize('<4sHHQQQQQBB6x4Q') == 88` assertion in Python.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

**Multi-silicon HardwareProbe.** The probe must not assume `torch.cuda.is_available()` implies a specific SM count or that `jax.devices()` returns a stable order. **Degeneracy risk:** if the probe enumerates devices in a non-deterministic order (CUDA_VISIBLE_DEVICES reordering, ROCm `HIP_VISIBLE_DEVICES`), the 88-byte descriptor's device-ID field becomes non-reproducible across runs. **Fix:** sort device list by `(vendor, pci_bus_id, uuid)` before assigning IDs.

**PmtpSlabAllocator.** A slab allocator for 88-byte records is *pathological* for cache lines: 88 is not a divisor of 64, so consecutive records straddle cache lines. At 64-byte lines, record *k* starts at byte `88k mod 64 = 24k mod 64`, cycling through offsets {0, 24, 48, 8, 32, 56, 16, 40} — **every record straddles a line boundary except when 88k ≡ 0 (mod 64), i.e., k ≡ 0 (mod 8).** This is a **7/8 cache-line-split rate**. For a hot-path descriptor this is a measurable ~15–30% throughput tax on the probe/validate loop.

**Recommendation:** either (a) pad to 128 bytes (2 lines, no split, but violates Rule 22's 88-byte mandate), or (b) allocate slabs in **8-record groups** (704 bytes = 11 lines) so that the group is line-aligned and the intra-group splits are deterministic and prefetchable. Option (b) preserves the 88-byte contract.

**12/12 physical conformance checks.** Without the check list I cannot verify. **Demand:** the 12 checks must include (i) `sizeof == 88`, (ii) `alignof == 8`, (iii) endianness tag, (iv) magic match, (v) version match, (vi) pad-zero, (vii) device-ID in range, (viii) slab pointer 64-byte aligned, (ix) length field ≤ slab capacity, (x) checksum over first 82 bytes, (xi) reserved bits zero, (xii) round-trip through all six FFI boundaries. If any of these is missing, the "12/12" is theater.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

**Neumaier compensated dot product.** The Neumaier variant is:
```
s = 0; c = 0
for x,y: t = s + x*y
         if |s| >= |x*y|: c += (s - t) + x*y
         else:            c += (x*y - t) + s
         s = t
return s + c
```
**Asymptotic condition number.** For a dot product of length *n* with inputs bounded by *M*, the *forward* error of naive summation is `O(n·u·M²)`; Neumaier reduces this to `O(u·M² + n·u²·M²)` — i.e., **the *n* factor is removed from the leading term**. The *condition number* of the dot product itself is `κ = Σ|xᵢyᵢ| / |Σxᵢyᵢ|`, which is **input-dependent and unbounded** as the true sum → 0 (catastrophic cancellation). Neumaier does **not** fix ill-conditioning; it fixes *accumulation* error. **The Tribunal must reject any claim that Neumaier makes the dot product "stable" in the condition-number sense.** It makes it *backward stable*; forward accuracy still degrades as κ → ∞.

**Subnormal audits at −12, −14.** These are presumably exponents (2⁻¹², 2⁻¹⁴) or log-magnitudes. **Degeneracy as step → 0:** if `step` enters the dot product as a scalar multiplier and `step < 2⁻¹⁰²²`, the product underflows to subnormal, then to zero. Neumaier's compensation term `c` will *also* underflow, and the compensation is lost. **Concrete failure mode:** `step = 1e-310`, `x·y = 1e-10` → `step·(x·y) = 1e-320` (subnormal, ~2 bits of precision). The compensated sum cannot recover the lost bits because they were never representable. **Fix:** scale `step` into the dot product *before* the loop (fold into one operand), or use `long double` / `__float128` accumulation with explicit exponent tracking. **AVX-512 caveat:** `_mm512_fmadd_pd` flushes subnormals to zero unless MXCSR FTZ/DAZ are cleared. **Verify MXCSR at kernel entry and restore at exit** — otherwise the "subnormal audit" is auditing a mode that the FMA units are silently overriding.

**Zero-copy PMTP validation.** "Zero-copy" + "validation" is a contradiction unless validation is *read-only and in-place*. If validation writes a checksum into the descriptor, it is no longer zero-copy. **Demand:** the validation path must be `const uint8_t*` and must not mutate. If it must mutate (e.g., set a "validated" bit), that bit must be in the *caller's* copy, not the shared slab.

**Rule 27 (no vendor lock).** C++20 + AVX-512 + OpenMP is **portable in principle** but **vendor-locked in practice** if the build hard-requires `-mavx512f`. **Fix:** runtime dispatch via `__builtin_cpu_supports("avx512f")` with a scalar/AVX2 fallback. OpenMP is vendor-neutral (GCC/Clang/ICX all support it). **Verdict: conditionally compliant.**

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

**`panic = unwind` as FFI safety barrier.** This is **the single most dangerous claim in the audit.** `panic = unwind` across an FFI boundary is **undefined behavior** unless the boundary is `extern "C-unwind"` (stabilized in Rust 1.71) *and* the other side is compiled with compatible unwind tables. If the C++ side is `-fno-exceptions` (common in HPC builds), an unwinding Rust panic will **abort the process** or **corrupt the stack**. **The correct barrier is `panic = abort` at the FFI boundary, with `catch_unwind` *inside* the Rust function before returning.** 

**Concrete hardening:**
```rust
#[no_mangle]
pub extern "C" fn poly_entry(desc: *const u8) -> i32 {
    let r = std::panic::catch_unwind(|| { /* ... */ });
    match r { Ok(v) => v, Err(_) => -1 }
}
```
with `panic = "abort"` in `[profile.release]` **only if** no `catch_unwind` is used; otherwise `panic = "unwind"` is required for `catch_unwind` to work, and the boundary must be `extern "C-unwind"`. **The summary's claim is self-contradictory as stated.**

**Safe SIMD.** Rust's `std::simd` is still nightly-only as of 2024. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe` and the "Safe SIMD" claim is **false**. If it uses `wide` or `pulp` crates, the safety is crate-level, not language-level. **Demand:** name the SIMD abstraction. 

**Packed 88-byte descriptor.** `#[repr(C, packed)]` on a struct containing `u64` fields produces **unaligned `u64` accesses**, which on x86 are slow and on ARM (aarch64) are **traps** unless `-mno-unaligned-access` is off. **Do not use `packed`.** Use `#[repr(C)]` with explicit `[u8; 6]` padding — the layout is already 88 bytes and 8-aligned (see §0). **This is a correctness bug, not a style issue.**

**Neumaier sums.** Same condition-number caveat as C++. Rust's `f64