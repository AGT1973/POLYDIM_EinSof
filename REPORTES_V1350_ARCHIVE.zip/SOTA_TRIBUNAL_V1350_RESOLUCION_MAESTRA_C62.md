# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 62

The available evidence does **not** contain the six Tribunal models’ actual reports or a public specification for “POLYDIM V1350,” “PMTP,” or the six kernels. Therefore, no valid model-by-model arbitration or claim of an already-proven V1350 guarantee is possible. The technically defensible synthesis is a **conditional architecture**: Cayley retraction with safeguarded solves for moderate steps, Householder/polar fallback for pathological steps, explicit release/acquire publication for snapshots, and separate conformance proofs for each execution backend.

## 1. Stiefel retraction under \(|\mathrm{step}| \ge 10^{10}\)

For \(X \in \mathrm{St}(n,p)\), a retraction must return a matrix satisfying

\[
R_X(\xi)^\top R_X(\xi)=I_p
\]

up to the implementation’s specified floating-point tolerance.

A Cayley retraction is commonly expressed in the form

\[
R_X(\xi)
=
\left(I-\frac{1}{2}A\right)^{-1}
\left(I+\frac{1}{2}A\right)X,
\]

where \(A^\top=-A\) is constructed from \(X\) and the tangent direction. In exact arithmetic, the Cayley transform preserves orthogonality when the inverse exists. In floating-point arithmetic, however, an extreme step does **not** imply unconditional numerical stability. The solve can become poorly scaled, overflow can occur while forming \(A\), and the denominator may approach singularity when the relevant transformed operator has an eigenvalue near \(-1\). Recent conditioning analysis gives bounded local condition numbers for canonical Cayley and polar-light retractions under their nonsingularity assumptions, but those assumptions are essential.[10]

### Arbitration

- **Cayley is not universally superior** for arbitrary steps of magnitude \(10^{10}\) or larger.
- A direct fixed-point Cayley implementation is unacceptable as the sole extreme-step path.
- **Householder QR** is generally the safest orthogonalization fallback because it avoids explicitly forming a normal-equation-like inverse and is backward stable for standard dense QR implementations.
- **Polar retraction** gives the closest orthogonal factor in Frobenius norm, but its implementation must itself be stabilized—for example, through SVD or a carefully scaled polar iteration. A naïve Newton–Schulz iteration can diverge or overflow without scaling.
- The mathematically strongest design is therefore **adaptive**, not doctrinally Cayley-only.

A defensible kernel contract is:

1. Scale or normalize the tangent update before constructing the skew operator.
2. Detect non-finite values, excessive norm, loss of skew symmetry, and an estimated near-singular Cayley solve.
3. Use a stable linear solve rather than explicit matrix inversion.
4. Verify the residual

   \[
   \|R^\top R-I\| \le \tau_{\mathrm{orth}}
   \]

   and, where applicable, the retraction residual against the input.
5. Fall back to Householder QR or a scaled polar/SVD path when the test fails.
6. Return an explicit diagnostic or status code if no finite result meeting the contract can be produced.

Thus, the exact guarantee should be stated as:

> For finite representable inputs and a successful status, the kernel returns a finite \(R\) satisfying the declared orthogonality and residual bounds. It does **not** guarantee that an unscaled direct Cayley computation remains stable for every step magnitude, including \(10^{10}\).

Any Tribunal conclusion claiming unconditional Cayley superiority at extreme step size is mathematically unsupported without a precise scaling, conditioning, precision, and fallback specification.

## 2. PMTP 88-byte descriptors and RCU/QSBR snapshot isolation

An 88-byte descriptor size alone establishes no memory-ordering guarantee. The descriptor must have a defined publication protocol, alignment rules, ownership model, and lifetime mechanism.

The correct publication pattern is conceptually:

```text
writer:
    initialize immutable descriptor payload
    release-store descriptor pointer/version
    retire old descriptor only after a grace period

reader:
    enter RCU/QSBR read-side critical section
    acquire-load descriptor pointer/version
    read immutable payload
    exit read-side critical section
```

A release store followed by an acquire load of the **same atomic publication location**, where the acquire observes the released value or its release sequence, establishes the required synchronization: prior descriptor initialization becomes visible to the reader.[1][3] Acquire and release are directional; acquire does not by itself publish writes, and release does not by itself validate a reader’s observation.[1][3]

### Required architectural guarantees

The PMTP design should guarantee all of the following:

- The publication pointer or generation field is atomic and correctly aligned.
- The writer performs ordinary initialization before the release publication.
- Readers acquire the publication field before reading descriptor contents.
- Descriptor contents are immutable after publication, or every mutable field has its own synchronization.
- Readers enter the QSBR/RCU read-side region before acquiring the pointer.
- Reclamation occurs only after every reader that could have observed the old version has passed a grace period.
- Version or ABA protection is present if pointer reuse is possible.
- The 88-byte layout is independently specified: offsets, padding, alignment, endianness, atomic-field widths, and cache-line behavior.

The strongest safe statement is:

> Release/acquire provides initialization visibility for a published descriptor; RCU/QSBR provides lifetime safety through grace periods. Neither mechanism replaces the other.

An acquire load cannot prevent use-after-free if the reader dereferences the pointer outside the protected read-side interval. Conversely, QSBR without a correctly ordered publication operation does not guarantee that the reader sees fully initialized payload data.

For heterogeneous devices, host-language C++20 or Rust memory order does not automatically imply equivalent ordering inside CUDA, XLA, or Triton kernels. The implementation must define the device scope—thread, block, device, or system—and use the backend’s corresponding atomic and fence primitives. A host release followed by a device acquire is not a portable guarantee unless the runtime and memory model explicitly provide that host-device synchronization.

## 3. Multi-silicon conformance

“Conformance across CUDA, XLA, Triton, C++20, and Rust” cannot be established merely by compiling equivalent source code. These systems differ in:

- floating-point contraction and reassociation;
- flush-to-zero and denormal handling;
- atomic scopes and fence semantics;
- supported data types;
- synchronization granularity;
- compiler transformations;
- layout and alignment rules;
- asynchronous execution and stream dependencies.

C++20 and Rust have intentionally aligned acquire/release concepts: Rust documents its atomic orderings as corresponding to the C++20 model.[1][2] That establishes source-language semantic correspondence, not universal correspondence with GPU backends.

A valid conformance claim requires a normative test suite covering:

1. **Layout:** exact 88-byte size, alignment, field offsets, padding, and serialization.
2. **Numerics:** orthogonality residual, finite-result requirements, backward error, and deterministic tolerances.
3. **Memory ordering:** publication-before-observation litmus tests, stale-read tests, reclamation tests, and ABA tests.
4. **Concurrency:** randomized producer/reader schedules and delayed readers crossing grace periods.
5. **Backend behavior:** CUDA, XLA, Triton, C++20, and Rust separately, with documented scope and synchronization primitives.
6. **Silicon matrix:** every supported GPU architecture, driver/runtime combination, compiler version, and relevant CPU memory model.
7. **Negative tests:** forced extreme steps, NaNs, overflow, near-singular Cayley operators, premature reclamation, misalignment, and unsupported atomics.

The conformance result should be reported as a tuple rather than a single binary label:

\[
(\text{layout},\ \text{numeric},\ \text{memory},\ \text{lifetime},\ \text{backend},\ \text{silicon})
\]

Each component must pass independently.

## Definitive synthesis

The mathematically and architecturally superior V1350 specification is:

- **Retraction:** adaptive Cayley for well-conditioned updates; scaled Householder QR or stabilized polar/SVD fallback for extreme or ill-conditioned updates.
- **Numerical guarantee:** finite successful output plus explicit bounds on orthogonality and residual error; no unconditional claim for raw \(10^{10}\)-scale Cayley evaluation.
- **Descriptor publication:** immutable 88-byte descriptor, atomically published with release semantics and read with acquire semantics on the same publication variable.
- **Snapshot lifetime:** RCU/QSBR read-side protection begins before pointer acquisition and ends after the final dereference; reclamation follows a completed grace period.
- **Cross-device ordering:** host and accelerator synchronization are specified separately; language-level acquire/release is not silently treated as a universal GPU fence.
- **Conformance:** defined by layout, numerical, memory-order, lifetime, backend, and silicon tests, with explicit tolerances and failure diagnostics.

Accordingly, the only exact guarantees justified by the available evidence are **conditional guarantees under these stated preconditions**. A claim that all six kernels are already SOTA-conformant, that Cayley is unconditionally stable for \(|\mathrm{step}| \ge 10^{10}\), or that an 88-byte descriptor intrinsically provides RCU/QSBR isolation would exceed what can be mathematically or evidentially established.