# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 123

I cannot produce a valid arbitration of the eight Tribunal models because their findings, the six V1350 kernel specifications, and the PMTP descriptor definition were not provided or publicly verifiable in the available material. The search results identify **PolyDiM**, a library for polytopal discretization methods, but do not establish any connection to “POLYDIM V1350,” “PMTP 88-byte Descriptor,” or the listed model reports.[3][10]

The technically defensible synthesis is therefore a **conditional architecture**, not a claimed SOTA result:

### 1. Cayley–Stiefel retraction under extreme steps

No mathematically valid guarantee can be made for \(|\mathrm{step}|\ge 10^{10}\) without specifying the update equation, scaling, precision, matrix dimensions, conditioning assumptions, and overflow policy.

For a Stiefel point \(X\) and skew-symmetric direction \(\Omega\), a Cayley update generally has the form

\[
X_{+}
=
\left(I-\frac{\tau}{2}\Omega\right)^{-1}
\left(I+\frac{\tau}{2}\Omega\right)X.
\]

In exact arithmetic, the Cayley transform preserves orthogonality when the inverse exists. In floating-point arithmetic, however:

- forming \(\tau\Omega\) at \(\tau\ge 10^{10}\) can overflow or destroy relative accuracy;
- the linear solve can become poorly scaled;
- the result is not guaranteed to satisfy \(X_{+}^{T}X_{+}=I\) to machine precision;
- the transform does not itself guarantee optimization stability.

The strongest defensible rule is:

- use **scaled/skew-symmetric Cayley evaluation** with condition monitoring;
- reject, damp, or rescale extreme steps;
- apply a final orthogonalization or residual check;
- fall back to **Householder QR** or a carefully implemented **polar decomposition** when the orthogonality residual or solve condition exceeds a specified threshold.

Thus, Cayley is not unconditionally superior to Householder or polar QR at extreme step sizes. Householder QR generally offers the most established backward-stability properties for orthogonalization; polar decomposition can provide the closest orthogonal factor but may be more expensive and algorithm-dependent.

A valid guarantee would be conditional, for example:

\[
\|X_{+}^{T}X_{+}-I\| \le C\,u\,\kappa_{\mathrm{solve}}\,p(n),
\]

provided that no overflow occurs, the solve is sufficiently conditioned, and the implementation uses a specified floating-point model. Without those conditions, “stable for all \(|\mathrm{step}|\ge 10^{10}\)” is not a meaningful guarantee.

### 2. PMTP 88-byte descriptor and RCU/QSBR isolation

The descriptor size alone says nothing about memory ordering or snapshot isolation. A correct RCU/QSBR design requires a complete publication and reclamation protocol.

The minimum architectural contract should be:

1. The writer fully initializes the new descriptor and its reachable immutable state.
2. The writer publishes the descriptor pointer with **release** semantics.
3. Readers acquire the pointer with **acquire** semantics before dereferencing it.
4. Readers enter a read-side critical section before the acquisition, or otherwise use an equivalent protected snapshot mechanism.
5. Writers retire old objects only after a grace-period condition proves that every preexisting reader has passed a quiescent state.
6. The descriptor and all reachable data remain immutable—or are separately synchronized—during the read-side lifetime.

Acquire/release ordering provides **publication visibility**; it does not by itself provide reclamation safety. In particular, this pattern is insufficient:

```cpp
auto p = current.load(std::memory_order_acquire);
// use p
```

unless the reader is already protected by RCU/QSBR or an equivalent lifetime mechanism.

The exact guarantee should therefore be stated as:

> A reader observes either a fully initialized old snapshot or a fully initialized new snapshot, and no retired object is reclaimed while an eligible reader may still access it, provided that publication uses release/acquire ordering and the QSBR/RCU grace-period protocol is correctly implemented.

The 88-byte layout additionally requires an explicit ABI contract covering alignment, padding, endianness, atomic field representation, cache-line behavior, and language-level object lifetime. A byte count is not a portable concurrency specification.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single automatic memory model shared identically by these five environments. Exact cross-silicon conformance requires defining observable behavior rather than assuming source-level equivalence.

A credible conformance specification must include:

- fixed-width integer and floating-point types;
- explicit alignment and serialization rules;
- overflow, NaN, denormal, and rounding behavior;
- deterministic reduction or an allowed numerical-error envelope;
- explicit synchronization scopes;
- device/host visibility rules;
- descriptor ownership and lifetime rules;
- identical test vectors and adversarial schedules;
- architecture-specific validation on every supported GPU and CPU target.

The portable core should be expressed as a language-neutral state machine:

\[
(\text{snapshot},\text{input},\text{step})
\mapsto
(\text{new snapshot},\text{status},\text{error bounds}),
\]

with CUDA, XLA, Triton, C++20, and Rust treated as separate implementations subject to differential testing.

The strongest legitimate cross-platform claim is **observational conformance within declared numerical and memory-ordering bounds**. Bitwise identity across all backends cannot be guaranteed unless execution order, compiler transformations, floating-point modes, and atomic behavior are all constrained accordingly.

### Arbitration

Based on the available evidence, the definitive findings are:

- **No unconditional extreme-step stability guarantee** should be awarded to Cayley updates.
- **Householder QR is the conservative orthogonalization fallback**; polar QR is a viable alternative when closest-factor behavior is required.
- **Acquire/release is necessary but insufficient** for RCU/QSBR; grace-period reclamation and reader protection are indispensable.
- **An 88-byte descriptor is not inherently portable or race-free** without an ABI and lifetime specification.
- **Multi-silicon conformance must be contract-based and empirically validated**, not inferred from equivalent-looking kernels.
- No claim that one of the eight Tribunal models is correct—or that a consensus exists—can be substantiated without their actual reports and the V1350 kernel definitions.