# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 74

No public, verifiable record of **POLYDIM V1350**, its six kernels, the “Cycle 74” tribunal reports, or the six model outputs was found in the available evidence. Therefore, I cannot legitimately arbitrate those models’ specific claims or certify an implementation-level guarantee. The defensible SOTA synthesis is the following, conditional on the kernels matching the standard mathematical and memory-model interpretations.

## 1. Stiefel retraction under \(\lvert\text{step}\rvert \ge 10^{10}\)

For \(X\in\mathrm{St}(n,p)\) and a tangent update \(\eta\), the polar retraction is

\[
R_{\mathrm{polar}}(X,\eta)
=(X+\eta)\bigl((X+\eta)^{\mathsf T}(X+\eta)\bigr)^{-1/2}.
\]

The canonical Cayley update is typically expressed through a skew-symmetric matrix \(A\), followed by solving a system involving \(I-\tfrac12A\). Both methods preserve orthogonality in exact arithmetic, but neither provides an unconditional finite-precision guarantee for arbitrarily large steps.

The mathematically superior arbitration is:

- **Do not claim that Cayley is unconditionally stable for extreme steps.**
- A direct Cayley implementation can suffer from overflow, loss of significance, ill-conditioned solves, or a poorly scaled linear system when the step is \(10^{10}\) or larger.
- A direct polar implementation can likewise fail if \(X+\eta\) overflows or becomes numerically dominated by \(\eta\).
- **Householder QR with column pivoting or a carefully implemented polar decomposition is the preferred fallback**, because it avoids explicitly forming an inverse square root and can be stabilized through scaling and orthogonal transformations.
- The strongest architecture is a **scaled, rank-aware hybrid**:
  1. scale \(Y=X+\eta\) before factorization;
  2. use Householder QR or SVD/polar factorization;
  3. detect overflow, underflow, rank deficiency, and loss of orthogonality;
  4. reduce or reject the step if the requested tolerance cannot be met;
  5. optionally use Cayley only in its well-conditioned regime.

Recent analysis reports bounded forward condition numbers for canonical Cayley and polar-light Stiefel retractions in the appropriate local formulation, with cited bounds of approximately \(2\) and \(3\), respectively.[5] Those are **conditioning results**, not proof that an unscaled implementation remains stable for \(\lvert\text{step}\rvert\ge10^{10}\). QR-based Stiefel retractions are also established alternatives.[6]

### Definitive guarantee

The strongest valid guarantee is conditional:

\[
\widehat Q^{\mathsf T}\widehat Q
=I+E,\qquad
\|E\|\le C(n,p)\,u+\text{factorization residual},
\]

provided that:

- scaling prevents overflow and underflow;
- the factorization completes without rank loss;
- the input is representable;
- the implementation uses backward-stable kernels;
- the requested step is accepted only after residual checks.

There is **no unconditional guarantee of stability for every finite floating-point input with step magnitude \(10^{10}\)**. Any tribunal result asserting that Cayley alone guarantees this should be rejected as too strong.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering is sufficient for publication of an immutable snapshot when used on the same atomic publication variable:

1. The writer fully initializes the descriptor and referenced state.
2. The writer publishes the pointer, version, or sequence using a **release** store.
3. The reader obtains it using an **acquire** load.
4. The reader accesses only state reachable from that published snapshot.
5. Reclamation occurs only after the RCU/QSBR grace-period condition is satisfied.

A release store synchronizes with an acquire load that reads the released value, making preceding writes visible to subsequent operations in the acquiring thread.[1][2][8]

However, the 88-byte size is not itself a memory-safety or isolation property. The descriptor must specify:

- atomicity and alignment of every publication field;
- ownership of the pointed-to data;
- version or generation semantics;
- reader registration and quiescent-state protocol;
- reclamation rules;
- ABA protection;
- padding and layout constraints across ABIs;
- whether fields are immutable after publication.

### Exact guarantee

Acquire/release provides:

\[
\text{initialize}_{writer}
\;\prec\;
\text{release-publish}
\;\mathrel{\text{synchronizes-with}}\;
\text{acquire-read}
\;\prec\;
\text{use}_{reader}.
\]

It guarantees visibility and ordering **only along that synchronization edge**. It does not by itself guarantee:

- reclamation safety;
- absence of ABA;
- atomicity of an 88-byte whole-descriptor copy;
- consistent reading of multiple independently modified fields;
- ordering for non-atomic data accessed without a valid publication protocol;
- cross-device or cross-process coherence.

Rust’s atomic orderings follow the C++20 memory model, including the release/acquire relationship.[1][2][3][4] Thus a C++20/Rust implementation can share the same abstract ordering proof, but only if the object lifetime and data-race rules are also respected.

For QSBR, readers must announce entry or advance their epoch before dereferencing the snapshot and must publish quiescence after leaving. A writer may reclaim version \(v\) only after every reader that could have observed \(v\) has passed through a quiescent state or advanced beyond the relevant epoch.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single “conformant” claim across all five environments is not justified merely because the source algorithm is mathematically identical. The systems expose different compilation, synchronization, floating-point, and memory models.

### What can be guaranteed

A portable specification can guarantee:

- identical abstract descriptor layout through explicit serialization rather than native ABI layout;
- identical mathematical result within a declared floating-point tolerance;
- acquire/release publication semantics on host C++20 and Rust;
- device-side ordering only through explicitly supported device primitives;
- deterministic behavior only when atomics, reduction order, compiler transformations, and math modes are controlled;
- conformance through a common test suite, not source-level identity.

### What cannot be assumed

- C++20 or Rust acquire/release automatically orders CUDA device memory.
- A host atomic publication automatically makes arbitrary GPU-visible data safe without an explicit host–device synchronization operation.
- XLA preserves imperative pointer publication or arbitrary aliasing semantics.
- Triton kernels inherit the full C++ memory model.
- An 88-byte native struct has identical alignment, padding, or endianness on all targets.
- Floating-point results are bitwise identical across CUDA, XLA, Triton, C++, and Rust.
- A kernel that is valid on one GPU architecture has universal multi-silicon behavior without testing.

### Required conformance boundary

The correct architecture separates three layers:

| Layer | Required contract |
|---|---|
| Mathematical layer | Orthogonality, residual, rank, and tolerance invariants |
| Memory layer | Publication, lifetime, epoch/QSBR, and reclamation invariants |
| Backend layer | Explicit synchronization, layout, numeric mode, and compiler-specific lowering |

For the Stiefel kernels, conformance should test

\[
\|Q^{\mathsf T}Q-I\|\le \tau_{\mathrm{orth}},
\qquad
\frac{\|Q-Y\|}{\|Y\|}\le\tau_{\mathrm{retract}},
\]

along with overflow handling, rank-deficiency behavior, NaN/Inf propagation, and deterministic fallback selection.

For the descriptor, conformance should test:

- publication before observation;
- no reader observing partially initialized state;
- no reclamation while a protected reader is active;
- generation/ABA detection;
- layout size and field offsets from an explicit wire-format specification;
- host–device visibility after every required transfer or synchronization boundary.

## Arbitration outcome

The defensible ranking is:

1. **Extreme-step stability:** scaled Householder QR or SVD/polar fallback with residual validation; Cayley is an optimized path, not an unconditional extreme-step guarantee.
2. **RCU/QSBR:** release publication plus acquire observation is necessary and sufficient for initialization visibility, but reclamation requires a separate correctly implemented grace-period protocol.
3. **Multi-silicon conformance:** achievable only as a layered, tolerance-based contract with explicit backend synchronization and serialization rules; it cannot be inferred from C++20/Rust semantics alone.

Accordingly, the definitive V1350 claim should be phrased as:

> The implementation guarantees mathematically valid Stiefel outputs and snapshot isolation when its scaling, residual checks, atomic publication, reader protection, reclamation, and backend synchronization preconditions hold. It does not guarantee unconditional Cayley stability at arbitrary extreme steps, whole-object atomicity of an 88-byte descriptor, or bitwise cross-backend equivalence.