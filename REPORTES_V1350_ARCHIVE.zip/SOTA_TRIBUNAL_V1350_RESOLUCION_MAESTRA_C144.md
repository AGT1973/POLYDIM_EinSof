# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 144

The requested **definitive arbitration cannot be performed from the supplied evidence**: the eight model reports, the six V1350 kernel specifications, and the PMTP memory-layout/ordering contract were not provided, and the available search evidence does not identify a public “POLYDIM V1350” specification. The only directly relevant result establishes general QSBR/RCU ordering requirements, not the claimed V1350 architecture.[1]

## Arbitration status

| Question | Defensible finding | Architectural guarantee |
|---|---|---|
| Cayley–Stiefel retraction at \(|\mathrm{step}|\ge 10^{10}\) | No unconditional stability claim is justified. A Cayley map can be undefined or severely ill-conditioned when its linear-system denominator becomes singular or nearly singular; extreme step size does not by itself establish stability. | **Conditional only:** guarantee stability if the implementation specifies a bounded/skew-symmetric formulation, pivoting or a backward-stable solve, finite-precision error bounds, singularity detection, and a fallback such as polar retraction or QR. |
| Householder/Polar QR comparison | Householder QR is generally backward stable for well-posed factorizations; polar decomposition can provide an orthogonal factor but requires a stable algorithm and rank/conditioning assumptions. Neither is automatically safe for arbitrary extreme steps. | **Numerical stability, not exact invariance:** guarantee only a residual/orthogonality bound tied to machine precision and condition number. |
| PMTP 88-byte descriptor and RCU/QSBR | Acquire/release operations alone do not create a complete RCU/QSBR protocol. Publication, reader entry, quiescent-state reporting, reclamation, and grace-period completion must be specified together. QSBR implementations explicitly rely on barriers and on readers observing the published generation before dereferencing the new pointer.[1] | **Conditional snapshot isolation:** a reader sees a fully initialized descriptor if publication is a release store and acquisition precedes all descriptor loads; reclamation is safe only after a correctly completed grace period. |
| CUDA, XLA, Triton, C++20, Rust | No single memory model makes an unqualified cross-silicon guarantee. CUDA and Triton use device-specific scopes and fences; XLA may reorder or fuse operations; C++20 and Rust define language-level atomic behavior but do not automatically impose accelerator or host-device ordering. | **No portable guarantee without a formal per-backend contract, generated barriers, scope mapping, and litmus/conformance tests.** |

## Mathematically defensible synthesis

For a Stiefel point \(X\) with \(X^{\mathsf T}X=I\), a Cayley-style update should be treated as

\[
X_{+} = Q(\alpha)X,\qquad
Q(\alpha)=(I-\alpha A)^{-1}(I+\alpha A),
\]

with \(A^{\mathsf T}=-A\), **only when** \(I-\alpha A\) is nonsingular and the solve is numerically controlled. In exact arithmetic, \(Q(\alpha)\) is orthogonal, so the Stiefel constraint is preserved. In floating-point arithmetic, the implementable guarantee is instead of the form

\[
\|X_{+}^{\mathsf T}X_{+}-I\|
\le
C\,u\,\kappa(I-\alpha A)+O(u^2),
\]

where \(u\) is unit roundoff and \(C\) depends on the solve and matrix dimensions. As \(|\alpha|\) becomes extreme, this bound is not uniformly small merely because \(A\) is skew-symmetric. Therefore, \(|\mathrm{step}|\ge10^{10}\) must trigger scaling, condition estimation, or fallback—not a claim of unconditional Cayley superiority.

A sound kernel policy is:

1. Scale or damp the step before forming the Cayley system.
2. Detect overflow, loss of skew symmetry, rank deficiency, and poor conditioning.
3. Use a backward-stable Householder QR or a stable polar algorithm as fallback.
4. Verify the orthogonality residual and return an explicit failure/status flag when the bound is exceeded.
5. Never advertise “stability for all extreme steps” without a quantified bound.

## PMTP/RCU guarantee that can actually be stated

For a descriptor \(D\), publication must follow this ordering:

\[
\text{initialize }D
\;\prec_{\mathrm{sb}}\;
\text{release-publish}(D).
\]

A reader must execute:

\[
\text{acquire-load}(D)
\;\prec_{\mathrm{sb}}\;
\text{all reads of }D.
\]

Retirement must follow:

\[
\text{unlink}(D)
\;\prec\;
\text{completed grace period}
\;\prec\;
\text{reclaim}(D).
\]

The 88-byte size is irrelevant to these ordering guarantees. It may affect alignment, cache-line placement, atomicity, and tearing, but it does not itself establish any memory barrier. If the descriptor contains multiword state, the implementation must specify which fields are atomic, whether readers may observe mixed versions, and whether a sequence counter, immutable publication, or double-collect validation is required.

The strongest defensible guarantee is therefore:

> A reader that enters the protected read-side critical section before acquiring the published descriptor observes a fully initialized immutable snapshot, and reclamation does not occur until that reader has passed through a recognized quiescent state.

That statement fails if readers access fields before acquisition, if QSBR reporting is delayed indefinitely, if the publisher reuses mutable storage, or if the grace-period algorithm is not correctly implemented. The relevant QSBR implementation evidence specifically describes waiting for readers to report quiescence or observe the current generation and requires ordering barriers around those transitions.[1]

## Cross-silicon conformance

A true conformance claim requires a reference abstract machine and backend obligations:

- **C++20/Rust:** define the source-level atomic protocol, ownership, aliasing, and data-race freedom.
- **CUDA:** map publication and reader operations to the required thread/block/device/system scope; host-device visibility must be explicit.
- **Triton:** prohibit transformations that remove or move synchronization, and define the supported scope of atomics/fences.
- **XLA:** represent synchronization as compiler-visible effects or opaque custom calls; ordinary tensor dataflow is insufficient for arbitrary RCU semantics.
- **Silicon tests:** run message-passing, publication, reclamation, ABA, torn-read, and stale-generation litmus tests on every supported device and execution mode.

Accordingly, the highest justified SOTA designation is:

> **Formally specified and conditionally verified**, not universally stable or universally conformant.

The requested “exact architectural guarantees” would require the missing eight tribunal reports plus, at minimum, the six kernel definitions, descriptor field map and alignment, atomic widths/scopes, publication/reclamation pseudocode, numerical tolerances, backend lowering rules, and conformance-test results.