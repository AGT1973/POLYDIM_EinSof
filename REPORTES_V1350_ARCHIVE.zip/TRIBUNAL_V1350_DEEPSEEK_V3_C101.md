# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 101)

# POLYDIM V1350 — High Tribunal Audit, Cycle 101

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods.
**Verdict posture:** Adversarial. Claims are treated as unproven until a proof or a counterexample is produced.

---

## 0. Preliminary: what the audit can and cannot certify

The six targets are described by *specification fragments*, not by source. I will therefore audit:

1. **The stated invariants** (88-byte descriptor, 12/12 conformance, Rule 22/27) as *claims to be falsified*.
2. **The numerical regimes** `|step| ≥ 1e10` and `step → 0` against the *algorithms named* (Neumaier, Cayley/Stiefel, Woodbury, Lyapunov, Clifford rotors).
3. **The FFI / silicon-contract surface** as described.

Where a claim is under-specified, I mark it **UNPROVEN** and give the exact test that would settle it. I do not invent line numbers.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let me actually count the struct.

| Field | Format | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Arithmetic check:** 4+4+40+2+6+32 = 88. ✅ The struct is *self-consistent*.

**But two adversarial observations:**

- **Alignment hazard.** With native alignment, `Q` requires 8-byte alignment. After `4sHH` (offset 8) the first `Q` is aligned. After `BB` (offset 50) the `6x` pad brings us to 56, aligned for `4Q`. So the layout is *naturally aligned* — good. However, if the C++/Rust/CUDA sides use `#pragma pack(1)` or `#[repr(packed)]`, the *same* 88 bytes will be produced but **misaligned 8-byte loads** will occur on the `4Q` tail. On AVX-512 this is a performance cliff, not a correctness bug — but on some ARM64 paths it is a fault. **Recommendation:** mandate `alignas(8)` / `#[repr(C, align(8))]` and add a `static_assert(sizeof(...) == 88)` in every language.

- **Endianness.** `4sHHQQQQQBB6x4Q` is endian-sensitive. The descriptor is described as "binary" but no byte-order tag is present in the visible fields. If the orchestrator ships descriptors across a heterogeneous fabric (x86 ↔ ARM ↔ TPU host), **Rule 22 compliance is not provable** without an explicit endianness field or a documented canonical order. **UNPROVEN.**

### 1.2 "12/12 physical conformance checks"

Twelve checks is a suspiciously round number. The audit demands the *list*. Without it, the claim is **UNPROVEN**. The minimum defensible set for a multi-silicon probe is:

1. `sizeof(descriptor) == 88`
2. `alignof(descriptor) == 8`
3. magic matches
4. version matches
5. `pmtp_offset % 64 == 0` (cache-line)
6. `pmtp_len` within slab
7. slab base 64-byte aligned
8. no overlap between descriptor and payload
9. checksum over bytes [0,88)
10. endianness tag matches host
11. `n_dims ≤ 4` (matches `4Q`)
12. reserved pad bytes are zero

If any of these is missing, the "12/12" is theater.

### 1.3 `PmtpSlabAllocator` — degeneracy at `step → 0`

A slab allocator keyed on `step`-derived sizes will, as `step → 0`, request **subnormal-sized** allocations. Two failure modes:

- **Integer underflow:** if `size = f(step)` with `f` monotone and `step` is a float, `int(f(step))` can round to 0, then `malloc(0)` returns a valid-but-unusable pointer. Subsequent writes are UB.
- **Denormal flush:** if `step` is stored as `float32` and the platform has FTZ/DAZ enabled (common on AVX-512 with `-ffast-math`), `step = 1e-40` becomes `0.0`, and the allocator silently collapses to the zero-size path.

**Proof obligation:** show `f` is bounded below by a positive integer for all `step ∈ (0, 1e10]`. **UNPROVEN.**

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška gives a **forward error bound** for the dot product `s = Σ aᵢbᵢ`:

$$
|\hat{s} - s| \;\le\; \big(2u + O(nu^2)\big)\sum_i |a_i b_i| \;+\; O(u^2)\,|s|
$$

where `u = 2⁻⁵³` for FP64. The **condition number** of the dot product is

$$
\kappa_{\text{dot}} \;=\; \frac{\sum_i |a_i b_i|}{|\sum_i a_i b_i|}
$$

Neumaier is **backward stable** but **not** immune to `κ_dot → ∞` (catastrophic cancellation). The claim "compensated ⇒ safe" is **false** in the regime where the true sum is near zero and the terms are large.

**Adversarial test:** `a = [1e16, 1, -1e16]`, `b = [1, 1, 1]`. Neumaier returns `1.0` correctly; naive returns `0.0`. But `a = [1e16, 1, -1e16 + 1e-16]` — Neumaier returns `1.0` while the true answer is `1.0 + 1e-16`, which is *not representable*. The compensation cannot recover information that was never in the inputs. **This is a fundamental limit, not a bug** — but the audit demands the kernel *document* it.

### 2.2 Subnormal audits at `-12, -14`

The exponents `-12` and `-14` are almost certainly **decimal** exponents (`1e-12`, `1e-14`), not binary. In FP64:

- `1e-12` is a **normal** number (min normal ≈ `2.2e-308`).
- `1e-14` is also **normal**.

So "subnormal audit at -12/-14" is a **category error** unless the kernel is operating in FP32 or FP16. In FP32, min normal ≈ `1.18e-38`, so `1e-12` and `1e-14` are still normal. **The audit flags this as a specification defect.** Either:

- The exponents are **binary** (`2⁻¹² ≈ 2.4e-4`, `2⁻¹⁴ ≈ 6.1e-5`) — still normal in FP64/FP32.
- The kernel is doing something else (e.g., scaling by `2^12`, `2^14`).

**Demand:** the exact test vectors and the exact FP format. **UNPROVEN.**

### 2.3 Zero-copy PMTP validation

"Zero-copy" + "validation" is a contradiction unless validation is done **in-place** on the mapped buffer. The audit requires:

- **TOCTOU proof:** between validation and use, can another thread mutate the descriptor? If yes, zero-copy is a **security hole** (Rule 22 violation in spirit).
- **Alignment proof:** AVX-512 `_mm512_load_ps` requires 64-byte alignment. If the PMTP slab is only 8-byte aligned, the kernel must use `_mm512_loadu_ps`, which is slower. **Demand:** `alignas(64)` on the slab.

### 2.4 `step → ∞` degeneracy

For `|step| ≥ 1e10`, any update of the form `x ← x + step·d` will **saturate** the mantissa: `x + 1e10·d` loses all bits of `x` below `1e10·|d|·u ≈ 1e10·|d|·2.2e-16 ≈ 2.2e-6·|d|`. If `|d| ~ 1`, the effective precision of `x` drops to ~6 decimal digits. **The kernel must clamp `step` or use compensated updates.** **UNPROVEN** whether it does.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the single most dangerous claim in the entire audit.**

`panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is explicitly `extern "C-unwind"` (stabilized in Rust 1.71) **and** the other side is compiled with compatible unwinding. The default `extern "C"` **aborts** on unwind (since Rust 1.81 this is enforced; before that it was UB).

**Verdict:** If the Rust kernel uses `extern "C"` and `panic = unwind`, the "safety barrier" is **fictional**. The correct patterns are:

1. `extern "C-unwind"` on both sides, with a C++ `catch(...)` at the boundary.
2. Or `catch_unwind` **inside** the Rust function, converting panic to an error code.
3. Or `panic = abort` and no unwinding at all.

**Recommendation (concrete FFI hardening):**

```rust
#[no_mangle]
pub extern "C" fn poly_kernel_step(
    desc: *const PmtpTensorDescriptor,
    step: f64,
    out: *mut f64,
) -> i32 {
    let result = std::panic::catch_unwind(|| {
        // ... kernel body ...
    });
    match result {
        Ok(()) => 0,
        Err(_) => -1, // panic converted to error code
    }
}
```

Plus `#[repr(C, align(8))]` on `PmtpTensorDescriptor` and a `const _: () = assert!(std::mem::size_of::<PmtpTensorDescriptor>() == 88);`.

### 3.2 "Safe SIMD"

Rust's `std::simd` is **nightly-only** as of this writing. If the kernel claims "Safe SIMD" on stable Rust