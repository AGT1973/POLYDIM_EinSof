# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 91

A definitive arbitration is not possible from the supplied record because the six Tribunal models’ actual reports, kernel specifications, and conformance tests were not provided. The available evidence supports a **conditional synthesis**, not a proof that any particular V1350 implementation satisfies the requested guarantees.

## 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

A Cayley retraction is not automatically stable merely because it preserves orthogonality algebraically. For a skew-symmetric generator \(\Omega\), the usual map is

\[
Q(\Omega)=(I-\tfrac12\Omega)^{-1}(I+\tfrac12\Omega),
\]

or an equivalent low-rank formulation. In exact arithmetic, \(Q(\Omega)\) is orthogonal whenever the inverse exists. However, its numerical behavior depends on scaling, conditioning, overflow avoidance, and the linear solver used.

The critical guarantee is therefore:

\[
\boxed{\text{Cayley is structure-preserving, but not unconditionally stable for arbitrary extreme steps.}}
\]

Relevant failure modes include:

- overflow or loss of significance while forming \(\Omega\);
- ill-conditioned solves if the implementation forms the inverse explicitly;
- loss of tangent-direction fidelity when the step is far outside the local-retraction regime;
- breakdown of inverse or logarithmic formulas near an eigenvalue of \(-1\).

Recent analysis reports bounded forward condition numbers for canonical Cayley and polar-light retractions under their stated domain assumptions, but also identifies the essential exclusion of an eigenvalue \(-1\) in the relevant relative transform.[2] Iterative Cayley methods likewise require a contraction condition involving the scaled generator; one cited formulation requires a sufficiently small scaling parameter relative to \(\|\Omega\|\), which directly conflicts with treating an unscaled \(10^{10}\) step as benign.[3]

Householder QR and polar retraction have different strengths:

| Method | Exact-arithmetic property | Extreme-step behavior | Appropriate guarantee |
|---|---|---|---|
| Cayley | Orthogonality if the solve is valid | Can be stable after scaling, but not unconditionally | Stable only with scaling, certified solve, residual checks, and fallback |
| Householder QR | Backward-stable factorization in standard floating-point settings | Usually the safest general projection, provided the input is representable | Orthogonality and backward-error bounds, not necessarily closest-point optimality |
| Polar | Nearest orthogonal/Stiefel factor in Frobenius norm | Good when the Gram/inverse-square-root computation is well-conditioned; iterative variants require safeguards | Best geometric projection, but needs robust eigensolver/SVD or certified inverse square root |

The mathematically superior policy is therefore **not “Cayley always wins.”** It is a safeguarded hybrid:

1. Represent the update in a scale-safe form.
2. Choose \(\alpha\) so that \(\|\alpha\Omega\|\) lies in a certified numerical range.
3. Evaluate Cayley through a backward-stable structured solve, never an explicit inverse.
4. Check
   \[
   \|Q^\top Q-I\| \le \tau_{\mathrm{orth}}
   \]
   and the linear-system residual.
5. If either test fails, fall back to Householder QR or a robust polar/SVD projection.
6. If the semantic contract requires the full step rather than a bounded retraction, reject the update instead of silently clipping it.

Thus the strongest defensible architectural guarantee is:

\[
\boxed{
\text{For every finite input that passes representability and conditioning checks,}
\ \widehat Q^\top\widehat Q=I+E,\quad
\|E\|\le \tau_{\mathrm{orth}},
}
\]

with a specified fallback or error for inputs outside the certified domain. No unconditional guarantee for all \(|\mathrm{step}|\ge10^{10}\) follows from the Cayley formula alone.

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

Acquire/release ordering is necessary but not sufficient for a complete RCU/QSBR design.

A release publication of a descriptor, followed by an acquire load that observes that publication, establishes the required happens-before relationship for initialization:

\[
\text{descriptor initialization}
\;\xrightarrow{\text{release}}\;
\text{publication}
\;\xrightarrow{\text{acquire}}\;
\text{reader access}.
\]

The C++ memory model states this synchronization rule explicitly: a release store synchronizes with an acquire load that reads its value.[6] Formal RCU verification likewise uses release/acquire ordering to ensure that node initialization precedes reader access.[1]

For reclamation, however, the descriptor must not be freed merely because a reader acquired the pointer. The writer also needs a valid grace-period protocol:

- readers announce entry or a protected epoch;
- readers perform the required acquire operations before dereferencing;
- readers publish quiescent states with the required release ordering;
- the writer waits until every pre-existing reader has passed through a quiescent state;
- only then may the old descriptor or payload be reclaimed.

QSBR documentation specifically calls for acquire loads in relevant reader-side checks,[5] while established QSBR implementations wait for the appropriate quiescent-state generation before committing or reclaiming state.[11]

The exact guarantee should distinguish **publication safety** from **snapshot consistency**:

\[
\boxed{
\text{Acquire/release prevents premature visibility of initialization;}
}
\]

\[
\boxed{
\text{RCU/QSBR grace-period completion prevents premature reclamation;}
}
\]

\[
\boxed{
\text{Immutable, versioned, or transactionally published payloads provide snapshot isolation.}
}
\]

An 88-byte size does not itself establish atomicity, alignment, lock-freedom, or tear-free copying. The PMTP descriptor should therefore have:

- explicit alignment and layout assertions;
- atomic publication fields rather than atomic assumptions about the whole 88-byte object;
- immutable fields after publication, or version/seqlock validation for mutable fields;
- a release publication and acquire consumption path;
- an explicit lifetime token, epoch, hazard pointer, or QSBR grace-period rule;
- version validation if a reader must observe a self-consistent multi-field snapshot.

The strongest defensible guarantee is:

\[
\boxed{
\text{A reader that acquires version }v\text{ and remains inside the protected read-side section}
\text{ observes a fully initialized descriptor for }v,
}
\]

and reclamation of \(v\) occurs only after all readers that could have observed \(v\) have passed a verified grace period.

Acquire/release alone does **not** guarantee:

- atomic 88-byte loads or stores;
- absence of torn field combinations;
- freedom from ABA;
- reclamation safety without QSBR/RCU protocol completion;
- a globally identical snapshot if fields are independently mutable.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or numerical model shared identically by all five targets. Conformance must therefore be defined as a **portable semantic contract**, with backend-specific implementations and tests.

C++20 provides a language-level atomic memory model, including release/acquire synchronization.[6] Rust can express comparable ordering through its atomic APIs, but unsafe pointer lifetime and reclamation obligations remain the programmer’s responsibility. CUDA and Triton expose device-side execution and memory-ordering mechanisms whose scopes, supported atomics, and synchronization behavior must be mapped explicitly. XLA is a compiler/IR system with aggressive transformation and execution-model constraints; host-language atomic semantics cannot simply be assumed to survive as device-side descriptor operations.

Consequently:

| Property | Portable across all five? | Required treatment |
|---|---:|---|
| Algebraic orthogonality | Yes, as a tested numerical contract | Define norm, tolerance, precision, and fallback behavior |
| Exact 88-byte atomic descriptor update | No general portable guarantee | Publish an atomic pointer/index/version, not the whole descriptor |
| Acquire/release publication | Only through backend-specific mappings | Specify scope, visibility domain, and compiler lowering |
| RCU/QSBR reclamation | Not automatically portable to accelerator kernels | Keep reclamation in a supported control plane or implement explicit epochs |
| Bitwise-identical floating-point results | Generally no | Require tolerance-based or deterministic-mode conformance |
| Layout compatibility | Not automatic | Use generated schemas, offsets, alignment, endian rules, and static/runtime checks |
| Progress and fairness | Backend-dependent | State separately; do not infer from memory ordering |

A sound cross-silicon conformance suite should test at least:

- descriptor size, alignment, offsets, and version encoding;
- publication-before-consumption visibility;
- no reader access after grace-period reclamation;
- ABA/version-wrap behavior;
- descriptor snapshot consistency under concurrent publication;
- Cayley residual and orthogonality error;
- QR/polar fallback equivalence within stated tolerances;
- overflow, NaN, Inf, singular-solve, and unrepresentable-step handling;
- CUDA/XLA/Triton lowering of the same abstract operations;
- C++20 and Rust reference-model equivalence;
- device memory scopes and synchronization domains;
- deterministic behavior where explicitly promised.

## Definitive arbitration

The strongest mathematically and architecturally defensible V1350 synthesis is:

1. **Retraction kernel:** use a scaled, structured Cayley update as the fast path; certify its residual and orthogonality; use Householder QR or robust polar projection as fallback. Do not claim unconditional stability for raw steps of magnitude \(10^{10}\) or greater.

2. **Descriptor kernel:** publish an immutable descriptor through an atomic pointer, index, or generation field using release semantics; consume it with acquire semantics; protect its lifetime with RCU/QSBR or an equivalent epoch protocol. Do not treat the 88-byte descriptor as one atomic object.

3. **Portability kernel:** define conformance at the level of observable invariants—visibility, lifetime, snapshot consistency, layout, numerical residuals, and error behavior—rather than claiming identical implementation semantics across CUDA, XLA, Triton, C++20, and Rust.

The exact guarantees that can legitimately be advertised are therefore **conditional and testable**:

\[
\boxed{
\text{Numerical safety} \iff
\text{finite representable inputs}
+\text{ certified conditioning}
+\text{ residual-checked fallback}.
}
\]

\[
\boxed{
\text{Snapshot safety} \iff
\text{ acquire/release publication}
+\text{ immutable/versioned state}
+\text{ completed grace period before reclamation}.
}
\]

\[
\boxed{
\text{Multi-silicon conformance} \iff
\text{ a backend-specific implementation satisfies one common invariant contract}.
}
\]

Claims stronger than these—especially “Cayley is unconditionally superior under extreme steps,” “acquire/release alone makes an 88-byte descriptor atomic,” or “all five execution environments share identical RCU and floating-point semantics”—are not established by the available evidence.