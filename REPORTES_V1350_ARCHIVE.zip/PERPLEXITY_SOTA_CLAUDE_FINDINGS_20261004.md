# 🚀 CONSULTA DIALÉCTICA SOTA PERPLEXITY (HALLAZGOS CLAUDE / TRIBUNAL)
**Fecha:** 2026-10-04 10:07:19
**Motor:** Perplexity Sonar-Pro (API Paga)
**Protocolo:** `polydim-virtual-hardening-loop` (Pasos 4, 5 y 6)

---



================================================================================
# 🚀 TEMA SOTA (HALLAZGO CLAUDE / TRIBUNAL): Exact Antipodal Levi-Civita Parallel Transport under Numerical Tangent Noise & Bisector Reformulation
================================================================================
### ⏱️ TIEMPO 1: ASYMPTOTIC D >= 10^5 RESEARCH (Latencia: 17.20s)

No. The Householder construction is **exact in exact arithmetic for the non-antipodal geodesic**, but it is not an *unconditionally stable* formulation for every \(\theta\in[0,\pi]\) in floating-point arithmetic. The antipodal case is intrinsically non-unique, and near \(\theta=\pi\) the problem is ill-conditioned regardless of the algebraic formula.

For \(x,y\in S^{D-1}\), \(y\neq -x\), define
\[
w=x+y,\qquad u=\frac{w}{\|w\|}.
\]
The reflection
\[
H=I-2uu^\top
\]
maps \(x\) to \(-y\), so
\[
P_{x\to y}(v)=-Hv
      =-v+2\langle u,v\rangle u
\]
is the Levi–Civita parallel transport of \(v\in T_xS^{D-1}\) along the unique minimizing great-circle geodesic from \(x\) to \(y\). Depending on the chosen orientation/sign convention, the same operation may be written using the Householder vector based on \(e_j-x_jx\); the sign of \(u\) does not affect the reflection.

The key numerical issue is
\[
\|x+y\|^2=2(1+\langle x,y\rangle)
         =4\cos^2(\theta/2).
\]
Thus, as \(\theta\to\pi\),
\[
\|x+y\|=2\cos(\theta/2)\to0.
\]
The bisector formulation avoids explicitly computing \(1+\langle x,y\rangle\) by catastrophic subtraction, and choosing
\[
j=\arg\min_i |x_i|
\]
makes
\[
e_j-x_jx
\]
well-conditioned as a tangent vector. These are important and correct stabilizations. In particular, using
\[
\langle u,v\rangle
 =
 \frac{v_j-x_j\langle x,v\rangle}
      {\|e_j-x_jx\|}
\]
is preferable to forming \(u\) and then separately taking a potentially noisy dot product in very high dimension.

However, they do **not** remove the fundamental singularity at the antipode:

- At \(y=-x\), infinitely many minimizing geodesics connect the two points.
- Levi–Civita transport depends on which geodesic is selected.
- Consequently, there is no single-valued continuous transport map \(P_{x\to y}\) extending the minimizing-geodesic transport through \(y=-x\).
- Near the antipode, small perturbations in \(y\) can change the selected great-circle plane substantially, so relative sensitivity necessarily grows like \(1/\|x+y\|\), approximately \(1/(\pi-\theta)\).

Therefore the precise conclusion is:

| Regime | Householder/bisector transport |
|---|---|
| \(\theta=0\) | Identity transport; handle directly to avoid unnecessary normalization |
| Moderate \(0<\theta<\pi\) | Exact geometric formula and generally numerically stable |
| \(\theta\) close to \(\pi\) | Algebraically stabilized, but intrinsically ill-conditioned |
| \(\theta=\pi\) | Not uniquely defined without an additional chosen tangent direction/geodesic |

The finite-precision condition \(\langle x,v\rangle\approx10^{-16}\) does not invalidate the formula. In exact geometry, \(v\in T_xS^{D-1}\) satisfies \(\langle x,v\rangle=0\); in floating point, one should usually project first:
\[
v\leftarrow v-x\langle x,v\rangle.
\]
For \(D\gtrsim10^5\), the dot product should be accumulated with a numerically robust reduction—pairwise summation, compensated summation, or an appropriate extended-precision accumulator when available. The expected absolute dot-product error is dimension-dependent, so treating \(10^{-16}\) as universally negligible is not justified merely because it is near machine epsilon.

A robust implementation should therefore:

1. Normalize \(x\) and \(y\), or maintain them normalized to working precision.
2. Project \(v\) onto \(T_xS^{D-1}\).
3. Use a stable inner product for \(c=\langle x,y\rangle\).
4. Handle \(c\approx1\) with \(P(v)=v\).
5. For \(c\) away from \(-1\), use the bisector/Householder formula.
6. When \(1+c\) is below a prescribed threshold, declare the pair **near-antipodal** rather than claiming unconditional accuracy.
7. At or near the antipode, select an explicit auxiliary tangent direction \(q\perp x\) and define transport along the corresponding chosen great circle; document that this is a convention, not a uniquely determined Levi–Civita transport between the endpoints.

The optimization literature distinguishes this exact geodesic parallel transport from **vector transport** associated with a retraction. Absil’s framework explicitly treats vector transport as a practical proxy for parallel translation, while Boumal’s treatment similarly separates the exact differential-geometric operation from retraction-based transports.[1][2] Recent optimization work continues to use retractions and vector transports specifically because exact parallel transport may be computationally impractical or unnecessary.[3][4] The sphere’s exact transport formula is standard, but these sources do not establish a floating-point theorem asserting unconditional stability at the antipode.

Thus, the Householder/bisector expression is best described as:

> **an exact non-antipodal formula with strong numerical safeguards, but not an unconditionally stable all-angle algorithm.**

The unavoidable qualification is the neighborhood of \(\theta=\pi\), where the mathematical transport problem itself loses uniqueness and becomes ill-conditioned.

**Citas:** https://perso.uclouvain.be/pa.absil/Talks/ICIAM070717_oom_05.pdf, https://publications.mfo.de/bitstream/handle/mfo/3825/OWR_2020_36.pdf?sequence=4&isAllowed=y, https://sma.epfl.ch/~nboumal/papers/boumal_optimization_and_estimation_on_manifolds_phd_thesis.pdf, https://optimization-online.org/wp-content/uploads/2013/06/3905.pdf, https://ar5iv.labs.arxiv.org/html/1802.09128

### ⏱️ TIEMPO 2: STRICT SILICON RESTRICTIONS & MEMORY LAYOUT (Latencia: 23.60s)

Use a **single streaming pass over `x` and `y`**, accumulate all three quantities in independent AVX-512 accumulators, and reduce only after the main loop:

\[
\|x+y\|^2=\sum_i(x_i+y_i)^2,\qquad
\langle x+y,v\rangle=\sum_i(x_i+y_i)v_i,\qquad
\langle x,v\rangle=\sum_i x_i v_i.
\]

For \(D=10^6\), this is normally **memory-bandwidth bound**, not FMA-throughput bound. The critical optimization is therefore to minimize loads, stores, loop overhead, and unnecessary reductions—not to horizontally reduce every vector iteration. Intel recommends software reduction sequences because AVX-512 has no direct promoted horizontal-add equivalent, and independent partial reductions can be kept in vector registers until the end.[1]

## Recommended inner-loop structure

Assume contiguous, non-overlapping `f64` arrays:

```rust
#[target_feature(enable = "avx512f")]
unsafe fn kernel_avx512(
    x: *const f64,
    y: *const f64,
    v: *const f64,
    n: usize,
) -> (f64, f64, f64) {
    use core::arch::x86_64::*;

    let mut p0 = _mm512_setzero_pd();
    let mut p1 = _mm512_setzero_pd();
    let mut p2 = _mm512_setzero_pd();

    let mut i = 0usize;

    // Process 4 zmm vectors per iteration: 32 doubles.
    while i + 32 <= n {
        let x0 = _mm512_loadu_pd(x.add(i));
        let y0 = _mm512_loadu_pd(y.add(i));
        let v0 = _mm512_loadu_pd(v.add(i));

        let x1 = _mm512_loadu_pd(x.add(i + 8));
        let y1 = _mm512_loadu_pd(y.add(i + 8));
        let v1 = _mm512_loadu_pd(v.add(i + 8));

        let x2 = _mm512_loadu_pd(x.add(i + 16));
        let y2 = _mm512_loadu_pd(y.add(i + 16));
        let v2 = _mm512_loadu_pd(v.add(i + 16));

        let x3 = _mm512_loadu_pd(x.add(i + 24));
        let y3 = _mm512_loadu_pd(y.add(i + 24));
        let v3 = _mm512_loadu_pd(v.add(i + 24));

        let s0 = _mm512_add_pd(x0, y0);
        let s1 = _mm512_add_pd(x1, y1);
        let s2 = _mm512_add_pd(x2, y2);
        let s3 = _mm512_add_pd(x3, y3);

        // p0 = sum (x+y)^2
        p0 = _mm512_fmadd_pd(s0, s0, p0);
        p0 = _mm512_fmadd_pd(s1, s1, p0);
        p0 = _mm512_fmadd_pd(s2, s2, p0);
        p0 = _mm512_fmadd_pd(s3, s3, p0);

        // p1 = sum (x+y)*v
        p1 = _mm512_fmadd_pd(s0, v0, p1);
        p1 = _mm512_fmadd_pd(s1, v1, p1);
        p1 = _mm512_fmadd_pd(s2, v2, p1);
        p1 = _mm512_fmadd_pd(s3, v3, p1);

        // p2 = sum x*v
        p2 = _mm512_fmadd_pd(x0, v0, p2);
        p2 = _mm512_fmadd_pd(x1, v1, p2);
        p2 = _mm512_fmadd_pd(x2, v2, p2);
        p2 = _mm512_fmadd_pd(x3, v3, p2);

        i += 32;
    }

    let mut a = horizontal_sum(p0);
    let mut b = horizontal_sum(p1);
    let mut c = horizontal_sum(p2);

    while i < n {
        let sx = *x.add(i) + *y.add(i);
        let vi = *v.add(i);
        let xi = *x.add(i);

        a += sx * sx;
        b += sx * vi;
        c += xi * vi;
        i += 1;
    }

    (a, b, c)
}

#[target_feature(enable = "avx512f")]
unsafe fn horizontal_sum(z: core::arch::x86_64::__m512d) -> f64 {
    use core::arch::x86_64::*;

    let lo = _mm512_castpd512_pd256(z);
    let hi = _mm512_extractf64x4_pd(z, 1);
    let s = _mm256_add_pd(lo, hi);

    let s = _mm_add_pd(
        _mm256_castpd256_pd128(s),
        _mm256_extractf128_pd(s, 1),
    );

    let s = _mm_add_sd(s, _mm_unpackhi_pd(s, s));
    _mm_cvtsd_f64(s)
}
```

The example is schematic: a production implementation should usually use **multiple accumulators per quantity**, rather than repeatedly updating only one accumulator. Four independent accumulators reduce dependency-chain pressure and provide enough instruction-level parallelism to hide FMA latency. Intel’s optimization guidance likewise recommends software reduction sequences and avoiding unnecessary horizontal reductions inside the main loop.[1]

## Memory traffic

For `f64`, every element requires approximately:

- `x`: 8 bytes loaded
- `y`: 8 bytes loaded
- `v`: 8 bytes loaded
- no stores in the streaming loop

Total: **24 bytes per element**, or roughly **24 MB per million elements**. The arithmetic is approximately:

- one vector add for \(x+y\)
- three products/FMA streams
- no temporary `x+y` array

Materializing `x+y` would add at least one store and one reload, increasing traffic and generally reducing attainable bandwidth.

The kernel should therefore:

- use **structure-of-arrays** layout: separate contiguous `x`, `y`, and `v`;
- avoid gathers and indirect indexing;
- avoid writing intermediate vectors;
- use `_mm512_loadu_pd` unless alignment is guaranteed and measured to matter;
- keep all partial sums in registers;
- perform scalar or vector horizontal reduction once per completed block or at function exit.

Alignment is helpful but usually less important than contiguous access and sufficient memory-level parallelism. For a one-million-element stream, benchmark aligned and unaligned loads on the target processor rather than assuming aligned loads are faster.

## Unrolling and accumulator count

A practical starting point is:

- unroll by **4 or 8 zmm vectors**;
- use at least **2–4 independent accumulators per scalar result**;
- process 32–64 doubles per iteration;
- keep the loop branch as a single predictable `while` back edge.

For example, conceptually maintain:

```text
norm0, norm1, norm2, norm3
dot_sum0, dot_sum1, dot_sum2, dot_sum3
dot_x0, dot_x1, dot_x2, dot_x3
```

and combine them after the loop. This increases register pressure: three reductions × four accumulators already consume twelve zmm registers, before accounting for loaded `x`, `y`, and `v`. AVX-512 provides enough architectural registers for this, but excessive unrolling can cause spills. Inspect generated assembly and benchmark unroll factors rather than maximizing them blindly.

If the kernel is truly DRAM-bandwidth limited, increasing unrolling beyond the point that hides arithmetic latency will not help and may hurt due to code size or register pressure.

## Avoid branch-misprediction penalties

There should be no data-dependent branches. Use:

1. One predictable main-loop branch.
2. One cleanup branch for the tail.
3. Masked loads for the final partial vector, or a short scalar cleanup.

A masked tail avoids a branch per element:

```rust
let remaining = n - i;
let mask = _bzhi_u32(u32::MAX, remaining as u32);
```

Then use `_mm512_maskz_loadu_pd` for each input. In practice, a scalar tail of fewer than eight `f64` values is often cheaper and simpler. The tail is negligible at \(D=10^6\), so prioritize the steady-state loop.

Do not use per-element checks such as:

```text
if i < n { ... }
```

inside the vector loop. Bounds checks should be eliminated by using raw pointers in the trusted `unsafe` kernel or by structuring slices so LLVM can prove the bounds.

## Dot-product algebra

The expression

\[
\langle x+y,v\rangle
\]

can be computed either as:

\[
(x+y)v
\]

or as:

\[
xv+yv.
\]

The first form requires one vector add and one multiply/FMA. The second requires two products, unless \(\langle y,v\rangle\) is needed independently. Therefore use:

```text
s = x + y
dot_xyv += s * v
dot_xv  += x * v
```

This shares the `x+y` vector and minimizes arithmetic.

For the norm, use an FMA:

```text
norm = fma(s, s, norm)
```

This reduces instruction count and generally improves both throughput and numerical behavior. However, if bitwise reproducibility or a specific floating-point error model is required, document the use of fused operations and reassociation.

## Numerical considerations

A parallel SIMD reduction changes summation order. If ordinary floating-point accuracy is sufficient, vector partial sums are appropriate. If reproducibility or improved accuracy is required:

- use pairwise reduction;
- accumulate in `f64` if inputs are `f32`;
- consider compensated summation only after measuring its cost;
- do not assume FMA alone provides compensated summation.

For Householder/bisector calculations, also guard the later scalar normalization steps against zero or near-zero vectors. The streaming reduction itself should remain branch-free; handle degenerate cases after the three scalars have been computed.

## Rust `cdylib` dispatch

Compile the AVX-512 implementation as a specialized function and dispatch once at the API boundary:

```rust
#[no_mangle]
pub extern "C" fn bisector_kernel(
    x: *const f64,
    y: *const f64,
    v: *const f64,
    n: usize,
    out: *mut f64,
) {
    assert!(std::arch::is_x86_feature_detected!("avx512f"));

    unsafe {
        let (a, b, c) = kernel_avx512(x, y, v, n);
        *out.add(0) = a;
        *out.add(1) = b;
        *out.add(2) = c;
    }
}
```

Rust supports runtime CPU-feature detection through `is_x86_feature_detected!`, while static enabling can be done with compiler target features or target CPU settings.[10][12] Keep the feature check outside the hot loop. If the deployment CPU is known and homogeneous, compiling the entire library with the appropriate target features can remove dispatch overhead, but it sacrifices portability.

For a portable `cdylib`, provide at least:

- scalar fallback;
- AVX2/FMA path;
- AVX-512F path.

Do not enable AVX-512 globally unless every consumer CPU supports it. AVX-512 can also trigger processor frequency changes on some systems, so compare total kernel time and system throughput—not only instructions per cycle.

## Measurement priorities

Benchmark the following separately:

- cold versus warm cache;
- one call versus repeated calls;
- aligned versus unaligned pointers;
- 4-way versus 8-way unrolling;
- one versus multiple accumulators;
- AVX2 versus AVX-512;
- local NUMA memory versus remote memory;
- scalar tail versus masked tail.

Use hardware counters for:

- achieved memory bandwidth;
- L1/L2/LLC misses;
- load-port utilization;
- FMA utilization;
- register spills;
- front-end stalls;
- AVX frequency behavior.

At \(D=10^6\), if the three arrays are not cache-resident, the best implementation will usually be the one that approaches the platform’s sustainable read bandwidth with the fewest instructions per byte. The central design is therefore: **three contiguous streaming loads, one shared `x+y`, three independent vector reductions, no temporary array, no inner-loop horizontal reduction, and one predictable loop branch**.

**Citas:** https://cdrdv2-public.intel.com/821614/356477-Software-Optimization-Manual_V2.pdf, https://cdrdv2-public.intel.com/814199/356477-Optimization-Reference-Manual-V2-002.pdf, https://dev-doc.rust-lang.org/beta/unstable-book/language-features/avx512-target-feature.html, https://cdrdv2-public.intel.com/814198/248966-Optimization-Reference-Manual-V1-049.pdf, https://builders.intel.com/docs/networkbuilders/intel-avx-512-instruction-set-for-packet-processing-technology-guide-1645717553.pdf

### 🔬 PASO 6: REPREGUNTA DE PROFUNDIZACION SOTA (Latencia: 43.56s)

Para \(D\ge 10^7\), la mejora SOTA no consiste en “hacer exacta” la operación en aritmética IEEE-754 —eso es imposible en general—, sino en separar tres objetivos:

1. **cero deriva geométrica**, imponiendo tangencia por construcción;
2. **tangencia numéricamente verificable**, mediante una corrección final;
3. **cotas explícitas dependientes de \(D\)**, usando acumulación reproducible o compensada y, cuando sea necesario, precisión extendida.

La transformación matemática sigue siendo

\[
P(v)=-v+2\langle u,v\rangle u,\qquad
u=\frac{x+y}{\|x+y\|},
\]

para \(y\neq -x\). Es ortogonal y, en aritmética exacta, preserva la norma y transforma \(T_xS^{D-1}\) en \(T_yS^{D-1}\). En punto flotante, sin embargo, cada producto escalar y cada operación vectorial introduce errores del orden de \(D\varepsilon_{\rm mach}\) si se usa suma secuencial; con suma por árbol, el factor pasa aproximadamente a \(\log_2D\), y con suma compensada puede reducirse sustancialmente, aunque no desaparecer.

## 1. La formulación más estable

No debe calcularse directamente

\[
u=\frac{x+y}{\|x+y\|}
\]

si \(\theta\) está cerca de \(\pi\), porque \(\|x+y\|\) es pequeño. Una formulación algebraicamente equivalente evita normalizar el bisector:

\[
P(v)
=
-v+
2\,\frac{\langle x+y,v\rangle}{\|x+y\|^2}(x+y).
\]

Pero tampoco conviene formar \(\|x+y\|^2=2(1+\langle x,y\rangle)\) mediante \(1+\langle x,y\rangle\), pues esa suma pierde resolución cuando \(\langle x,y\rangle\approx-1\).

La versión recomendada es formar

\[
w=x+y
\]

componente a componente, calcular \(\|w\|\) con una norma escalada tipo LAPACK, y usar una sola normalización estable. Para evitar además una división problemática en la proyección, puede elegirse el índice

\[
j=\arg\min_i |x_i|
\]

y utilizar el vector tangente

\[
q=e_j-x_jx.
\]

Como

\[
\|q\|^2=1-x_j^2,
\]

la elección anterior garantiza

\[
\|q\|^2\ge 1-\frac1D.
\]

Para \(D\ge 10^7\), esto significa que \(\|q\|\) está extremadamente cerca de \(1\). En consecuencia, la construcción basada en \(q\) no sufre la degeneración que aparecería al escoger una coordenada arbitraria con \(|x_j|\approx1\).

Una forma particularmente útil es calcular la reflexión mediante el vector \(q\), evitando formar una matriz \(D\times D\):

\[
R_q(v)=v-2\frac{\langle q,v\rangle}{\langle q,q\rangle}q.
\]

La operación de transporte se obtiene con el signo correspondiente a la convención elegida. La estructura importante es que sólo requiere:

- uno o dos productos escalares;
- una actualización tipo \(v+\alpha q\);
- ningún almacenamiento de matriz densa;
- trabajo \(O(D)\) y memoria \(O(D)\).

Las transformaciones de Householder son ortogonales y están perfectamente condicionadas en norma \(2\); su aplicación es backward-stable, con error relativo típico del orden de \(\varepsilon_{\rm mach}\) por aplicación, no de la condición de la reflexión. La estabilidad real queda dominada por la formación de \(x,y\), las normas y los productos escalares, no por la reflexión ideal en sí.[2][6][11]

## 2. Tangencia exacta por construcción

Si \(v\in T_xS^{D-1}\), entonces idealmente

\[
\langle x,v\rangle=0.
\]

El resultado ideal satisface

\[
\langle y,P(v)\rangle=0.
\]

En punto flotante, calcular simplemente

\[
\widehat p=-\widehat v+
2\,\widehat{\langle u,v\rangle}\,\widehat u
\]

no garantiza que

\[
\widehat{\langle y,\widehat p\rangle}=0.
\]

La solución más robusta es aplicar una **proyección tangencial final**:

\[
p_{\rm tan}
=
\widehat p-
\widehat y\,
\operatorname{fl}\!\bigl(\langle \widehat y,\widehat p\rangle\bigr).
\]

Si \(\widehat y\) está normalizado con suficiente precisión, esto produce

\[
\langle \widehat y,p_{\rm tan}\rangle
\]

del orden del error de redondeo de la última actualización, en vez de acumular el error completo de la reflexión.

Para obtener una condición aún más fuerte, debe combinarse con una segunda evaluación reproducible de la tangencia:

\[
r_y=\operatorname{fl}\!\bigl(\langle \widehat y,p_{\rm tan}\rangle\bigr),
\qquad
p_{\rm tan}\leftarrow p_{\rm tan}-r_y\widehat y.
\]

Una o dos iteraciones son suficientes en la práctica si el producto escalar se calcula con acumulación precisa. No se obtiene cero bit a bit en IEEE-754 en general, pero sí un residuo acotado por la evaluación final.

La propiedad clave es:

\[
\left|\langle \widehat y,p_{\rm tan}\rangle\right|
\lesssim
\gamma_D\|\widehat y\|\,\|p_{\rm tan}\|,
\]

donde, para suma secuencial,

\[
\gamma_D=\frac{D\varepsilon}{1-D\varepsilon}
\approx D\varepsilon,
\]

mientras que para suma por árbol balanceado,

\[
\gamma_{\lceil\log_2D\rceil}
\approx
\lceil\log_2D\rceil\varepsilon.
\]

Para \(D=10^7\), con aritmética binaria de doble precisión,

\[
D\varepsilon_{64}\approx 2.2\times10^{-9},
\]

pero

\[
\log_2(10^7)\varepsilon_{64}
\approx 5\times10^{-15}.
\]

Por tanto, para esa dimensión la diferencia entre suma secuencial y suma por árbol es de varios órdenes de magnitud. Las cotas estándar de productos escalares muestran precisamente una dependencia proporcional al número de niveles de acumulación; una suma por árbol produce un factor del tipo \(\gamma_{\lceil\log_2D\rceil}\), no \(\gamma_D\).[13]

## 3. “Cero deriva” geométrica: qué puede garantizarse realmente

Hay que distinguir tres significados de cero deriva.

### Cero deriva algebraica

La fórmula exacta satisface

\[
\|P(v)\|=\|v\|,
\qquad
P(v)\in T_yS^{D-1}.
\]

Esto sólo es cierto exactamente en aritmética real.

### Cero deriva estructural

Puede conservarse la estructura ortogonal usando una reflexión Householder, en lugar de una expansión que forme matrices o acumule rotaciones. La reflexión ideal no amplifica errores porque

\[
\|H\|_2=1.
\]

Esta es la garantía numérica más importante: el algoritmo es backward-stable respecto de una reflexión cercana.[2][6]

### Cero deriva observable

Para imponer una garantía operacional, deben corregirse explícitamente las invariantes:

1. renormalizar \(x\) e \(y\);
2. transportar mediante la reflexión;
3. proyectar el resultado sobre \(T_yS^{D-1}\);
4. renormalizar sólo si la conservación de norma es prioritaria;
5. repetir la proyección tangencial si el residuo excede el umbral.

La renormalización final debe usarse con cuidado:

\[
p\leftarrow \frac{p}{\|p\|}\|v\|.
\]

Esto controla la norma, pero puede volver a introducir un pequeño residuo tangencial. Por ello, el orden recomendado es:

\[
\text{reflexión}
\;\longrightarrow\;
\text{corrección de tangencia}
\;\longrightarrow\;
\text{corrección de norma}
\;\longrightarrow\;
\text{corrección final de tangencia}.
\]

Si se exige simultáneamente norma y tangencia con máxima precisión, es preferible resolver ambas restricciones mediante una normalización tangencial:

\[
z=p-y\langle y,p\rangle,
\qquad
p_{\rm final}
=
\frac{\|v\|}{\|z\|}z.
\]

Después de esta normalización debe evaluarse nuevamente \(\langle y,p_{\rm final}\rangle\), porque la multiplicación escalar puede introducir un último error.

## 4. Productos escalares para \(D\ge 10^7\)

La principal amenaza no es la reflexión, sino la reducción de \(10^7\) productos.

### Suma secuencial

Una reducción ordinaria tiene una cota pesimista

\[
|\operatorname{fl}(a^\top b)-a^\top b|
\le
\gamma_D\sum_i|a_ib_i|.
\]

Con \(D\varepsilon\) ya cercano a \(10^{-9}\) en doble precisión, esta cota es demasiado débil para garantías estrictas.

### Suma por árbol

Una reducción paralela balanceada reduce la profundidad a

\[
L=\lceil\log_2D\rceil.
\]

La cota pasa a

\[
|\widehat{s}-s|
\lesssim
\gamma_L\sum_i|a_ib_i|.
\]

Para \(D=10^7\), \(L\approx24\), lo que hace que el error de acumulación sea del orden de unas pocas decenas de \(\varepsilon_{64}\), en lugar de millones de \(\varepsilon_{64}\).

### Suma compensada

Kahan, Neumaier o variantes por bloques pueden reducir el error a aproximadamente

\[
O(\varepsilon)\sum_i|a_ib_i|
\]

bajo hipótesis habituales, aunque el coste y la reproducibilidad dependen de la implementación. Para GPU o sistemas distribuidos, la mejor solución suele ser:

- productos en FP64;
- suma local compensada;
- reducción global por árbol;
- orden fijo de reducción.

### FMA

El uso de FMA para calcular

\[
s\leftarrow \operatorname{fma}(a_i,b_i,s)
\]

redondea el producto y la suma conjuntamente. No elimina el crecimiento dependiente de \(D\), pero reduce el error por operación y evita un redondeo intermedio.

### Precisión extendida

Si se necesita una garantía cercana al límite de resolución de FP64, los productos escalares críticos —en particular \(\langle x,v\rangle\), \(\langle y,p\rangle\) y las normas— deben acumularse en:

- double-double;
- acumulador de expansión;
- FP128 cuando esté disponible;
- o un producto escalar exactamente redondeado.

La estrategia práctica más eficiente es mixta: almacenar vectores en FP64, pero acumular los escalares geométricamente críticos en precisión extendida.

## 5. Cotas recomendadas

Sea \(\widehat p\) el resultado de una aplicación Householder estable y sea \(\widehat y\) la versión normalizada de \(y\). Una cota razonable de backward error tiene la forma

\[
\widehat p
=
P_{\widetilde x\to\widetilde y}(\widetilde v)
+
\delta p,
\]

con

\[
\frac{\|\delta p\|}{\|\widetilde v\|}
\lesssim
C\,
\gamma_L
+
C'\varepsilon,
\]

donde:

- \(L=D\) para reducción secuencial;
- \(L=\lceil\log_2D\rceil\) para reducción balanceada;
- \(C,C'\) son constantes moderadas;
- la cota empeora cerca del antipodal porque el problema mismo se vuelve mal condicionado.

Para la tangencia final, tras proyectar,

\[
\frac{|\langle \widehat y,p_{\rm tan}\rangle|}
{\|\widehat y\|\,\|p_{\rm tan}\|}
\lesssim
\gamma_L+\varepsilon.
\]

Con suma secuencial y \(D=10^7\), la cota pesimista puede ser del orden de \(10^{-9}\). Con árbol balanceado en FP64, puede reducirse al orden de \(10^{-15}\), salvo cancelaciones, subnormales, errores de normalización o problemas de entrada. La afirmación “tangencia exacta” debe reservarse, por tanto, para:

- aritmética exacta;
- o una representación algebraica que fuerce el residuo a cero, algo que IEEE-754 no garantiza para un producto escalar general.

## 6. Tratamiento de \(\theta\approx\pi\)

Ninguna fórmula puede hacer bien condicionado el transporte cuando \(y\approx-x\): la geodésica minimizante deja de ser única. La mejora correcta es definir un umbral explícito.

Por ejemplo, usar el bisector si

\[
\|x+y\|>\tau_{\rm anti},
\]

y, si no,

1. seleccionar un eje \(e_j\) con \(|x_j|\) mínimo;
2. construir un vector tangente \(q=e_j-x_jx\);
3. definir una dirección ortogonal auxiliar;
4. declarar que el transporte depende de esa elección de rama.

El umbral debe expresarse en términos de la precisión y del objetivo de exactitud, no sólo de \(\theta\). Cerca del antipodal, un cambio de tamaño comparable con el ruido de entrada puede cambiar la geodésica elegida por una cantidad grande. Éste es un límite de condicionamiento, no un defecto del algoritmo.

## 7. Diseño SOTA recomendado

Para \(D\ge10^7\), la implementación de referencia debería cumplir:

- entradas \(x,y,v\) normalizadas con norma escalada;
- productos escalares mediante árbol reproducible;
- FMA cuando esté disponible;
- acumulación FP64 como mínimo;
- acumulación extendida para las restricciones críticas;
- reflexión Householder aplicada implícitamente;
- selección \(j=\arg\min_i|x_i|\) en la rama auxiliar;
- ninguna formación explícita de matrices;
- proyección final sobre \(T_yS^{D-1}\);
- normalización tangencial para corregir simultáneamente norma y tangencia;
- segunda proyección de verificación;
- detección explícita de la región antipodal;
- pruebas de invariantes con el mismo acumulador reproducible usado por el algoritmo.

Las transformaciones Householder son preferibles porque son ortogonales, no amplifican errores en norma \(2\) y admiten análisis backward-stable; la calidad final, especialmente a \(D\ge10^7\), depende principalmente del esquema de reducción de productos escalares y de las correcciones explícitas de las restricciones geométricas.[1][2][6][11]

**Citas:** https://www.bohrium.com/en/sciencepedia/feynman/numerical_linear_algebra_graduate-stability_of_numerical_algorithms, https://www.cs.cornell.edu/courses/cs6210/2019fa/lec/2019-10-07.pdf, https://ollybritton.com/notes/uni/part-c/mt25/nla/notes/overview-of-results-and-methods/, https://ocw.mit.edu/courses/18-335j-introduction-to-numerical-methods-spring-2019/pages/week-4/, https://johnkerl.org/doc/hh.pdf



================================================================================
# 🚀 TEMA SOTA (HALLAZGO CLAUDE / TRIBUNAL): SOTA GPU Triton Stiefel Retractions: 2-Phase SMW (Wen-Yin) vs Polar Newton-Schulz
================================================================================
### ⏱️ TIEMPO 1: ASYMPTOTIC D >= 10^5 RESEARCH (Latencia: 22.04s)

For \(D=10^5\!-\!10^7\) and \(K=16\!-\!64\), **the two-phase Cayley–SMW method is the most likely lowest-latency choice when the update is already expressed as a low-rank Cayley transform**, while **QR is the safer choice for strict \(10^{-6}\) isometry on arbitrary or poorly conditioned inputs**. Newton–Schulz can be competitive only when several matrix operations are efficiently fused and the input is suitably scaled; it is not the default winner for this extreme tall-skinny regime.

## Cost structure

| Method | Dominant work | Synchronization / memory behavior | Expected isometry |
|---|---:|---|---|
| **Cayley–SMW, 2 phase** | \(O(DK)\) streaming plus \(O(K^3)\) host/device reduction | One or more reductions, small \(K\times K\) solve, then one streaming pass | Excellent in exact arithmetic; implementation-sensitive |
| **Polar Newton–Schulz** | Usually \(m\) passes of \(O(DK)\) GEMM-like work plus \(K\times K\) products | Multiple global passes and iteration-dependent synchronization | Approximate; tolerance depends strongly on scaling, precision, and iteration count |
| **QR / TSQR** | \(O(DK^2)\) arithmetic, though often memory-bound for \(K\le64\) | Reduction tree and orthogonalization dependencies | Best-established route to near-machine-precision orthogonality |

### 1. Two-phase Cayley–SMW

For a rank-\(K\) Cayley update, the required operations are:

\[
G=V^\top U,\qquad
p=V^\top X,\qquad
q=U^\top X,
\]

followed by the \(K\times K\) solve

\[
(I+G)^{-1},
\]

and a streamed update of the form

\[
Y=X-2(U\alpha-V\beta).
\]

The large-\(D\) portion is therefore a small number of \(O(DK)\) memory passes. Since \(K\le64\), the \(K^3\) inversion is negligible relative to reading and writing \(D\times K\) data. The critical issue is not floating-point operation count but **global reduction latency and data movement**.

For a single vector \(X\), the reduction phase computes only \(K\)-dimensional quantities and can be implemented with GPU reductions or host/BLAS work. However, moving these reductions to the host introduces synchronization and PCIe/NVLink latency. For a single retraction, that overhead may dominate. If many columns or many independent updates are batched, the reduction cost amortizes much better.

The streamed phase is close to the theoretical lower bound: it reads the tall-skinny operands and performs \(O(DK)\) work. This is especially favorable because the \(D\times K\) problem is generally **memory-bandwidth-bound**, not compute-bound. Recent TSQR work similarly reports that very skinny factorizations are dominated by memory traffic and that avoiding extra passes over \(Q\) can provide substantial speedups.[13]

**Latency verdict:** likely best for a low-rank Cayley update, provided the reductions remain on-device or are efficiently batched.

### 2. Polar Newton–Schulz

Newton–Schulz computes an approximation to the polar factor through repeated matrix iterations. Convergence requires appropriate spectral scaling; one cited formulation requires the largest singular value to satisfy

\[
\sigma_{\max}(X_0)<\sqrt{3},
\]

with nonsingularity also required.[1][7]

Each iteration generally requires another multiplication involving the tall matrix, so the method makes multiple \(O(DK)\) passes. For well-conditioned, nearly orthogonal inputs, two to five iterations are commonly reported as a practical range.[10] Accelerated variants such as CANS reduce the number of iterations needed for a target accuracy, and one source reports that a single CANS iteration can approach the accuracy of two Cayley iterations for small steps.[1]

The drawback for this use case is that **every extra iteration costs another full traversal of the \(D\times K\) matrix**. At \(D=10^7\), that is expensive even when \(K\) is only 16–64. Newton–Schulz becomes more attractive when:

- the update is already available as a dense \(D\times K\) matrix;
- Tensor Cores can be used effectively;
- several iterations are fused;
- host/device synchronization must be avoided;
- approximate orthogonality is acceptable.

It is less attractive when the update naturally has a rank-\(K\) Cayley representation and only one streamed output pass is needed.

**Latency verdict:** usually slower than 2-phase SMW for a single low-rank Cayley update; potentially competitive for batched dense orthogonalization with a highly optimized fused implementation.

**Accuracy verdict:** not inherently sufficient for

\[
\|Y^\top Y-I\|_2\le10^{-6}.
\]

The iteration count, normalization, precision, and conditioning must be calibrated empirically. FP32 variants can achieve high accuracy in favorable cases, whereas lower-precision variants may preserve orthogonality but exhibit larger reconstruction error.[5]

### 3. QR retraction

QR computes

\[
X=QR,
\]

and returns \(Q\). It is the most conventional retraction for the Stiefel manifold and generally provides the strongest numerical orthogonality guarantee, particularly with Householder QR or a carefully implemented TSQR.

However, classical QR has \(O(DK^2)\) arithmetic and more synchronization than the SMW update. For \(K=16\!-\!64\), the arithmetic count is still moderate, but the matrix is so tall that memory traffic and reduction dependencies dominate. GPU TSQR and communication-avoiding QR are specifically designed for this regime; TSQR reorganizes the factorization into block reductions to reduce memory movement.[2][14] Recent work on very tall, very skinny matrices identifies the regime \(K\le64\) as inherently memory-bound and reports benefits from Q-less formulations that avoid storing or materializing \(Q\).[13]

QR is therefore not automatically slow, but it needs a specialized implementation. A generic library QR may incur:

- unnecessary formation of Householder data;
- extra workspace traffic;
- multiple kernel launches;
- poor utilization for \(K\le64\);
- a costly explicit application of \(Q\).

A Q-less or fused TSQR implementation can substantially narrow the gap, especially when the output itself is the only required object.

**Latency verdict:** generally behind SMW for a structured rank-\(K\) Cayley update, but potentially competitive with an optimized Q-less TSQR implementation.

**Accuracy verdict:** best default for the strict isometry requirement. Reorthogonalization or higher-precision accumulation may be required if the input is ill-conditioned or if the implementation uses low precision.

## Meeting \(\|Y^\top Y-I\|_2\le10^{-6}\)

The answer depends on the precision and on what is being retracted.

### If \(Y\) is formed by a Cayley transform

In exact arithmetic, a Cayley transform is orthogonal. The SMW formulation preserves that property mathematically, but finite-precision error enters through:

- the \(K\times K\) solve;
- the reductions \(U^\top X\) and \(V^\top X\);
- cancellation in \(U\alpha-V\beta\);
- accumulation and output precision;
- conditioning of \(I+V^\top U\).

For FP32, a well-conditioned implementation with FP64 or compensated accumulation for the \(K\times K\) reductions can plausibly satisfy the \(10^{-6}\) spectral isometry target. But this should not be assumed solely from the algebra. The implementation should explicitly measure

\[
\|Y^\top Y-I\|_2
\]

and monitor the condition number of \(I+V^\top U\).

A practical robust configuration is:

- FP32 storage for \(D\times K\) arrays;
- FP32 or FP64 accumulation for dot products;
- FP64 or at least high-quality FP32 factorization of the \(K\times K\) system;
- residual checking of the small solve;
- optional reorthogonalization only when the measured error exceeds tolerance.

### If \(Y\) is produced by Newton–Schulz

The tolerance is not guaranteed by using a fixed iteration count. The stopping criterion should be based on a small Gram matrix:

\[
E=Y^\top Y-I_K,\qquad \|E\|_2\le10^{-6}.
\]

Because \(K\) is small, this check is inexpensive, but checking after every iteration adds synchronization. A fixed iteration schedule is faster but requires prior characterization over the expected spectrum and step sizes.

### If \(Y\) is produced by QR

Householder TSQR with stable accumulation is the most reliable way to meet the tolerance across a broad range of inputs. Cholesky-based QR can be faster, but its orthogonality degrades with conditioning; iterated Cholesky QR or Householder reorthogonalization may be needed for difficult inputs.

## Recommendation

For the stated dimensions, the practical ranking is:

1. **Two-phase Cayley–SMW** — lowest latency when the update is genuinely low-rank and the reduction phase is kept on the GPU or batched. It is the preferred performance path.
2. **Q-less TSQR / specialized QR** — preferred when strict numerical robustness is more important than minimum latency, or when the input is arbitrary and not naturally a Cayley low-rank update.
3. **Polar Newton–Schulz** — attractive for dense batched orthogonalization and GPU-friendly matrix-multiply pipelines, but usually requires multiple full \(D\times K\) passes and explicit accuracy validation.

Thus, for a **well-conditioned rank-\(K\) Cayley step**, choose **2-phase SMW** and use mixed-precision reductions plus a Gram-residual check. For a requirement that must hold robustly across poorly conditioned inputs without problem-specific tuning, choose **Householder/Q-less TSQR**, accepting higher latency. Newton–Schulz should be selected only after benchmarking its iteration count and measured isometry error on the actual spectrum of updates.

**Citas:** https://arxiv.org/pdf/2506.10935, https://www2.eecs.berkeley.edu/Pubs/TechRpts/2010/Archive/EECS-2010-131.pdf, https://www.emergentmind.com/topics/chebyshev-optimized-newton-schulz-cans-method, https://www.emergentmind.com/topics/momentum-matrix-orthogonalization, https://iclr-blogposts.github.io/2026/blog/2026/polar-svd/

### ⏱️ TIEMPO 2: STRICT SILICON RESTRICTIONS & MEMORY LAYOUT (Latencia: 26.00s)

For \(D=10^6\) and \(K=32\), the kernel is primarily a **streaming, memory-bandwidth-bound update**, not a shared-memory– or tensor-core–bound GEMM. Use `BLOCK_SIZE=1024` as a starting point, but benchmark 512 and 2048 as well; the best choice depends on register pressure, launch occupancy, and the exact update formula.

## Recommended layout

Assume vectors or rows are laid out contiguously in the dimension \(D\), with rank-\(K\) factors stored in a compact second dimension:

\[
X[d] \leftarrow X[d] + \sum_{k=0}^{K-1} a_k\,b_{d,k}.
\]

A practical Triton mapping is:

- One program instance owns a contiguous tile of \(D\): 512–2048 elements.
- Iterate over \(K=32\) inside the program.
- Load the \(K\)-length coefficients once per program, preferably into registers.
- Load each \(D\)-tile with a contiguous, vectorizable access pattern.
- Accumulate in FP32 where numerical stability matters.
- Store once at the end.

Conceptually:

```python
pid = tl.program_id(0)
offs_d = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
mask_d = offs_d < D

acc = tl.load(x_ptr + offs_d, mask=mask_d, other=0.0).to(tl.float32)

for k in range(K):
    coeff = tl.load(a_ptr + k).to(tl.float32)
    vals = tl.load(
        b_ptr + k * D + offs_d,
        mask=mask_d,
        other=0.0,
    ).to(tl.float32)
    acc += coeff * vals

tl.store(x_ptr + offs_d, acc, mask=mask_d)
```

This pattern is suitable when each rank component is stored with \(D\) as the fastest-changing dimension. If the source is stored as `[D, K]`, use `b_ptr + offs_d * K + k`; however, that makes each iteration over \(k\) strided and may reduce global-load efficiency. For this kernel, `[K, D]` is usually the preferable layout.

## Tile-size guidance

### Start with `BLOCK_SIZE=1024`

A 1024-element tile is a reasonable default because it provides:

- Coalesced 32-bit or 16-bit global accesses.
- Enough work per program to amortize launch and index-calculation overhead.
- A relatively small number of program instances:

\[
\left\lceil \frac{10^6}{1024} \right\rceil \approx 977.
\]

That is still enough parallelism to occupy a modern GPU.

### Benchmark at least three sizes

Use autotuning over:

```python
BLOCK_SIZE in {512, 1024, 2048}
```

and, if register pressure is low:

```python
BLOCK_SIZE in {256, 512, 1024, 2048}
```

Expected trade-offs:

| Tile | Advantages | Risks |
|---|---|---|
| 256 | Low register pressure; higher program count | More launch/index overhead; weaker latency hiding per program |
| 512 | Often a strong compromise | May underutilize bandwidth for very light arithmetic |
| 1024 | Good default for contiguous streaming | Larger live accumulator; possible occupancy reduction |
| 2048 | Fewer program instances; high amortization | More registers, possible spills, lower occupancy |

The critical measurement is not theoretical occupancy alone. Check:

- Achieved HBM bandwidth.
- Register count.
- Local-memory/register spills.
- Active warps or waves.
- Kernel duration.
- Global-load and global-store efficiency.

A larger tile is harmful if the accumulator causes spills or reduces the number of resident warps enough to expose memory latency.

## Do not stage the entire tile in shared memory by default

For the basic update above, explicit shared-memory staging is usually unnecessary:

- Each element is loaded once.
- Each element is consumed once per rank component.
- There is no reuse among neighboring program instances.
- Staging adds global-to-shared and shared-to-register movement.
- Synchronization and allocation can reduce occupancy.

Triton may automatically use shared memory for some block-level operations, but ordinary `tl.load` → arithmetic → `tl.store` code should generally keep the data in registers unless profiling demonstrates reuse.

Shared-memory/LDS staging becomes worthwhile when:

- Multiple threads reuse the same \(D\)-tile.
- Several rank components reuse the same source tile.
- The update includes a reduction or matrix-like contraction.
- The same tile is consumed by multiple phases.
- Global-memory traffic is reduced enough to offset staging overhead.

For \(K=32\), stage the small rank coefficients rather than the million-element vector. The coefficient array is only 32 values; keeping it in registers is generally preferable. If coefficients are shared across many programs, the read-only cache may already handle this effectively.

## H100-specific considerations

Hopper H100 provides substantially more on-chip shared-memory capacity than earlier NVIDIA architectures: up to 228 KB per SM, with a maximum block allocation of approximately 227 KB according to NVIDIA’s Hopper tuning documentation.[5][7] Its HBM bandwidth is approximately 3.35–3.9 TB/s depending on the H100 variant.[6]

Those limits do **not** imply that a 1024-element streaming tile should consume large shared-memory allocations. For example:

- FP32 tile: \(1024 \times 4 = 4\) KB.
- FP16/BF16 tile: \(1024 \times 2 = 2\) KB.
- Two-buffer FP32 staging: about 8 KB.

The memory footprint is small, but the more important constraints are registers and instruction throughput. A 1024-element FP32 accumulator can consume approximately 4 KB per program before accounting for temporaries and compiler transformations. If Triton materializes too much state, occupancy can fall or registers can spill.

Recommended H100 configuration:

- Start with `BLOCK_SIZE=1024`.
- Use `num_warps=4` or `8`; benchmark both.
- Use `num_stages=2` or `3` only if pipelining improves measured bandwidth.
- Avoid large explicit shared-memory buffers unless reuse is demonstrated.
- Consider Hopper-specific asynchronous copy/TMA paths only for a genuinely tiled, reusable operation; for a simple one-pass vector update, the added complexity is unlikely to pay off.

The H100’s large shared-memory capacity is most valuable for kernels with substantial data reuse, not for a single-use streaming tile.

## MI300X-specific considerations

On MI300X, LDS is 64 KB per compute unit/workgroup allocation domain in the relevant ROCm guidance, and LDS usage directly limits occupancy. AMD’s documentation gives the occupancy relation:

\[
\text{occ}_{\mathrm{LDS}}
=
\left\lfloor \frac{65536}{L} \right\rfloor,
\]

where \(L\) is the LDS allocation in bytes.[1][9][12]

AMD also reports an LDS read bandwidth of 128 bytes per clock in its workload-optimization guidance.[1][2] Even with high LDS bandwidth, explicit staging should be justified by reuse because the kernel still pays for the initial global-to-LDS transfer and synchronization.

Recommended MI300X configuration:

- Start with `BLOCK_SIZE=1024`.
- Benchmark `num_warps=4`, `8`, and possibly `16`, subject to the installed Triton/ROCm version.
- Keep LDS allocation near zero for the baseline.
- If staging is needed, use a compact single or double buffer and verify the generated kernel’s LDS allocation.
- Avoid allocating close to 64 KB merely because it is available; that can reduce resident workgroups to one or otherwise constrain occupancy.
- Inspect VGPR usage as carefully as LDS usage. A large `BLOCK_SIZE` can increase VGPR pressure even when LDS is unused.

A useful MI300X rule is to keep explicit LDS well below the occupancy cliff. For example, allocating 32 KB permits at most two such allocations by the simple LDS-capacity bound, whereas 64 KB permits only one. The actual occupancy is also constrained by VGPRs, waves per workgroup, and other hardware limits.

## Masked vector loads

Use a single vector mask derived from the dimension tile:

```python
offs = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
mask = offs < D
```

Then apply that mask consistently to every load and store touching the \(D\) dimension:

```python
x = tl.load(x_ptr + offs, mask=mask, other=0.0)
b = tl.load(b_ptr + k * D + offs, mask=mask, other=0.0)
tl.store(x_ptr + offs, result, mask=mask)
```

Important details:

- The mask prevents out-of-bounds accesses for the final partial tile.
- `other=0.0` is appropriate for additive accumulation.
- The mask should be uniform for neighboring lanes except at the final tile, preserving efficient coalescing for nearly all programs.
- Do not use masking to compensate for a poor layout; contiguous addresses remain the primary requirement.
- Ensure pointer arithmetic uses a sufficiently wide integer type when forming offsets involving \(D\), strides, batches, or rank dimensions.

For block pointers, Triton’s block-pointer form uses boundary checking rather than combining `mask` with the block-pointer load; follow the API constraints for the installed Triton version.[4]

## Memory layout

Prefer:

```text
B[K, D]   # D contiguous
```

over:

```text
B[D, K]   # K contiguous
```

for this access pattern.

With `[K, D]`, the access for fixed `k` is:

\[
B[kD + d],
\]

so adjacent lanes access adjacent elements. With `[D, K]`, fixed `k` produces a stride-\(K\) access:

\[
B[dK + k],
\]

which is less favorable for bandwidth unless the compiler or cache behavior happens to compensate.

For multiple independent vectors, flatten the leading dimensions where possible so each program still processes a contiguous \(D\)-range. Avoid assigning one program to the entire \(D=10^6\) vector: it would create excessive live state, poor scheduling flexibility, and likely register spills.

## Accumulation and datatype choices

For FP16 or BF16 inputs:

- Load in the storage type.
- Convert to FP32 for accumulation if accuracy permits the extra arithmetic.
- Convert back only at the final store.

For FP32 inputs and a bandwidth-dominated update:

- FP32 accumulation is straightforward.
- If the update is numerically simple and error-tolerant, reduced precision may increase bandwidth efficiency, but validate the result carefully.

The arithmetic intensity is approximately low. A rank-32 update may perform roughly 32 multiply-adds per element but also require repeatedly reading rank data. If the rank source is \(K \times D\), the dominant traffic can be on the order of \(32D\) source elements plus one read and one write of the destination. Consequently, optimizing layout and avoiding redundant loads matters more than using tensor-core instructions.

## Practical autotuning matrix

A useful initial autotuning set is:

```python
configs = [
    {"BLOCK_SIZE": 512,  "num_warps": 4, "num_stages": 2},
    {"BLOCK_SIZE": 512,  "num_warps": 8, "num_stages": 2},
    {"BLOCK_SIZE": 1024, "num_warps": 4, "num_stages": 2},
    {"BLOCK_SIZE": 1024, "num_warps": 8, "num_stages": 2},
    {"BLOCK_SIZE": 1024, "num_warps": 8, "num_stages": 3},
    {"BLOCK_SIZE": 2048, "num_warps": 8, "num_stages": 2},
]
```

For H100, consider a Hopper-specific configuration using asynchronous/TMA mechanisms only as a separate variant. For MI300X, separately autotune configurations with and without LDS staging rather than assuming the NVIDIA-optimal configuration transfers directly.

The most likely winning baseline for both devices is:

1. `[K, D]` source layout with \(D\) contiguous.
2. `BLOCK_SIZE=1024`.
3. Masked, coalesced `tl.load` and `tl.store`.
4. Coefficients kept in registers.
5. No explicit shared-memory/LDS staging.
6. FP32 accumulation where required.
7. Autotuning over warps and tile size.
8. Profiling for register/VGPR pressure, spills, occupancy, and achieved HBM bandwidth.

The H100 and MI300X have different execution and occupancy behavior, so use separate autotuning spaces and avoid treating shared memory/LDS capacity as a reason to stage data that has no intra-kernel reuse.

**Citas:** https://rocm.docs.amd.com/projects/ai-ecosystem/en/latest/optimization/workload-optimization.html, https://rocm.docs.amd.com/en/docs-7.2.4/how-to/rocm-for-ai/inference-optimization/workload.html, https://www.techpowerup.com/gpu-specs/docs/nvidia-gh100-architecture.pdf, https://triton-lang.org/main/python-api/generated/triton.language.load.html, https://docs.nvidia.com/cuda/pdf/Hopper_Tuning_Guide.pdf

### 🔬 PASO 6: REPREGUNTA DE PROFUNDIZACION SOTA (Latencia: 42.54s)

Para \(D\gg K\), las mejoras SOTA deben concentrarse en tres puntos: **acotar explícitamente \(\kappa(M)\)**, **controlar el régimen de convergencia de Newton–Schulz** y **sustituir la escala Moonlight fija por una escala dependiente de la geometría y del estado numérico**.

## 1. Cota de \(\kappa(M)\) para Cayley–SMW

Sea el update de Cayley

\[
Q=(I+UV^\top)^{-1}(I-UV^\top),
\]

con \(U,V\in\mathbb{R}^{D\times K}\), y defina

\[
G=V^\top U\in\mathbb{R}^{K\times K}.
\]

La reducción SMW introduce típicamente

\[
M=I_K+G.
\]

Una cota inmediata, usando la desigualdad espectral, es

\[
\sigma_{\min}(M)\ge 1-\|G\|_2,
\qquad
\sigma_{\max}(M)\le 1+\|G\|_2.
\]

Por tanto, si \(\|G\|_2<1\),

\[
\boxed{
\kappa_2(M)
\le
\frac{1+\|G\|_2}{1-\|G\|_2}
}.
\]

Esta cota es útil como condición suficiente, pero puede ser demasiado pesimista. Una cota más precisa es

\[
\kappa_2(I+G)
=
\frac{\sigma_{\max}(I+G)}{\sigma_{\min}(I+G)},
\]

y, si \(G\) es simétrica,

\[
\kappa_2(I+G)
=
\frac{1+\lambda_{\max}(G)}
     {1+\lambda_{\min}(G)},
\]

siempre que \(1+\lambda_{\min}(G)>0\).

### Caso skew-simétrico: la situación ideal

En una parametrización Cayley estructuralmente correcta suele aparecer una matriz skew-simétrica

\[
A^\top=-A.
\]

En ese caso, \(I+A\) es siempre no singular y sus valores singulares satisfacen

\[
\sigma_i(I+A)=\sqrt{1+\mu_i^2},
\]

donde \(\pm i\mu_i\) son los autovalores de \(A\). Así,

\[
\boxed{
\kappa_2(I+A)
=
\frac{\sqrt{1+\mu_{\max}^2}}
     {\sqrt{1+\mu_{\min}^2}}
\le
\sqrt{1+\|A\|_2^2}
}.
\]

Si \(A\) tiene rango \(2r\), aparecen \(r\) pares \(\pm i\mu_j\), y el resto de los valores singulares de \(I+A\) son exactamente \(1\). En consecuencia, la mala condición solo puede proceder de la magnitud de los bloques activos, no de la dimensión \(D\).

Ésta es una mejora importante: **para un Cayley skew-simétrico exacto, la matriz reducida no se vuelve singular por crecimiento de \(D\)**. El problema práctico es la pérdida de skew-simetría por redondeo, truncamiento o parametrización no equilibrada.

### Cota con perturbación de skew-simetría

Suponga que

\[
G=A+E,
\qquad A^\top=-A,
\]

donde \(E\) mide la violación de skew-simetría. Entonces

\[
M=I+A+E.
\]

Como

\[
\sigma_{\min}(I+A)\ge 1,
\]

se obtiene, por perturbación singular,

\[
\sigma_{\min}(M)\ge 1-\|E\|_2,
\]

y

\[
\sigma_{\max}(M)
\le
\sqrt{1+\|A\|_2^2}+\|E\|_2.
\]

Por tanto, si \(\|E\|_2<1\),

\[
\boxed{
\kappa_2(M)
\le
\frac{\sqrt{1+\|A\|_2^2}+\|E\|_2}
     {1-\|E\|_2}
}.
\]

Esto proporciona un criterio operativo:

\[
\|E\|_2\ll 1
\]

es más importante que minimizar únicamente \(\|A\|_2\). En implementación, conviene construir explícitamente

\[
A=\frac{UV^\top-VU^\top}{2}
\]

en lugar de depender de una representación que solo sea skew-simétrica en aritmética exacta.

## 2. Cotas para el error de la aplicación Cayley–SMW

Si se resuelve el sistema reducido con error relativo \(\eta\), el error en la aplicación a \(X\) puede amplificarse aproximadamente como

\[
\frac{\|\widehat{QX}-QX\|_2}{\|X\|_2}
\lesssim
C\,\kappa_2(M)\,\eta
+
C'\,u\,\Phi(D,K),
\]

donde \(u\) es la unidad de redondeo y \(\Phi(D,K)\) resume los errores de las reducciones \(U^\top X\), \(V^\top X\) y \(V^\top U\).

Para una reducción bien equilibrada,

\[
\Phi(D,K)
=
O\!\left(\log D+\gamma_K\right),
\]

con

\[
\gamma_K=\frac{Ku}{1-Ku}.
\]

La recomendación SOTA es, por tanto:

- formar \(G\) y las proyecciones mediante reducción por pares o árboles;
- resolver \(M\) con LU pivotado o QR pequeño, no con inversión explícita;
- estimar \(\kappa(M)\) usando una estimación barata de \(\|M^{-1}\|_1\) o \(\|M^{-1}\|_\infty\);
- activar una ruta QR/TSQR si la estimación supera un umbral.

Para una tolerancia de isometría de \(10^{-6}\), un criterio práctico es exigir

\[
\kappa(M)\,\eta_{\mathrm{solve}}
+
\Phi(D,K)u
\lesssim 10^{-6}.
\]

La inversión explícita de \(M\) debería evitarse porque transforma un problema de resolución estable en uno con error aproximadamente proporcional a

\[
\kappa(M)^2u.
\]

## 3. Convergencia de Newton–Schulz

Para la polar derecha, la iteración clásica es

\[
X_{j+1}
=
\frac{1}{2}X_j(3I-X_j^\top X_j).
\]

Si \(X_0\) está escalada de modo que

\[
\|X_0\|_2<\sqrt{3},
\]

la iteración converge cuadráticamente hacia el factor polar en exactitud aritmética. La convergencia cuadrática significa que, localmente,

\[
e_{j+1}\le C e_j^2,
\]

donde \(e_j\) puede ser el error espectral respecto del factor polar.

Sin escalado, el método puede divergir cuando las singularidades de la entrada están fuera de la región de atracción. Una normalización segura es

\[
X_0=\frac{A}{\alpha},
\qquad
\alpha>\frac{\|A\|_2}{\sqrt{3}}.
\]

En práctica, \(\alpha\) puede estimarse mediante:

\[
\alpha\approx \|A\|_F,
\]

o mediante una estimación barata de \(\|A\|_2\). La norma de Frobenius es más barata, pero puede sobreescalar mucho una matriz muy rectangular o de rango efectivo bajo.

### Escalado adaptativo

Una mejora preferible para \(D\gg K\) es el escalado dinámico:

\[
X_{j+1}
=
X_j
\left[
a_j I+b_j X_j^\top X_j+c_j(X_j^\top X_j)^2
\right],
\]

con coeficientes escogidos para ampliar la región de convergencia o maximizar la contracción sobre el intervalo espectral estimado. Las variantes de mayor grado reducen el número de pasadas \(D\times K\), aunque aumentan el trabajo \(K\times K\).

Para el esquema cúbico estándar, si \(s\) es una singularidad normalizada, cada iteración transforma

\[
s\mapsto \frac{s}{2}(3-s^2).
\]

El error de singularidad cerca de \(s=1\) se comporta como

\[
|1-s_{j+1}|
\approx
\frac{3}{2}|1-s_j|^2.
\]

Por ello, el número de iteraciones requerido después de entrar en el régimen local es aproximadamente

\[
m
=
O\!\left(\log\log\frac{1}{\varepsilon}\right).
\]

Sin embargo, la fase inicial puede dominar cuando \(\kappa(A)\) es grande. Los resultados recientes sobre Newton escalado muestran que el número de pasos puede seguir siendo razonable para matrices extremadamente condicionadas, pero la estabilidad depende críticamente del escalado y de mantener la norma inicial suficientemente alejada del borde \(\sqrt{3}\). Cerca de ese borde, la iteración es numéricamente frágil.

### Implicación para \(D=10^5\!-\!10^7,\ K\le64\)

Si cada iteración requiere una pasada completa sobre \(D\times K\), el coste es aproximadamente

\[
T_{\mathrm{NS}}
\approx
m\,T_{\mathrm{stream}}
+
m\,T_{K\times K}.
\]

Aunque \(m=5\) o \(m=6\) puede producir una aproximación polar útil, la mejora de precisión entre cinco y diez pasos puede no justificar el doble de tráfico global de memoria. Resultados recientes para optimización tipo Muon/Moonlight indican precisamente que pocos pasos de Newton–Schulz pueden ser preferibles a una polarización más exacta cuando el objetivo es minimizar el coste total de entrenamiento, no el error matricial aislado.

Para una garantía explícita de isometría \(10^{-6}\), no debe fijarse \(m\) universalmente. Conviene detenerse cuando

\[
\|I-X_j^\top X_j\|_2
\le
\tau_{\mathrm{orth}},
\]

con

\[
\tau_{\mathrm{orth}}
\approx
10^{-6}
-
c\,\gamma_{D,K},
\]

o utilizar un máximo de iteraciones junto con una comprobación final. Si la comprobación falla, debe cambiarse a QR/TSQR o a una corrección polar final.

## 4. Mejora híbrida recomendada

La opción más robusta es un esquema de tres niveles:

1. **Cayley–SMW** si el update ya tiene forma de bajo rango y la estimación de \(\kappa(M)\) es moderada.
2. **Newton–Schulz escalado** si el coste de varias pasadas está amortizado por fusión de kernels y no se exige precisión extrema.
3. **TSQR o polarización correctiva** si el residuo de ortogonalidad excede el umbral.

Una política concreta puede ser:

\[
\widehat{\kappa}(M)\le \kappa_{\mathrm{safe}}
\quad\Longrightarrow\quad
\text{Cayley--SMW},
\]

\[
\widehat{\kappa}(M)>\kappa_{\mathrm{safe}}
\ \text{y}\ 
\|A\|_2\ \text{está bien estimada}
\quad\Longrightarrow\quad
\text{NS escalado},
\]

\[
\text{residuo final}>\tau
\quad\Longrightarrow\quad
\text{corrección QR/TSQR}.
\]

El umbral \(\kappa_{\mathrm{safe}}\) debe depender de la precisión. En FP32, un valor del orden de \(10^4\!-\!10^6\) puede ser razonable para una meta de \(10^{-6}\), pero debe ajustarse a la longitud de las reducciones y al hardware. En TF32 o precisiones menores, el umbral debe ser considerablemente inferior o las acumulaciones críticas deben hacerse en FP32/FP64.

## 5. Escalado Moonlight: qué escala y por qué

La regla Moonlight habitual para una matriz \(m\times n\) es

\[
S_{\mathrm{Moonlight}}
=
0.2\sqrt{\max(m,n)}.
\]

Su motivación es compensar el decrecimiento del RMS elemento a elemento del factor polar. Si \(Q\in\mathbb{R}^{m\times n}\) tiene columnas ortonormales, entonces

\[
\|Q\|_F^2=n
\]

para \(m\ge n\), por lo que

\[
\operatorname{RMS}(Q)
=
\frac{\|Q\|_F}{\sqrt{mn}}
=
\frac{1}{\sqrt{m}}.
\]

Multiplicar por \(\sqrt{m}\) neutraliza esta dependencia dimensional. Para una matriz rectangular general, la escala simétrica correspondiente es

\[
\sqrt{\max(m,n)}.
\]

La constante \(0.2\) no es una consecuencia universal de la teoría de la polar; es una calibración algorítmica. Por ello, no debe interpretarse como óptima para todas las distribuciones, precisiones o arquitecturas.

### Limitación de la escala estática

La escala Moonlight depende solo de la forma y no de:

- la norma del gradiente o momento;
- el rango efectivo;
- la distribución singular;
- la varianza por capa;
- el grado de convergencia de Newton–Schulz;
- la precisión numérica.

Dos matrices con la misma forma \(m\times n\) pueden requerir escalas muy distintas si una tiene rango efectivo bajo y otra tiene espectro casi plano.

Una mejora natural es usar

\[
S
=
c\,
\frac{\rho_{\mathrm{target}}}
     {\operatorname{RMS}(Q)+\epsilon}
\]

con

\[
Q=\operatorname{NS}_q(M),
\]

y combinarlo con la corrección de forma:

\[
\boxed{
S_{\mathrm{adaptive}}
=
c\sqrt{\max(m,n)}
\frac{\operatorname{RMS}_{\mathrm{ref}}}
     {\operatorname{RMS}(Q)+\epsilon}
}.
\]

Para evitar oscilaciones, la estadística puede suavizarse exponencialmente:

\[
r_t
=
\beta r_{t-1}+(1-\beta)\operatorname{RMS}(Q_t),
\]

\[
S_t
=
c\sqrt{\max(m,n)}
\frac{1}{r_t+\epsilon}.
\]

Esto convierte la escala Moonlight en una corrección de forma más un trust ratio adaptativo.

### Escala basada en rango efectivo

Si \(Q\) tiene rango efectivo \(r_{\mathrm{eff}}\), la escala \(\sqrt{\max(m,n)}\) puede sobrecompensar. Una alternativa es

\[
S_{\mathrm{rank}}
=
c\sqrt{\frac{mn}{r_{\mathrm{eff}}\max(m,n)}}.
\]

El rango efectivo puede estimarse mediante

\[
r_{\mathrm{eff}}
=
\frac{\left(\sum_i \sigma_i^2\right)^2}
     {\sum_i \sigma_i^4},
\]

o mediante trazas de \(M^\top M\) y \((M^\top M)^2\), que solo requieren operaciones \(K\times K\) después de las reducciones. Para \(r_{\mathrm{eff}}\approx n\) en una matriz alta y delgada, se recupera esencialmente la escala convencional; para rango efectivo mucho menor, la escala se reduce.

## 6. Escalado en función del error de Newton–Schulz

Los resultados recientes sobre polarización aproximada indican que el efecto de usar \(q\) pasos finitos puede modelarse mediante un factor multiplicativo \(\chi_q\) que converge a \(1\) rápidamente con \(q\). Una forma representativa de la cota es

\[
\chi_q
\le
\left[
1-\delta_0^{(\kappa+1)^q}
\right]^{-1/2},
\]

donde \(\delta_0\) depende de la separación espectral inicial y \(\kappa\) del grado del polinomio de polarización.

Esto sugiere corregir la escala por

\[
S_q
=
\frac{S_{\mathrm{Moonlight}}}{\chi_q},
\]

o, de forma más práctica, estimar directamente el residuo

\[
r_q=\|I-Q_q^\top Q_q\|_2
\]

y usar

\[
S_q
=
S_{\mathrm{Moonlight}}
\left(1+r_q\right)^{-1/2}.
\]

Así se evita que una aproximación polar todavía no convergida produzca un update excesivamente grande.

## 7. Recomendación final para el régimen indicado

Para \(D=10^5\!-\!10^7\) y \(K=16\!-\!64\):

- **Cayley–SMW** debe ser la ruta principal cuando \(M=I+V^\top U\) tiene estructura skew-simétrica aproximada y \(\widehat{\kappa}(M)\) es baja.
- Debe usarse resolución factorizada, acumulación de precisión superior y una estimación explícita de \(\kappa(M)\); nunca una inversión densa ingenua.


**Citas:** https://arxiv.org/html/2605.07815v1, https://www.mcs.anl.gov/papers/P5059-0114.pdf, https://people.maths.ox.ac.uk/nakatsukasa/publishedpdf/pub11.pdf, https://ntrs.nasa.gov/api/citations/19890016282/downloads/19890016282.pdf, https://twist-shan.github.io/posts/2026/08/optimizer/

