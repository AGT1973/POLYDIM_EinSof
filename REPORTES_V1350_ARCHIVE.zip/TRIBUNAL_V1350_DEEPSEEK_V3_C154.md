# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 154)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 154 · Multi-File Adversarial SOTA Review

**Verdict posture:** The architecture is *structurally sound* but contains **three latent numerical degeneracies**, **one Rule-22 ambiguity**, and **two Rule-27 vendor-lock exposures** that must be remediated before SOTA certification. Details below, per target, with proofs and hardening.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Binary descriptor `struct` layout audit

Declared format: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | 4s | 4 | 0 |
| ver_major | H | 2 | 4 |
| ver_minor | H | 2 | 6 |
| flags | Q | 8 | 8 |
| n_rows | Q | 8 | 16 |
| n_cols | Q | 8 | 24 |
| stride | Q | 8 | 32 |
| dtype_code | Q | 8 | 40 |
| rank | B | 1 | 48 |
| pad0 | B | 1 | 49 |
| pad | 6x | 6 | 50 |
| reserved | 4Q | 32 | 56 |
| **Total** | | **88** | |

✅ **88-byte conformance confirmed.** Alignment: `<` forces no padding, so `sizeof == 88` on all ABIs. This is correct and portable.

⚠️ **Adversarial note:** `4sHHQQQQQBB6x4Q` has **five Q fields** (flags, n_rows, n_cols, stride, dtype_code) — the spec text says "QQQQQ" but the field list above shows only 5 Q's before the B's. If the intent was 6 Q's (e.g., adding `epoch`), the struct would be 96 bytes and **Rule 22 would be violated**. Recommend a compile-time `static_assert(sizeof(desc)==88)` in the C++/Rust mirrors and a Python `assert struct.calcsize(fmt)==88` at import.

### 1.2 HardwareProbe multi-silicon

- **Degeneracy risk:** If `HardwareProbe` returns `None` for `avx512` on a CPU that *does* support it (e.g., masked by cgroup or VM), the orchestrator silently falls back to scalar. **Recommendation:** emit a `WARN` token with the probe's raw CPUID leaf, not a silent downgrade.
- **Rule 27:** Probe must not *require* a vendor SDK. If it imports `pynvml`, `rocm_smi`, or `intel_extension_for_pytorch` at module top-level, that is a **soft vendor-lock**. Gate all imports behind `importlib.util.find_spec`.

### 1.3 PmtpSlabAllocator

- **Degeneracy:** Slab size `S` with `S mod 88 != 0` leaves a tail fragment. If `S = 88 * k + r`, the last `r` bytes are unusable and **must be zero-filled** to preserve Rule 22 (no 1D tokens). Add `memset(tail, 0, r)`.
- **Asymptotic:** Allocation is O(1) amortized; fragmentation ratio `r/S → 0` as `S → ∞`. Fine.

### 1.4 12/12 physical conformance checks

Without the check list, I can only assert: **any check that reads uninitialized padding bytes (offsets 50–55) will fail nondeterministically.** The `6x` pad must be explicitly zeroed before hashing/serialization.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — degeneracy analysis

Neumaier's algorithm:
```
s = 0; c = 0
for i: t = s + x[i]*y[i]
       if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
       else:                  c += (x[i]*y[i] - t) + s
       s = t
return s + c
```

**Theorem (Neumaier 1974):** For `n` terms, the compensated sum satisfies
`|s + c − Σ x_i y_i| ≤ (2u + O(nu²)) · Σ|x_i y_i|`
where `u = 2⁻⁵³` for FP64. **Condition number:** `κ = Σ|x_i y_i| / |Σ x_i y_i|`. For ill-conditioned dot products (`κ → ∞`), Neumaier still delivers **componentwise relative accuracy**, unlike naive summation.

**Degeneracy at `step → ∞`:** If `step ≥ 10¹⁰` and the kernel computes `step · B` before the Woodbury solve (Target 4), the product `step · B` can overflow FP64 (`max ≈ 1.8e308`) only if `B > 1.8e298`. **Not a practical risk**, but the *compensated* term `c` can lose its compensation if `s` saturates. **Recommendation:** pre-scale `B` by `1/step` and post-scale the result, as Target 4 already does.

**Degeneracy at `step → 0` (subnormals):** For `|step| < 2⁻¹⁰²²`, `step · B` enters the subnormal range. Neumaier's `c` term then loses precision because subnormal arithmetic has **reduced mantissa bits**. The audit mentions "subnormal audits (-12, -14)" — these are likely exponent thresholds. **Proof of degeneracy:** if `step = 2⁻¹⁰⁷⁴` (smallest subnormal), then `step · B` for `B ~ 1` is subnormal, and `c` accumulates rounding errors at the subnormal ULP, which is **not** `2⁻⁵³ · |s|` but `2⁻¹⁰⁷⁴`. **Recommendation:** flush-to-zero (FTZ) with a documented `-12` exponent floor, or scale `step` up by `2¹⁰⁰` and rescale the result.

### 2.2 AVX-512 / OpenMP

- **Rule 27:** AVX-512 is Intel/AMD-specific. If the kernel *requires* AVX-512 (no scalar fallback), that is a **hard vendor-lock**. The orchestrator's HardwareProbe must dispatch to a scalar or NEON path. **Recommendation:** `#if defined(__AVX512F__)` guards + a `__attribute__((target_clones("avx512f","avx2","default")))` on the hot function.
- **OpenMP:** `#pragma omp parallel for` with `reduction(+:s,c)` is **not** Neumaier-safe (the compensation term is order-dependent). Use `reduction(+:s)` on the naive sum and a separate compensated pass, or use Kahan-Babuška-Neumaier with a thread-local accumulator merged in a deterministic tree.

### 2.3 Zero-copy PMTP validation

- **Rule 22:** Zero-copy means the 88-byte descriptor is passed by pointer. **Validation must check `sizeof == 88` and that the pointer is 8-byte aligned** (for `Q` fields). Misaligned `Q` access is UB on x86 and a fault on ARM. Add `assert(((uintptr_t)p & 7) == 0)`.

### 2.4 FFI hardening

```cpp
extern "C" __attribute__((visibility("default")))
int poly_dim_v1350_step(const uint8_t* desc, size_t desc_len,
                        const double* x, double* y, size_t n);
```
- Validate `desc_len == 88` **before** casting.
- Use `std::span<const uint8_t, 88>` internally.
- Never `reinterpret_cast` a `char*` to a struct with `Q` fields without alignment check.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety barrier

**Critical finding:** `panic=unwind` across an FFI boundary is **UB** unless the panic is caught. Rust's `extern "C"` functions abort on panic by default (since Rust 1.71, `extern "C"` is `nounwind`). If the crate is compiled with `panic=unwind` and the FFI function is `extern "C"`, a panic will **abort the process**, not unwind into C++. That is *safe* but **not** a "safety barrier" — it's a hard kill.

**Recommendation:** Use `extern "C-unwind"` only if the C++ side is compiled with `-fexceptions` and has a matching `catch`. Otherwise, wrap the body in `std::panic::catch_unwind` and return an error code:
```rust
#[no_mangle]
pub extern "C" fn poly_dim_v1350_step(...) -> i32 {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1,
    }
}
```

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

```rust
#[repr(C, packed)]
pub struct PmtpTensorDescriptor {
    pub magic: [u8; 4],
    pub ver_major: u16,
    pub ver_minor: u16,
    pub flags: u64,
    pub n_rows: u64,
    pub n_cols: u64,
    pub stride: u64,
    pub dtype_code: u64,
    pub rank: u8,
    pub pad0: u8,
    pub _pad: [u8; 6],
    pub reserved: [u64; 4],
}
```
✅ `size_of == 88` (packed, no padding). ⚠️ **`packed` makes all field accesses unaligned** — taking a reference to `flags` is UB. Use `{desc.flags}` (copy) or `read_unaligned`. **Recommendation:** prefer `#[repr(C)]` with explicit `_pad` and a `static_assert` (via `const _: () = assert!(size_of::<T>() == 88);`).

### 3.3 Neumaier sums

Same degeneracy analysis as C++. Rust's `f64` is IEEE-754, so subnormal behavior matches. **Rust does not have FTZ by default** — subnormals are preserved, which is *more* accurate but slower on some x86. Document the choice.

### 3.4 Rule 27

Rust core is vendor-neutral. ✅ No lock. But if `std::arch::x86_64::_mm512_*` intrinsics are used without `is_x86_feature_detected!`, that's a **runtime vendor-lock**. Use `#[target_feature(enable = "avx512f")]` + runtime dispatch.

---

## TARGET 4 — `kernel_c