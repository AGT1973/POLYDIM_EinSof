# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 87

The six “Tribunal” findings cannot be independently compared because no model reports, benchmark data, kernel specifications, or formal proofs were supplied, and the named **V1350 kernels** and **PMTP 88-byte descriptor** do not appear in the retrieved public material. The defensible synthesis is therefore a set of conditional guarantees—not a claim that any particular implementation already satisfies them.

## 1. Stiefel retraction under \(|\mathrm{step}| \ge 10^{10}\)

For \(X \in \mathrm{St}(n,p)\), the standard polar retraction is

\[
R_X(\xi)=(X+\xi)(I+\xi^\mathsf{T}\xi)^{-1/2},
\]

while a QR retraction takes the orthogonal factor \(Q\) from \(X+\xi=QR\).[8] Both are established Stiefel retractions.[8][13]

A Cayley update can preserve orthogonality in exact arithmetic when formulated as

\[
Y=(I-\tfrac12 W)^{-1}(I+\tfrac12 W)X,
\qquad W^\mathsf{T}=-W,
\]

provided the inverse exists. Iterative Cayley schemes have a contraction guarantee only under a step restriction such as

\[
0<\alpha<\frac{2}{\lVert W\rVert},
\]

not for arbitrary extreme steps.[15]

### Arbitration

No mathematically valid result supports the unconditional statement that Cayley is more stable than Householder QR or polar retraction at \(|\mathrm{step}|\ge10^{10}\).

- **Unscaled Cayley:** cannot receive an extreme-step stability guarantee. Its linear system may be badly conditioned, overflow may occur in forming \(W\), and a fixed-point implementation can violate its contraction condition.
- **Householder QR:** generally offers the strongest robust fallback for producing an orthonormal basis from a badly scaled matrix, assuming a stable blocked QR implementation and appropriate scaling.
- **Polar:** gives the closest orthogonal factor in Frobenius norm, but the computation of \((I+\xi^\mathsf{T}\xi)^{-1/2}\) can be ill-conditioned or overflow if performed without scaling.
- **Best SOTA architecture:** use **step-norm scaling plus a safeguarded Cayley path**, with Householder QR or scaled polar as the certified fallback. A practical policy is:
  1. rescale the tangent/update before forming products;
  2. use a stable solve rather than explicit inversion;
  3. detect nonfinite values, excessive condition estimates, or failed orthogonality checks;
  4. fall back to Householder QR;
  5. optionally reorthogonalize and verify
     \[
     \lVert Q^\mathsf{T}Q-I\rVert \le \tau_{\mathrm{orth}}.
     \]

The exact threshold \(\tau_{\mathrm{orth}}\) must be tied to precision, matrix dimensions, and backend—not asserted universally.

**Definitive guarantee:** only the fallback-and-verification design can guarantee a returned orthonormal factor, subject to successful finite arithmetic and a specified tolerance. Plain Cayley alone cannot guarantee stability at \(10^{10}\)-scale steps.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release synchronization applies to the **same atomic publication variable**: a release store publishes prior initialization, and an acquire load that reads that publication makes the initialized state visible to the reader.[3] In RCU, a release update of a link followed by an acquiring reader load orders initialization before reader access.[1]

Therefore, an 88-byte descriptor is not made safe merely by its size or by placing acquire/release operations somewhere in the structure.

### Required protocol

A sound immutable-snapshot protocol is:

1. Writer allocates and fully initializes a new descriptor.
2. Writer publishes its pointer or generation through an atomic variable using **release** semantics.
3. Reader loads that same atomic using **acquire** semantics.
4. Reader accesses only immutable fields of the acquired snapshot.
5. Writer retires the old snapshot.
6. Reclamation occurs only after the RCU/QSBR grace-period condition proves that no pre-publication reader can still hold the old snapshot.

The release/acquire pair orders initialization and visibility; it does **not**, by itself, prevent reclamation while a reader still holds a reference. QSBR specifically defers reclamation until participating threads pass through quiescent states.[5]

### Exact architectural guarantee

The strongest justified guarantee is:

> If every reader acquires the published snapshot through the designated atomic publication variable, every writer publishes only fully initialized immutable descriptors with release semantics, and reclamation waits for a correctly implemented RCU/QSBR grace period, then readers observe one fully initialized snapshot and cannot access a reclaimed descriptor.

This does **not** guarantee:

- atomicity of arbitrary 88-byte loads or stores;
- safety for in-place mutation of descriptor fields;
- safety when readers cache raw pointers beyond their read-side critical section;
- protection against stalled, unregistered, or incorrectly reporting QSBR threads;
- ordering from a release operation on one atomic variable to an acquire operation on an unrelated variable.

For a descriptor containing mutable counters, flags, or sequence fields, those fields require their own atomic protocol or a seqlock/versioning design. Padding and alignment must also be specified explicitly; “88 bytes” alone gives no portability guarantee.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

The five environments do not share one identical execution or memory model:

- **C++20 and Rust** provide language-level atomic semantics, but Rust’s guarantees depend on the chosen atomic types and target support.
- **CUDA** has device-, block-, and system-scope synchronization distinctions; host-language acquire/release assumptions cannot be transferred automatically to GPU code.
- **Triton** exposes compiler-managed GPU operations and barriers rather than the full C++20/Rust atomic abstraction.
- **XLA** is graph/compiler-oriented; operation ordering and aliasing depend on the HLO/StableHLO operation semantics and backend lowering, not merely on source-level syntax.

Consequently, source-level similarity is not conformance.

### Required conformance contract

A portable V1350 specification should define:

- descriptor layout, field offsets, size, alignment, and endianness;
- ownership and lifetime rules;
- publication variable and atomic width;
- acquire/release or stronger ordering required at each publication point;
- reader critical-section boundaries;
- grace-period and reclamation obligations;
- permitted mutation and aliasing;
- numerical tolerances for orthogonality and residuals;
- behavior on overflow, NaN, failed factorization, and unsupported atomics;
- backend-specific lowering and test requirements.

Conformance should then be tested with:

- layout/ABI assertions;
- litmus tests for publication and reclamation;
- stress tests under delayed readers and writer churn;
- cross-backend numerical tests;
- randomized extreme-step tests;
- negative tests that intentionally omit the acquire, release, or grace-period operation;
- race detection and sanitizer instrumentation where available.

### Final arbitration

The mathematically superior synthesis is **not “Cayley plus acquire/release is universally optimal.”** It is:

1. **Numerics:** safeguarded, scaled Cayley for normal updates; Householder QR as the extreme-condition fallback; polar as a high-quality option when its small matrix inverse square root is stably computed.
2. **Concurrency:** release publication plus acquire consumption of the same atomic snapshot pointer/generation, combined with a complete RCU/QSBR grace period before reclamation.
3. **Portability:** a backend-specific conformance layer with explicit layout, memory-order, lifetime, and numerical contracts; no claim of multi-silicon equivalence without litmus, ABI, and numerical evidence.

Thus the only defensible exact guarantees are conditional: orthogonality after verified fallback, snapshot isolation after verified acquire/release publication and grace-period reclamation, and cross-platform conformance only for implementations that pass the explicitly defined contract tests.