# AUDITORÍA TRIBUNAL DE SABIOS — Claude_Sonnet_5_5 (CICLO 146)

No files were actually shared for me to audit—just descriptions of claims like the Cayley retraction, Woodbury identity, and descriptor layout. I can at least verify the math behind these claims, like checking the byte-size computation for that struct format string to see if it adds up correctly.

Working through the Cayley retraction on the Stiefel manifold, I'm tracing how the low-rank Woodbury update applies: forming the skew-symmetric matrix from the gradient and current point, then reducing to a 2K×2K system. But I notice the claimed symmetric eigendecomposition step doesn't actually apply here, since the reduced matrix V^T U isn't symmetric in general—so the described cuSOLVER symmetric eigensolver call would be mathematically inappropriate unless there's a different reduction I'm missing.

But V^T U is still not symmetric in general, so that path doesn't resolve things. The Cayley transform of a skew-symmetric W stays orthogonal for any t, with eigenvalues of modulus 1, meaning the full system never becomes singular since its singular values stay at least 1. But the smaller Woodbury matrix M = I + (t/2)V^T U can still be poorly conditioned, since V^T U isn't symmetric and its eigenvalues could behave badly.

Looking at eigenvalues of V^T U, which match the nonzero eigenvalues of UV^T, I see they give M eigenvalues of 1 + (t/2)iλ_j, which never vanish but M can still be far from normal, so its condition number could blow up with the departure from normality. As t grows large, M scales like (t/2)V^T U, and if V^T U is singular — say when G loses rank in some direction — then M picks up a zero eigenvalue, causing real conditioning trouble there.

After normalizing by the scale factor, the identity term shrinks relative to the dominant term as t grows, so the smallest singular directions become effectively invisible at floating-point precision, costing roughly ten digits of accuracy in those nullspace components. I'm now checking whether this precision loss actually affects the quantities we care about in the final solution.

Scaling is really just a floating-point no-op for conditioning — κ(M/s) stays the same, it only helps avoid overflow for huge t. The real fix is dividing by t itself: M/t = I/t + V^TU/2, which stays well-behaved as t→∞ (converging to a projection-like limit) even when V^TU is singular, though I need to watch for cancellation in computing Y = X − tUZ at extreme t values like 1e10.

A backward-stable solve bounds the relative error in Z by κ·eps, propagating to roughly 1e-6 in Y. I should recommend re-orthonormalizing via polar decomposition or QR, or alternatively using an eigendecomposition approach exploiting the skew structure, or applying iterative refinement.

