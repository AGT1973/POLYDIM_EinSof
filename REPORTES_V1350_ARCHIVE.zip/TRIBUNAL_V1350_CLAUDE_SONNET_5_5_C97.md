# AUDITORÍA TRIBUNAL DE SABIOS — Claude_Sonnet_5_5 (CICLO 97)

No files were actually attached for me to audit, so I can't fabricate findings about code I haven't seen. Instead I should be upfront about the missing attachments and offer a rigorous framework: analyzing the mathematical validity of described designs, like checking the byte size of that struct format string, and flagging what needs verification once the files are provided.

I'm working through the Woodbury form for the Cayley retraction, with U=[G,X] and V=[X,-G] giving a skew-structured update. I realize the 2k×2k matrix V^T U isn't symmetric in general, so if the implementation claims to use a symmetric eigensolver like cuSOLVER's syevd on it, that's a problem—syevd only reads one triangle and would silently produce wrong results unless the matrix gets symmetrized first.

I'm also checking whether M is normal: since the Cayley factor involves a skew matrix W, its eigenvalues take the form 1/(1+iτλ), suggesting a Hermitian eigensolver on iW or a real Schur/LU decomposition would be more appropriate than symmetric eigendecomposition for this piece. I want to verify the conditioning of I + (τ/2)W given its skew structure before trusting any proposed eigendecomposition route.

I realize the scaling trick doesn't actually change the condition number since uniform scalar scaling is condition-invariant — it just prevents overflow during formation, which isn't a real concern here given FP64's range. So the real conditioning issue comes from V^TU having a null space, giving eigenvalues of 1 on that subspace and large values elsewhere, with condition number scaling like τ times the norm of V^TU.

For edge cases: a zero step trivially gives identity and Y=X, while a subnormal step causes τ·V^TU to underflow, leaving the update negligible but harmless since the absolute error stays tiny and orthogonality is preserved to the same O(ε) as usual — though I should flag that flush-to-zero/denormals-are-zero compiler flags could interact oddly here.

The bigger danger is fast-math flags reassociating or zeroing out Neumaier compensation terms, so compensated summation needs -fno-associative-math (Rust is safe by default since it has no fast-math mode). For AVX-512 or multi-threaded reductions, I need per-lane compensation vectors combined via TwoSum-style merging rather than a naive reduction(+), to keep the summation order deterministic across threads.

For error bounds, Neumaier gives first-order condition-independence when nε<1, but that only compensates the summation step, not the multiplication — true compensated dot products need FMA-based TwoProduct (Ogita-Rump-Oishi style) to get exact products before summing, otherwise rounding error creeps in through the uncompensated products themselves.

On the Lyapunov solve, Bartels-Stewart requires a Schur decomposition, and that's where hardware becomes a problem: TPUs only emulate FP64 (very slow), and Trainium lacks native FP64 support entirely.

