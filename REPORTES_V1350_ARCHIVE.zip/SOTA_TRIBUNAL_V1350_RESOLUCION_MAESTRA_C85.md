# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 85

The requested **Cycle 85 arbitration cannot be validated as a comparison of six model reports** because those reports, the six kernel specifications, and their test evidence were not provided. The available public search results identify an unrelated PolyDiM PDE library and one GitHub document discussing a Cayley–SMW Stiefel retraction, but they do not establish the claimed V1350 tribunal corpus or PMTP descriptor specification.[2][11][14]

A defensible SOTA synthesis, conditional on the stated design goals, is:

## 1. Extreme-step Stiefel retraction

For \(X \in \mathrm{St}(D,K)\), a Cayley update should be formed from a skew-symmetric generator

\[
A = UV^{T}-VU^{T}, \qquad A^{T}=-A,
\]

and evaluated as

\[
X^{+}
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)X.
\]

The low-rank Sherman–Morrison–Woodbury form reduces the solve to a small \(2K\times 2K\) system, which is the principal architectural advantage reported for the Cayley–SMW design.[14]

However, **no mathematically valid implementation can guarantee stability merely because \(|\alpha|\ge 10^{10}\)**. The guarantee depends on:

- finite-precision conditioning of \(I-\frac{\alpha}{2}A\);
- accurate construction of the skew-symmetric matrix;
- overflow-safe scaling;
- pivoted or rank-revealing solution of the reduced system;
- residual and orthogonality checks.

In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists, so

\[
(X^{+})^{T}X^{+}=X^{T}X=I.
\]

In floating-point arithmetic, the strongest realistic guarantee is a backward-stability statement such as

\[
\left\|(X^{+})^{T}X^{+}-I\right\|
\le
c\,u\,\kappa_{\mathrm{solve}}\,\mathrm{poly}(D,K),
\]

where \(u\) is machine unit roundoff. That bound is not uniform in \(\alpha\); extreme steps can amplify conditioning and cancellation.

### Arbitration

- **Cayley–SMW:** best choice when the update is intrinsically low rank and orthogonality must be preserved without a full \(D\times K\) factorization.
- **Householder QR:** generally the strongest robust reference implementation for arbitrary extreme updates, provided blocked and pivot-safe QR is used.
- **Polar retraction:** geometrically attractive and often highly accurate, but its Newton/SVD/eigendecomposition path can be more expensive and may require its own scaling safeguards.

Therefore, the definitive claim should be:

> Cayley–SMW is the preferred high-performance kernel for low-rank Stiefel updates, but Householder QR remains the numerical-certification oracle. No unconditional stability guarantee is justified for \(|\alpha|\ge10^{10}\) without a specified scaling, solver, precision, and residual policy.

A conforming kernel should reject, rescale, or fall back when the reduced solve is singular, poorly conditioned, nonfinite, or fails the orthogonality tolerance.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release operations alone do **not** automatically guarantee snapshot isolation. The guarantee requires a complete publication and reclamation protocol:

1. The writer initializes the descriptor and all referenced immutable payloads.
2. The writer publishes the descriptor pointer or version with **release** semantics.
3. The reader loads the publication state with **acquire** semantics.
4. The reader announces its epoch, hazard, or QSBR participation before dereferencing the payload.
5. Writers reclaim old storage only after every pre-existing reader has passed a quiescent state.

The essential ordering is:

\[
\text{initialize payload}
\;\prec_{\mathrm{release}}\;
\text{publish descriptor}
\]

and

\[
\text{acquire publication}
\;\prec\;
\text{dereference payload}.
\]

For a versioned snapshot, readers should validate a sequence/version field, commonly using a seqlock-style protocol:

\[
v_1 \leftarrow \mathrm{acquire}(V),\qquad
\text{read immutable fields},\qquad
v_2 \leftarrow \mathrm{acquire}(V),
\]

accepting the snapshot only if \(v_1=v_2\) and the version is not marked as being written.

### Architectural guarantee

A valid PMTP design can guarantee:

- no reader observes a partially published immutable snapshot;
- no reclaimed payload is accessed by a registered reader;
- descriptor and payload versions are coherent;
- updates are linearizable at the publication point.

It cannot guarantee those properties from an 88-byte size constraint or from isolated acquire/release instructions. The descriptor layout must also define:

- field alignment and atomic widths;
- ownership of pointed-to memory;
- version and generation semantics;
- reclamation domain;
- ABA prevention;
- behavior for wraparound and stale handles;
- host/device visibility rules.

For C++20, the relevant correctness argument must be expressed through the C++ memory model. For CUDA, device-scope or system-scope atomics and the relevant fence domain must be specified. A host acquire does not, by itself, establish device visibility, and a device fence does not automatically establish host-language synchronization.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single cross-silicon memory model shared identically by these ecosystems. “Conformance” must therefore mean **observational equivalence under an explicitly defined contract**, not identical instruction sequences.

The contract should specify:

- scalar types and permitted rounding;
- NaN, infinity, signed-zero, and flush-to-zero behavior;
- reduction associativity and determinism;
- tensor layout and alignment;
- atomic scope and ordering;
- publication and reclamation protocol;
- error and fallback behavior;
- orthogonality and residual tolerances;
- supported dimensions, ranks, and step ranges.

### Required implementation mapping

| Layer | Required interpretation |
|---|---|
| C++20 | `std::atomic` acquire/release plus an explicit RCU/QSBR reclamation protocol |
| Rust | `Ordering::Acquire`/`Release` or stronger, with lifetime/ownership rules that prevent use-after-reclaim |
| CUDA | Correctly scoped atomics and fences; scope must cover every producer and consumer |
| Triton | Explicitly supported atomic/fence subset; unsupported publication semantics require a wrapper or fallback |
| XLA | Use compiler-supported collective/ordering primitives; do not assume arbitrary host-style acquire/release behavior |
| Multi-silicon | Require per-backend conformance tests, not source-level equivalence |

The numerical kernels should be tested with metamorphic properties:

\[
\|X^{T}X-I\| \le \tau_{\mathrm{orth}},
\]

\[
\frac{\|F(X^{+})-\widehat{F}(X^{+})\|}
{\max(1,\|F(X^{+})\|)}
\le \tau_{\mathrm{res}},
\]

and, for descriptor publication:

- readers never accept a mixed-version snapshot;
- no reader accesses storage after reclamation;
- all accepted snapshots correspond to a published generation;
- repeated runs satisfy the declared determinism policy.

## Definitive arbitration

The strongest justified architecture is a **tiered design**, not a universal unconditional guarantee:

1. **Cayley–SMW fast path** for low-rank Stiefel updates.
2. **Scaled, pivoted reduced solve** with condition and residual monitoring.
3. **Householder QR fallback** as the numerical reference path.
4. **Polar fallback** where closest-point projection is required and its factorization path is available.
5. **Acquire-release publication** for immutable descriptors.
6. **Epoch/QSBR or hazard-based reclamation** for lifetime safety.
7. **Backend-specific synchronization adapters** for CUDA, XLA, Triton, C++20, and Rust.
8. **A conformance suite** defining numerical tolerances and memory-observation properties independently of implementation.

Thus the exact guarantees that can legitimately be claimed are:

- **Geometric:** exact Cayley updates preserve the Stiefel constraint; floating-point preservation is tolerance-bounded, not exact.
- **Numerical:** stability is conditional on scaling, conditioning, precision, and fallback policy.
- **Memory-ordering:** release publication plus acquire observation orders initialization before consumption.
- **Lifetime:** QSBR/RCU reclamation prevents use-after-free only when all readers participate correctly.
- **Cross-platform:** conformance is observational and test-defined; it is not implied by sharing an 88-byte layout or source code.
- **Extreme-step:** \(|\mathrm{step}|\ge10^{10}\) is a stress regime, not a proof of stability. Any claim of unconditional safety at that magnitude is unsupported without reproducible conditioning, residual, and cross-backend evidence.