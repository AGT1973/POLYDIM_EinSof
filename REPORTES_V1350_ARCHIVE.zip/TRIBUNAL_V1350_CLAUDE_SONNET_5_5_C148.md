# AUDITORÍA TRIBUNAL DE SABIOS — Claude_Sonnet_5_5 (CICLO 148)

Six files were referenced but never actually provided to me, so I can't audit code that doesn't exist or verify claims like "12/12 conformance checks" without seeing it. What I can do is work through the underlying mathematics rigorously—the Cayley retraction, Woodbury identity, Neumaier summation, struct layout, and FFI boundary—and I'm starting by computing the byte layout implied by the descriptor format string to check field sizes and alignment.

I confirm the struct comes out to 88 bytes under both packed little-endian and natural C alignment, since the fields happen to align on 8-byte boundaries anyway—so no `repr(packed)` is strictly needed in Rust, just careful use of explicit reserved bytes and a compile-time size assertion rather than reading unaligned references directly. I also note I don't actually know what "Rule 22," "Rule 27," or "zero 1D tokens" refer to as defined terms, so I should flag that I'm taking them as given by the user rather than claiming independent knowledge, and the "1D token" framing is ambiguous since a packed byte descriptor is technically a flat byte stream. Then I shift into deriving the Cayley retraction on the Stiefel manifold using a low-rank skew-symmetric update and applying the Woodbury identity to invert the resulting matrix efficiently.

So M = I + (t/2)S has eigenvalues 1 ± itσ/2, but since S itself is nonnormal, cond(M) may exceed the simple sqrt bound due to departure from normality — I'm now considering how this interacts with cuSOLVER's symmetric eigendecomposition routine.

Since syevd is strictly a symmetric/Hermitian solver, applying it to a non-symmetric S would be invalid unless they reformulate through a skew-symmetric construction (like Wen-Yin's Cayley transform basis) — otherwise syevd silently reads only one triangle and produces a wrong answer. I'm weighing alternatives: treating iK as Hermitian and using a complex solver, falling back to a real Schur decomposition, or just using pivoted LU for the Cayley solve instead of an eigendecomposition.

I also realize squaring the skew generator A to get a symmetric A² (so syevd can extract σ²) sacrifices precision badly — small singular values lose relative accuracy because the error scales with σmax², so tiny σ can fall below machine epsilon.

As for scaling the whole system by a constant before solving, I conclude that's mathematically a no-op and doesn't improve conditioning — power-of-2 scaling is exact in floating point and only guards against overflow, while LU with partial pivoting is already scale-invariant. Even for step sizes as large as 1e10, FP64's range comfortably avoids overflow, so scaling isn't actually necessary here.

As the step size grows toward infinity, the Cayley map approaches a reflection — negative identity on the range of W, identity on its null space — meaning the retraction stops behaving like a genuine descent direction and instead the curve winds around, with the rotation angle saturating at π. This shows Cayley loses first-order accuracy for large steps since it no longer approximates the exponential map well when the step times the singular value is large.

A step this enormous is meaningless numerically, so I'd recommend clamping the step relative to a trust region so that t‖W‖ stays bounded, and also checking the orthogonality defect of Y in finite precision.

