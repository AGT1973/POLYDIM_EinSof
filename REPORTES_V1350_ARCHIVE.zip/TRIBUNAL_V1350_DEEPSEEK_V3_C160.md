# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 160)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 160 · Adversarial SOTA Review

**Presiding note.** The Tribunal treats every claim as unproven until a certificate is produced. Below, each target is dissected along the four mandated axes: (1) numerical degeneracy at `|step| → ∞` and `step → 0`; (2) Rule 22 (zero 1D tokens, 88-byte PMTP); (3) Rule 27 (silicon contract / vendor lock); (4) proofs, condition numbers, FFI hardening. Verdicts are rendered per target, then a consolidated ruling.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Structural claims under audit
- Multi-silicon `HardwareProbe`
- `PmtpSlabAllocator`
- 88-byte binary descriptor `<4sHHQQQQQBB6x4Q`
- 12/12 physical conformance checks

### 1.2 Descriptor arithmetic (Rule 22)
`struct.calcsize("<4sHHQQQQQBB6x4Q")`:
```
4s → 4
H  → 2
H  → 2
Q  → 8
Q  → 8
Q  → 8
Q  → 8
Q  → 8
B  → 1
B  → 1
6x → 6
4Q → 32
```
Sum = 4+2+2+8·5+1+1+6+32 = **88 bytes**. ✅ **Rule 22 byte-budget satisfied.**

**Caveat (Tribunal finding):** `<` forces little-endian *and* no alignment padding. On a big-endian host (POWER10, s390x) the descriptor is silently byte-swapped relative to the C++/Rust/CUDA peers unless they also declare `__attribute__((packed))` + explicit LE conversion. **Recommendation:** add a `b"PMTP"` magic + version byte and a `struct.unpack` round-trip self-test at import time; fail-closed if `calcsize != 88`.

### 1.3 Numerical degeneracy
The orchestrator itself is integer/descriptor logic — no FP arithmetic. Degeneracy risk is **inherited** from the slab allocator's alignment math:
- If `step` is passed as a Python `int` and later cast to `float64` for the C++/Rust peers, `|step| ≥ 2^53` loses integer precision. **At `|step| ≥ 10^10` this is still exact** (10^10 < 2^53 ≈ 9.007×10^15), so no degeneracy at the stated threshold. ✅
- `step → 0`: if the allocator computes `slab_size = ceil(step * K)` with `step` subnormal, `ceil` of a subnormal is `1` — safe. But if it computes `step / scale` with `scale` also subnormal, you get `0/0 → NaN`. **Recommendation:** clamp `step` to `[2^-1022, 2^53]` at the orchestrator boundary and emit a `PMTP_ERR_STEP_RANGE` token.

### 1.4 Rule 27 (vendor lock)
`HardwareProbe` enumerating CUDA/ROCm/TPU/Trainium/AVX-512 is **descriptive**, not prescriptive — no lock *if* the probe result is a capability bitmask and the dispatch table has a scalar fallback. **Tribunal demands:** a `PMTP_BACKEND_SCALAR` path that is always compiled. Without it, Rule 27 is violated.

### 1.5 Verdict
**PASS with reservations.** Descriptor is 88 bytes; add endianness self-test and step-range clamp.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product
Standard Neumaier:
```
s = 0; c = 0
for x,y: t = s + x*y
         if |s| ≥ |x*y|: c += (s - t) + x*y
         else:           c += (x*y - t) + s
         s = t
return s + c
```
**Error bound (Ogita–Rump–Oishi 2005):** `|fl(x·y) − x·y| ≤ (u + O(nu²)) · Σ|xᵢyᵢ|`, with `u = 2^-53`. This is **unconditionally stable** — no condition-number blow-up. ✅

### 2.2 Subnormal audits at −12, −14
The claim "subnormal audits (−12, −14)" presumably means exponents `2^-12` and `2^-14` (i.e., `~2.44e-4` and `~6.10e-5`). **These are NOT subnormals** — subnormals begin at `2^-1022` (double) or `2^-126` (float). **Tribunal finding: mislabeled.** If the intent was `2^-1012` and `2^-1014`, then:
- AVX-512 `vfmadd` with FTZ/DAZ **on** (default in many `-ffast-math` builds) will flush these to zero, silently breaking Neumaier's compensation term `c`.
- **Recommendation:** compile with `-fno-fast-math -ffp-contract=off` and explicitly clear `MXCSR.FTZ`/`DAZ` around the kernel, or use `_mm512_mask_*` with `_MM_FROUND_NO_EXC` and a post-hoc subnormal re-injection.

### 2.3 `step → ∞` degeneracy
If the kernel computes `W = (step/scale) B` (Woodbury, see Target 4), then `step/scale` overflows to `+inf` when `step ≥ 10^10` and `scale ≤ 10^-298`. Then `W` is `inf·B` → `inf` or `NaN` (if `B` has zeros). **Proof of degeneracy:** let `B = e₁`, `scale = 2^-1074` (min subnormal), `step = 10^10`. Then `step/scale = 10^10 · 2^1074 ≈ 10^333` → `+inf`. `inf · e₁ = (inf, 0, …)` → downstream `DnDsyevd` on a matrix with `inf` entries returns `INFO > 0`. **Mitigation:** pre-scale `B` by `2^-⌈log2(step/scale)⌉` and carry the exponent separately (log-domain Woodbury).

### 2.4 Rule 22
C++ side must consume the same 88-byte descriptor. **Demand:** `static_assert(sizeof(PmtpTensorDescriptor) == 88)` and `#pragma pack(push,1)`. Without `pack(1)`, `Q` fields align to 8 and the struct becomes 96 bytes → **Rule 22 violation**.

### 2.5 Rule 27
AVX-512 is Intel/AMD-specific. **Vendor lock risk: HIGH** unless a `#if defined(__AVX512F__)` guard falls back to AVX2 → SSE2 → scalar. OpenMP is portable. **Verdict: conditional pass** if the fallback ladder exists.

### 2.6 FFI hardening
- Export only `extern "C"` symbols with `__attribute__((visibility("default")))`.
- Validate descriptor magic + `calcsize` before dereferencing.
- Use `std::span<const double>` at the boundary; never raw `double*` without length.
- `-fstack-protector-strong -D_FORTIFY_SOURCE=3 -fcf-protection=full`.

### 2.7 Verdict
**FAIL on subnormal labeling; PASS on Neumaier math; CONDITIONAL on Rule 27.**

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 Safe SIMD + Neumaier
Rust 2021 `std::simd` (nightly) or `wide`/`packed_simd_2` crates. Neumaier in Rust is identical math to C++ — same ORO bound. ✅

### 3.2 `panic = unwind` FFI barrier
**Tribunal finding: this is the wrong choice.** `panic = unwind` across an `extern "C"` boundary is **UB** unless every FFI entry point is wrapped in `std::panic::catch_unwind`. The correct hardening is:
```rust
#[no_mangle]
pub extern "C" fn pmtp_kernel(...) -> i32 {
    match std::panic::catch_unwind(|| inner(...)) {
        Ok(r) => r,
        Err(_) => PMTP_ERR_PANIC,
    }
}
```
Better: `panic = "abort"` for the FFI crate, with a separate `unwind` crate for the host. **Recommendation: switch to `panic = "abort"` + `catch_unwind` at the boundary.**

### 3.3 Packed 88-byte descriptor
```rust
#[repr(C, packed)]
struct PmtpTensorDescriptor { ... }
const _: () = assert!(std::mem::size_of::<PmtpTensorDescriptor>() == 88);
```
`repr(C, packed)` gives 88 bytes. **But:** taking a reference to a packed field is UB in Rust (`E0793`). Must use `read_unaligned` / `addr_of!`. **Demand:** audit every field access.

### 3.4 `step → ∞` / `step → 0`
Same as C++: `step/scale` overflow. Rust's `f64` follows IEEE-754, so `inf` propagates. **Add:** `debug_assert!(step.is_finite() && step.abs() < 1e10)` in release too via `if !step.is_finite() { return PMTP_ERR_STEP_RANGE; }`.

### 3.5 Rule 27
Rust core is portable; SIMD via `std::simd` is target-agnostic. **PASS.**

### 3.6 Verdict
**FAIL on `panic = unwind` FFI; PASS on descriptor size; PASS on Rule 27.**

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K×2K)
Cayley: `Y = (I − ½W)^{-1}(I + ½W) X`, `W = A X^T − X A^T` (skew). For Stiefel `St(n,p)`, the retraction is `Y = (I + ½W)^{-1}(I − ½W) X` with `W = A X^T − X A^T` projected. **Condition number of `(I − ½W)`:** since `W` is skew, eigenvalues of `I − ½W` are `1 − ½iλ`, `λ ∈ ℝ`, so `|1 − ½iλ