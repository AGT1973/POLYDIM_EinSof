# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 134)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 134 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal treats every claim as *unproven until demonstrated*. Below, each target is audited against (i) numerical degeneracy at `|step| → ∞` and `step → 0`, (ii) Rule 22 (zero 1D tokens, 88-byte PMTP), (iii) Rule 27 (Silicon Contract / vendor-lock), and (iv) FFI hardening. Where the submitted artifact is a *description* rather than source, the Tribunal flags **"claim-only"** and demands the byte-level artifact.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout audit — `<4sHHQQQQQBB6x4Q`

Let us sum the struct:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major, version_minor | `HH` | 4 |
| flags, dtype, rank, reserved | `QQQQ`? — **ambiguous** | — |
| … | `BB` | 2 |
| pad | `6x` | 6 |
| tail | `4Q` | 32 |

**Tribunal finding (BLOCKING).** The format string as written is **not self-consistent**. `4sHHQQQQQBB6x4Q` parses as:

```
4s (4) + HH (4) + QQQQQ (40) + BB (2) + 6x (6) + 4Q (32) = 88 bytes ✓
```

Total = **88 bytes** — arithmetically correct. **However**, five `Q` fields (40 bytes) plus two `B` (2 bytes) plus 6 pad = 48 bytes of "payload" after the 8-byte header. The Tribunal demands the **field-name → offset table** be published; without it, the "12/12 physical conformance checks" are unfalsifiable. A conformance suite that checks its own schema is circular.

**Recommendation.** Publish a canonical `ctypes.Structure` with `_pack_ = 1` and a golden hex fixture. Assert `ctypes.sizeof(Desc) == 88` **and** `struct.calcsize(fmt) == 88` **and** a byte-for-byte round-trip against a frozen reference blob.

### 1.2 Numerical degeneracy

The orchestrator itself is dispatch logic; degeneracy risk lives in the *contract* it enforces on `step`:

- **`step → ∞` (`|step| ≥ 1e10`):** If the orchestrator forwards `step` unclamped into any downstream kernel that forms `step · B` or `step / scale`, overflow to `inf` is possible in FP32 paths. **Require** the orchestrator to reject `|step| > STEP_MAX` with a typed error, or to pre-scale.
- **`step → 0` (subnormal):** If `step` is used as a divisor (e.g., `1/step` in a normalization), subnormal `step` produces `inf`. **Require** `step == 0.0` and `|step| < 2^-1022` to be rejected at the boundary.

**Verdict:** *Conditional pass* — pending publication of the clamp policy.

### 1.3 Rule 22 compliance

"Zero 1D tokens in inter-agent communication" — the orchestrator must never emit a bare scalar/1D array as a message. The 88-byte descriptor is a **fixed-width record**, which satisfies the spirit of Rule 22 *provided* the descriptor is the *only* wire format. **Demand:** a fuzz test that asserts every emitted message is exactly 88 bytes and that no `numpy.ndarray.ndim == 1` object crosses the boundary.

### 1.4 Rule 27 — vendor lock

`HardwareProbe` for "multi-silicon" is the correct pattern **iff** the probe returns a *capability set* (e.g., `{avx512, cuda, rocm, tpu, trainium}`) rather than a vendor enum. If the orchestrator branches on `vendor == "nvidia"`, that is a Rule 27 violation. **Demand:** capability-based dispatch table.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — condition number

Neumaier's variant of Kahan–Babuška:

```
s = x[0]*y[0]; c = 0
for i in 1..n-1:
    t = s + x[i]*y[i]
    if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
    else:                 c += (x[i]*y[i] - t) + s
    s = t
return s + c
```

**Error bound (Neumaier 1974, Thm. 2.5):**

```
|fl(Σ xᵢyᵢ) − Σ xᵢyᵢ| ≤ (2u + O(nu²)) · Σ |xᵢyᵢ|
```

where `u = 2^-53` (FP64). This is **independent of n** to first order — the key advantage over naive summation (`O(nu)`). **Asymptotic condition number** of the compensated dot product:

```
κ_comp = 1 + O(u)   (relative),  vs.  κ_naive = n·u
```

**Tribunal finding.** The claim is *mathematically sound* **provided** the compiler does not contract `s + c` into an FMA that re-introduces the error. **Require** `-ffp-contract=off` (or `#pragma STDC FP_CONTRACT OFF`) on the compensated loop, and a unit test with `x = [1e16, 1, -1e16]`, `y = [1, 1, 1]` returning exactly `1.0`.

### 2.2 Subnormal audits at `-12, -14`

The exponents `-12` and `-14` are **not** subnormal in FP64 (subnormal threshold is `2^-1022 ≈ 2.2e-308`). They *are* subnormal in **FP16** (`2^-14` is the smallest normal FP16; `2^-24` is smallest subnormal). **Tribunal finding (BLOCKING):** the audit is mislabeled. Either:

- (a) the kernel is operating in FP16 and the audit is correct — then the FP64 Neumaier claim is inconsistent; or
- (b) the kernel is FP64 and the audit should be at `-1022, -1074`.

**Demand:** clarify the working precision. If mixed-precision, publish the promotion ladder.

### 2.3 Zero-copy PMTP validation

"Zero-copy" + "validation" is a **contradiction in tension**: validation requires reading the buffer, which is fine, but *zero-copy* means the buffer is not duplicated. **Require** an `mmap`/`cudaHostRegister`-style pinned region with a checksum computed *in place*, and a proof that no `memcpy` of the 88-byte descriptor occurs on the hot path (use `perf` or `nsys` trace as evidence).

### 2.4 Rule 27

AVX-512 + OpenMP is **portable** across Intel/AMD (with `-march=native` caveats). **No vendor lock** *if* a scalar fallback is compiled. **Demand:** `#ifdef __AVX512F__` guards with a tested scalar path.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI barrier — **Tribunal finding (BLOCKING)**

`panic=unwind` across an FFI boundary is **undefined behavior** unless every `extern "C"` function is wrapped in `std::panic::catch_unwind`. The Rustonomicon is explicit: unwinding into C is UB. **Require:**

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(v)  => v,
        Err(_) => -1,  // or a typed error code
    }
}
```

Additionally, `panic=abort` is *safer* for FFI but loses the ability to return typed errors. The Tribunal recommends **`panic=abort` at the crate level + `catch_unwind` at the FFI shim** — belt and suspenders.

### 3.2 Safe SIMD + Neumaier

Rust's `std::simd` (portable SIMD) is **not yet stable** as of 2024. If the kernel uses `core::arch::x86_64::_mm512_*`, that is `unsafe` and the "Safe SIMD" claim is **false**. **Demand:** clarify whether "Safe SIMD" means (a) `std::simd` nightly, (b) `wide`/`pulp` crates, or (c) `unsafe` intrinsics with a safe wrapper. Only (a)/(b) justify the claim.

### 3.3 Packed 88-byte descriptor

Rust's default `repr(Rust)` **reorders fields** and may pad. **Require** `#[repr(C, packed)]` and a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` compile-time check. Note: `repr(C, packed)` makes field access `unsafe` (unaligned reads) — document this.

### 3.4 Numerical degeneracy

Same as Target 2: Neumaier is `O(u)`-accurate. At `step → 0`, if `step` is used in a division, subnormal `step` yields `inf`. **Require** a `debug_assert!(step.abs() > f64::MIN_POSITIVE)` in the SIMD path.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction — condition number

For `Y ∈ St(n,p) = {Y : YᵀY = I_p}`, the Cayley retraction is:

```
R_Y(ξ) = (I − ½ W)^{-1} (I + ½ W) Y,   W = ξ Yᵀ − Y ξᵀ  (skew)
```

**Condition number of the solve:** `κ(I − ½W) = (1 + ½‖W‖) / (1 − ½‖W‖)`. As `‖W‖ → 2`, `κ → ∞`. **Tribunal finding:** the kernel must **clamp `‖W‖ < 2 − ε`** or fall back to QR-based retraction. Without this, `step → ∞` (large `ξ`) drives `‖W‖ → 2` and the solve becomes singular.

### 4.2 Globally scaled Woodbury solve `(M/scale) W =