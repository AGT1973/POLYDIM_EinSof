# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 123)

# POLYDIM V1350 – MULTI‑FILE ADVERSARIAL SOTA AUDIT  
**High Tribunal of Mathematical and Systems Sages** – Cycle 123  

*Prepared for the POLYDIM V1350 development team – 2026‑10‑05*  

---

## 1. Executive Summary  

| Target | Main Numerical‑Stability Mechanisms | Potential Degeneracy (|step| ≫ 10¹⁰) | Potential Degeneracy (|step| ≈ 0) | Rule 22 (88‑byte PMTP) | Rule 27 Vendor‑Lock | Cond.‑Number Insight | FFI Hardening (Top‑3) |
|--------|--------------------------------------|----------------------------|-------------------------------|------------------------|----------------------|-----------------------|----------------------|
| **kernel_orchestrator_v1350.py** | Binary‑descriptor sanity checks, hardware‑probe auto‑re‑calibration | Overflow in the 64‑bit *Q* fields (max 2⁶⁴‑1) – mitigated by saturating cast to `uint64` and overflow trap | Subnormal handling via explicit `np.float64` promotion; 12/12 physical checks catch under‑flow | Full compliance – descriptor conforms to `<4sHHQQQQQBB6x4Q>` exactly, no extra 1‑D tokens | No lock – pure‑Python + `ctypes` shim; vendor‑agnostic | Condition number of the descriptor‑mapping is `κ≈1` (bijection) | 1. Validate descriptor length at entry; 2. Guard each `ctypes` call with `errno` check; 3. Use `memoryview` for zero‑copy checks |
| **kernel_cpp_v1350.cpp** | Neumaier‑compensated dot‑products, AVX‑512‑wide fused‑multiply‑add, OpenMP parallelism | AVX‑512 64‑bit lanes saturate at 2⁶³‑1 ≈ 9.22e18 – a step ≥ 10¹⁰ is well‑within range, but intermediate accumulators in the Woodbury solve may overflow; compensated arithmetic caps growth to `O(ε·|step|·n)` | Subnormal numbers are flushed to zero by default (`_MM_DENORM_DISABLE`), but the source code explicitly enables subnormal handling (`_MM_SET_DENORMALS_ZERO_MODE(0)`) – still risks under‑flow in the *−12, −14* kernels where `float64` values < 2⁻¹⁰⁰ are used. | The 88‑byte descriptor is passed via a POD `struct PmtpTensorDescriptor` whose layout matches the Python format byte‑for‑byte (packed `#pragma pack(push,1)`). No stray 1‑D token is emitted. | **Vendor lock** – heavy reliance on Intel‑specific AVX‑512 intrinsics and on `libiomp5`. The code will not compile on non‑AVX‑512 CPUs without a fallback path; this constitutes a lock to Intel‑Si. | The matrix‑vector product in the Woodbury step has condition number  
\[
\kappa_{\text{Woodbury}} = \frac{\|M\|_2\|A^{-1}\|_2}{\sigma_{\min}(M A^{-1})}
\]  
which grows linearly with `|step|`. The Neumaier scheme guarantees relative error ≤ \(2\varepsilon\)·κ. |
| **kernel_rust_v1350.rs** | Safe SIMD (`std::arch::x86_64::*` + `packed_simd`), “panic = unwind” barrier, Neumaier sum, `repr(packed, C)` descriptor | SIMD lanes are 64‑bit; overflow checks are performed via Rust’s `checked_add` on the *scalar* accumulator before vectorisation – overflow yields a `Result::Err` that aborts the kernel. With `|step| ≥ 10¹⁰` the guard remains effective up to 2⁶³‑1. | The Rust compilation target forces `-C denorms=preserve`, yet the `neumaier` crate normalises subnormals to zero before accumulation, guaranteeing no catastrophic cancellation for `|step| ≈ 0`. | The descriptor is declared  
```rust
#[repr(C, packed)]
pub struct PmtpTensorDescriptor {
    magic: [u8;4],
    version: u16,
    flags: u16,
    ... // exactly matches 4sHHQQQQQBB6x4Q
}
```  
No one‑dimensional token appears. | **Vendor lock** – only uses the standard Rust SIMD intrinsics, which are supported on both AMD and Intel; the crate also provides a fallback to scalar code, so the lock is *soft* at worst. | The condition number of the packed descriptor‑to‑tensor mapping is exactly 1 (bijection). The core numeric kernel solves a Stiefel manifold retraction; its condition number is bounded by  
\[
\kappa_{\text{retract}} \le 1 + O\!\bigl(\|X\|_2^2\cdot\|step\|_2\bigr)
\]  
and therefore remains moderate for `|step| ≤ 10⁵`. For `|step| ≥ 10¹⁰` the bound blows up, requiring scaling (see § 5). | 1. Enforce `#[repr(align(64))]` on the external tensor buffer; 2. Use `std::ptr::addr_of_mut!` with `unsafe {}` guard for the FFI entry; 3. Add `#[track_caller]` to panic‑unwind boundaries to capture stack traces. |
| **kernel_cuda_v1350.cu** | Stiefel–Cayley retraction via cuSOLVER `DnDsyevd`, Woodbury solve scaled by `scale = max(‖step‖, 1)`, CUDA Graphs for async safety | cuSOLVER works in double‑precision; the eigen‑solver’s internal scaling automatically prevents overflow up to `≈10⁸` in the matrix norm. For `|step| ≥ 10¹⁰` the pre‑scale `scale = max(‖step‖,1)` reduces the matrix to ∼ 1, preserving floating‑point range. However, the final un‑scale (`W = (step/scale) B`) may re‑introduce overflow if `step` itself exceeds `2⁶³‑1`. | Subnormals are *not* supported on most NVIDIA GPUs (they are flushed to zero). The kernel therefore inserts an explicit “renorm” pass: values |v| < 2⁻¹⁰⁵ are set to `sign(v)*2⁻¹⁰⁵`. This eliminates under‑flow but introduces a bias bounded by `ε·|step|`. | The descriptor is transferred via `cudaMemcpy` of exactly 88 bytes; the kernel uses `__align__(8)` to guarantee 64‑bit alignment. No extra 1‑D token is emitted. | **Vendor lock** – exclusive dependence on NVIDIA’s cuSOLVER and CUDA Graphs binds the implementation to the NVIDIA stack; AMD ROCm lacks a direct equivalent to `DnDsyevd`. This is a *hard* vendor lock. | The eigen‑problem condition number can be expressed as  
\[
\kappa_{\text{eig}} = \frac{\lambda_{\max}}{\lambda_{\min}} .
\]  
Because the matrix is a scaled Woodbury `W = (step/scale) B`, the scaling guarantees `κ_eig ≤ κ_B·max(1,|step|/scale) = κ_B`. Hence the algorithm remains numerically stable even for extreme steps, provided the un‑scale step is done in FP64 (which it is). | 1. Verify that the `cudaMemcpy` of the descriptor uses `cudaMemcpyHostToDevice` with `cudaMemcpyDefault` to avoid mismatched endianess; 2. Insert a guard page after the descriptor buffer (via `cudaHostAlloc` with `cudaHostAllocMapped`) to catch overruns; 3. Set `cudaDeviceSetLimit(cudaLimitStackSize, 4 MiB)` to guarantee enough stack for recursive eigen‑solvers. |
| **kernel_xla_v1350.py** | JAX `@jit`‐compiled XLA HLO fusion, `lax.linalg.solve_continuous_lyapunov` on HBM, pure FP64, automatic scaling via `lax.cond` | XLA HLO includes a *dynamic range analysis* pass that inserts `clamp` ops when the estimated exponent exceeds 1023; for `|step| ≥ 10¹⁰` the analysis inserts a safe‑scale factor `α = 2^{-⌈log2|step|⌉}` before the Lyapunov solve, then rescales the result. This avoids overflow but adds a condition‑number factor of `α^{-1}`. | When `|step|` goes to subnormal ranges (< 2⁻¹⁰⁰) the JAX compiler’s `float64` mode preserves subnormals by default. However the *fusion* pass may drop them when it decides to replace a multiplication by a fused multiply‑add that has denorm‑flush enabled on the underlying accelerator. The code explicitly calls `jax.config.update("jax_enable_x64", True)` and `jax.config.update("jax_cpu_enable_x64", True)` to keep subnormals, and adds a `lax.select` guard that forces any value with `abs(x) < 2⁻¹⁰⁴` to be set to `sign(x)*2⁻¹⁰⁴`. | The descriptor is passed to JAX as a **DeviceArray** of shape `(88,)` with dtype `uint8`; the JIT‑compiled function treats it as a *byte‑string* argument, not as a 1‑D token in the communication graph. Hence Rule 22 is satisfied. | **Vendor lock** – relies on Google Cloud TPU / AWS Trainium XLA back‑ends. While XLA is open‑source, the *hardware‑specific* back‑ends are proprietary; cross‑compilation to a generic CPU back‑end is possible but would require a substantial re‑write of the HLO fusion. This is a *soft