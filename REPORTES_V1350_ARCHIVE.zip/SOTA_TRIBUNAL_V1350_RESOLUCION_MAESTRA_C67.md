# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 67

No authoritative public record of the six Tribunal reports, the **POLYDIM V1350 kernels**, or the **PMTP 88-byte descriptor** was available in the gathered material. Therefore, a definitive arbitration of model-specific findings or an unconditional conformance claim would be unsupported. The technically defensible SOTA synthesis is the following.

## 1. Stiefel retraction under extreme steps

For \(X \in \mathrm{St}(n,p)\) and tangent-like update \(\Delta\), the relevant candidates are:

\[
R_{\mathrm{polar}}(X,\Delta)
=
(X+\Delta)\bigl(I+\Delta^{\mathsf T}\Delta\bigr)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Delta)
=
\operatorname{qf}(X+\Delta),
\]

and a Cayley update of the form

\[
R_{\mathrm{Cayley}}(X,\Delta)
=
\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)X,
\]

where \(A^{\mathsf T}=-A\) is constructed from \(X\) and \(\Delta\). Polar and QR retractions are established Stiefel constructions; the cited literature describes polar, QR, and Cayley alternatives and gives their differing computational costs.[2][8][11]

### Arbitration

The claim that Cayley is unconditionally more stable than Householder/QR or polar for \(|\mathrm{step}|\ge 10^{10}\) is not mathematically valid. At that magnitude, stability depends on scaling, floating-point format, matrix dimensions, conditioning, overflow handling, and the exact Cayley implementation.

The strongest defensible guarantee is:

- **Cayley:** preserves orthogonality in exact arithmetic because it is a rational orthogonal transform. In floating-point arithmetic, it requires a reliably solved linear system and can suffer overflow, loss of relative accuracy, or ill-conditioning in the construction of \(A\).
- **Polar:** gives the orthogonal factor closest to \(X+\Delta\) in Frobenius norm when the argument is sufficiently well-conditioned. It is generally the best geometric projection, but forming \(\Delta^{\mathsf T}\Delta\) can overflow or lose scale for extreme steps.
- **Householder/QR:** is usually the preferred baseline for backward stability and avoids explicitly forming a Gram matrix. However, sign conventions, rank deficiency, and column scaling must be specified.

The mathematically superior production policy is therefore **scale-aware dispatch**, not unconditional Cayley selection:

1. Compute a safe scale \(s\) such that
   \[
   \widehat{\Delta}=\Delta/s
   \]
   is representable and does not overflow intermediate products.
2. Perform the factorization on \(X+\widehat{\Delta}\), or use a scaled Cayley formulation.
3. Use Householder QR as the default robust path.
4. Use polar when high-quality nearest-orthogonal projection is required and the scaled factorization is well-conditioned.
5. Use Cayley when an orthogonality-preserving rational update is specifically required and the linear solve passes conditioning and residual checks.
6. Verify
   \[
   \|Q^{\mathsf T}Q-I\| \le \tau_{\mathrm{orth}}
   \]
   and reject or retry if the residual exceeds the configured bound.

Thus the exact guarantee is conditional:

\[
\text{if the scaled factorization succeeds and the residual test passes,}
\quad
Q^{\mathsf T}Q=I+E,
\quad
\|E\|\le\tau_{\mathrm{orth}}.
\]

No implementation can honestly promise finite-precision stability for every \(|\mathrm{step}|\ge10^{10}\) without specifying dimensions, precision, hardware arithmetic, scaling rules, and failure behavior.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

An 88-byte descriptor has no intrinsic memory-ordering semantics. Correctness comes from the publication protocol, not from its size or alignment.

The required protocol is:

### Publisher

1. Fully initialize the descriptor and all immutable payload reachable from it.
2. Publish the pointer or generation using a **release** operation.
3. Retire the old version only after the reclamation scheme confirms that no reader can still hold it.

### Reader

1. Enter the RCU/QSBR read-side critical section.
2. Load the published pointer or generation using **acquire** semantics.
3. Read the descriptor and immutable payload.
4. Exit the read-side critical section.
5. Permit reclamation only after the QSBR/RCU grace-period condition is satisfied.

The key happens-before relation is:

\[
\text{descriptor initialization}
\;\xrightarrow{\text{release publication}}\;
\text{acquire reader load}
\;\xrightarrow{}\;
\text{descriptor observation}.
\]

Acquire/release alone does **not** solve reclamation. A reader can acquire a valid pointer and then race with freeing unless the reader is protected by an RCU/QSBR epoch, hazard pointer, reference count, or equivalent lifetime mechanism.

The exact architectural guarantee should therefore be stated as:

> A reader that enters the read-side protocol before acquiring the published descriptor observes a fully initialized immutable snapshot; a retired snapshot is not reclaimed until every reader that could have observed it has passed through a documented grace period.

Additional requirements are necessary:

- the publication word must be atomic and naturally aligned;
- descriptor fields must not be concurrently mutated after publication;
- pointer provenance and lifetime rules must be respected in C++20 and Rust;
- GPU memory visibility must use the target runtime’s documented device/system-scope primitives;
- “acquire/release” must not be treated as a portable synonym across CPU, CUDA, XLA, Triton, C++, and Rust.

If descriptors contain mutable subobjects, the snapshot guarantee fails unless those subobjects have their own synchronization or are versioned immutably.

## 3. Multi-silicon and multi-language conformance

CUDA, XLA, Triton, C++20, and Rust do not share one universal execution or memory model. Source-level equivalence is insufficient for conformance.

A valid conformance definition needs three layers:

### Numerical conformance

For identical inputs, dimensions, precision, and permitted nondeterminism:

\[
\|Y_i-Y_{\mathrm{ref}}\|
\le
\epsilon_{\mathrm{abs}}
+
\epsilon_{\mathrm{rel}}\|Y_{\mathrm{ref}}\|.
\]

The tolerance must be specified separately for FP32, TF32, FP16, BF16, mixed precision, and any compensated or fused implementation.

### Structural conformance

Every backend must implement the same:

- descriptor layout and offsets;
- endianness and alignment assumptions;
- version/generation interpretation;
- null and invalid-state behavior;
- overflow and NaN policy;
- retraction selection and scaling policy;
- retry, fallback, and failure semantics.

An 88-byte layout is not portable merely because its total size matches. Each field’s offset, width, alignment, and atomicity must be fixed explicitly.

### Memory-model conformance

Each backend must provide the same abstract publication contract:

\[
\text{initialize}
\prec
\text{release publish}
\prec
\text{acquire consume}
\prec
\text{protected read}
\prec
\text{grace-period reclamation}.
\]

CUDA and Triton require explicit scope and fence choices; XLA may reorder or fuse operations unless the API operation establishes the required dependency; C++20 requires atomics and a valid object lifetime; Rust requires a synchronization design compatible with its ownership and aliasing rules. A C++ or Rust acquire load cannot by itself establish visibility for a separate GPU execution domain.

## Definitive arbitration

The strongest defensible SOTA architecture is:

- **Retraction:** scale-aware Householder QR as the universal fallback; polar for nearest-orthogonal projection; Cayley for rational orthogonality-preserving updates, never as an unconditional extreme-step winner.
- **Extreme steps:** mandatory scaling, overflow-safe intermediates, residual verification, and deterministic fallback. No unconditional guarantee is made for raw \(|\mathrm{step}|\ge10^{10}\).
- **Descriptor publication:** immutable snapshots, release publication, acquire consumption, and explicit RCU/QSBR grace-period reclamation.
- **Portability:** define one abstract contract and provide backend-specific implementations; do not claim bitwise or memory-model equivalence across CUDA, XLA, Triton, C++20, and Rust without litmus tests and hardware validation.
- **Guarantees:** only conditional guarantees backed by specified precision, dimensions, memory scopes, layout, lifetime protocol, and validation thresholds.

Accordingly, any Tribunal finding asserting unconditional Cayley superiority, acquire/release-only reclamation safety, or automatic cross-silicon conformance should be rejected as overstated.