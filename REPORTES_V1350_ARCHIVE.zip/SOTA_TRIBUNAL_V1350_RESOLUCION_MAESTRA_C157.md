# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 157

The requested arbitration is **not verifiable from the available evidence**. I found no public, authoritative record of a “POLYDIM V1350” specification, its six kernels, or the eight claimed tribunal reports; the searchable POLYDIM material instead concerns **PolyDiM**, a C++ library for polytopal discretization methods, and does not establish the architecture described here.[8][11] A PMTP draft exists, but the available result does not substantiate the claimed 88-byte descriptor or its complete memory-ordering contract.[15]

What can be stated rigorously is the following.

### 1. Cayley–Stiefel retraction versus Householder or polar QR

No method can honestly be guaranteed stable for arbitrary \(\lvert\mathrm{step}\rvert \ge 10^{10}\) merely because it is called a Cayley, Householder, or polar method.

For a Stiefel iterate \(X\) and tangent-like update \(A\), a Cayley transform typically has the form

\[
X_{+}
=
\left(I-\frac{\tau}{2}W\right)^{-1}
\left(I+\frac{\tau}{2}W\right)X,
\qquad W^{\mathsf T}=-W.
\]

In exact arithmetic, the transform is orthogonal when the solve is well-defined. In floating-point arithmetic, however, very large \(\tau\) can cause:

- overflow in forming \(\tau W\);
- loss of significance in \(I\pm \tau W/2\);
- poorly scaled linear solves;
- amplified backward error;
- failure if \(W\) or its representation is not genuinely skew-symmetric.

A Cayley implementation can therefore preserve orthogonality well **only under explicit scaling, stable solves, and residual checks**. It is not unconditionally stable at extreme step sizes.

Householder QR is generally the stronger default for robust orthogonalization because blocked Householder transformations are backward stable and do not require subtracting nearly equal large quantities in the same way as a naïvely formed Cayley update. Polar retraction can offer excellent geometric properties, but its implementation must use a stable factorization—typically SVD or a carefully implemented Newton–Schulz scheme with scaling. A Newton–Schulz polar iteration without norm control is not an extreme-step guarantee.

The defensible arbitration is therefore:

- **No unconditional winner exists for arbitrary extreme steps.**
- **Householder QR** is the safest generic repair or retraction mechanism.
- **Scaled polar decomposition** is attractive when closest-orthogonal-factor accuracy is the objective.
- **Cayley** is appropriate when its skew structure and solve are controlled, but it requires explicit safeguards.

A mathematically meaningful guarantee would have to specify bounds such as

\[
\|X_{+}^{\mathsf T}X_{+}-I\| \le c\,u\,\kappa_{\mathrm{solve}}\,p(n),
\]

together with finite-range assumptions, scaling rules, a residual threshold, and a fallback path. Without those, the phrase “stable for \(\lvert\mathrm{step}\rvert \ge 10^{10}\)” is not a theorem.

### 2. PMTP descriptor barriers and RCU/QSBR isolation

Acquire/release operations alone do not automatically provide RCU or QSBR snapshot isolation. The required ordering is a protocol property involving:

1. publication of a fully initialized immutable object;
2. release publication of its pointer or generation;
3. acquire consumption by readers;
4. reader registration or active-epoch announcement;
5. writer retirement of the old object;
6. a grace-period test proving that every pre-publication reader has passed through a quiescent state;
7. reclamation only after that proof.

For a publication sequence, the core relation must be equivalent to

\[
\text{initialize object}
\;\xrightarrow{\text{release}}\;
\text{publish pointer/version}
\;\xrightarrow{\text{acquire}}\;
\text{reader dereference}.
\]

For reclamation, the writer must additionally establish a grace-period condition. A release store to the descriptor followed by an acquire load by a reader does **not** by itself prove that no reader still holds the old pointer.

The publicly visible QSBR implementation material explicitly reflects this distinction: readers must observe the relevant generation/parity before accessing the newly published pointer, and the writer must wait for the required quiescent states before committing the next generation.[2] Thus the definitive guarantee should be stated as:

- **Acquire/release can provide publication visibility.**
- **RCU/QSBR safety additionally requires correct reader-state tracking and grace-period completion.**
- **Descriptor width—88 bytes—has no bearing on correctness unless alignment, atomicity, padding, and field-level access rules are specified.**

An 88-byte descriptor is especially unsuitable for any assumption that the entire descriptor can be atomically loaded or stored on ordinary CPUs. The design should instead identify which fields are independently atomic, prevent torn observations through a version/seqlock or immutable-generation scheme, and define cache-line alignment and false-sharing behavior. If a descriptor contains a pointer, length, flags, generation, and checksum, readers should validate a coherent version before and after consuming non-atomic payload fields, or obtain an immutable descriptor pointer whose contents never mutate after publication.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared identically by these environments. Exact cross-silicon conformance cannot be inferred from source-level use of the same words—such as “acquire,” “release,” “barrier,” or “atomic.”

The relevant semantic layers differ:

- **C++20 and Rust** define language-level atomic ordering and object-access rules, subject to their respective implementations.
- **CUDA** adds device, block, system, and scoped atomic/fence behavior, with visibility depending on scope and synchronization domain.
- **Triton** exposes compiler- and backend-dependent synchronization and atomic semantics rather than serving as a complete replacement for the C++ memory model.
- **XLA** lowers computations through compiler IR and backend-specific synchronization; guarantees must be stated for the selected backend and operation set.

A genuine multi-silicon conformance claim therefore requires a formal contract with:

- permitted data races: ideally none on ordinary memory;
- atomic field widths and alignment;
- synchronization scope;
- publication and reclamation protocol;
- progress assumptions;
- NaN, overflow, and denormal behavior;
- deterministic reduction requirements;
- numerical error tolerances;
- compiler lowering constraints;
- litmus tests and stress tests for every backend.

The strongest portable contract is not “identical execution.” It is:

\[
\text{same abstract state-machine result}
\]

under explicitly bounded numerical error and an explicitly defined happens-before relation. Bitwise identity across CUDA, XLA, Triton, C++20, and Rust is generally an additional requirement, not a consequence of memory ordering.

### Definitive arbitration

The supplied record does **not** justify a claim that any of the eight models established SOTA guarantees. The technically defensible synthesis is:

1. Use **scaled Cayley updates only as an optimized path**, with skew-symmetry enforcement, overflow-safe scaling, stable solves, residual checks, and Householder or SVD/polar fallback.
2. Use **release publication plus acquire consumption** for descriptor visibility, but use a separately proven **RCU/QSBR grace-period protocol** for reclamation.
3. Treat the 88-byte descriptor as a layout, not an atomic unit; specify field atomicity, alignment, versioning, and cache-line behavior.
4. Define conformance through a language- and backend-neutral abstract memory contract, then verify each implementation with litmus tests, model checking, numerical bounds, and adversarial stress tests.
5. Do not claim guarantees for arbitrary \(\lvert\mathrm{step}\rvert \ge 10^{10}\), arbitrary silicon, or arbitrary compiler lowering without the missing algorithms, layouts, backend versions, and test evidence.

The available sources support general QSBR ordering principles and identify PolyDiM as a numerical C++ library, but they do not substantiate the claimed V1350 architecture or the eight-model findings.[2][8][11][15]