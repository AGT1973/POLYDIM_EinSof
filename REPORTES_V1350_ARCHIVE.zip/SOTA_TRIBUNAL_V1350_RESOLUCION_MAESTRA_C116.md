# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 116

There is not enough verifiable information to arbitrate the claimed findings of the eight Tribunal models or the six “V1350 kernels”: no model reports, kernel specifications, numerical results, code, or conformance test logs were provided. The available public evidence supports a conditional synthesis, not an unconditional “definitive” guarantee.

## 1. Extreme-step Stiefel retraction

Let \(X\in\mathrm{St}(n,r)\), \(X^\top X=I\), and let \(\Delta\) be a tangent step. The methods have different guarantees:

| Method | Mathematical guarantee | Behavior for \(\lVert\Delta\rVert\ge 10^{10}\) | Arbitration |
|---|---|---|---|
| **Polar** | \(R_{\mathrm{polar}}(X+\Delta)\) is the Frobenius-nearest orthonormal factor when the argument has full column rank | The scale of \(\Delta\) largely cancels mathematically, but rank loss, overflow, underflow, and SVD/eigendecomposition conditioning remain implementation concerns | Strongest default for projection quality and backward stability, provided a rank-revealing, scaled implementation is used |
| **Householder/QR** | Produces an orthonormal \(Q\) from a QR factorization; Householder QR is generally more stable than classical Gram–Schmidt | More robust than naive orthogonalization, but sign conventions, near-rank deficiency, scaling, and finite-precision overflow still matter | Strong production baseline; requires explicit scaling and rank/finite-value checks |
| **Cayley** | Preserves orthogonality in exact arithmetic when evaluated as a valid Cayley transform; commonly uses a solve involving \(I-\tfrac12W\) and \(I+\tfrac12W\) | A fixed-step or truncated iterative implementation is not automatically stable for arbitrarily large steps. A cited convergence condition for one iteration is \(\alpha<2/\lVert W\rVert\), so an unscaled extreme step violates the usual contraction regime.[14] | Acceptable only with adaptive scaling, a stable solve, residual checks, and fallback; not defensible as unconditionally superior at \(10^{10}\)-scale |

The key distinction is between **exact-arithmetic geometric preservation** and **finite-precision numerical stability**. A Cayley map can be orthogonality-preserving in exact arithmetic, but that does not imply stable evaluation for an extreme step. The literature describes Cayley, polar, and QR retractions as distinct computational choices, with different costs and numerical properties.[3] Recent work also reports bounded conditioning for a particular polar-light retraction, but that result does not automatically apply to every polar implementation or to the V1350 kernels.[8]

### Superior arbitration

The mathematically strongest architecture is a **scaled hybrid retraction**:

1. Reject NaN, infinity, and structurally invalid dimensions.
2. Scale the step before factorization or Cayley evaluation:
   \[
   \widehat{\Delta}=\Delta/s,\qquad
   s=\max\!\left(1,\|\Delta\|_{\mathrm{safe}}\right).
   \]
3. Use a stable polar or Householder-QR path as the reference projection.
4. Permit Cayley only when:
   \[
   \kappa(I-\tfrac12W)
   \]
   is within a configured bound and the computed orthogonality residual satisfies
   \[
   \frac{\|Y^\top Y-I\|}{u\,\mathrm{poly}(n,r)}\le \tau_{\mathrm{orth}},
   \]
   where \(u\) is unit roundoff.
5. Fall back to scaled Householder QR or polar decomposition when the Cayley solve, residual, rank test, or finite-value test fails.
6. Verify the postcondition rather than trusting the algorithm label.

The exact architectural guarantee should therefore be:

\[
Y^\top Y=I
\]

**in exact arithmetic**, and in finite precision:

\[
\|Y^\top Y-I\|\le \tau_{\mathrm{orth}},
\]

provided the input is finite, the chosen factorization succeeds, and the implementation’s residual threshold is met. No unconditional finite-precision guarantee follows merely from \(|\mathrm{step}|\ge10^{10}\).

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering is necessary but not sufficient for a complete RCU or QSBR design.

A correct publication pattern is:

```cpp
// Writer:
initialize_descriptor_and_payload();
published.store(new_version, std::memory_order_release);

// Reader:
auto v = published.load(std::memory_order_acquire);
consume_descriptor_and_payload(v);
```

If the acquire load reads the value published by the release store, prior initialization becomes visible to the reader.[1][9] RCU verification work likewise identifies release/acquire ordering as the mechanism that orders node initialization before reader access and coordinates quiescent-state progress before reclamation.[2]

However, the 88-byte size does **not** establish correctness. The descriptor must additionally satisfy:

- atomic publication of the version or pointer;
- correct alignment and non-tearing access for every concurrently accessed atomic field;
- immutable payload after publication, or separately synchronized mutation;
- a valid lifetime protocol;
- reader registration and quiescent-state reporting;
- reclamation only after every pre-existing reader has passed a grace period;
- protection against ABA, typically through generations, epochs, or tagged pointers;
- explicit cache-line and false-sharing policy where performance matters.

The correct guarantee is:

> A reader that successfully acquires a published descriptor observes a fully initialized immutable snapshot, and reclamation occurs only after the applicable RCU/QSBR grace-period condition is satisfied.

Acquire/release alone does **not** guarantee:

- reclamation safety;
- absence of ABA;
- atomicity of a non-atomic 88-byte copy;
- snapshot isolation across multiple separately published objects;
- ordering across CUDA, XLA, Triton, or device-host domains.

For a multi-field descriptor, publish **one immutable descriptor pointer or generation token**, rather than attempting to update 88 bytes in place. Readers acquire the token once and dereference only the associated immutable object. If the descriptor must remain exactly 88 bytes, an external immutable payload and a compact atomic publication word are preferable to treating the entire byte array as an atomic object.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single shared memory model that permits an unconditional cross-silicon guarantee across all five environments. C++20 and Rust define language-level atomic semantics; CUDA defines host/device and device/device behavior through its own scopes and synchronization mechanisms; XLA may fuse, reorder, duplicate, or lower operations according to compiler semantics; Triton exposes its own compiler and GPU memory-order behavior.

Accordingly, conformance must be specified as **semantic portability**, not source-level equivalence.

The portable contract should define:

- descriptor layout: byte size, alignment, offsets, endianness, and padding;
- ownership and lifetime;
- publication event;
- reader snapshot event;
- reclamation event;
- required visibility scope;
- permitted reordering;
- numerical tolerances;
- failure and fallback behavior.

Each backend then maps the abstract events to its native primitives:

- **C++20:** release publication, acquire consumption, and an explicit reclamation scheme.
- **Rust:** equivalent atomic ordering plus ownership/lifetime enforcement; `unsafe` code must preserve the same publication and reclamation invariants.
- **CUDA:** scope-appropriate atomics and fences, with explicit host/device synchronization where data crosses the execution boundary.
- **XLA:** express synchronization and data dependencies through supported compiler-visible operations; do not assume that a host-language atomic translates into an equivalent device-side barrier.
- **Triton:** use the backend-supported atomic and memory-order features and validate generated behavior on every target architecture.

A conformance suite should test at least:

1. descriptor size and alignment;
2. publication-before-observation ordering;
3. absence of torn or mixed-generation snapshots;
4. grace-period reclamation;
5. ABA resistance;
6. numerical orthogonality residuals after retraction;
7. extreme-step finite-value behavior;
8. deterministic fallback selection;
9. host/device visibility;
10. compilation and execution on every supported GPU and CPU target.

## Final arbitration

The defensible SOTA synthesis is:

- **Retraction:** scaled polar or Householder QR is the reference-stability path; Cayley is an optimized conditional path, not an unconditional extreme-step winner.
- **Descriptor:** publish an immutable snapshot through one atomic release/acquire token; use RCU/QSBR for lifetime, with generation protection against ABA. The 88-byte layout is an ABI constraint, not a synchronization guarantee.
- **Portability:** guarantee an abstract snapshot-and-retraction contract, then prove each backend mapping with litmus tests, numerical residual tests, and reclamation stress tests. C++20/Rust semantics cannot by themselves establish equivalent CUDA/XLA/Triton behavior.

Without the eight Tribunal outputs and the V1350 specifications, claims stronger than these—such as unconditional Cayley stability at \(|\mathrm{step}|\ge10^{10}\), atomicity of the full 88-byte descriptor, or universal cross-silicon memory-order equivalence—are not established.