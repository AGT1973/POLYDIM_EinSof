# AUDITORÍA TRIBUNAL DE SABIOS — Claude_Sonnet_5_5 (CICLO 84)

Since the six files weren't actually shared with me, I can't audit real code — but I can still verify the math behind what's described, like checking the Cayley retraction, Woodbury identity, and Neumaier summation, and manually computing the byte size implied by that struct format string to see if it matches expectations.

Working through the Woodbury factorization, I realize the resulting 2k×2k matrix isn't actually symmetric, which breaks the assumption that syevd can be applied directly—it would silently misuse the lower/upper triangle and give wrong results. I'm considering alternatives, like reformulating via a QR decomposition of [G,X] to get a skew matrix expressed in a smaller orthonormal basis instead.

Pivoting to the Cayley transform approach: since I+(t/2)S is a normal matrix when S is skew-symmetric, its condition number stays bounded as sqrt(1+(tλmax/2)²), meaning the system is always well-conditioned regardless of step size—a nice structural guarantee.

But as t grows large, the Cayley map rotates by nearly π and saturates toward reflection, so it loses its descent direction even though orthonormality of X^T Y remains preserved to machine precision throughout.

I should also think about global scaling in the implementation: dividing by a power-of-two scale factor keeps things exact in floating point, whereas arbitrary scaling introduces rounding error in the identity contribution — so using ldexp/frexp-style power-of-two scaling is the safer choice.

But uniform scaling doesn't change the matrix's conditioning, so the real risk is non-normality of V^T U: the 2k×2k matrix can have the same eigenvalues as UV^T but a poorly conditioned eigenbasis, meaning the Woodbury-based solve could still amplify errors far beyond what the normal-matrix bound would suggest.

Doing a QR factorization of the combined [G X] block upfront avoids this squared conditioning when the gradient is nearly parallel to X or rank-deficient. I'm also checking the small-step limit: if step size shrinks toward subnormal floating point values, step/2 can lose precision, but since Y reduces to X - step·(projected gradient) to first order, for step below machine epsilon Y collapses exactly to X, which trivially satisfies the retraction condition without needing special underflow handling.

I should flag that FP64 subnormals actually start around 2.225e-308, not 1e-12 or 1e-14 — if any audit is labeling those thresholds as "subnormal," that's a mislabeling worth calling out, since those values are just small normal numbers, not denormalized ones.

On the compensated-summation side, Neumaier's error bound only holds if the compiler doesn't reassociate or fuse operations — so the build must avoid fast-math flags, and any OpenMP reduction needs a custom declared reduction over the (sum, correction) pair with a fixed iteration order, since FMA contraction or vectorization could silently break the compensation logic.

