# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 80)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 80 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has reviewed the six artifacts as *specifications* (the source bodies were not attached to this docket; the audit is therefore conducted against the declared contracts, invariants, and the numerical/FFI claims asserted in the brief). Where a claim is unverifiable from the brief alone, it is flagged **[UNVERIFIED — demand artifact]**. Where a claim is *mathematically* checkable from the brief, it is adjudicated on the merits.

---

## §0. Cross-Cutting Findings (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor is declared as `<4sHHQQQQQBB6x4Q`.

**Byte accounting (little-endian, standard `struct` alignment disabled by `<`):**

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version | `H` | 2 |
| flags | `H` | 2 |
| dim0 | `Q` | 8 |
| dim1 | `Q` | 8 |
| dim2 | `Q` | 8 |
| dim3 | `Q` | 8 |
| stride0 | `Q` | 8 |
| stride1 | `Q` | 8 |
| dtype | `B` | 1 |
| rank | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **96** |

**Verdict: FAIL.** The declared format string yields **96 bytes**, not 88. The brief asserts 88-byte conformance across Targets 1, 2, 3, 5, 6. Either:
- (a) the format string is mis-transcribed in the brief, or
- (b) the `4Q` reserved tail is actually `2Q` (→ 80 B) plus a 8-byte trailer, or
- (c) the `6x` pad is `0x` and one `Q` is dropped (→ 88 B).

**Required remediation:** publish the canonical `struct.calcsize` assertion in CI:
```python
assert struct.calcsize("<4sHHQQQQQBB6x4Q") == 88, "PMTP drift"
```
This assertion **will fail** as written. The Tribunal demands the corrected format string before Rule 22 can be certified. Until then, **Rule 22 is NOT satisfied** on Targets 1, 2, 3, 5, 6.

**Rule 22 (Zero 1D tokens):** No target in the brief exposes a 1D token channel in inter-agent messaging. The PMTP descriptor is the sole wire format. **Provisionally PASS**, contingent on the 88-byte fix above.

### 0.2 Rule 27 — Silicon Contract / Vendor Lock

| Target | Vendor surface | Lock risk |
|---|---|---|
| 1 orchestrator | Multi-silicon probe | **PASS** if probe is runtime-dispatched |
| 2 C++ AVX-512 | Intel/AMD x86 only | **CONDITIONAL** — needs scalar fallback |
| 3 Rust SIMD | portable via `std::simd` | **PASS** |
| 4 CUDA | NVIDIA-only (cuSOLVER, CUDA Graphs) | **FAIL** unless HIP/ROCm path exists |
| 5 XLA | Google TPU **and** AWS Trainium | **PASS** (dual-vendor) |
| 6 Triton | AMD ROCm **and** NVIDIA | **PASS** (dual-vendor) |

**Verdict:** Target 4 is the sole Rule 27 violator. cuSOLVER `DnDsyevd` and CUDA Graphs have no first-class AMD equivalent in the same source. **Remediation:** either (i) declare Target 4 as an *optional accelerator* behind a capability flag, or (ii) provide a HIP port using `rocSOLVER` `syevd` + HIP Graphs. The Tribunal accepts (i) as a minimal fix.

---

## §1. Target 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator
- **Multi-silicon probe:** must be *idempotent* and *side-effect-free* at import. If the probe caches device handles in module globals, fork-safety is violated. **Recommendation:** probe behind `os.register_at_fork` reset hook.
- **Slab allocator:** 88-byte descriptors imply slab alignment of 88 → **not a power of two**. This is a cache-line hazard: 88 B descriptors straddle 64 B lines. **Recommendation:** pad to 128 B in the slab, keep 88 B on the wire. This is a *performance* finding, not a correctness one.

### 1.2 12/12 physical conformance checks
The brief asserts 12/12. The Tribunal cannot verify without the check list. **[UNVERIFIED — demand artifact]**. If any check is `assert`-based and compiled with `-O`, it vanishes. **Recommendation:** use explicit `if not check: raise ConformanceError(...)`.

### 1.3 Degeneracy at step → ∞ / step → 0
Orchestrator is a dispatcher; degeneracy is inherited from Targets 2–6. **No independent finding.**

---

## §2. Target 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product
Neumaier's variant of Kahan–Babuška:
```
s = x; c = 0
for i: t = s + x_i
       if |s| >= |x_i|: c += (s - t) + x_i
       else:            c += (x_i - t) + s
       s = t
return s + c
```
**Error bound (Higham, Thm 4.3):** for `n` terms,
```
|fl(dot) - dot| <= (2u + O(nu²)) * Σ|x_i y_i|
```
i.e. **forward error is independent of n to first order**. This is the correct choice for the stated use.

**Degeneracy at step → ∞:** the *step* does not enter the dot product; only the operands do. If `step` scales operands, then `Σ|x_i y_i|` scales as `step²`, and the *relative* error is preserved. **No degeneracy.** ✅

**Degeneracy at step → 0 (subnormals):** Neumaier's compensation term `c` is itself a sum of subnormals. On x86 with FTZ/DAZ enabled (default under `-ffast-math`), `c` is flushed to zero and the compensation is **silently lost**. The brief's "subnormal audits (-12, -14)" suggests the authors are aware. **Required:** explicit `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)` and `_MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_OFF)` around the kernel, or compile with `-fno-fast-math`. **Verdict: CONDITIONAL PASS.**

### 2.2 AVX-512 / OpenMP
- AVX-512 downclocking on Skylake-X is a known hazard; on Ice Lake+ it is mitigated. **Recommendation:** runtime dispatch via `__builtin_cpu_supports("avx512f")` with AVX2 fallback (also satisfies Rule 27).
- OpenMP `reduction(+:s,c)` on Neumaier is **incorrect** — the compensation term is not associative. **Recommendation:** per-thread Neumaier accumulators, then a final Neumaier merge. If the code uses `reduction(+:)` on `c`, that is a **correctness bug**.

### 2.3 Zero-copy PMTP validation
Zero-copy implies the descriptor points into caller memory. **Required:** validate `magic`, `version`, `rank <= 4`, `dtype` in enum, and that `stride_i * dim_i` does not overflow `size_t`. **Recommendation:** a single `validate_pmtp(const PmtpTensorDescriptor*)` with `[[nodiscard]]` and a `noexcept` contract.

---

## §3. Target 3 — `kernel_rust_v1350.rs`

### 3.1 Safe SIMD
Rust 2021 `std::simd` is nightly-only as of the 2021 edition stabilization; if the crate uses `portable_simd`, it is **not** stable Rust 2021. **Verdict: [UNVERIFIED — demand `rust-toolchain.toml`]**. If it uses `core::arch::x86_64::*` intrinsics, they are `unsafe` and the "Safe SIMD" claim is false.

### 3.2 `panic=unwind` FFI barrier
This is the **correct** choice. `panic=abort` across FFI is UB-adjacent (the panic cannot be caught by the foreign runtime). With `panic=unwind`, the Rust side must still **not** unwind across the FFI boundary — `extern "C"` functions abort on unwind since Rust 1.71 (the `C-unwind` ABI is opt-in). **Required:** every `extern "C"` entry point wraps the body in `std::panic::catch_unwind` and returns a sentinel error code. **Recommendation:**
```rust
#[no_mangle]
pub extern "C" fn poly_kernel(...) -> i32 {
    match std::panic::catch_unwind(|| inner(...)) {
        Ok(Ok(())) => 0,
        Ok(Err(e)) => e.code(),
        Err(_)     => -1,
    }
}
```

### 3.3 Neumaier sums
Same analysis as §2.1. Rust does **not** enable FTZ/DAZ by default; subnormals are preserved. **PASS** on subnormal handling, *provided* the FFI caller (C++/CUDA) does not enable FTZ before calling in. **Recommendation:** document the FP environment contract in the FFI header.

### 3.4 Packed 88-byte descriptor
`#[repr(C, packed)]` on a struct containing `u64` fields produces **unaligned loads** on some targets. On x86 this is fine; on ARM64 it is a fault. **Recommendation:** `#[repr(C)]` with explicit `u8` padding, or `#[repr(C, align(8))]` and accept 96 B on the wire, or use `zerocopy::FromBytes`. **Verdict: CONDITIONAL PASS.**

---

## §4. Target 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)
The Cayley retraction on the Stiefel manifold `St(n,p)` is
```
Y(τ) = (I - (τ/2) A)^{-1} (I + (τ/2) A) Y