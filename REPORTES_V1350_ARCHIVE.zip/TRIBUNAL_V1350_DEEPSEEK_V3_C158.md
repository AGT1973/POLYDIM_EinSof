# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 158)

# POLYDIM V1350 — High Tribunal Audit, Cycle 158

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods
**Verdict posture:** Adversarial. Claims of "SOTA" are treated as unproven until each invariant is discharged.

---

## 0. Preliminary: What the Audit Can and Cannot Certify

The Tribunal notes at the outset that **no source artifacts were supplied** — only architectural claims. Therefore this audit is a *specification-level* review. Every finding below is stated as a **conditional obligation**: "If the implementation matches the described contract, then the following holds; if not, the claim is void." Concrete line-level defects cannot be certified without the files. We flag this as **Finding A0 (procedural)**.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us actually sum the struct.

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Arithmetic checks out.** But two adversarial observations:

- **Finding 1.1a (alignment trap).** With native alignment, `Q` requires 8-byte alignment. The `6x` pad after `BB` places the trailing `4Q` at offset 56 — which is 8-aligned *only if* the struct base is 8-aligned. Under `struct.pack` this is fine (no padding inserted), but under `ctypes.Structure` or C++ `#pragma pack` mismatches, the layout will silently diverge. **Obligation:** publish a `static_assert(sizeof(...) == 88)` in C++ and `assert(ctypes.sizeof(...) == 88)` in Python, plus a golden-vector byte dump in CI.
- **Finding 1.1b (endianness).** `<` forces little-endian. On a big-endian host (rare but exists in some POWER/SPARC HPC nodes), the descriptor is silently misread. **Obligation:** either assert `sys.byteorder == 'little'` at import, or emit a `>` variant.

### 1.2 "12/12 physical conformance checks"

Without the check list, we can only demand: the checks must be **independent** (no two checks testing the same invariant), **total** (cover all 88 bytes), and **falsifiable** (each must have a known-bad input that fails it). A 12/12 pass rate is meaningless if the checks are correlated. **Obligation:** publish the check matrix and a mutation-testing report showing each check kills ≥1 mutant.

### 1.3 Numerical degeneracy at step extremes

The orchestrator itself is not numerical, but it *routes* `step`. **Finding 1.3:** if the orchestrator does not clamp `step` before dispatch, a `step = 1e300` will propagate to CUDA/XLA and produce `inf` in the Cayley retraction (see Target 4). **Obligation:** orchestrator must enforce `|step| ∈ [ε_subnormal_safe, 1e10]` and reject otherwise with a typed error, not silently clamp.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška gives a **forward error bound** for the dot product `s = Σ aᵢbᵢ`:

$$
|\hat{s} - s| \le \big(2u + O(nu^2)\big)\sum_i |a_i b_i| + O(u^2)|s|
$$

where `u = 2⁻⁵³` for FP64. This is **independent of the condition number of the dot product itself** — the *relative* error is bounded by `2u · Σ|aᵢbᵢ| / |s|`, which *does* degrade when `Σ|aᵢbᵢ| ≫ |s|` (catastrophic cancellation). **Finding 2.1:** Neumaier does **not** rescue cancellation; it only removes the *accumulation* error. If the kernel is used inside a Stiefel retraction where `⟨X, Y⟩ → 0` near orthogonality, the relative error blows up as `κ = Σ|aᵢbᵢ|/|s|`. **Obligation:** publish the empirical `κ` distribution over the target workload; if `κ > 10¹²`, switch to double-double (Dekker/Knuth) or exact accumulation.

### 2.2 Subnormal audits at −12 and −14

The exponents −12 and −14 are **not** the FP64 subnormal boundary (that is −1022). They are the **FP32** subnormal boundary (−126) — no. They are the **FP16** subnormal boundary (−14) and the **BF16** subnormal boundary (−126). **Finding 2.2:** the labels "−12, −14" are ambiguous. If they refer to *decimal* exponents of the *step* magnitude (`10⁻¹²`, `10⁻¹⁴`), then the audit is testing step→0, not subnormals. **Obligation:** disambiguate. If the intent is FP64 subnormals, the audit must probe `2⁻¹⁰²²` and `2⁻¹⁰⁷⁴`.

### 2.3 Zero-copy PMTP validation

Zero-copy implies the C++ kernel reads the 88-byte descriptor directly from shared memory. **Finding 2.3 (TOCTOU):** if the descriptor is validated *after* the pointer is dereferenced, a concurrent writer can flip `magic` between check and use. **Obligation:** validate into a stack-local copy, then use the copy; or use a seqlock.

### 2.4 AVX-512 + OpenMP

**Finding 2.4:** AVX-512 downclocking on Intel Skylake-X/Ice Lake can cost 15–40% throughput on mixed workloads. If the kernel is memory-bound (likely for a dot product), AVX-512 is a net loss. **Obligation:** publish roofline analysis; consider AVX2 fallback with runtime dispatch.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier — **this is backwards**

**Finding 3.1 (critical).** The Rustonomicon is explicit: **`panic = unwind` across an FFI boundary is undefined behavior** unless the boundary is `extern "C-unwind"` (Rust 1.71+) and the callee is prepared. The *safe* choice for FFI is `panic = abort`, which converts a panic into a process abort — ugly but defined. Using `unwind` as a "safety barrier" is a **misreading of the guarantee**. **Obligation:** either (a) switch to `panic = abort`, or (b) wrap every `extern "C"` entry point in `std::panic::catch_unwind` and return a sentinel error code. Option (b) is the only one that preserves the "barrier" semantics the architecture claims.

### 3.2 Safe SIMD + Neumaier

Rust's `std::simd` is still nightly-only as of the audit date. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. **Finding 3.2:** "Safe SIMD" is a marketing claim unless the kernel is on nightly `portable_simd`. **Obligation:** state the toolchain and the `unsafe` block count; a "safe" kernel with 200 `unsafe` blocks is not safe.

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` will produce 88 bytes, but **taking a reference to a packed field is UB** if the field is not aligned. **Finding 3.3:** any `&desc.field` on a packed struct is a latent UB. **Obligation:** use `#[repr(C)]` with explicit `_pad: [u8; 6]` and `#[repr(align(8))]`, or read fields via `read_unaligned`.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction — the step→∞ degeneracy

The Cayley retraction on the Stiefel manifold is

$$
Y(\tau) = \left(I - \tfrac{\tau}{2} A\right)^{-1}\left(I + \tfrac{\tau}{2} A\right) X, \quad A = G X^\top - X G^\top
$$

(skew-symmetric `A`). As `τ → ∞`, `Y(τ) → -X` (the antipode). The map is **well-defined for all finite τ**, but the *condition number* of the solve `(I - τA/2)⁻¹` grows linearly in `τ`:

$$
\kappa_2(I - \tfrac{\tau}{2}A) = \frac{1 + \tau\|A\|_2/2}{1 - \tau\|A\|_2/2} \to \infty \text{ as } \tau\|A\|_2 \to 2
$$

**Finding 4.1 (critical).** For `τ ≥ 10¹⁰` and `‖A‖₂ ~ O(1)`, the linear system is **numerically singular** in FP64: `1 - τ‖A‖/2` underflows to a value indistinguishable from 0 at `u = 2⁻⁵³`. The retraction returns garbage. **Obligation:** clamp `τ‖A‖₂ ≤ 1` (or use the QR-based retraction, which is unconditionally stable). The claim "Stiefel Cayley retraction" without a step clamp is **not SOTA**; it is a known failure mode.

### 4.2 Globally scaled Woodbury solve `(M/scale) W = (step/scale) B`

This is the standard trick to keep the RHS in range. But **Finding 4.2:** if `scale` is chosen as `‖M‖_F`, then `step/scale` can still overflow if `step = 1e300` and `scale = 1e-300`. **Obligation:** `scale = max(‖M‖_F, |step|, ε_min)` and clamp `step/scale ∈ [ε, 1/ε]`.

### 4.3 cuSOLVER `DnDsyevd` — **wrong routine**

`DnDsyevd` is the **divide-and-conquer** eigensolver for **symmetric** matrices. The Cayley retraction requires a **linear solve**, not an eigendecomposition. If the kernel is using