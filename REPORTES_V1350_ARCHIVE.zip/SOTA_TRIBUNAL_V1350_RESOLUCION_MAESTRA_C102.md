# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 102

The available public evidence does **not** identify a documented “POLYDIM V1350” kernel suite, “PMTP 88-byte Descriptor,” or the six purported Tribunal-model reports. The search results instead point to the unrelated **PolyDiM** PDE library and general CUDA/XLA/Triton material.[3][6][13] Therefore, no defensible arbitration of the six model findings—or claim of an already achieved SOTA implementation—can be made from the supplied record.

A mathematically and architecturally sound synthesis would be:

## 1. Extreme-step Stiefel retraction

For a Stiefel point \(X\in\mathrm{St}(n,p)\), a Cayley update can be written as

\[
X_{+}
=
\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)X,
\qquad A^\top=-A .
\]

In exact arithmetic, the Cayley transform is orthogonal:

\[
Q(\tau)^\top Q(\tau)=I,
\]

so it preserves the Stiefel constraint for any finite \(\tau\) for which the solve is nonsingular. That does **not** imply numerical stability for \(|\tau|\ge 10^{10}\). At such scales:

- the update may become dominated by floating-point rounding;
- forming \(I\pm \tau A/2\) can cause severe scaling and conditioning problems;
- iterative solves may lose orthogonality;
- finite-precision behavior depends on matrix norms, precision, scaling, and preconditioning.

A polar or Householder-QR retraction generally provides a stronger practical orthogonality-restoration mechanism:

\[
X_{+}=\operatorname{qf}(X+\tau \Delta)
\]

or, for the polar form,

\[
X_{+}=(X+\tau\Delta)
\bigl((X+\tau\Delta)^\top(X+\tau\Delta)\bigr)^{-1/2}.
\]

However, neither method has an unconditional guarantee for arbitrary extreme steps. The correct arbitration is:

- **Cayley:** constraint-preserving in exact arithmetic and potentially efficient, but requires a condition-number and residual guard for extreme steps.
- **Householder QR:** usually the preferred robust fallback because it avoids explicitly constructing a potentially ill-conditioned normal matrix.
- **Polar:** attractive when high-quality nearest-point retraction is required, but its implementation must use a stable SVD, eigensolver, or carefully controlled Newton iteration.

The definitive guarantee should therefore be conditional:

\[
\|X_{+}^{\top}X_{+}-I\| \le c\,u\,\kappa_{\mathrm{alg}},
\]

where \(u\) is unit roundoff and \(\kappa_{\mathrm{alg}}\) captures the conditioning and backward error of the selected factorization or solve. If this bound fails, the implementation must reject, rescale, reduce the step, or fall back to QR/polar retraction. No honest SOTA claim can guarantee stability solely from the fact that \(|\tau|\ge 10^{10}\).

## 2. PMTP descriptor and RCU/QSBR isolation

An 88-byte size is an ABI/layout property, not a memory-ordering guarantee. Acquire/release semantics must be attached to the publication protocol, not inferred from the descriptor’s size or alignment.

A valid immutable-snapshot publication pattern is conceptually:

```cpp
// Writer
new_snapshot->initialize();
std::atomic_thread_fence(std::memory_order_release);
published.store(new_snapshot, std::memory_order_release);

// Reader
auto p = published.load(std::memory_order_acquire);
enter_qsbr_or_rcu_read_section();
use_immutable_snapshot(p);
exit_qsbr_or_rcu_read_section();
```

The ordering requirements are:

1. All snapshot contents are initialized before publication.
2. The reader’s acquire operation observes the release publication.
3. The reader enters the read-side critical section before dereferencing data whose reclamation it must prevent.
4. Reclamation occurs only after every pre-existing reader has passed through a quiescent state or after an equivalent grace period.
5. Descriptor mutation is prohibited while readers may hold the snapshot, unless fields themselves use an independently specified atomic protocol.

Acquire/release establishes **visibility and ordering**; it does not by itself establish **lifetime safety**. A release store plus acquire load cannot prevent use-after-free without RCU/QSBR grace-period discipline. Conversely, QSBR alone does not necessarily publish initialized data unless the publication operation has the appropriate ordering.

A defensible architectural guarantee is:

\[
\text{reader observes either a fully initialized old snapshot or a fully initialized new snapshot,}
\]

provided that snapshots are immutable after publication and reclamation waits for a grace period. It is not valid to promise isolation for partially updated in-place descriptors.

The descriptor should additionally specify:

- exact field offsets and padding;
- alignment;
- endianness;
- ownership and lifetime rules;
- atomic fields and their memory orders;
- versioning or ABA protection;
- host/device visibility behavior;
- whether device atomics participate in the same coherence domain.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no automatic semantic equivalence across these environments. CUDA, XLA, Triton, C++20, and Rust expose different compilation, memory, aliasing, synchronization, and numerical models. The search results provide no V1350 conformance specification; they only identify general PolyDiM and Triton/XLA-related projects, not this kernel suite.[6][10][12][13]

Conformance must therefore be defined through a language-independent contract containing:

- mathematical preconditions and postconditions;
- permitted floating-point error;
- NaN, infinity, overflow, and underflow behavior;
- tensor layouts and strides;
- aliasing rules;
- synchronization scope;
- atomicity and memory-order requirements;
- lifetime and reclamation rules;
- deterministic versus nondeterministic execution;
- supported architectures and feature levels.

The strongest practical model is:

- **C++20:** normative host reference for object representation, atomics, and ABI rules.
- **Rust:** ownership-safe implementation, with `unsafe` limited to a reviewed FFI/device boundary; it must not silently strengthen or weaken the C++ memory contract.
- **CUDA:** normative device implementation for thread scopes, synchronization, and device memory ordering.
- **Triton:** conforming implementation only where its compiler and target provide the required barriers, atomics, layouts, and memory scopes.
- **XLA:** conforming lowering only if the HLO/custom-call contract preserves the required ordering, aliasing, side effects, and numerical semantics.

Bitwise identity across all five targets should not be promised unless the implementation restricts operations, compiler transformations, reduction order, and floating-point modes accordingly. A more realistic guarantee is bounded observational equivalence:

\[
d\!\left(F_{\text{backend}}(x),F_{\text{ref}}(x)\right)
\le \varepsilon_{\text{backend}}(x),
\]

with backend-specific tolerances and explicit synchronization tests.

## Definitive arbitration

The mathematically superior synthesis is not “Cayley always wins,” “QR always wins,” or “Acquire/Release guarantees RCU isolation.” It is a **guarded, contract-driven design**:

1. Use Cayley updates when the skew operator and solve pass conditioning and residual checks.
2. Use Householder QR as the robust default fallback for extreme or poorly conditioned steps; use stable polar retraction where nearest-point geometry is more important than cost.
3. Publish immutable PMTP snapshots with release/acquire ordering and protect their lifetime with RCU/QSBR grace periods.
4. Treat the 88-byte descriptor as a versioned ABI with compile-time layout assertions, not as a synchronization mechanism.
5. Define one formal semantic contract and validate every backend against it through property-based tests, race tests, numerical residual tests, layout tests, and reclamation stress tests.
6. Claim only conditional guarantees supported by measured residuals, memory-model proofs, and backend-specific validation.

Accordingly, the exact unconditional guarantees requested cannot be established from the available findings. Any Tribunal conclusion asserting universal extreme-step stability, automatic snapshot isolation from acquire/release alone, or full multi-silicon conformance without a published specification and reproducible tests would be technically overstated.