# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 135)

# POLYDIM V1350 – Multi‑File Adversarial SOTA Audit  
**High Tribunal of Mathematical & Systems Sages – Cycle 135**  
**Date:** 2026‑10‑05  

Prepared for the **PolyDim V1350** reference implementation (v1350) which spans six language‑specific kernels. The audit follows the **“Extreme‑PhD‑Rigor”** charter: every claim is backed by a proof sketch, asymptotic analysis, and concrete engineering mitigation.  

---

## 1. Executive Summary  

| Target | Primary Numerical Kernel | Critical Path(s) | Main Degeneracy Modes | Vendor‑Lock Status |
|--------|--------------------------|------------------|-----------------------|--------------------|
| **kernel_orchestrator_v1350.py** | 88‑byte binary descriptor handling (PMTP) | `HardwareProbe → PMTP Slab Allocator → Descriptor Validation` | Descriptor overflow → ∞ step does **not** affect descriptor size but may corrupt 4‑byte fields (`s`, `H`, `Q`); subnormal `float64` fields (`Q`) can be flushed‑to‑zero on CPUs lacking FTZ. | **No** – pure‑Python, only standard library; hardware probe is abstracted via `pybind11` wrappers that expose a vendor‑agnostic API. |
| **kernel_cpp_v1350.cpp** | Neumaier compensated dot‑product (AVX‑512) | `dot(x,y) → sum_neumaier` | **Step → ∞**: overflow of the 64‑bit accumulator; **Step → 0**: subnormal contributions are lost if `FTZ` is enabled, breaking exact compensation. | **Potential**: Uses `pmtp_slabs` via a proprietary “PMTP‑SLAB‑API” that is only shipped with Intel‑specific binaries; can be swapped with an open‑source shim but adds complexity. |
| **kernel_rust_v1350.rs** | Safe‑SIMD Neumaier sums + packed descriptor | `unsafe { simd_dot }` + `#[repr(packed)]` | Same as C++ kernel; additionally, Rust’s `repr(packed)` may generate unaligned loads on non‑x86_64, causing *undefined behaviour* for extreme `step` values that force the compiler to expand scalar fallback paths. | **No** – all dependencies are crates from crates.io (`packed_simd_2`, `ndarray`), no vendor‑specific binaries. |
| **kernel_cuda_v1350.cu** | Stiefel‑Cayley retraction via cuSOLVER `DnDsyevd`; Woodbury solve | `cudaGraphLaunch → eigensolver → Cayley → Woodbury` | **Step → ∞**: eigenvalues scale linearly with `step`; finite‑precision eigen‑decomposition becomes ill‑conditioned (`cond ≈ |step|·κ(A)`); **Step → 0**: degenerates to identity → loss of curvature information; subnormals in `double` are flushed on consumer GPUs (e.g., RTX 4090). | **Partial** – relies on **cuSOLVER** (NVIDIA‑only) and **CUDA Graphs** – no AMD alternative in the same source tree. |
| **kernel_xla_v1350.py** | Lyapunov continuous‑time solve (FP64) on TPUs / Trainium | `jax.jit → XLA HLO → solve_cont_lyap` | **Step → ∞**: Lyapunov matrix `A(step)` may become non‑stable; condition number grows ∝ |step|; XLA may saturate to `inf` for eigenvalues > 2⁵³; **Step → 0**: matrix collapses to zero → trivial solution but may trigger *divide‑by‑zero* in the HLO that assumes invertible `A`. | **Yes** – the kernel uses **JAX/XLA** compiled exclusively for **Google Cloud TPU** or **AWS Trainium**; no fallback for generic CPUs or other accelerators. |
| **kernel_triton_v1350.py** | Coalescent SRAM tiling & Clifford bivector rotation (ROCm & CUDA) | `triton.kernel → tile → rotate` | **Step → ∞**: rotation angles scale with `step`; loss of orthogonality due to limited 16‑bit mantissa in triton’s half‑precision path (even though kernel forces FP64, intermediate reduction may be promoted to half for speed). **Step → 0**: zero‑angle rotation yields identity; but triton’s compile‑time constant folding may eliminate the kernel, breaking the “always‑run” invariant required for security audits. | **Partial** – Triton kernels are compiled for **both** ROCm and CUDA, but the **host‑side Python** selects the runtime based on `torch.cuda.is_available()`. This *hard‑codes* NVIDIA as primary; a ROCm‑only environment would need an explicit flag. |

> **Bottom‑line:** 3 of the 6 kernels obey **Rule 22** and **Rule 27** strictly; the remaining three exhibit either *vendor‑lock* (CUDA‑only/TPU‑only) or *potential protocol violations* that must be mitigated.

---

## 2. Detailed Component Audits  

### 2.1. `kernel_orchestrator_v1350.py`  

**2.1.1. Numerical Degeneracy**  

- The descriptor format (`<4sHHQQQQQBB6x4Q`) packs the following fields:  

| Offset (bytes) | Type | Semantic |
|----------------|------|----------|
| 0‑3            | `4s` | Magic string (always `"PMTP"`). |
| 4‑5            | `H`  | Version (uint16). |
| 6‑7            | `H`  | Flags (bitmask). |
| 8‑15           | `Q`  | `step` (uint64). |
| 16‑23          | `Q`  | `scale` (uint64). |
| 24‑31          | `Q`  | `tensor_ptr` (addr). |
| 32‑39          | `Q`  | `allocator_id`. |
| 40‑47          | `Q`  | `checksum`. |
| 48‑49          | `B`  | `status`. |
| 50‑51          | `B`  | `error_code`. |
| 52‑57          | `6x` | Reserved padding. |
| 58‑73          | `4Q` | Additional payload (4×uint64). |

- **Step → ∞**: stored as `uint64`; overflow occurs when `step > 2⁶⁴‑1`. In Python the conversion `int(step) & ((1<<64)-1)` silently wraps, violating **Rule 22** (zero‑token rule) because the checksum field (computed from the raw bytes) will no longer match.  
  - **Proof Sketch:** The checksum is `crc64(descriptor_bytes)`. Wrapping changes the lower 64 bits, thus `checksum' = crc64(wrapped_bytes) ≠ checksum` unless the wrap is *exact* (probability 2⁻⁶⁴).  

- **Step → 0 (subnormals):** The descriptor holds `step` as an integer, so subnormal floating‑point numbers are never represented. However downstream kernels read the descriptor and cast the integer to `double`. For `step = 0`, the conversion is exact, but if any *floating‑point* field (e.g., `scale`) is encoded via subnormal `double`, Python’s struct.pack will raise `OverflowError` unless `float.fromhex` is used, which the current code does **not** perform.  

**Recommendation:**  
1. Enforce *saturation* before packing: `if step > MAX_UINT64: raise ValueError`.  
2. Add an explicit *subnormal guard* for the `scale` field: `if 0 < abs(scale) < 2⁻¹⁰⁴: scale = 0.0`.  

**2.1.2. Rule 22 Compliance**  

- “Zero 1D tokens in inter‑agent communication” demands that **no field may be all‑zero** unless the token is explicitly marked `status = 0xFF`.  
- The orchestrator currently sets `status = 0` for a *healthy* descriptor, violating the rule when **all payload fields** happen to be zero (e.g., after a reset).  

**Mitigation:**  
```python
if all(payload[i] == 0 for i in range(4)):
    descriptor["status"] = 0xFF  # token‑enabled zero‑payload flag
```

**2.1.3. Rule 27 – Silicon Contract**  

- The Python component imports `pmtp_slabs` via a `ctypes` wrapper that links against **libpmtp.so** shipped only for **x86_64‑Linux**.  
- No alternative implementation exists for ARM or RISC‑V.  

**Hardening Recommendation:**  
- Provide a pure‑Python reference implementation (`pmtp_slabs_py`) that mimics the allocation strategy (first‑fit on a `bytearray`).  
- Ship the C library under a permissive BSD‑3 license to permit re‑compilation on other ISAs.  

**2.1.4. FFI Hardening**  

| Issue | Current Code | Fix |
|-------|--------------|-----|
| Buffer overflow when reading raw descriptor | `ctypes.create_string_buffer(88)` then `memcpy(dst, src, 88)` | Validate `len(src) >= 88` before copy; raise `ValueError` otherwise. |
| Unaligned pointer dereference (`tensor_ptr`) on non‑x86 | Direct cast to `uintptr_t` | Use `ctypes.c_void_p` with `ctypes.alignment` check; abort if `tensor_ptr % 8 != 0`. |
| Lack of *canary* for descriptor corruption | No canary field | Insert a 64‑bit canary (`0xDEADBEEFDEADBEEF`) after the checksum and verify it on read. |

---

### 2.2. `kernel_cpp_v1350.cpp`  

**2.2.1. Numerical Degeneracy**  

| Operation | Condition Number (asymptotic) | Extreme‑Step Behaviour |
|----------|-------------------------------|------------------------|
| **Neumaier dot** `s = Σ (x_i*y_i)` | `cond ≈ 1 + Σ|x_i*y_i|/|s|` (relative to cancellation) | When `|step| → ∞`, each term may overflow (`|x_i*y_i| ≈ |step|²·|base|²`); `