# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 67)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 67 · Six-Component Adversarial Review

**Presiding note.** The Tribunal treats each target as a *claim of correctness* under adversarial step regimes, cross-language FFI, and heterogeneous silicon. We do not accept "it compiles" as evidence. We demand: (i) a numerical-stability certificate, (ii) a byte-layout certificate, (iii) a vendor-neutrality certificate, (iv) an FFI-safety certificate. Where the artifact is not in front of us, we audit the *specification as stated* and flag every place where the spec is under-determined — because under-determination is where SOTA architectures die.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout `<4sHHQQQQQBB6x4Q`

Let us decode byte-by-byte under CPython `struct` with native alignment disabled (`<` = little-endian, standard sizes, no padding):

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version_major | `H` | 2 | 4 |
| version_minor | `H` | 2 | 6 |
| flags | `Q` | 8 | 8 |
| n_rows | `Q` | 8 | 16 |
| n_cols | `Q` | 8 | 24 |
| stride | `Q` | 8 | 32 |
| dtype_code | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| pad_a | `B` | 1 | 49 |
| pad_b | `6x` | 6 | 50 |
| reserved | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Certificate:** 4+2+2+8+8+8+8+8+1+1+6+32 = **88 bytes**. ✅ Rule 22 byte-count satisfied.

**Adversarial finding A1.1 — endianness asymmetry.** The `<` prefix forces little-endian on the wire. If the orchestrator ever ships this descriptor to a big-endian host (IBM POWER, some s390x CI runners), the receiver must byte-swap. The spec does not state a canonical network order. **Recommendation:** declare the descriptor *wire format* as little-endian by fiat and add a `magic` check that rejects byte-swapped input (`b'PDM1'` vs `b'1MDP'`).

**Adversarial finding A1.2 — `4s` magic is only 32 bits.** Birthday collision probability across a fleet of ~10⁶ distinct tensor kinds is ~10⁻⁷ — acceptable, but the `version_major/minor` fields are the real discriminator. Ensure the parser rejects `version_major > CURRENT` rather than silently truncating.

**Adversarial finding A1.3 — `12/12 physical conformance checks` is an unverifiable claim.** The Tribunal demands the *list* of the 12 checks. A conformance suite that is not enumerated is not a suite. Minimum acceptable set:
1. `sizeof(descriptor) == 88`
2. `offsetof` of each field matches table above
3. magic round-trip
4. version monotonicity
5. `n_rows * n_cols * dtype_size` does not overflow `Q`
6. `stride >= n_cols * dtype_size` (no aliasing)
7. `rank <= 8` (if rank is a tensor-order field)
8. reserved bytes are zero on emit
9. reserved bytes are ignored on parse
10. alignment of the *payload* pointer is 64 B (AVX-512) or 128 B (cache line)
11. descriptor is trivially copyable (`memcpy`-safe)
12. descriptor is hashable for dedup

**Adversarial finding A1.4 — `PmtpSlabAllocator`.** No size class is specified. If slabs are power-of-two, internal fragmentation is ≤ 50 %; if they are Fibonacci or buddy, different. The Tribunal requires the *fragmentation bound* as a function of allocation size distribution. Without it, "slab allocator" is a word, not a guarantee.

**Adversarial finding A1.5 — `HardwareProbe` multi-silicon.** Probing must be *idempotent* and *side-effect-free*. If the probe opens CUDA contexts or ROCm handles, it violates Rule 27 (see §3). Probe must use `cudaDeviceGetAttribute` / `hipDeviceGetAttribute` / `sysfs` reads only, never `cudaSetDevice`.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:

```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
    else:                c += (x_i*y_i - t) + s
    s = t
return s + c
```

**Error bound (standard result):** for `n` terms with unit roundoff `u = 2⁻⁵³` (FP64),

$$|\hat{s} - s| \le (2u + O(nu^2)) \sum_i |x_i y_i|$$

i.e. the *relative* error is bounded by `2u · κ`, where `κ = Σ|x_i y_i| / |Σ x_i y_i|` is the **condition number of the dot product**. This is the correct asymptotic statement: Neumaier does **not** beat the condition number; it removes the `n·u` growth. ✅

### 2.2 Adversarial finding A2.1 — `step → ∞` degeneracy

If `step ≥ 10¹⁰` and the kernel computes `step · B` before a Woodbury solve (see Target 4), the product can overflow FP64 (`DBL_MAX ≈ 1.8e308`) only if `B` is itself ~10²⁹⁸ — unlikely. The real degeneracy is **catastrophic cancellation in the Cayley retraction**:

$$Y = (I - \tfrac{s}{2}A)^{-1}(I + \tfrac{s}{2}A)X$$

As `s → ∞`, `(I - sA/2)⁻¹ → 0` and `(I + sA/2) → ∞`; the product is `-X + O(1/s)`. In floating point, `(I + sA/2)` overflows when `s·‖A‖ > 2·DBL_MAX`. **Certificate required:** the kernel must clamp `s` to `s_max = 2·DBL_MAX / ‖A‖_F` and document the clamp. Without it, `step ≥ 10¹⁰` with `‖A‖ ~ 10³⁰⁰` produces `inf · 0 = NaN`.

### 2.3 Adversarial finding A2.2 — subnormal audits at `-12, -14`

The notation `(-12, -14)` presumably means *exponents*: `2⁻¹²` and `2⁻¹⁴`? Or *decimal* `1e-12`, `1e-14`? The Tribunal flags this as **ambiguous**. If the audit is "does the kernel produce correct results when inputs are subnormal (`< 2⁻¹⁰²²` in FP64)", then:

- AVX-512 `vfmadd` on subnormals is **not** guaranteed to be fast; on some Intel parts it traps to microcode (100× slowdown). The audit must measure *throughput*, not just correctness.
- Neumaier's compensation term `c` can itself become subnormal and lose bits. The bound above assumes `c` is representable; if `c < 2⁻¹⁰²²`, the compensation is silently flushed.

**Recommendation:** add an explicit `FTZ/DAZ` policy declaration. If the kernel sets `MXCSR.FTZ = 1`, the Neumaier bound is **void** and must be replaced by the naive bound `n·u·Σ|x_i y_i|`.

### 2.4 Adversarial finding A2.3 — zero-copy PMTP validation

"Zero-copy" means the kernel reads the 88-byte descriptor and the payload from the same buffer without an intermediate `memcpy`. The validation must check:
- descriptor is at offset 0 of the buffer,
- payload starts at offset 88 (or at a declared offset),
- payload alignment ≥ 64 B,
- buffer is pinned (for DMA) or in unified memory.

If any of these fail, "zero-copy" is a lie. **Demand:** a `static_assert(offsetof(PmtpDescriptor, reserved) + 32 == 88)` and a runtime `assert((uintptr_t)payload % 64 == 0)`.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the single most dangerous claim in the entire audit.** `panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is `extern "C-unwind"` (stabilized in Rust 1.71) and the C++ side is compiled with `-fexceptions` and matching personality routines. The default `extern "C"` boundary **aborts** on unwind (since Rust 1.81, `extern "C"` is `nounwind` by default).

**Certificate required:** every `extern "C"` function in this file must be annotated `extern "C-unwind"` **and** the C++ caller must be compiled with `-fexceptions`. Otherwise, the "safety barrier" is a **soundness hole**.

**Recommendation (concrete FFI hardening):**
```rust
#[no_mangle]
pub extern "C-unwind" fn poly_dim_kernel_v1350(
    desc: *const PmtpTensorDescriptor,
    out: *mut f64,
) -> i32 {
    let result = std::panic::catch_unwind(|| { /* ... */ });
    match result {
        Ok(Ok(())) => 0,
        Ok(Err(e)) => e.code(),
        Err(_)     => -1,  // panic caught, converted to error code
    }
}
```
This converts every panic into an error code **before** it crosses the boundary. The `C-unwind` annotation is then belt-and-suspenders.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

```rust
#[repr(C, packed)]
pub struct PmtpTensorDescriptor {
    pub magic: [u8; 4],
    pub version_major: u16,
    pub version_minor: u16,
    pub flags: u64,
    pub n_rows: u64,
    pub n_cols: u64,
    pub stride: u64,
    pub dtype_code: u64,
    pub rank: u8,
    pub pad_a: u8,
    pub pad_b: [u8; 6],
    pub