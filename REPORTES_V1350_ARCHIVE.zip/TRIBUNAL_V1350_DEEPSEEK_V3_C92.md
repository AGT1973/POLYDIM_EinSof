# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 92)

# POLYDIM V1350 — High Tribunal Audit, Cycle 92

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods.

**Verdict posture:** The architecture is *plausible but not yet provably safe*. Six findings of severity ≥ MEDIUM, two of severity HIGH, one CRITICAL. Details below, per target, then cross-cutting.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Binary descriptor `<4sHHQQQQQBB6x4Q`

Let me lay out the layout explicitly:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version_major | `H` | 2 | 4 |
| version_minor | `H` | 2 | 6 |
| flags | `Q` | 8 | 8 |
| n_rows | `Q` | 8 | 16 |
| n_cols | `Q` | 8 | 24 |
| stride | `Q` | 8 | 32 |
| dtype_code | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| ndim | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| aux[4] | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Finding T1-A (LOW):** `struct.calcsize("<4sHHQQQQQBB6x4Q")` = 88 only under **native alignment = 1** for the `Q` fields. Python's `struct` with `<` prefix forces standard size, no alignment — so 88 is correct. **But** the C++/Rust/CUDA mirrors must use `#pragma pack(1)` / `#[repr(C, packed)]` / `__attribute__((packed))`. If any mirror uses natural alignment, `Q` at offset 8 is fine, but `4Q` at offset 56 is fine too — however the *total* would round to 88 only if the struct's alignment is 8. **Recommendation:** add a static_assert in C++ (`static_assert(sizeof(PmtpDescriptor)==88)`), a `const _: () = assert!(size_of::<PmtpDescriptor>()==88);` in Rust, and a `_Static_assert` in CUDA. This is the only way to guarantee Rule 22 compliance across FFI.

### 1.2 HardwareProbe multi-silicon

**Finding T1-B (MEDIUM):** The probe must not branch on vendor string at *runtime dispatch* in a way that changes the *descriptor semantics*. If `dtype_code` is reinterpreted per-vendor (e.g., `0x01` = FP32 on NVIDIA but FP32x2 on AMD), Rule 27 is violated in spirit. **Demand:** a canonical `dtype_code` table in a shared header, hashed into the magic.

### 1.3 PmtpSlabAllocator

**Finding T1-C (HIGH):** Slab allocators with 88-byte objects and 64-byte cache lines produce **1.375 objects/line** — i.e., 37.5% of cache lines straddle two descriptors. Under concurrent `HardwareProbe` writes this is a false-sharing hazard. **Proof sketch:** Let object size `s=88`, line `L=64`. Number of lines touched per object = `⌈(s + (o mod L))/L⌉` where `o` is offset. For `o ≡ 0 (mod 64)`, object spans lines `[o/64, (o+87)/64]` = 2 lines. Fraction of offsets causing 2-line span = `(88-64)/88 = 27.3%`. **Recommendation:** pad to 128 bytes for the *allocator* while keeping the *wire format* at 88. Two distinct structs, one `#[repr(C, packed)]` for wire, one `#[repr(C, align(64))]` for slab.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant:
```
sum = 0; c = 0
for x,y:
    t = sum + x*y
    if |sum| >= |x*y|: c += (sum - t) + x*y
    else:              c += (x*y - t) + sum
    sum = t
return sum + c
```

**Finding T2-A (MEDIUM):** Neumaier is **not** correctly rounded and its error bound is `|E| ≤ (n-1)u · Σ|x_i y_i| + O(u²)` where `u = 2^-53`. For `n = 10^6` and `Σ|x_i y_i| ~ 10^6`, error ~ `10^6 · 10^-16 · 10^6 = 10^-4`. **This is fine for FP64 accumulation but not for the subnormal audit at -12/-14.** Subnormals have `u_sub = 2^-1074`; Neumaier's compensation term `c` can itself underflow to zero, silently losing the correction. **Demand:** a `-ffast-math`-free build, and an explicit `std::fenv` check that `FE_UNDERFLOW` is not raised during the compensation step.

### 2.2 Subnormal audits at -12, -14

**Finding T2-B (HIGH):** If `-12` and `-14` refer to *exponents* (i.e., `2^-12`, `2^-14`), these are **normal** in FP64 (min normal exponent is `-1022`). If they refer to *decimal* magnitudes (`1e-12`, `1e-14`), they are also normal. **The audit is therefore vacuous unless the inputs are scaled.** **Demand:** clarify whether the audit is on the *result* of a dot product whose inputs are `~1e-12`, in which case the *product* `1e-24` is still normal but the *sum* may lose precision. Provide the actual test vectors.

### 2.3 Zero-copy PMTP validation

**Finding T2-C (CRITICAL):** "Zero-copy" + "validation" is a contradiction unless validation is done on a *sealed* descriptor. If the C++ core reads the 88-byte descriptor from shared memory and then dereferences `aux[0]` as a pointer, a TOCTOU race exists between `HardwareProbe` and the kernel. **Proof:** Let `D` be the descriptor in shared memory. Thread A validates `D.aux[0]` is a valid pointer, then yields. Thread B overwrites `D.aux[0]`. Thread A dereferences. **Mitigation:** copy the 88 bytes into a stack-local `PmtpDescriptor` with `std::atomic_thread_fence(std::memory_order_acquire)` before validation, then validate the *copy*. This is the only sound zero-copy pattern.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI barrier

**Finding T3-A (HIGH):** `panic=unwind` across an FFI boundary is **UB** unless every `extern "C"` function is wrapped in `std::panic::catch_unwind`. Rust 2021 does not do this automatically. **Demand:** every FFI entry point must be:
```rust
#[no_mangle]
pub extern "C" fn pmtp_kernel(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1,
    }
}
```
And the C++ side must treat `-1` as a hard abort, not a retry.

### 3.2 Packed 88-byte descriptor

**Finding T3-B (MEDIUM):** `#[repr(C, packed)]` on a struct containing `u64` fields causes **unaligned loads** on every field access. On x86 this is a perf hit; on ARM (Trainium host) it is a **SIGBUS**. **Demand:** use `#[repr(C)]` with explicit `#[repr(align(8))]` and a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`. If the wire format must be 88 bytes, serialize/deserialize via `to_le_bytes()` on a `[u8; 88]` buffer, not via `transmute`.

### 3.3 Safe SIMD

**Finding T3-C (LOW):** `std::simd` is still nightly. If the crate uses `core::arch::x86_64::_mm512_*`, it is `unsafe`. The "Safe SIMD" claim is therefore aspirational. **Demand:** document the `unsafe` blocks and their invariants.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction

Cayley: `Y = (I - (α/2) A)^{-1} (I + (α/2) A) X` where `A = G X^T - X G^T` is skew-symmetric.

**Finding T4-A (MEDIUM):** The `cuSOLVER DnDsyevd` call is for **symmetric** eigenproblems. `A` is skew-symmetric, so its eigenvalues are purely imaginary. `DnDsyevd` will **not** work on `A`. You need `DnDsyevd` on `iA` (Hermitian) or `DnDsyevd` on `A^T A` (symmetric, but squares the condition number). **Demand:** clarify. If the intent is `expm(A)` via `DnDsyevd` on `iA`, the condition number of the eigenvector matrix is `κ(V)`, and the retraction error is `O(κ(V) · u)`.

### 4.2 Globally scaled Woodbury solve

`(M/scale) W = (step/scale) B` → `W = M^{-1} B · step`. The scaling cancels. **Finding T4-B (LOW):** The scaling is a no-op algebraically but a **conditioning** improvement if `M` has a large norm. **Proof:** `κ(M/scale) = κ(M)`. So the scaling does **not** improve conditioning. It only prevents overflow in the intermediate `M W`. **Demand:** state the actual purpose (overflow prevention, not conditioning).

### 4.3 CUDA Graphs

**Finding T4-C (MEDIUM):** CUDA Graphs capture a fixed DAG. If `step` changes between iterations, the graph must be re-captured or the step must be a device-side scalar. **Demand:** confirm `step` is passed as a kernel argument, not baked into the graph.

### 4.4 `step → ∞` degeneracy

**Finding T4-D (HIGH):** For `|step| ≥ 10^10