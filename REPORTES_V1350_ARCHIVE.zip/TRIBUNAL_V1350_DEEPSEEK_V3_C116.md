# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 116)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 116 · Six-Component Adversarial SOTA Review

**Presiding note.** The Tribunal treats each target as a *claim* to be falsified. Where the submission asserts "12/12 physical conformance," "Neumaier compensated," "Stiefel Cayley," "continuous Lyapunov," or "coalescent SRAM tiling," we demand the invariant that makes the claim true, the regime where it breaks, and the FFI/ABI surface that can be attacked. We do not accept "SOTA" as a proof.

---

## 0. Cross-cutting invariants (apply to all six targets)

Let the PMTP descriptor be the 88-byte packed record

```
struct PmtpTensorDescriptor {           // 88 bytes, 8-byte aligned
    char     magic[4];                  // "<4s"
    uint16_t version;                   // "H"
    uint16_t flags;                     // "H"
    uint64_t n_elem;                    // "Q"
    uint64_t stride0;                   // "Q"
    uint64_t stride1;                   // "Q"
    uint64_t data_ptr;                  // "Q"
    uint64_t aux_ptr;                   // "Q"
    uint8_t  dtype;                     // "B"
    uint8_t  rank;                      // "B"
    uint8_t  _pad[6];                   // "6x"
    uint64_t shape[4];                  // "4Q"
};                                      // 4+2+2+8*5+1+1+6+8*4 = 88
```

**Tribunal finding 0.1 (Rule 22 compliance — structural).** The format string `<4sHHQQQQQBB6x4Q` yields exactly 88 bytes *only if* the compiler honors `#pragma pack(1)` or the struct is emitted via `struct.pack`/`bytemuck::Pod`. In C++20 the natural alignment of `uint64_t` forces 8-byte padding; without `alignas(1)`/`__attribute__((packed))` the struct is **96 bytes** on x86-64 SysV and **104 bytes** on some AArch64 ABIs. **This is a Rule 22 violation risk in TARGET 2 and TARGET 3 unless explicitly packed.** Demand: static_assert(sizeof(PmtpTensorDescriptor)==88) in C++, and `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` in Rust.

**Tribunal finding 0.2 (Rule 22 — semantic).** "Zero 1D tokens" means no component may emit a flat `[N]`-shaped tensor across the inter-agent bus. Every descriptor must carry `rank >= 2` and `shape[0]*shape[1] == n_elem` (or the rank-2 slice thereof). The 88-byte record *permits* rank=1; the orchestrator must reject it. **Demand:** a `validate_pmtp()` gate in TARGET 1 that returns `E_RANK1_FORBIDDEN` before any FFI dispatch.

**Tribunal finding 0.3 (Rule 27 — vendor lock).** Rule 27 forbids any component from *requiring* a single vendor's runtime to function. TARGET 4 (CUDA) and TARGET 5 (XLA/TPU) are the two at risk. The contract is satisfied **iff** each kernel exposes a pure-CPU fallback path selectable at runtime, and the descriptor's `flags` field encodes the backend without the orchestrator branching on vendor strings. We audit each below.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator

**Claim:** multi-silicon probe + slab allocator + 12/12 physical conformance.

**Tribunal analysis.**
- A "probe" that enumerates CPU/GPU/TPU/NPU must be *idempotent* and *side-effect free*. If it calls `torch.cuda.is_available()` or `jax.devices()` at import time, it violates Rule 27 (forces vendor import). **Demand:** lazy probe behind a capability token, cached in a `frozenset[str]` of abstract capabilities (`{"simd.avx512","simd.neon","accel.cuda","accel.rocm","accel.tpu"}`), never vendor names.
- **PmtpSlabAllocator:** slab of 88-byte descriptors. Alignment must be 64 B (cache line) to avoid false sharing across agent threads. If the slab is `bytearray(n*88)`, `struct.pack_into` is fine, but **`memoryview` slicing must be `cast('B')`** to avoid implicit copies. Demand: `assert slab_addr % 64 == 0`.

### 1.2 The 12/12 conformance checks

Without the checklist we can only state the *necessary* conditions. The Tribunal requires the following 12 to be present (and will reject any list that omits them):

1. `sizeof(desc) == 88` (all backends)
2. `alignof(desc) == 8` and slab base `% 64 == 0`
3. `magic == b"PMTP"` and `version == 1350`
4. `rank >= 2` (Rule 22)
5. `n_elem == prod(shape[:rank])`
6. `stride0 >= shape[1]` (no overlap) unless `flags & ALIAS_OK`
7. `data_ptr != 0` and `data_ptr % dtype_align == 0`
8. `dtype ∈ {f64, f32, bf16, i32, i64}` (no implicit upcast)
9. `flags & VENDOR_MASK` decodes to a *capability*, not a brand
10. Endianness tag matches host (or `flags & SWAP`)
11. `aux_ptr` is null or points to a valid 88-byte descriptor (recursive depth ≤ 1)
12. Checksum over bytes [0,80) matches `shape[3]` low 64 bits (tamper detection)

**Finding 1.1.** If check 12 is absent, the descriptor is forgeable across the FFI boundary — a hostile agent can craft an 88-byte blob with `data_ptr` pointing into kernel memory. **Severity: Critical.**

### 1.3 step → ∞ / step → 0 degeneracy

The orchestrator itself does not integrate, but it *routes* `step`. If it computes `step / scale` in Python floats before dispatch, `step = 1e10` with `scale = 1e-10` overflows to `inf` silently (Python float is IEEE-754 binary64, max ~1.8e308, so 1e20 is fine — but `step=1e300, scale=1e-300` → `inf`). **Demand:** orchestrator must pass `(step, scale)` as a *pair* to the kernel; never pre-divide. This is the single most important cross-target fix.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:

```
s = 0; c = 0;
for i: t = s + x[i]*y[i];
       if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i];
       else:                  c += (x[i]*y[i] - t) + s;
       s = t;
return s + c;
```

**Theorem 2.1 (error bound).** For `n` terms with `|x_i y_i| ≤ M`, Neumaier's sum satisfies
`|computed − exact| ≤ (2u + O(nu²)) · Σ|x_i y_i|`, where `u = 2⁻⁵³`.
This is *not* the same as Kahan's bound; Neumaier is unconditionally `O(u)` even when the running sum is smaller than a term (Kahan degrades to `O(nu)` there). **The claim "Neumaier compensated" is therefore correct only if the branch is implemented exactly as above.** A common bug: using `fabs(s) >= fabs(prod)` with `prod` recomputed — that recomputation is itself rounded and breaks the bound. Demand: `prod` must be a single `fma`-free product stored once.

**AVX-512 concern.** `_mm512_fmadd_pd` fuses the multiply-add, which *changes* the error model: FMA has a single rounding, so the compensation term `(s - t) + prod` becomes `(s - t) + (a*b)` where `a*b` is *not* separately rounded. The Neumaier bound still holds (FMA is *more* accurate), but the *implementation* must not mix FMA and non-FMA lanes. Demand: `#pragma omp simd` with `reduction(+:s,c)` is **incorrect** for Neumaier — the two accumulators are coupled. Use explicit lane-wise accumulators + a final tree reduction.

### 2.2 Subnormal audits at −12, −14

`-12` and `-14` are almost certainly *decimal exponents* (i.e., `1e-12`, `1e-14`). In binary64, subnormals begin at `2⁻¹⁰²² ≈ 2.2e-308`. So `1e-12` and `1e-14` are **normal**, not subnormal. **Finding 2.1:** the audit labels are misleading. If the intent is *denormal* testing, the probes must be at `~1e-308` and `~5e-324`. If the intent is *near-cancellation* testing (which is what `1e-12`/`1e-14` suggests), then the correct diagnostic is the **condition number** of the dot product:

```
κ = (Σ|x_i y_i|) / |Σ x_i y_i|
```

For `κ ≥ 1/u ≈ 9e15`, no compensated algorithm can recover the sign. Demand: the audit must report `κ` and refuse to certify when `κ > 1/(4u)`.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the C++ kernel to read the 88-byte descriptor *in place* from shared memory. **Finding 2.2:** if the descriptor is passed by value across the FFI, the ABI may copy it (and pad it to 96/104 bytes). Demand: pass `const PmtpTensorDescriptor*` and `static_assert(sizeof==88)`. Also demand `std::atomic_thread_fence(std::memory_order_acquire)` after reading `data_ptr` to prevent TOCTOU on the pointer.

### 2.4 step → ∞ / step → 0

If the C++ kernel computes `M/scale` with `scale → 0`, `M/scale → inf`. The Woodbury solve then produces `inf - inf = NaN`. **Demand:** clamp `scale ≥ 2⁻¹⁰