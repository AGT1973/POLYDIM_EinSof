# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 84

The requested **Cycle 84 arbitration cannot be validated as a factual comparison of six model reports** because no Claude, Qwen, Kimi, Gemini, DeepSeek, or Perplexity findings, kernel specifications, test logs, proofs, or benchmark artifacts were supplied. The public search evidence available here identifies **PolyDiM**, a PDE discretization library, not a “POLYDIM V1350” kernel suite or “PMTP 88-byte Descriptor.”[1][2] Accordingly, the guarantees below are the strongest defensible architectural synthesis—not a claim that the six tribunals reached these results.

## Arbitration verdict

### 1. Stiefel retraction under \(\lvert\mathrm{step}\rvert \ge 10^{10}\)

A **plain Cayley Stiefel retraction is not unconditionally stable** for extreme steps. For a point \(X\) on the Stiefel manifold,

\[
\mathrm{St}(n,p)=\{X\in\mathbb{R}^{n\times p}:X^\top X=I_p\},
\]

a typical Cayley update has the form

\[
X_{+}=\left(I-\frac{\alpha}{2}A\right)^{-1}
       \left(I+\frac{\alpha}{2}A\right)X,
\]

where \(A^\top=-A\). In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists. That does **not** imply numerical stability for arbitrarily large \(\alpha\). At \(\alpha\approx10^{10}\), the implementation is dominated by:

- conditioning of \(I-\frac{\alpha}{2}A\);
- overflow or underflow in forming scaled coefficients;
- loss of skew-symmetry from floating-point construction;
- inaccurate linear solves;
- failure of the tangent-space model itself for an excessively large step.

**Arbitration:** neither Cayley nor Householder/QR nor polar decomposition can honestly be guaranteed stable for unrestricted extreme steps in ordinary finite precision. The mathematically superior policy is:

1. represent the step through a bounded parameterization, such as
   \[
   \tau=\frac{\alpha}{1+\lvert\alpha\rvert},
   \]
   or use a trust-region/clipped step;
2. construct the skew operator with an explicitly enforced
   \[
   A\leftarrow\frac{A-A^\top}{2};
   \]
3. solve the Cayley system with a backward-stable method and residual certification;
4. measure
   \[
   r=\lVert X_{+}^{\top}X_{+}-I\rVert;
   \]
5. fall back to a rank-revealing Householder QR or polar orthogonalization if the residual, conditioning estimate, or solve status violates the contract.

Householder QR is generally the strongest **repair and canonicalization** primitive because it is backward stable and avoids explicit normal equations. Polar decomposition gives the nearest orthogonal factor in the Frobenius norm and is often the cleanest projection, but its implementation cost and conditioning behavior depend on the chosen algorithm. Cayley is preferable when a smooth, structure-preserving update is required—not as an unconditional extreme-step method.

The defensible guarantee is therefore:

\[
\boxed{
\text{For accepted updates, }X_{+}^{\top}X_{+}=I+E,\quad
\lVert E\rVert\le \varepsilon_{\mathrm{contract}},
}
\]

where \(\varepsilon_{\mathrm{contract}}\) is measured and enforced, not assumed. There is **no valid guarantee** of stable output for every \(\lvert\alpha\rvert\ge10^{10}\) without step control and fallback.

### 2. PMTP 88-byte descriptors and RCU/QSBR isolation

An 88-byte layout alone provides **no memory-ordering guarantee**. Descriptor size, alignment, cache-line placement, and padding are representation properties; RCU/QSBR correctness depends on the publication and reclamation protocol.

The minimum sound protocol is:

- writer fully initializes a new immutable descriptor;
- writer publishes its pointer with **release** semantics;
- reader loads the pointer with **acquire** semantics before dereferencing;
- reader enters and exits the QSBR read-side critical section according to the implementation’s documented protocol;
- reclamation occurs only after every pre-existing reader has passed a quiescent state;
- descriptor contents remain immutable after publication, or each mutable field uses its own atomic protocol.

Formally, for publication \(P\), reader acquisition \(A\), and initialization writes \(I\),

\[
I \;\mathsf{sb}\; P_{\mathrm{release}}
\;\mathsf{sw}\;
A_{\mathrm{acquire}}
\;\mathsf{hb}\;
\text{reader loads}.
\]

Here \(\mathsf{sb}\) denotes sequenced-before, \(\mathsf{sw}\) synchronizes-with, and \(\mathsf{hb}\) happens-before. This establishes visibility of initialization. It does **not**, by itself, establish safe reclamation. Reclamation additionally requires a QSBR grace-period proof.

**Arbitration:** acquire/release is sufficient for **publication visibility** when the pointer and protocol are correctly designed; it is not sufficient as a standalone claim for **snapshot isolation and lifetime safety**. Sequential consistency is unnecessary for the usual single-publication immutable-snapshot pattern, but relaxed operations are insufficient unless an independent protocol supplies the required ordering.

The strongest architectural guarantee should be stated as:

\[
\boxed{
\text{A reader observes one fully initialized immutable snapshot, and no snapshot is reclaimed}
}
\]

\[
\boxed{
\text{until all readers that could have observed it have reported quiescence.}
}
\]

For heterogeneous CUDA/XLA/Triton environments, host-language C++20/Rust atomics cannot automatically establish device-wide ordering. Device publication must use the target platform’s documented atomic and fence scopes, and host/device ownership transitions must include an explicit synchronization boundary. A host acquire does not substitute for a device-system-scope acquire.

The 88-byte descriptor should therefore be treated as an ABI container with explicitly specified:

- alignment;
- endian/layout rules;
- pointer or handle representation;
- atomic field widths;
- ownership state;
- publication sequence;
- reclamation domain;
- host/device visibility scope.

Without those fields and rules, “88-byte PMTP descriptor” is not a sufficient architectural specification.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single universal guarantee across these ecosystems is not supportable without a conformance matrix, reference semantics, generated-code tests, and hardware results. The systems have materially different execution and memory models:

- **C++20 and Rust** can express host-side atomic ownership and lifetime protocols, subject to their language memory models.
- **CUDA** adds scoped device atomics, asynchronous execution, stream ordering, and host/device synchronization requirements.
- **Triton** exposes GPU-oriented programming abstractions whose lowering and supported atomic/fence behavior must be verified for each target.
- **XLA** is compiler-driven and may legally fuse, reorder, replicate, or rematerialize operations unless the program uses supported ordering and aliasing constructs.

Thus, source-level similarity does not imply semantic equivalence. Conformance must be defined observationally:

\[
\forall e\in\mathcal{E},\quad
\mathrm{Obs}_{e}(K_{\mathrm{impl}})
\subseteq
\mathrm{Obs}(K_{\mathrm{spec}}),
\]

where \(\mathcal{E}\) is the supported environment set and \(\mathrm{Obs}\) includes numerical results, orthogonality residuals, publication visibility, reclamation safety, and permitted nondeterminism.

The correct SOTA architecture is a **portable semantic core plus backend-specific certified mechanisms**:

- one language-independent descriptor schema;
- one reference state machine for publication, acquisition, quiescence, and reclamation;
- one numerically specified manifold-update contract;
- backend adapters for CUDA, XLA, Triton, C++20, and Rust;
- differential tests against the reference implementation;
- litmus tests for acquire/release and grace-period behavior;
- numerical stress tests covering \(\lvert\mathrm{step}\rvert\ge10^{10}\);
- per-backend capability declarations rather than a blanket portability claim.

## Definitive guarantees

The strongest guarantees that can legitimately be claimed are conditional:

1. **Numerical manifold guarantee:** every committed update satisfies a measured orthogonality residual bound; extreme steps are clipped, rescaled, rejected, or repaired.
2. **Cayley guarantee:** Cayley preserves orthogonality in exact arithmetic and is structure-preserving when its solve is well-conditioned; it is not unconditionally stable for arbitrary extreme steps.
3. **Descriptor publication guarantee:** release publication plus acquire observation makes prior initialization visible to the reader.
4. **RCU/QSBR guarantee:** snapshot lifetime is safe only when reclamation waits for a complete grace period; acquire/release alone does not provide that guarantee.
5. **Cross-backend guarantee:** conformance exists only for explicitly tested backend/version/hardware tuples and only under a stated synchronization scope.
6. **ABI guarantee:** 88 bytes is guaranteed only after alignment, field offsets, atomic widths, ownership, and endian rules are frozen and verified.
7. **No-go claims:** no defensible evidence supports unconditional stability at \(\lvert\mathrm{step}\rvert\ge10^{10}\), unconditional RCU isolation from descriptor size alone, or universal CUDA/XLA/Triton/C++20/Rust equivalence without implementation artifacts and tests.

The resulting arbitration is therefore **conditional-contract SOTA**, not an unconditional “all six models unanimously prove the V1350 kernels.” The available evidence does not establish that the named V1350 artifacts or the six tribunal reports are publicly verifiable.[1][2]