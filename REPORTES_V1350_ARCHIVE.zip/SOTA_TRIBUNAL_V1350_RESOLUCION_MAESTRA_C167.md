# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 167

The requested arbitration **cannot be made definitively from the available evidence**: the eight model reports, the six kernel specifications, test vectors, and conformance logs were not provided, and the public search results do not establish an authoritative “POLYDIM V1350” specification. The only clearly related result is an unofficial GitHub document describing a low-rank Cayley–Sherman–Morrison–Woodbury Stiefel method; it does not validate the claimed six kernels, 88-byte descriptor, or Tribunal findings.[1]

## Provisional technical arbitration

### 1. Extreme-step Stiefel retraction

For a Stiefel point \(X\) satisfying \(X^{T}X=I\), a Cayley map of the form

\[
R_X(\xi)
=
\left(I-\frac{\tau}{2}W\right)^{-1}
\left(I+\frac{\tau}{2}W\right)X,
\qquad W^{T}=-W,
\]

has an important mathematical property: in exact arithmetic, the Cayley transform is orthogonal because \(W\) is skew-symmetric. Consequently,

\[
R_X(\xi)^T R_X(\xi)=I
\]

provided the linear solve is well-defined. The related public proposal uses a low-rank skew-symmetric construction and reduces the solve to a small \(2K\times 2K\) system.[1]

That does **not** imply unconditional stability for \(|\tau|\ge 10^{10}\). In floating-point arithmetic, the dominant issues are:

- loss of skew-symmetry during formation of \(W\);
- overflow or underflow in \(\tau W\);
- cancellation in \(I\pm \tau W/2\);
- ill-conditioned or poorly scaled low-rank solves;
- amplification of residuals when the implementation forms explicit inverses;
- inaccurate projection of the step into the tangent space.

The mathematically superior guarantee is therefore conditional:

\[
\|R^T R-I\|
\le
C\bigl(u\,\kappa_{\mathrm{solve}}+\delta_W+\delta_{\mathrm{proj}}\bigr),
\]

where \(u\) is machine unit roundoff, \(\delta_W\) is skew-symmetry error, \(\delta_{\mathrm{proj}}\) is tangent/projection error, and \(\kappa_{\mathrm{solve}}\) is the condition number of the structured solve.

**Arbitration:** choose **Cayley with structure-preserving, scaled solves** over Householder or polar-QR for the extreme-step regime if the objective is an orthogonality-preserving retraction without a full factorization. Do not claim stability merely from the Cayley formula. The implementation must:

- rescale \(\alpha W\) before forming the solve;
- enforce \(W\leftarrow (W-W^T)/2\);
- use QR, pivoted QR, or a backward-stable small solve—not an explicit inverse;
- compute residuals and orthogonality error;
- reject, damp, or renormalize steps when the residual budget is exceeded.

Householder QR is generally the strongest **generic orthogonalization fallback**. Polar iteration can be accurate but requires explicit convergence and conditioning controls. Thus the correct ranking is:

1. **Scaled structure-preserving Cayley** for a valid skew generator and extreme-step efficiency.
2. **Householder QR** as the robust fallback and reference implementation.
3. **Polar methods** when a nearest-orthogonal/polar factor is specifically required.

No unconditional guarantee is possible for arbitrary \(|\tau|\ge 10^{10}\).

### 2. PMTP 88-byte descriptor and RCU/QSBR

Acquire/release semantics can provide publication ordering, but they do not by themselves provide complete RCU or QSBR snapshot isolation.

A valid publication pattern requires:

1. The writer fully initializes the descriptor and all reachable immutable payload.
2. The writer publishes the descriptor pointer or generation with a **release** store.
3. Readers enter the read-side critical section before loading the publication point.
4. Readers load the publication point with **acquire** semantics.
5. Writers retire old objects only after every pre-existing reader has passed a quiescent state or an equivalent grace period.
6. Reclamation uses a safe lifetime mechanism; memory ordering alone does not prevent use-after-free.

The descriptor’s size—88 bytes—is architecturally irrelevant to the memory-ordering proof. If it crosses cache-line boundaries, false sharing and torn visibility may also matter, but alignment and atomicity must be specified separately. A non-atomic 88-byte copy cannot be assumed to be indivisible across CPUs, CUDA devices, or accelerators.

The strongest defensible guarantee is:

\[
\text{Acquire(read)} \;\;\text{observes}\;\;
\text{Release(publish)}
\Longrightarrow
\text{reader sees the writer's prior initialization}
\]

subject to the language and execution model. It does **not** imply that a reader sees a globally frozen snapshot unless the snapshot identity is itself immutable and reclamation is delayed through a grace period.

**Arbitration:** accept acquire/release for publication and generation validation, but require explicit RCU/QSBR epoch or hazard-pointer rules for reclamation. The architectural contract should state:

- descriptor fields used for publication are atomic or protected by an atomic publication word;
- payload reachable after publication is immutable;
- readers hold a read-side token/epoch;
- reclamation occurs only after a completed grace period;
- ABA is prevented with generations, tagged pointers, or epoch-qualified identities;
- descriptor layout, alignment, endian representation, and ownership are fixed.

### 3. CUDA, XLA, Triton, C++20, and Rust

A single unconditional conformance claim across these environments is not justified. They have different execution and memory models:

- **C++20** provides a language memory model for host code, not a universal device-memory model.
- **Rust** provides strong type and aliasing guarantees, but unsafe foreign-function interfaces and device code can invalidate higher-level assumptions.
- **CUDA** has scoped atomics and synchronization domains whose guarantees depend on scope and memory space.
- **Triton** exposes program-instance and accelerator memory semantics, not C++20’s full abstract machine.
- **XLA** is compiler- and backend-mediated; operation ordering and aliasing must be expressed through its supported IR and synchronization mechanisms.

Therefore, “conformance” must be decomposed into separate contracts:

| Property | Required guarantee |
|---|---|
| Numerical | Same specified result within an explicit tolerance and condition-dependent error bound |
| Layout | Identical field offsets, alignment, size, endian convention, and ABI ownership |
| Publication | Backend-appropriate release/acquire or equivalent ordering |
| Lifetime | No reclamation before the backend’s grace-period/read-completion rule |
| Synchronization | Explicit stream, event, barrier, or collective dependencies |
| Determinism | Defined reduction order or an allowed nondeterministic tolerance |
| Failure behavior | Identical validation, overflow, timeout, and fallback policy |

**Arbitration:** claim *portable semantic conformance*, not identical implementation semantics. The reference should be a C++20/Rust host specification plus backend-specific adapters and litmus tests. CUDA and Triton kernels should be validated against the reference using randomized adversarial tests; XLA should be validated at the graph/IR level rather than by assuming host-style memory ordering.

## Definitive synthesis

The strongest defensible V1350 architecture is:

1. **Numerical core:** scaled, skew-symmetrized Cayley–SMW retraction with residual checks and Householder-QR fallback.
2. **Extreme-step policy:** no unconditional acceptance of \(|\text{step}|\ge 10^{10}\); use scaling, compensated formation, residual validation, and a bounded fallback policy.
3. **Descriptor protocol:** release publication plus acquire observation, immutable post-publication payload, epoch/QSBR-protected reclamation, and generation-based ABA prevention.
4. **ABI:** formally specified 88-byte layout with compile-time size/offset assertions in C++20 and Rust, plus backend-specific layout tests.
5. **Cross-silicon contract:** define observable semantics—orthogonality residual, descriptor version consistency, lifetime safety, and permitted numerical tolerance—rather than pretending that all five platforms share one memory model.
6. **Guarantee level:**  
   - **Mathematical:** exact orthogonality only in exact arithmetic.  
   - **Numerical:** backward-stable behavior under stated conditioning and scaling bounds.  
   - **Concurrency:** publication visibility and reclamation safety only when the complete protocol is followed.  
   - **Portability:** semantic conformance only after backend-specific synchronization and ABI validation.

Accordingly, any Tribunal model claiming unconditional Cayley stability at arbitrary extreme steps, snapshot isolation from acquire/release alone, or automatic cross-platform conformance should be rejected as overstated. The available evidence supports a **conditional, testable architecture**, not the “exact architectural guarantees” requested.