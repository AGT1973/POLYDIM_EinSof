# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 131)

# POLYDIM V1350 – MULTI‑FILE ADVERSARIAL SOTA AUDIT  
**Cycle 131 – High Tribunal of Mathematical and Systems Sages**  

**Scope** – Exhaustive, PhD‑level audit of the six core source artefacts that constitute the POLYDIM V1350 stack.  
**Methodology** – For each component we (i) model the numerics mathematically, (ii) derive the asymptotic condition numbers of the dominant linear‑algebraic kernels, (iii) examine the behaviour for extreme step magnitudes (|step| ≫ 10¹⁰) and for sub‑normal regimes (|step| ≈ 2⁻¹⁰⁰), (iv) check conformance to **Rule 22** (zero‑length 1‑D tokens in all inter‑agent comms, 88‑byte PMTP descriptor) and **Rule 27** (Silicon‑Contract vendor‑lock), and (v) issue concrete FFI‑hardening recommendations together with mathematical proofs where feasible.  

---  

## 1. kernel_orchestrator_v1350.py  

### 1.1 Architecture & Data‑flow  

* **HardwareProbe** – probes up to *N* silicon islands, each exposing a **PMTP** (Physical‑Memory‑Tensor‑Pass) slab.  
* **PmtpSlabAllocator** – reserves a contiguous memory block described by the **88‑byte binary descriptor** with layout  

```
struct PmtpTensorDescriptor {
    uint64_t base_addr;          // 8
    uint64_t size_bytes;         // 8
    uint16_t elem_type;          // 2  (0=FP16,1=FP32,2=FP64)
    uint16_t rank;               // 2
    uint64_t dim[4];             // 32 (max rank 4)
    uint8_t  flags;              // 1
    uint8_t  pad[3];             // 3
    uint64_t uuid[2];            // 16
    uint32_t checksum;           // 4
    uint32_t reserved;           // 4
};
```

* **12/12 physical conformance checks** – enforce alignment, endianness, cache‑line size, NUMA locality, temperature, power budget, timing, etc.

### 1.2 Numerical Degeneracy  

The orchestrator does **not** perform arithmetic itself, but it *passes* the `step` scalar to downstream kernels. The only place where the magnitude of `step` can cause a *division‑by‑zero* or *overflow* is the **PMTP header generation** (e.g. when `step` is incorporated into a scaling factor for `size_bytes`).  

* **Lemma 1 (Descriptor overflow).** Let `S = size_bytes` be encoded as a 64‑bit unsigned integer. If `step` appears multiplicatively (e.g. `S = base * |step|`), then overflow occurs when  

\[
|step| > \frac{2^{64}-1}{\text{base}}.
\]

Because `base` is typically ≤ 2³², the overflow bound is ≈ 2³² ≈ 4.3 × 10⁹, far *below* the stipulated domain |step| ≥ 10¹⁰. Therefore **Rule 22 violation** can happen via descriptor overflow.  

* **Sub‑normal safeguard.** When `step` is inserted into a 64‑bit floating‑point field (e.g. for FP64 scaling), sub‑normal values (|step| < 2⁻¹⁰²) are representable but may be flushed to zero by the CPU if the *DAZ* (Denorm‑are‑Zero) mode is enabled. The orchestrator does not explicitly clear the DAZ flag, leaving the system dependent on the host’s default. This is a *potential degeneracy* for |step| → 0.

### 1.3 Rule 22 – Zero‑length 1‑D Tokens  

The orchestrator is the only place where a **token** is created for inter‑agent communication. The token definition in the spec: *“A token of dimension 1 must have zero length in the direction of communication; only the descriptor payload may be non‑zero.”*  

* **Verification** – The Python code builds a NumPy array of shape `(1,)` and then immediately discards it (`del token`). The `sizeof` of the payload is exactly 88 bytes, matching the descriptor size. No stray payload is attached. **Compliant**.

### 1.4 Rule 27 – Silicon‑Contract Vendor‑Lock  

*The orchestrator* is **vendor‑agnostic**: it discovers silicon islands via a generic *PCIe‑enumeration* interface (`pyudev`), and the `PmtpSlabAllocator` only assumes *byte‑addressable* memory and a *64‑bit address space*. No vendor‑specific IDs (e.g., AMD‐specific `vendor_id = 0x1002`) are hard‑coded. **No lock‑in**.

### 1.5 FFI Hardening Recommendations  

| Issue | Recommendation |
|-------|----------------|
| Descriptor overflow for large `step` | Clamp `step` to a safe range before forming descriptors, or use a 128‑bit integer (`np.uint128`) for intermediate calculations. |
| DAZ / FTZ modes for subnormals | Explicitly set the MXCSR control word to *clear* DAZ/FTZ before the orchestrator hands a descriptor to a downstream kernel (use `ctypes` to call `mm_setcsr`). |
| Token lifetime | Zero‑fill the token buffer before deletion (`token[:] = 0`) to avoid accidental leakage. |
| Cross‑process sharing | Insert a **checksum** verification on every receipt of a descriptor (already present, but enforce constant‑time compare). |

---  

## 2. kernel_cpp_v1350.cpp  

### 2.1 Core Numerical Kernels  

| Kernel | Algorithmic Description |
|--------|------------------------|
| **Neumaier compensated dot product** | Computes \(\sum_{i} a_i b_i\) with a single compensation term `c`. |
| **Subnormal audit** | Checks for values < 2⁻¹⁴ (‑14) and < 2⁻¹² (‑12) and flags them. |
| **Zero‑copy PMTP validation** | Directly maps the PMTP slab via `mmap` and verifies alignment. |

The code is compiled with **C++20**, targeting **AVX‑512** and **OpenMP** for thread‑level parallelism.

### 2.2 Degeneracy for |step| → ∞  

The `step` scalar is used as a **global scaling factor** in the dot‑product:

\[
y = \text{step} \;\cdot\; \sum_{i=1}^{n} a_i b_i .
\]

Define the *effective* dot‑product as \(d = \sum a_i b_i\).  

* **Theorem 1 (Overflow bound).** For IEEE‑754 double precision the product overflows when  

\[
|\text{step}| > \frac{2^{1024-1}}{|d|} \approx \frac{1.8\times10^{308}}{|d|}.
\]

Because typical `d` ≈ O(1‑10⁶) (depending on problem size), the safe `|step|` is ≈ 10³⁰⁰ – many orders of magnitude larger than 10¹⁰, so *no overflow* occurs in the prescribed domain.

* However, **catastrophic cancellation** can arise when `step` multiplies a *nearly zero* compensated sum (`c ≈ -d`). The compensated algorithm guarantees that the *relative* error is bounded by  

\[
\frac{|c|}{|d|} \;\le\; \epsilon_{\text{mach}} \bigl(1+ \mathcal{O}(n\epsilon_{\text{mach}})\bigr),
\]

but if `step` is *extremely large* the *absolute* error becomes  

\[
| \text{step} |\; |c| \;\approx\; |\text{step}|\,\epsilon_{\text{mach}} |d| .
\]

Thus the **absolute error grows linearly with |step|**, exposing a *degeneracy* for `|step| ≥ 10¹⁰` when `d` is of order 1.  

**Proof Sketch.** The compensated sum satisfies  

\[
\hat{d} = d + \delta,\qquad |\delta| \le \epsilon_{\text{mach}}(|d|+|c|) .
\]

Multiplying by `step` yields  

\[
\widehat{y}= \text{step}\,\hat{d} = \text{step}\,d + \text{step}\,\delta .
\]

Hence the relative error in the final result is  

\[
\frac{|\text{step}\,\delta|}{|\text{step}\,d|}= \frac{|\delta|}{|d|}\le \epsilon_{\text{mach}}\bigl(1+ \tfrac{|c|}{|d|}\bigr) .
\]

If `|c|/|d|≈1` (worst case), the bound becomes `2εmach`. ***But*** the **absolute** error is `|step|·|δ|`, which may dominate the downstream tolerance for large `|step|`.

**Conclusion** – *Numerical degeneracy* appears as **absolute‑error blow‑up**, not as overflow.

### 2.3 Degeneracy for |step| → 0 (Subnormals)  

When `step` is sub‑normal (`|step| < 2⁻¹⁴`), the multiplication under AVX‑512 may trigger **Denorm‑are‑Zero** (DAZ) mode implicitly if the system’s MXCSR has `DAZ=1`. The code does **not** set MXCSR, leaving the hardware to possibly **flush to zero**.  

* **Lemma 2 (Subnormal flattening).** If DAZ is on, any operand < 2⁻¹² (or the defined ‑12 threshold) is replaced by 0 before the multiplication. Hence `y` may be **exactly zero**, regardless of the dot‑product value. This violates numerical fidelity.  

Because the code explicitly *audits* for values `< 2⁻¹²` and `< 2⁻¹⁴` and simply **logs a warning**, there is no *mitigation* (e.g., scaling, Kahan‑style renormalisation).