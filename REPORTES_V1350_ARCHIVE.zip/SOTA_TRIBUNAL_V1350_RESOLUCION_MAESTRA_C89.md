# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 89

There is no publicly verifiable record in the available evidence of a **POLYDIM V1350** specification, “Cycle 89” tribunal transcript, or the six models’ actual findings. Therefore, no honest arbitration can attribute conclusions to Claude, Qwen, Kimi, Gemini, DeepSeek, or Perplexity individually. The following is a standards- and mathematics-based synthesis, with explicit limits on what can be guaranteed.

## 1. Stiefel retraction under extreme steps

For \(X\in\mathrm{St}(n,p)\), \(X^\top X=I_p\), and tangent update \(\Xi\), the standard polar and QR retractions are

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)\bigl(I_p+\Xi^\top\Xi\bigr)^{-1/2},
\]

and

\[
R_{\mathrm{QR}}(X,\Xi)=Q,\qquad X+\Xi=QR.
\]

Both produce a point on the Stiefel manifold in exact arithmetic, provided \(X+\Xi\) has full column rank. These are established alternatives to Cayley-based retractions.[1][3][6][9][13]

A Cayley update has the form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

where \(W^\top=-W\) and \(W\) is selected so that the first-order displacement agrees with \(\Xi\). The Cayley transform is orthogonal in exact arithmetic because

\[
\left[\left(I-\frac12W\right)^{-1}
\left(I+\frac12W\right)\right]^\top
\left[\left(I-\frac12W\right)^{-1}
\left(I+\frac12W\right)\right]
=I.
\]

However, this does **not** imply numerical stability for an unscaled step of magnitude \(10^{10}\).

### Arbitration

| Criterion | Cayley | Householder/QR | Polar |
|---|---:|---:|---:|
| Exact manifold preservation | Yes, if the linear solve is exact | Yes, if factorization succeeds | Yes, if inverse square root is exact |
| Extreme-step numerical robustness | Conditional | Generally strongest fallback | Strong, but conditioning-dependent |
| Avoids explicit large inverse | Yes, via a solve or low-rank formulation | Yes | Requires inverse square root or iterative equivalent |
| Sensitivity to overflow/underflow | High if \(W\) is formed naively | Lower with blocked, pivot-free Householder QR | High if \(X+\Xi\) is formed without scaling |
| Best production policy | Scaled/implicit only | Primary emergency fallback | Preferred when well-scaled |

The mathematically superior conclusion is therefore **not** “Cayley is unconditionally stable for \(|\mathrm{step}|\ge10^{10}\).” The defensible guarantee is:

1. Never form \(I\pm W/2\) or \(X+\Xi\) in an unscaled representation when the step can overflow or destroy relative accuracy.
2. Scale the update:
   \[
   \Xi=s\widehat{\Xi},\qquad
   s=\max(1,\|\Xi\|/\tau),
   \]
   and apply the transformation through a numerically stable solve or equivalent normalized representation.
3. Use Householder QR as the mandatory fallback when the scaled Cayley solve is ill-conditioned or fails.
4. Optionally use polar retraction when a high-quality closest-point projection is desired and the inverse square-root computation is backward stable.

Householder QR is not automatically perfect: a nearly rank-deficient \(X+\Xi\) remains problematic. But it is usually the most reliable **fallback factorization** because Householder transformations are backward stable and do not require the explicit normal-equation formation \((X+\Xi)^\top(X+\Xi)\). Polar retraction is geometrically attractive because it gives the Frobenius-nearest Stiefel factor, but it still requires a well-conditioned positive-definite Gram matrix or a robust SVD/eigendecomposition.

**Definitive kernel guarantee:** for finite, representable inputs and a successful stable factorization, return \(Y\) satisfying

\[
\|Y^\top Y-I\|
\le C\,u\,\kappa_{\mathrm{alg}},
\]

where \(u\) is machine unit roundoff and \(\kappa_{\mathrm{alg}}\) is the relevant conditioning factor. No floating-point implementation can guarantee exact orthogonality for arbitrary \(10^{10}\)-scale inputs, nor can it guarantee success when the update is nonrepresentable or rank deficient.

## 2. PMTP 88-byte descriptors and RCU/QSBR

An **88-byte size** is only a layout property. It does not itself establish atomicity, publication ordering, snapshot isolation, or portability. In particular, an 88-byte object is generally too large for a single naturally atomic machine-word operation, so publishing it by ordinary non-atomic whole-object assignment would create a data race or torn observation in C++20 and Rust.

The correct design is to publish an **immutable descriptor indirectly**:

```text
descriptor storage:
    immutable payload: 88 bytes
    publication field: atomic pointer, index, or generation token
```

The writer protocol is:

1. Construct the complete immutable descriptor in private storage.
2. Perform all payload writes.
3. Publish its pointer or version using **release** semantics.
4. Retire the old descriptor only after the reclamation protocol confirms that no reader can still reference it.

The reader protocol is:

1. Enter an RCU/QSBR read-side critical section.
2. Load the publication pointer or version with **acquire** semantics.
3. Read the immutable descriptor.
4. Exit the read-side critical section.

Acquire/release ordering establishes the essential visibility relation:

\[
\text{payload initialization}
\;\xrightarrow{\text{release publication}}\;
\text{acquire load}
\;\rightarrow\;
\text{payload reads}.
\]

But acquire/release alone does **not** provide reclamation safety. It does not prevent a writer from freeing an object while a reader is using it. That requires RCU grace periods, hazard pointers, epochs, or an equivalent QSBR protocol. Existing QSBR implementations likewise use release operations for state publication, but the memory-ordering operation is only one part of the reclamation algorithm.[14]

### Exact architectural guarantee

A conforming PMTP implementation may guarantee:

- No reader observes a partially initialized immutable descriptor.
- A reader observes one published descriptor instance for the duration of its protected read-side section.
- A retired descriptor is not reclaimed until every pre-existing reader has passed through a quiescent state.
- Publication is lock-free only if the selected atomic pointer/index operations and allocator satisfy that property.

It may **not** claim:

- that the 88-byte payload is atomically replaced as a unit;
- that acquire/release alone creates RCU;
- that QSBR protects readers who fail to register, fail to report quiescence, or access the object outside the read-side protocol;
- that arbitrary GPU memory operations inherit C++20 or Rust memory-model guarantees.

For C++20, the publication field should be a suitably aligned `std::atomic<T*>`, integer index, or versioned token. For Rust, the equivalent requires an explicitly justified atomic publication mechanism and a reclamation implementation whose ownership and lifetime rules are sound. The payload itself should be immutable after publication.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory model shared identically by these five environments. “Conformance” must therefore mean conformance to a specified abstract contract, not bit-for-bit identity of language, compiler, and accelerator semantics.

The portable contract should separate three layers:

- **Mathematical layer:** output belongs to the Stiefel manifold within a stated residual bound.
- **Publication layer:** descriptor publication and reclamation obey the defined acquire/release plus RCU/QSBR protocol.
- **Backend layer:** each implementation documents its supported dtypes, synchronization scopes, atomic widths, alignment requirements, and failure behavior.

### Backend-specific limits

- **C++20:** can express the host-side atomic publication and lifetime protocol, but only when all accesses participate in the C++ memory model.
- **Rust:** can enforce ownership and aliasing constraints, but unsafe code, atomics, FFI, and device memory still require an explicit proof.
- **CUDA:** host C++ atomics do not automatically govern device memory. Device publication requires CUDA-supported atomics and the correct thread/block/device/system synchronization scope.
- **Triton:** kernel execution and barriers must be expressed using Triton-supported operations; host-language acquire/release assumptions cannot simply be imported into a Triton kernel.
- **XLA:** compilation may reorder, fuse, replicate, or distribute operations according to its execution model. A custom call or explicit synchronization boundary is required when the descriptor protocol depends on side effects or a precise publication event.

Consequently, exact cross-backend conformance requires:

\[
\text{same input}
\Rightarrow
\begin{cases}
\|Y^\top Y-I\|\le \varepsilon_{\text{backend}},\\
\text{same descriptor version is observed within a protected snapshot},\\
\text{no reclamation before the corresponding grace period},\\
\text{specified behavior for overflow, rank deficiency, and unsupported atomics}.
\end{cases}
\]

The tolerances \(\varepsilon_{\text{backend}}\) cannot be identical by assertion; they must be specified by dtype, algorithm, and backend. Bitwise equality across CUDA, XLA, Triton, C++20, and Rust is not a mathematically meaningful default because reduction order, fused operations, compiler transformations, and hardware arithmetic differ.

## Definitive arbitration

The strongest defensible SOTA architecture is:

1. **Retraction:** use a scaled Cayley implementation when its solve is well-conditioned; otherwise fall back to Householder QR; use polar/SVD-based retraction where nearest-point quality is more important than minimum cost.
2. **Extreme steps:** define an explicit scaling, overflow, rank-deficiency, and failure policy. No unconditional stability claim is valid merely because the Cayley transform is orthogonal in exact arithmetic.
3. **Descriptor publication:** keep the 88-byte descriptor immutable and publish an atomic pointer/index/version, not the payload as one atomic object.
4. **Snapshot isolation:** require acquire on publication, release before publication, and a complete RCU/QSBR grace-period protocol for reclamation.
5. **Cross-silicon portability:** standardize the abstract contract and residual bounds, then implement backend-specific synchronization adapters. Do not equate C++20, Rust, CUDA, Triton, and XLA memory semantics.
6. **Guarantees:** promise bounded numerical residuals and protocol-level snapshot safety under stated preconditions—not exact arithmetic, universal lock-freedom, bitwise cross-backend identity, or safety outside the prescribed reader/writer protocol.