# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 113

The public evidence retrieved does **not** substantiate a real “POLYDIM V1350,” “PMTP 88-byte Descriptor,” Cycle 113 tribunal record, or the claimed six-model findings. The identifiable POLYDIM sources describe an open-source C++ library for polytopal discretization methods, not this architecture.[6][10] Therefore, no evidence-based arbitration can declare a definitive SOTA result for those six kernels.

That said, the technically defensible synthesis is:

## 1. Cayley–Stiefel retraction under \(\lvert\text{step}\rvert \ge 10^{10}\)

A Cayley update has the form

\[
Q_{+}
=
\left(I-\frac{\tau}{2}A\right)^{-1}
\left(I+\frac{\tau}{2}A\right)Q,
\qquad A^\mathsf{T}=-A.
\]

In exact arithmetic, the Cayley factor is orthogonal whenever the inverse exists. In floating-point arithmetic, however, **orthogonality does not imply numerical stability** for arbitrarily large \(\tau\).

The correct arbitration is:

- A Cayley retraction is **not unconditionally stable** for extreme steps.
- It can suffer from ill-conditioning, overflow in forming \(\tau A\), loss of significance, and failure when \(I-\frac{\tau}{2}A\) is poorly conditioned.
- Householder QR is generally the strongest default for robust orthogonalization because it avoids explicitly forming a potentially ill-conditioned normal-equation-like object and has well-understood backward stability.
- Polar retraction can provide excellent geometric fidelity, but its implementation must use a stable SVD or iterative polar algorithm; naïve eigendecomposition or matrix square-root implementations are not sufficient.
- For \(\lvert\tau\rvert\ge 10^{10}\), there is no universal guarantee without bounds on \(\|A\|\), scaling, precision, and conditioning.

The mathematically valid guarantee is conditional:

\[
\widehat Q^\mathsf{T}\widehat Q
=
I+E,
\qquad
\|E\|
\lesssim
\operatorname{poly}(n)\,u\,\kappa(\text{algorithm}),
\]

where \(u\) is unit roundoff. A claim of “stable for all extreme steps” is unjustified.

**Recommended architecture:** scale the skew generator, use a bounded effective step, reject or subdivide steps that exceed a conditioning threshold, and finish with Householder QR or a stable polar correction. The strongest practical contract is:

> The output is orthonormal to a stated tolerance when all intermediate operations remain finite and the conditioning monitor passes; otherwise the kernel returns a deterministic failure or invokes a fallback.

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

Acquire/release ordering is necessary but not sufficient to define snapshot isolation.

For an RCU-style publication path, the writer must:

1. Construct the complete immutable descriptor or snapshot.
2. Publish the pointer or version with a **release** operation.
3. Ensure reclamation occurs only after a valid grace-period protocol.

Readers must:

1. Enter the read-side critical section before obtaining the snapshot.
2. Load the published pointer/version with **acquire** semantics.
3. Dereference only immutable data associated with that acquired snapshot.
4. Exit the read-side critical section before reclamation can proceed.

The essential happens-before relation is

\[
\text{descriptor initialization}
\;\xrightarrow{\text{release publication}}\;
\text{reader acquire}
\;\xrightarrow{}\;
\text{descriptor reads}.
\]

For QSBR, acquire/release operations alone do **not** establish reclamation safety. The implementation additionally needs:

- correctly registered readers;
- explicit read-side state transitions;
- a writer-side grace-period algorithm;
- a proof that every reader active before publication has reported a quiescent state;
- protection against ABA and premature reuse;
- defined behavior for stalled or permanently inactive readers.

The 88-byte size is an ABI/layout property, not a memory-model guarantee. It must be specified independently:

- field offsets;
- alignment;
- endianness;
- atomic field widths;
- padding bytes;
- cache-line placement;
- language ABI;
- serialization representation.

A robust contract would state:

\[
\operatorname{sizeof}(\text{Descriptor})=88,
\qquad
\operatorname{alignof}(\text{Descriptor})=a,
\]

plus compile-time layout assertions and an explicit publication protocol. It should not claim that “88 bytes” itself provides isolation.

**Exact guarantee that can be defended:**

> A reader that enters the protected region before acquiring the root and uses an acquire load observes a fully initialized immutable snapshot published by a release operation; reclamation is permitted only after the grace-period protocol proves that no such reader can still hold a reference.

This is **RCU read-consistency**, not serializable transactions and not general multi-object snapshot isolation unless all objects are covered by one published root/version.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single unconditional conformance claim across these systems is not presently supportable. They have different execution and memory models:

- C++20 defines the host-language atomic model.
- Rust inherits platform/compiler guarantees through its atomic and synchronization abstractions.
- CUDA has device, block, system, and scoped memory-ordering mechanisms whose validity depends on address space and scope.
- Triton lowers through compiler-dependent GPU IR and does not automatically provide C++-style portable atomics for every pattern.
- XLA uses graph-level and compiler-level transformations; host-side C++ memory-order assumptions do not automatically transfer into an XLA computation.

Therefore, “conformant across all five” requires a **portable semantic subset**, not merely compiling the same source.

The portable subset should require:

- immutable snapshots after publication;
- one designated publication root;
- explicit version or epoch tagging;
- no unsynchronized mutation of descriptor fields;
- no reliance on implicit GPU global ordering;
- no pointer reclamation inside kernels unless the target runtime explicitly supports it;
- deterministic layout and endianness;
- backend-specific lowering tests;
- litmus tests for publication, stale reads, ABA, and reclamation;
- numerical tolerances defined independently of backend.

The strongest honest claim is:

> The algorithm is semantically portable across CUDA, XLA, Triton, C++20, and Rust only when each backend supplies an implementation of the same abstract operations—publish, acquire snapshot, enter/exit protection, quiesce, and reclaim—and passes the same conformance and numerical test suite.

That is weaker than bitwise identity. Floating-point results may legitimately differ because of fused operations, reduction order, precision modes, compiler reassociation, and GPU architecture.

## Arbitration of the alleged tribunal findings

Without the actual six reports, the proper arbitration rule is:

- Reject any conclusion asserting unconditional extreme-step Cayley stability.
- Reject any conclusion treating acquire/release as a complete RCU/QSBR reclamation proof.
- Reject any claim that descriptor byte size establishes memory safety or isolation.
- Reject any cross-backend “conformance” claim that lacks backend-specific memory-model mappings and litmus tests.
- Prefer Householder QR as the default orthogonalization fallback under extreme conditioning.
- Prefer release publication plus acquire consumption, combined with a separately proved grace-period protocol, for RCU/QSBR.
- Define portability as semantic equivalence under an explicit abstract machine, not identical implementation behavior.

## Definitive SOTA synthesis

The mathematically strongest defensible V1350 design would be:

1. **Geometry kernel:** scaled Cayley update only within a monitored conditioning region; otherwise adaptive step subdivision followed by Householder QR or stable polar correction.
2. **Snapshot kernel:** immutable versioned snapshots published through a release root pointer and consumed through acquire loads.
3. **Reclamation kernel:** epoch/QSBR grace periods with explicit reader registration, quiescent-state reporting, ABA protection, and delayed reuse.
4. **ABI kernel:** formally specified 88-byte layout with compile-time assertions, alignment rules, and serialization tests.
5. **Portability kernel:** a backend-neutral abstract memory protocol with separate CUDA, XLA, Triton, C++20, and Rust implementations.
6. **Verification kernel:** numerical conditioning tests, weak-memory litmus tests, differential backend tests, fault injection, and model checking of publication/reclamation histories.

The exact architectural guarantees should therefore be stated conditionally—not as universal claims:

\[
\boxed{
\begin{aligned}
&\text{Numerical: } \|\widehat Q^\mathsf{T}\widehat Q-I\|\le \varepsilon
\text{ when the conditioning contract passes};\\
&\text{Visibility: release publication happens-before acquire consumption};\\
&\text{Lifetime: reclamation occurs only after a completed grace period};\\
&\text{ABI: descriptor layout is exactly specified and verified};\\
&\text{Portability: each backend refines the same abstract semantics};\\
&\text{Failure: overflow, timeout, stalled readers, or failed conditioning are explicit outcomes.}
\end{aligned}
}
\]

Anything stronger would require the missing V1350 specification, the six tribunal reports, implementation artifacts, and reproducible cross-silicon test results.