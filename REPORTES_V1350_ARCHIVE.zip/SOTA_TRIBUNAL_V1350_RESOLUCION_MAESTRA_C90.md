# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 90

There is **no publicly verifiable record in the available material of a “POLYDIM V1350” specification, six Tribunal-model reports, or six defined V1350 kernels**. Therefore, a definitive arbitration of those model outputs—or exact architectural guarantees attributed to them—would be fabricated. The evidence does support a rigorous provisional synthesis based on established numerical-linear-algebra and memory-model principles.

## 1. Cayley–Stiefel retraction versus Householder/polar QR at \(|\mathrm{step}|\ge 10^{10}\)

A Cayley retraction updates a Stiefel point \(X\) through a transform of the form

\[
X_{+}=(I-\tfrac{\tau}{2}A)^{-1}(I+\tfrac{\tau}{2}A)X,
\qquad A^{\mathsf T}=-A.
\]

In exact arithmetic, the Cayley factor is orthogonal whenever the inverse exists. That does **not** imply numerical stability for an extreme step. As \(\tau\) grows, the solve can become poorly scaled, overflow can occur in forming \(\tau A\), and the result becomes highly sensitive to finite precision, especially when \(A\) is formed explicitly or the solve is unpivoted.

Householder QR is generally the safest **orthogonalization primitive** for rank-revealing, backward-stable computation. Polar retraction is attractive because it gives the nearest orthonormal factor in the Frobenius norm, but its implementation must use a stable SVD, eigensolver, or carefully stabilized Newton–Schulz iteration. A raw normal-equations implementation is not acceptable because it squares the condition number.

The mathematically defensible arbitration is therefore:

| Requirement | Preferred method | Guarantee |
|---|---|---|
| Extreme-step safety | **Scaled polar/Householder fallback** | Prevents overflow and reprojects onto the Stiefel manifold |
| General-purpose orthonormalization | **Householder QR** | Backward stability under standard floating-point assumptions |
| Nearest-point Stiefel projection | **Polar factor** | Optimal Frobenius-norm projection when full column rank holds |
| Unrestricted Cayley use | **Rejected** | Not guaranteed stable merely because the exact map is orthogonal |

The correct production design is a **hybrid retraction**:

1. Scale the step or generator before arithmetic.
2. Avoid explicit formation of enormous \(\tau A\).
3. Monitor the solve condition, residual, norm, and orthogonality defect.
4. Fall back to Householder QR or a stable polar factor when thresholds are exceeded.
5. Define behavior for rank deficiency and non-finite values.

A valid guarantee can be stated as:

\[
\|X_{+}^{\mathsf T}X_{+}-I\| \le c\,u\,p(n,\kappa,\text{algorithm}),
\]

for accepted inputs and a specified implementation, where \(u\) is unit roundoff. **No unconditional finite-precision guarantee exists for all inputs with \(|\mathrm{step}|\ge 10^{10}\)**, particularly in FP16, BF16, or unscaled FP32 arithmetic.

The available literature confirms that Cayley, QR, and polar constructions are recognized Stiefel retractions, while recent work explicitly notes that the metric affects Cayley-retraction order and conditioning.[4][6][7][9][12]

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

An 88-byte size or layout constraint is an ABI property; it does not itself provide synchronization. Acquire/release operations can establish ordering only when they participate in a correct publication and reclamation protocol.

A correct RCU/QSBR publication pattern is conceptually:

```text
writer:
    initialize immutable snapshot
    release-store descriptor.pointer and associated metadata
    wait until all pre-publication readers have quiesced
    reclaim old snapshot

reader:
    enter read-side critical section
    acquire-load descriptor.pointer/version
    read immutable snapshot
    exit read-side critical section
```

The essential guarantees are:

- A reader that performs the acquire load after publication observes the fully initialized snapshot.
- Immutable data referenced by that snapshot remains valid until the reader leaves its read-side critical section.
- Reclamation occurs only after the relevant grace period or QSBR epoch.
- Descriptor fields participating in publication are not concurrently modified in a way that creates a data race.
- Pointer, version, length, flags, and checksums are validated consistently.

**Acquire/release alone does not guarantee RCU safety.** It orders visibility; it does not prevent reclamation while a reader still holds a pointer. Nor does it make a multi-field descriptor atomic if readers can observe a torn or mixed state.

For an 88-byte descriptor, the exact guarantee depends on:

- Alignment and atomicity of each field.
- Whether publication is through one atomic pointer, an atomic index, or a versioned protocol.
- Cache-line placement and false sharing.
- The target architecture’s supported atomic widths.
- Whether the descriptor is immutable after publication.
- The formal C++20 or Rust memory-model implementation.
- The QSBR reader-registration and grace-period algorithm.

The strongest portable design is to publish **one atomic snapshot handle**—for example, a pointer to an immutable descriptor body or an atomic generation/index—and keep the 88-byte representation as payload rather than assuming that the entire 88 bytes can be atomically replaced. If a multiword descriptor must be read in place, use a sequence counter or double-buffered publication protocol with validation and retry.

Thus the definitive arbitration is:

> **Release publication plus acquire consumption provides initialization visibility; RCU/QSBR provides lifetime isolation. Both are required. Neither byte size nor acquire/release alone guarantees snapshot isolation.**

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

These systems do not share one identical execution or memory model:

- **C++20** defines language-level atomics and happens-before relationships, but not CUDA, XLA, or Triton execution semantics.
- **Rust** exposes atomic orderings and ownership rules, but unsafe code and FFI can invalidate those guarantees.
- **CUDA** has device-, block-, warp-, and system-scope synchronization distinctions; host/device visibility requires the appropriate scope and operations.
- **Triton** expresses kernel-level memory and synchronization behavior through compiler- and backend-specific primitives.
- **XLA** is an optimizing graph compiler; operation ordering and aliasing guarantees depend on its IR semantics, backend, and lowering.
- CUDA-backed XLA commonly lowers selected GPU computations through Triton IR and then to PTX, so semantic preservation must be tested across lowering boundaries rather than assumed.[10][14]

Accordingly, “multi-silicon conformance” cannot mean bit-identical output or identical timing. A precise conformance contract should separate:

1. **Functional conformance**  
   Same defined result within a stated tolerance.

2. **Numerical conformance**  
   Explicit bounds for orthogonality, residual, error, and determinism.

3. **Memory-model conformance**  
   No data races; publication and reclamation satisfy the declared happens-before relation.

4. **ABI conformance**  
   Descriptor size, alignment, field offsets, endianness, and serialization are fixed and tested.

5. **Progress conformance**  
   No deadlock, livelock, or invalid assumption about warp-wide or device-wide progress.

6. **Failure conformance**  
   Overflow, NaN, rank deficiency, stale generation, unsupported atomic width, and allocation failure have specified outcomes.

The implementation should use a common reference specification and independent backends, with differential tests covering:

- \(\mathrm{step}=0\), ordinary steps, and \(|\mathrm{step}|\ge10^{10}\).
- Ill-conditioned and rank-deficient matrices.
- NaN, infinity, subnormal, and overflow inputs.
- Concurrent publication, delayed readers, nested read-side critical sections, and reclamation races.
- CUDA architectures and host CPUs with different cache-coherence and atomic-width properties.
- XLA-to-Triton lowering and C++/Rust FFI boundaries.

## Definitive SOTA synthesis

The strongest defensible architecture is:

- **Numerics:** Use a scaled Cayley proposal only when conditioning and residual checks pass; otherwise use Householder QR or a stable polar projection. Never promise extreme-step stability from Cayley alone.
- **Descriptor publication:** Treat the 88-byte object as an ABI layout, not an atomic unit. Publish an immutable snapshot through a single atomic handle or validated version protocol.
- **Reclamation:** Require a formally specified RCU/QSBR grace-period mechanism. Acquire/release establishes visibility; quiescence establishes lifetime.
- **Portability:** Define one language-independent contract, then provide backend-specific implementations with explicit scope, atomicity, alignment, synchronization, and numerical tolerances.
- **Guarantees:** State conditional bounds—under specified precision, conditioning, alignment, atomic support, and backend semantics—not unconditional claims over all silicon and all extreme inputs.

The available search evidence supports the standard classification of Stiefel retractions and the relevance of polar and QR projections, but it does **not** substantiate any V1350-specific claim or establish that six independent models reached a particular consensus.[4][6][7][9][12]