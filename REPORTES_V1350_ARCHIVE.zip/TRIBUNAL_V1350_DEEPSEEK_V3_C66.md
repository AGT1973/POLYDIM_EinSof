# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 66)

# POLYDIM V1350 — High Tribunal Audit, Cycle 66

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute, Formal Methods.
**Verdict posture:** Adversarial. Claims are treated as unproven until shown.

---

## 0. Preliminary: What the Tribunal Can and Cannot Verify

The audit brief describes six artifacts by *name and claimed property*. No source bytes were submitted. Therefore this ruling is a **conditional audit**: every finding is stated as a *proof obligation* that the V1350 authors must discharge, plus the *failure modes* that are mathematically forced by the described design regardless of implementation detail. Where a claim is unfalsifiable as stated, the Tribunal says so.

Three claims are **structurally suspicious on their face** and are flagged up front:

- **C1.** "88-byte binary descriptor `<4sHHQQQQQBB6x4Q`" — the format string does not sum to 88 bytes. (See §1.)
- **C2.** "12/12 physical conformance checks" — a count is not a proof; the Tribunal demands the *predicate* of each check.
- **C3.** "globally scaled Woodbury solve (M/scale) W = (step/scale) B" — the scaling is *algebraically inert* unless `scale` is chosen with a condition-number argument. (See §4.)

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor: format-string arithmetic

`struct` format `<4sHHQQQQQBB6x4Q`:

| Field | Size (bytes) |
|---|---|
| `<` | 0 (endianness) |
| `4s` | 4 |
| `HH` | 4 |
| `QQQQQ` | 40 |
| `BB` | 2 |
| `6x` | 6 (pad) |
| `4Q` | 32 |
| **Total** | **88** |

**Result: 88 bytes exactly.** ✅ The claim survives arithmetic. However:

- **Alignment hazard.** With `<` (little-endian, *no* alignment), the struct is packed. If any consumer re-declares the same layout in C/Rust *without* `#[repr(C, packed)]` / `__attribute__((packed))`, the compiler will insert padding and the FFI ABI will silently diverge. **Rule 22 compliance is therefore conditional on a `static_assert(sizeof(...) == 88)` in every language binding.** Demand this assertion in C++, Rust, and CUDA.
- **`6x` is a smell.** Six bytes of explicit padding between `BB` and `4Q` suggests the author was chasing a magic number rather than a natural layout. The Tribunal requires a *semantic* justification: what are the two `B` flags, and why do the four `Q` fields need 8-byte alignment that the preceding `BB` breaks? If the answer is "to hit 88," the design is numerology, not engineering.

### 1.2 `HardwareProbe` multi-silicon

Claimed: probes CPU, CUDA, ROCm, TPU/Trainium. **Rule 27 risk:** if the probe *imports* `torch.cuda`, `jax`, `triton`, or `cupy` at module load, the orchestrator acquires a hard vendor dependency even when the target silicon is absent. **Required hardening:** lazy, capability-gated imports behind `importlib.util.find_spec`, with a `ProbeResult` dataclass that never raises on missing backends. A probe that crashes on a CPU-only host is a Rule 27 violation.

### 1.3 `PmtpSlabAllocator`

Slab allocation of 88-byte descriptors implies **alignment 8** (largest member `Q`). If the allocator returns 88-byte-strided slabs, then every descriptor is 8-byte aligned but *not* 64-byte aligned, which will defeat AVX-512 loads in Target 2 unless the C++ side uses `_mm512_loadu_si512`. **Demand:** either 64-byte-stride slabs (wasting 40 bytes/descriptor) or explicit unaligned-load discipline documented in the C++ kernel.

### 1.4 "12/12 physical conformance checks"

Unfalsifiable as stated. The Tribunal requires the 12 predicates in writing. A conformance check that is `assert True` counts as zero checks. **Rule 22 verification is not satisfied by a count.**

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan summation gives a **forward error bound**

\[
|\hat{s} - s| \le \big(2u + O(nu^2)\big)\sum_{i=1}^{n}|x_i y_i|,
\]

where \(u = 2^{-53}\) for FP64. The **condition number** of the dot product is

\[
\kappa_{\text{dot}} = \frac{\sum_i |x_i y_i|}{\big|\sum_i x_i y_i\big|},
\]

which is **unbounded** as the true sum approaches zero (catastrophic cancellation). Neumaier does *not* fix cancellation; it fixes *accumulation* error. **The Tribunal warns:** if V1350 uses Neumaier to claim "exact" dot products near cancellation, that claim is false. The correct statement is: Neumaier is *backward stable* with respect to the perturbed inputs, not *forward exact*.

### 2.2 Subnormal audits at \(-12\) and \(-14\)

Subnormals in FP64 begin at \(2^{-1022} \approx 2.2\times10^{-308}\). The exponents \(-12\) and \(-14\) are **nowhere near** the subnormal range — they are ordinary normal numbers. **This is a red flag.** Either:

- (a) the audit is in a *scaled* space (e.g., log-domain, or after division by a large `scale`), in which case the audit must state the scaling; or
- (b) the exponents refer to a *different* precision (FP32 subnormals start at \(2^{-126}\), still not \(-12\)); or
- (c) the numbers are **mislabeled** and the audit is meaningless.

**Demand:** the exact bit patterns being tested, and the IEEE-754 clause being exercised (gradual underflow, FTZ/DAZ behavior under `-ffast-math`). Note: **`-ffast-math` disables subnormal handling and Neumaier's compensation is not preserved under it.** If the build uses `-ffast-math`, the entire numerical claim collapses.

### 2.3 Zero-copy PMTP validation

Zero-copy across an FFI boundary requires that the 88-byte descriptor be **POD** and **trivially copyable**. In C++20, `std::is_trivially_copyable_v<Descriptor>` must be `true` and the struct must be `alignas(8)` at minimum. If any field is `std::string` or `std::vector`, zero-copy is a lie. **Demand:** `static_assert(std::is_trivially_copyable_v<PmtpTensorDescriptor>)`.

### 2.4 AVX-512 + OpenMP

- **AVX-512 downclocking** on Intel Skylake-X/Ice Lake can reduce sustained throughput by 15–40% for mixed workloads. The "SOTA" claim must be benchmarked against AVX2 on the same silicon.
- **OpenMP `#pragma omp simd` does not guarantee AVX-512 codegen.** Demand `-march=native -qopt-report` (ICC) or `-fopt-info-vec` (GCC) evidence.
- **OpenMP thread affinity** must be pinned; otherwise NUMA effects dominate the Neumaier error budget via non-deterministic reduction order.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as an FFI safety barrier — **this is backwards**

The Rustonomicon is explicit: **`panic = "abort"` is the *safer* choice for FFI**, because unwinding across an `extern "C"` boundary is **undefined behavior** in stable Rust (until `C-unwind` ABI is used). Setting `panic = "unwind"` and calling into C/C++ without `catch_unwind` at every boundary is a **soundness bug**, not a safety barrier.

**Required hardening:**
```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1, // or set a thread-local error code
    }
}
```
Or use `extern "C-unwind"` (Rust 1.71+) with a matching C++ `-fexceptions` contract. **The claim as stated is a Rule 27 / soundness violation.**

### 3.2 Packed 88-byte descriptor

`#[repr(C, packed)]` on a struct containing `u64` fields produces **unaligned references**, which are UB in Rust when you take `&field`. The correct pattern is `#[repr(C)]` with explicit `_pad: [u8; 6]` and `#[repr(align(8))]`, or `#[repr(C, packed(8))]` (Rust 1.33+) which packs to 8-byte alignment. **Demand:** the exact attribute and a `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`.

### 3.3 Safe SIMD

`std::simd` is still nightly-only as of the audit date. If V1350 uses `core::arch::x86_64::_mm512_*`, those are `unsafe` and the "Safe SIMD" claim is false. If it uses `wide` or `pulp` crates, the claim is defensible but the crate must be audited for `unsafe` blocks.

---

## 4. TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction

For \(Y \in \mathbb{R}^{n\times p}\) with \(Y^\top Y = I\), the Cayley retraction is

\[
R_Y(\xi) = \left(I - \tfrac{1}{2}W\right)^{-1}\left(I + \tfrac{1}{2}W\right)Y, \quad W = A Y^\top - Y A^\top,
\]

where \(A\) is the tangent step. **The matrix \(I - \tfrac12 W\) is invertible for all real \(W\)** because \(W\) is skew-symmetric, so its eigenvalues are purely imaginary and \(I - \tfrac12 W\) has eigenvalues \(1 - \tfrac12 i\lambda \ne 0\). ✅ **No degeneracy as step → ∞** in exact arithmetic.

**But:** in floating point, as \(\|\xi\| \to \infty\), \(W\) grows and the solve \((I - \tfrac12 W)^{-1}\) loses accuracy at rate \(O(u