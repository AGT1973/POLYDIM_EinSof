# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 62)

# POLYDIM V1350 — High Tribunal Audit (Cycle 62)

**Presiding note.** The Tribunal treats the six artifacts as *claimed* specifications. Where source is not in evidence, we audit the *stated invariants* and flag any claim that cannot be discharged by the stated mechanism. We do not grant "SOTA" on assertion.

---

## 0. Cross-cutting findings (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens / 88-byte PMTP

The 88-byte descriptor is claimed as `<4sHHQQQQQBB6x4Q`:

| Field | Type | Bytes |
|---|---|---|
| magic | 4s | 4 |
| version, flags | HH | 4 |
| 5×Q (shape/stride/offset family) | QQQQQ | 40 |
| 2×B (dtype, rank) | BB | 2 |
| pad | 6x | 6 |
| 4×Q (checksum, epoch, tag, reserved) | QQQQ | 32 |
| **Total** | | **88** |

**Verdict:** Structurally 88 B *only if* `struct` is packed with no implicit alignment. Python `struct.calcsize('<4sHHQQQQQBB6x4Q')` = 88 **iff** the format string is used with `<` (little-endian, no alignment). ✅ **But** the C++/Rust/CUDA sides must declare `#pragma pack(1)` / `#[repr(C, packed)]` / `__align__(8)` consistently. **Finding F-22.1:** the audit demands a byte-for-byte golden vector (hex dump) shared across all six runtimes; without it, Rule 22 is *unverifiable*, not *satisfied*.

**Rule 22 "zero 1D tokens":** interpreted as *no scalar/1-D payloads cross the inter-agent boundary* — only the 88-B descriptor + PMTP slab handle. All six targets appear compliant **provided** the CUDA Graph capture and XLA HLO do not smuggle 1-D scalars (e.g., `step`, `scale`) as separate kernel args. **Finding F-22.2:** `step` and `scale` in Target 4 are scalars; they must be folded into the descriptor's `QQQQ` tail or a device-resident 0-D tensor, else Rule 22 is violated at the graph-launch boundary.

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor surface | Lock risk |
|---|---|---|
| 1 orchestrator | none (probe only) | ✅ |
| 2 C++ AVX-512 | Intel/AMD ISA | ⚠️ AVX-512 is *not* universal (Zen4 yes, Zen3 no, ARM no) |
| 3 Rust SIMD | portable `std::simd`? | ✅ if `core::simd` nightly; ⚠️ if `packed_simd` |
| 4 CUDA | NVIDIA only | ❌ **hard lock** unless HIP/ROCm path exists |
| 5 XLA | Google TPU + AWS Trainium | ⚠️ dual-vendor, but both proprietary |
| 6 Triton | AMD ROCm + NVIDIA | ✅ dual-vendor |

**Finding F-27.1:** Target 4 as described (cuSOLVER `DnDsyevd`, CUDA Graphs) is **vendor-locked to NVIDIA**. Rule 27 requires a *documented fallback* (hipSOLVER `syevd`, ROCm graph capture). Absent that, Target 4 **fails Rule 27**.

**Finding F-27.2:** Target 2's AVX-512 must be gated by `__builtin_cpu_supports("avx512f")` with a scalar/AVX2 fallback, else Rule 27 fails on non-AVX-512 hosts.

---

## 1. Target 1 — `kernel_orchestrator_v1350.py`

**Claims:** multi-silicon probe, PMTP slab allocator, 88-B descriptor, 12/12 conformance.

**Audit:**
- **HardwareProbe:** must enumerate `{x86_avx512, x86_avx2, arm_sve, cuda_cc, rocm_gfx, tpu_gen, trainium}`. If probe returns a *set* and dispatch is by set-membership, no lock. ✅
- **PmtpSlabAllocator:** the critical invariant is **alignment ≥ 64 B** (cache line) and **size multiple of 88 B** for descriptor arrays. If the allocator uses `mmap(MAP_HUGETLB)` for ≥2 MB slabs, TLB pressure drops ~512×. **Finding F-1.1:** no stated huge-page policy → demand `MADV_HUGEPAGE` or explicit `MAP_HUGETLB` with fallback.
- **12/12 conformance:** the Tribunal requires the *list* of the 12 checks. A "12/12" claim without the check matrix is **non-falsifiable**. **Finding F-1.2:** publish the 12-tuple; at minimum: magic, version, endianness, alignment, size, checksum, epoch monotonicity, tag uniqueness, dtype∈enum, rank≤4, stride monotonic, offset<size.

**Degeneracy at step→∞ / →0:** orchestrator is control-plane; degeneracy lives downstream. ✅ conditional.

---

## 2. Target 2 — `kernel_cpp_v1350.cpp`

**Claims:** C++20 AVX-512 + OpenMP, Neumaier compensated dot, subnormal audits at −12/−14, zero-copy PMTP.

### 2.1 Neumaier dot — asymptotic condition number

Neumaier (Kahan–Babuška) compensated summation gives, for `s = Σ xᵢyᵢ` with `n` terms:

- **Forward error:** `|ŝ − s| ≤ (2u + O(nu²)) Σ|xᵢyᵢ|` where `u = 2⁻⁵³`.
- **Condition number:** `κ = Σ|xᵢyᵢ| / |Σ xᵢyᵢ|`. Neumaier is **backward stable** in the sense that the computed sum is the exact sum of perturbed inputs with `|δᵢ| ≤ 2u|xᵢyᵢ|`.
- **Asymptotic:** error grows as `O(u)` **independent of n** (vs `O(nu)` naive). ✅

**Finding F-2.1:** Neumaier does **not** protect against *catastrophic cancellation in the products themselves*. If `xᵢyᵢ` underflows to subnormal, the compensation term `c` also underflows and the guarantee degrades to `O(u_subnormal)`. Demand **FTZ/DAZ disabled** (`_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`) and explicit subnormal handling.

### 2.2 Subnormal audits at −12, −14

- `2⁻¹² ≈ 2.44e-4`, `2⁻¹⁴ ≈ 6.10e-5` — these are **normal** in FP32/FP64. The "audit" must mean *exponent thresholds* in a scaled representation, not IEEE subnormals.
- True FP64 subnormal threshold: `2⁻¹⁰²² ≈ 2.2e-308`. FP32: `2⁻¹²⁶ ≈ 1.2e-38`.
- **Finding F-2.2:** if the audit is at `2⁻¹²`/`2⁻¹⁴` in *scaled* units, the scale factor must be in the descriptor. Otherwise the claim is dimensionally incoherent.

### 2.3 step → ∞ / step → 0

- **step → ∞ (|step| ≥ 10¹⁰):** in a gradient/retraction step `x ← x − step·g`, the product `step·g` overflows FP32 if `|g| > 3.4e28`. In FP64, overflow at `|g| > 1.8e298`. **Finding F-2.3:** demand a `step` clamp `|step| ≤ 10⁸` or a log-domain step representation.
- **step → 0 (subnormal):** `step·g` underflows; the update becomes a no-op and the optimizer stalls silently. **Finding F-2.4:** demand `if (|step| < 2⁻¹⁰⁰⁰) step = 0` explicit branch, or a "step floor" in the descriptor.

### 2.4 Zero-copy PMTP

Zero-copy requires the descriptor's `offset` field to point into the slab. **Finding F-2.5:** demand `static_assert(sizeof(PmtpDescriptor) == 88)` and `alignas(64)` on the slab base. Without `alignas`, AVX-512 unaligned loads cost ~2× on some µarchs.

---

## 3. Target 3 — `kernel_rust_v1350.rs`

**Claims:** Rust 2021 safe SIMD, `panic=unwind` FFI barrier, Neumaier, packed 88-B descriptor.

### 3.1 `panic=unwind` as FFI barrier — **this is a bug, not a feature**

Rust's default `panic=unwind` **does not** make panics safe across FFI. A panic unwinding into C++ is **UB** (the C++ side has no landing pad). The correct barrier is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> i32 {
    std::panic::catch_unwind(|| { /* ... */ })
        .map(|_| 0).unwrap_or(-1)
}
```

**Finding F-3.1 (critical):** `panic=unwind` alone is **insufficient**. Demand `catch_unwind` at every `extern "C"` boundary, or `panic=abort` with a documented abort handler. The claim as stated is **unsound**.

### 3.2 Safe SIMD

`core::simd` is nightly-only. If the crate uses `std::arch::x86_64::_mm512_*`, those are `unsafe`. **Finding F-3.2:** "Safe SIMD" is only true if wrapped in a `#[target_feature(enable="avx512f")]` + `unsafe` block with a runtime feature check. Demand the wrapper.

### 3.3 Packed descriptor

`#[repr(C, packed)]` on an 88-B struct is correct, but **taking a reference to a packed field is UB** in Rust (unaligned reference). **Finding F-3.3:** demand `#[repr(C, align(8))]` with explicit `6x` padding, or `read_unaligned` for every field access.

### 3.4 step degeneracy

Same as Target 2: `step·g` overflow/underflow. Rust's `f64` follows IEEE; no extra protection. **Finding F-3.4:** demand `step.clamp(-1e8, 