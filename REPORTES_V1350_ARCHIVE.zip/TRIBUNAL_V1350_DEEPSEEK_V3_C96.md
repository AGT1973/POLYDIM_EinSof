# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 96)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 96 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal will not accept marketing prose. Every claim below is either (a) a *proof*, (b) a *counterexample*, or (c) an *explicitly flagged unverifiable assertion*. Where the submitted architecture description is silent on a mechanism, we treat silence as a defect, not a virtue.

---

## 0. Preliminary: What the Tribunal Can and Cannot Verify

The submission is a **specification sketch**, not source. We therefore audit:

1. **Internal consistency** of the described invariants (88-byte descriptor, 12/12 checks, Neumaier, Cayley, Lyapunov, Rule 22/27).
2. **Numerical claims** that are decidable from the stated algorithms.
3. **FFI / silicon-contract claims** that are decidable from the stated ABI.

We flag every place where the description is *under-determined* and would require source to close.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us *count*:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Verdict: arithmetically correct.** Alignment: `struct` with native alignment would insert padding; the format string as written is *explicitly packed* only if the caller uses `struct.Struct("<4sHHQQQQQBB6x4Q")` with `<` (little-endian, no alignment). **The Tribunal demands the `<` prefix be present in source** — otherwise `Q` fields will be 8-byte aligned and the struct will be 96 bytes on x86-64. This is a **latent Rule 22 violation** if the prefix is omitted.

**Recommendation:** assert `struct.calcsize(fmt) == 88` at import time; fail-fast.

### 1.2 "12/12 physical conformance checks"

The Tribunal cannot verify 12 unnamed checks. We require the *check manifest* to be published as a frozen tuple, e.g.:

```
CHECKS = ("magic", "version", "rank_le_2K", "dtype_fp64", "stride_aligned_64",
          "pmtp_size_eq_88", "no_1d_tokens", "silicon_tag_valid",
          "subnormal_guard", "step_finite", "scale_positive", "graph_captured")
```

Without this, "12/12" is **unfalsifiable**. Rule 22 compliance is *asserted*, not *demonstrated*.

### 1.3 Multi-silicon `HardwareProbe`

The probe must return a **capability bitmask**, not a vendor string. If it returns `"nvidia"` / `"amd"` / `"tpu"` and downstream code branches on that string, **Rule 27 is violated** (see §7). The correct pattern is:

```python
caps = probe()  # {has_avx512, has_amx, has_dnnd, has_cayley_fused, ...}
```

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — error bound

For vectors `a, b ∈ ℝ^n`, Neumaier's variant of Kahan–Babuška gives a *running* compensation `c` such that the returned `s + c` satisfies (Higham, *Accuracy and Stability*, Thm 4.3, adapted):

$$
\left|\,\widehat{a\cdot b} - a\cdot b\,\right| \;\le\; \bigl(2u + O(nu^2)\bigr)\sum_{i=1}^{n}|a_i b_i|,
$$

with `u = 2^{-53}` for FP64. **This is a *relative-to-absolute-sum* bound, not a relative-to-result bound.** When `a·b → 0` by cancellation (e.g. `a = b = [1, -1, ε, -ε, …]`), the *absolute* error stays `O(u·Σ|aᵢbᵢ|)` while the *result* shrinks — the **condition number of the dot product is**

$$
\kappa_{\text{dot}} = \frac{\sum_i |a_i b_i|}{|a\cdot b|},
$$

which is **unbounded** as `a·b → 0`. Neumaier does **not** fix this; it only removes the *first-order* accumulation error. **The Tribunal rejects any claim that Neumaier makes the dot product "accurate" in the ill-conditioned regime.**

### 2.2 Subnormal audit at `-12, -14`

The exponents `-12` and `-14` are *not* subnormal for FP64 (subnormals begin at `2^{-1022}`). They are subnormal for **FP16** (`2^{-14}` is the smallest normal FP16; `2^{-24}` is smallest subnormal). **The Tribunal suspects a dtype confusion.** If the kernel is FP64 (as Target 5 asserts "pure FP64"), then `-12, -14` are *ordinary* numbers and the "subnormal audit" is **vacuous**.

**Demand:** publish the actual dtype of the audit. If FP16, then AVX-512 FP16 requires `AVX512-FP16` (Sapphire Rapids+); if the kernel claims portability, this is a **Rule 27 violation**.

### 2.3 Zero-copy PMTP validation

"Zero-copy" means the 88-byte descriptor is `mmap`'d or `memcpy`'d once and then *aliased*. The Tribunal requires:

- A `static_assert(sizeof(PmtpDescriptor) == 88)`.
- `alignas(64)` on the descriptor to avoid false sharing across the 12-check pipeline.
- A `std::atomic<uint64_t>` generation counter to prevent torn reads during re-allocation.

Without the generation counter, **zero-copy is a data race** under concurrent re-probe.

### 2.4 AVX-512 / OpenMP portability

AVX-512 is **not** available on AMD Zen 1–3 (Zen 4 has it, Zen 5 has full-width). If the kernel unconditionally emits AVX-512 intrinsics, it **fails on Zen 3** — a Rule 27 concern *only if* the orchestrator cannot fall back. The Tribunal requires a `__builtin_cpu_supports("avx512f")` dispatch with a scalar fallback.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier — **this is backwards**

The Rustonomicon is explicit: **`panic = unwind` across an FFI boundary is UB** unless the callee is `extern "C-unwind"` (Rust 1.71+) *and* the caller is prepared to receive the unwind. The safe pattern is:

- `panic = abort` for the FFI-exposed crate, **or**
- `catch_unwind` at every `extern "C"` entry point, converting panic → error code.

**The Tribunal rules: `panic = unwind` as an "FFI safety barrier" is a category error.** It is the *opposite* of a barrier. This is a **critical defect**.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust's `#[repr(C, packed)]` gives 88 bytes but **unaligned field access is UB-adjacent** (it's defined but generates `memcpy` on every read, and `&packed.field` is a hard error). The correct pattern is:

```rust
#[repr(C, align(8))]
struct PmtpTensorDescriptor { /* fields summing to 88 */ }
```

with `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`. **`packed` is the wrong tool**; `align(8)` + manual padding is correct.

### 3.3 Neumaier in Rust

Rust's `f64::mul_add` (FMA) is **not** Neumaier — it's a single fused op. Neumaier requires the two-sum / two-product decomposition. If the kernel uses `mul_add` and calls it "Neumaier," that is a **misnomer**. Demand source.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in `R^{2K × 2K}`

The Cayley retraction on the Stiefel manifold `St(n, p)` is

$$
R_Y(\xi) = \left(I - \tfrac{1}{2}W\right)^{-1}\left(I + \tfrac{1}{2}W\right)Y, \quad W = \xi Y^\top - Y\xi^\top,
$$

where `Y ∈ R^{n×p}` is orthonormal and `ξ ∈ T_Y St`. For `n = p = 2K` (square), `Y ∈ O(2K)` and `W` is skew-symmetric `2K × 2K`.

**Numerical degeneracy as `step → ∞`:** `W = step · (…)`, so `(I - W/2)^{-1}` requires solving a `2K × 2K` linear system whose condition number grows like `‖W‖`. For `|step| ≥ 10^{10}` and `‖ξ‖ = O(1)`, `‖W‖ ~ 10^{10}`, and

$$
\kappa_2(I - W/2) \;\sim\; \|W\|/2 \;\sim\; 5\times 10^{9}.
$$

In FP64 (`u = 2^{-53} ≈ 1.1×10^{-16}`), the *relative* error in the solve is `~ u · κ ≈ 5×10^{-7}` — **acceptable**. But the *retraction itself* is no longer close to the exponential map: the Cayley retraction has `R_Y(ξ) = exp(ξ Y^T Y …)` only to second order; for `‖ξ‖ ≫ 1` the retraction is **not a retraction** in the manifold sense (it leaves the `O(1)` neighborhood where the retraction property holds). **The Tribunal rules: `step → ∞` is mathematically invalid for Cayley, regardless of conditioning.**

### 4.2 Globally scaled Woodbury solve `(M/scale) W = (step/scale) B`

Woodbury identity:

$$
(A + UCV)^{-1} = A^{-1} - A^{-1}U(C^{-1} + VA^{-1}U)^{-1}VA^{-1}.
$$

Scaling `M → M/scale` and `B → B/scale` is a **similarity transform** only if `scale` is applied to