# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 92

The requested **Cycle 92 arbitration cannot be validated as a definitive V1350 result** from the available evidence: no public, verifiable specifications or reports for “POLYDIM V1350,” “PMTP,” the six tribunal outputs, or the six kernels were found. The available literature supports only conditional mathematical and systems conclusions, not exact architectural guarantees for this named design.

## 1. Extreme-step Stiefel retraction

For \(X\in\mathrm{St}(n,p)\), a Cayley update commonly has the form

\[
Y(\alpha)=\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
\left(I+\frac{\alpha}{2}\Omega\right)X,
\qquad \Omega^\top=-\Omega .
\]

In exact arithmetic, the Cayley transform is orthogonal because \(\Omega\) is skew-symmetric. Thus, if the inverse exists and the solve is performed stably, it preserves the Stiefel constraint. The relevant singularity condition is that the associated transformed operator must not have an eigenvalue at \(-1\).[1]

However, **\(|\alpha|\ge 10^{10}\) is not, by itself, a stability guarantee**. At such scales:

- forming \(I\pm \alpha\Omega/2\) can cause overflow, excessive scaling, or loss of relative accuracy;
- the linear solve can become dominated by conditioning and floating-point range;
- an implementation that explicitly forms the inverse is weaker than one using a backward-stable factorization or structured solve;
- finite precision can produce \(Y^\top Y-I\neq0\), even though the exact transform is orthogonal.

The available source reports bounded absolute condition numbers for canonical Cayley and polar-light retractions under their stated assumptions, with bounds of 2 and 3 respectively, but those are **local conditioning results for the retraction map**, not a blanket guarantee for arbitrary floating-point implementations or unbounded step sizes.[1]

QR and polar retractions have different failure modes:

\[
R_{\mathrm{QR}}(X,\xi)=\operatorname{qf}(X+\xi),
\]

while the polar retraction is

\[
R_{\mathrm{polar}}(X,\xi)
=(X+\xi)\bigl(I+\xi^\top \xi\bigr)^{-1/2}.
\]

QR is generally cheaper than polar decomposition in standard flop counts, while polar retraction has a direct orthogonalization formula.[2] Neither should be declared universally superior without specifying scaling, rank separation, precision, pivoting, and reorthogonalization policy.

**Arbitrated result:** the mathematically strongest claim is conditional:

> A Cayley implementation is constraint-preserving in exact arithmetic and can be backward stable for extreme steps only if it uses a scaled structured solve, avoids explicit inversion, detects overflow/conditioning failures, and verifies the orthogonality residual.

It is not justified to claim unconditional superiority over Householder QR or polar QR at \(|\mathrm{step}|\ge10^{10}\). A robust architecture should use:

- Cayley for the primary update when its structured system is well-conditioned;
- Householder QR or polar fallback when scaling, solve residuals, or orthogonality checks fail;
- postcondition checks such as
  \[
  \|Y^\top Y-I\| \le c\,u\,\kappa_{\mathrm{alg}},
  \]
  with \(u\) the machine unit roundoff and \(c\) an implementation-dependent constant.

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

No verifiable public definition of the **PMTP 88-byte descriptor** was available, so its exact field layout, ownership rules, and memory-ordering contract cannot be confirmed.

More importantly, **Acquire/Release operations alone do not establish complete RCU/QSBR snapshot isolation**. A sound publication protocol requires, at minimum:

1. The writer initializes the descriptor and all immutable payload reachable from it.
2. The writer publishes the descriptor pointer with **Release** semantics.
3. A reader loads the pointer with **Acquire** semantics.
4. The reader enters the relevant RCU/QSBR read-side critical section before dereferencing protected state.
5. Reclamation is delayed until every reader that could have observed the old version has passed a quiescent state or exited its read-side section.
6. Descriptor reuse is protected against ABA, typically through versioning, hazard protection, epoch tagging, or non-reuse until grace-period completion.

The architectural guarantee should therefore be stated as:

> Acquire/Release provides initialization visibility and publication ordering; RCU/QSBR grace-period accounting provides lifetime and reclamation safety. Neither mechanism substitutes for the other.

If the descriptor contains atomics, the layout must also specify alignment, atomicity, permitted tearing, cache-line ownership, and whether the 88-byte size includes padding. An 88-byte object can straddle cache lines, which may affect performance and, on some platforms or field types, implementation legality. The byte count is not itself a memory-model guarantee.

**Arbitrated result:** the strongest defensible guarantee is **snapshot consistency for immutable, fully published descriptors**, provided that reclamation is deferred through a correctly implemented RCU/QSBR grace period. “Acquire/Release semantics guarantee isolation” is too strong without the lifetime protocol.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

No conformance matrix or executable reference implementation for V1350 was available. Therefore, exact multi-silicon conformance cannot be certified.

These environments do not share an identical execution or memory model:

- **CUDA** has GPU-specific scopes, synchronization primitives, relaxed atomics, and architecture-dependent behavior.
- **Triton** exposes compiler-controlled GPU kernels whose generated code and supported atomics depend on backend and target capability.
- **XLA** is an optimizing compiler IR/runtime system; operation ordering and aliasing are governed by its compiler semantics rather than by direct source-level imperative sequencing.
- **C++20** defines an abstract machine and memory model, but host-language guarantees do not automatically transfer to device code.
- **Rust** provides language-level ownership and concurrency guarantees, but unsafe FFI, device kernels, atomics, and memory-mapped data still require target-specific contracts.

A valid conformance claim requires a **canonical abstract specification**, not merely matching source code. At minimum, it must define:

- integer widths, floating-point formats, NaN and signed-zero behavior;
- overflow and rounding rules;
- descriptor ABI, alignment, padding, and endianness;
- atomic scopes and memory orders;
- synchronization and visibility points;
- permitted nondeterminism;
- numerical tolerances;
- aliasing and lifetime rules;
- behavior under device loss, retries, and asynchronous execution.

The correct guarantee is consequently:

> Cross-backend conformance is achievable only for an explicitly defined subset of operations and memory behaviors, validated by differential tests and litmus tests on every target architecture.

It is not valid to infer CUDA/XLA/Triton/C++20/Rust equivalence from source-level similarity.

## Definitive arbitration

The six-model findings cannot be ranked or merged as stated because the underlying tribunal reports were not supplied and the V1350 artifacts are not publicly verifiable. The mathematically and architecturally defensible synthesis is:

1. **Stiefel updates:** Cayley is exactly orthogonal in exact arithmetic, but extreme-step robustness is conditional on scaled, stable solves and residual checking. Householder QR or polar retraction must remain available as a verified fallback.
2. **PMTP descriptors:** Release publication plus Acquire observation establishes visibility; RCU/QSBR grace periods establish safe reclamation. Full snapshot isolation requires both, plus an ABA-resistant versioning policy where reuse is possible.
3. **Multi-silicon execution:** Conformance must be defined through a canonical behavioral contract and tested per backend. No unconditional bitwise, ordering, or numerical equivalence follows across CUDA, XLA, Triton, C++20, and Rust.

Accordingly, the strongest exact guarantees that can responsibly be issued are **conditional guarantees with explicit preconditions**, not unconditional SOTA claims for the unnamed V1350 architecture.