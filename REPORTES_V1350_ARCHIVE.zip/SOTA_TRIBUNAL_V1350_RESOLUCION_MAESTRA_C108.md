# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 108

The six-model tribunal findings cannot be independently reconciled from the prompt alone: the six reports, the definitions of the “six V1350 kernels,” and the PMTP 88-byte layout are not provided. Therefore, no defensible arbitration can declare a benchmark winner or an implementation-specific guarantee. The mathematically supportable synthesis is the following conditional architecture.

## 1. Stiefel retraction under extreme steps

Let \(X\in\mathrm{St}(n,p)\), so \(X^{\mathsf T}X=I\), and let \(\Xi\in T_X\mathrm{St}(n,p)\). The principal alternatives are:

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)\bigl(I+\Xi^{\mathsf T}\Xi\bigr)^{-1/2},
\]

and a QR retraction,

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi).
\]

These are established Stiefel retractions; Cayley updates are also valid retractions when formed from a skew-symmetric generator. The polar expression is explicitly based on a small \(p\times p\) positive-definite matrix, while QR uses the \(Q\) factor of \(X+\Xi\).[9]

### Arbitration

For \(\lvert\text{step}\rvert\ge 10^{10}\), **no unscaled floating-point Cayley implementation should receive an unconditional stability guarantee**. A Cayley transform typically requires solving a system involving a matrix of the form

\[
I-\frac{\alpha}{2}W,
\]

where \(W^{\mathsf T}=-W\). Iterative Cayley schemes require a step restriction such as

\[
0<\alpha<\frac{2}{\lVert W\rVert}
\]

for the cited contraction argument.[12] Consequently, a raw extreme step violates the conditions under which convergence and numerical reliability are established.

The superior rule is:

1. Construct the skew generator \(W\).
2. Compute a safe scaling \(s\), for example by norm estimation.
3. Replace the requested step by \(\widehat{\alpha}=\alpha/s\), with \(s\) chosen to keep the solve well-conditioned.
4. Apply the retraction in one or more bounded substeps.
5. Verify \( \lVert Y^{\mathsf T}Y-I\rVert \) and reject, rescale, or fall back if the tolerance is exceeded.

For a **single extreme update**, Householder QR is generally the safest practical fallback because it orthogonalizes using backward-stable transformations and does not require a Cayley linear solve. Polar retraction is attractive when high-quality orthogonality and smoothness are important, but it requires a stable inverse square root; inaccurate matrix-root iterations can materially degrade the result.[15]

Thus the definitive hierarchy is:

- **Default for bounded steps:** scaled Cayley, if its solve is monitored.
- **Robust fallback for extreme or ill-conditioned steps:** Householder QR.
- **Highest-quality orthogonal projection when implemented with a reliable symmetric eigensolver or SVD:** polar retraction.
- **Forbidden guarantee:** “Cayley is stable for every \(\lvert\text{step}\rvert\ge10^{10}\)” without scaling, conditioning checks, and fallback.

The exact guarantee that can be made is numerical, not absolute:

\[
\lVert Y^{\mathsf T}Y-I\rVert
\le C\,u\,\kappa_{\mathrm{alg}}+\tau_{\mathrm{fallback}},
\]

where \(u\) is unit roundoff, \(\kappa_{\mathrm{alg}}\) captures the conditioning of the solve or factorization, and \(\tau_{\mathrm{fallback}}\) is the configured acceptance tolerance. The constant and bound must be established experimentally for each precision and backend; they cannot be inferred from the step magnitude alone.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering is sufficient for a publication protocol only when the descriptor’s initialization and publication fields are designed as one coherent protocol. In C++, a release store followed by an acquire load that reads from that store establishes a synchronizes-with relationship.[4] In verified RCU reasoning, release/acquire ordering ensures that node initialization precedes reader access, and that reader-side accesses complete before reclamation proceeds.[1]

### Required publication protocol

A writer must:

1. Fully initialize the immutable payload and metadata.
2. Publish the descriptor pointer, generation, or sequence using a release operation.
3. Retain the old object until the RCU grace-period condition is satisfied.

A reader must:

1. Enter the RCU/QSBR read-side critical section.
2. Load the published pointer or generation with acquire semantics.
3. Read only immutable state reachable from that publication.
4. Exit the read-side section or report a quiescent state.

The 88-byte size is **not itself a memory-ordering guarantee**. In particular:

- Atomicity of an 88-byte descriptor is not implied by its size.
- A descriptor must not be copied non-atomically while readers can observe it.
- If the descriptor spans cache lines, readers need an atomic pointer, index, or versioned publication mechanism—not an assumed atomic 88-byte load.
- Release/acquire prevents reordering across the publication edge; it does not provide mutual exclusion, automatic reclamation, or protection against ABA reuse.
- QSBR protects reclamation only if every participating reader reports quiescence according to the protocol.

The architecturally correct guarantee is therefore:

> A reader that acquires publication value \(v\), enters the corresponding RCU/QSBR epoch, and completes before reclamation may access the fully initialized immutable snapshot associated with \(v\); the writer may reclaim that snapshot only after all readers that could have observed \(v\) have passed through a confirmed grace period.

This is **snapshot isolation**, not serializability. Concurrent snapshots may legitimately observe different generations. If readers require a self-consistent multi-field view, use one of:

- an immutable object published by atomic pointer;
- a seqlock/version protocol with acquire validation;
- double-collect validation;
- transactional or locked access.

A plain acquire load of one field from an 88-byte structure does not guarantee consistency of the remaining fields.

## 3. CUDA, XLA, Triton, C++20, and Rust

There is no single memory model shared identically by all five environments. C++20 and Rust provide language-level atomic semantics; CUDA provides device/system scopes and GPU-specific ordering; Triton exposes compiler- and hardware-dependent atomic operations; XLA is an optimizing tensor compiler whose observable semantics depend on the operation set and backend. Consequently, source-level equivalence does not establish cross-silicon equivalence.

### Conformance rule

Define a backend-independent abstract contract:

- **Publication:** payload initialization happens-before publication.
- **Observation:** an acquire observation of publication makes the payload visible.
- **Retirement:** reclamation occurs only after a completed grace period.
- **Snapshot:** each read returns one complete generation, or detects and retries.
- **Numerical update:** output satisfies the configured Stiefel residual and finite-value checks.
- **Failure behavior:** unsupported atomics, insufficient precision, or failed residual checks produce rejection or fallback—not silent success.

Then implement a backend-specific refinement:

| Environment | Required implementation discipline |
|---|---|
| C++20 | Use atomic publication with release/acquire or stronger ordering; ensure lifetime and reclamation are separately protected. |
| Rust | Use `std::sync::atomic` or equivalent with explicit ordering; uphold ownership and lifetime guarantees, especially around `unsafe` reclamation. |
| CUDA | Select the correct thread/block/device/system scope; use CUDA atomics and fences appropriate to the communicating agents; do not assume host C++ ordering automatically applies to device memory. |
| Triton | Restrict the protocol to operations whose atomicity, scope, and ordering are documented for the target backend; otherwise use a host/device coordination layer. |
| XLA | Express the protocol through supported ordered update primitives; do not assume arbitrary pointer-based RCU/QSBR is preserved through graph compilation or fusion. |

### Definitive conformance guarantee

The strongest valid claim is:

> A V1350 implementation is conformant on a target backend only if litmus tests, compiler-level tests, numerical residual tests, and reclamation stress tests all pass under the backend’s documented memory and execution model.

The test suite must include:

- publication-before-initialization litmus tests;
- stale-generation and ABA tests;
- delayed-reader QSBR tests;
- reclamation-under-contention tests;
- descriptor tearing tests;
- all supported memory scopes and device topologies;
- extreme-step retraction tests with NaN, overflow, rank loss, and orthogonality checks;
- cross-precision and cross-silicon comparisons.

## Final arbitration

The mathematically superior SOTA design is a **verified hybrid**, not a single universal kernel:

1. Use **scaled Cayley** for efficient regular updates.
2. Use **Householder QR** as the mandatory extreme-step and failed-solve fallback.
3. Use **polar retraction** where smoothness or projection quality justifies the inverse-square-root cost.
4. Publish an **immutable snapshot by atomic pointer or generation**, using release publication and acquire observation.
5. Treat the **88-byte descriptor as non-atomically stored metadata** unless a separately proven atomic representation is used.
6. Reclaim only through a correctly implemented **RCU/QSBR grace period**.
7. Define conformance as refinement of an abstract happens-before and snapshot contract, then validate separately on CUDA, XLA, Triton, C++20, and Rust.

No stronger guarantee—particularly universal Cayley stability at \(\lvert\text{step}\rvert\ge10^{10}\), atomicity of an 88-byte descriptor, or identical RCU semantics across all five execution environments—is justified by the available evidence.