# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 166

A definitive arbitration is **not possible from the available evidence**: the eight Tribunal models’ actual reports, the six V1350 kernel specifications, test vectors, and conformance logs were not provided, and no publicly verifiable specification for “POLYDIM V1350,” “PMTP,” or “Cycle 166” was found. The available literature supports only general claims about Cayley/Stiefel retractions—not the claimed implementation-level guarantees.

## Provisional arbitration

### 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For a skew-symmetric generator \(\Omega\), the Cayley update is generally written as

\[
Q_{\text{new}}
=
\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
\left(I+\frac{\alpha}{2}\Omega\right)Q.
\]

In exact arithmetic, the Cayley transform preserves orthogonality because it maps skew-symmetric generators to orthogonal matrices. It is also recognized as a second-order Stiefel retraction under the canonical metric.[1][3]

However, this does **not** imply numerical stability for arbitrarily large \(\alpha\). At \(\alpha\ge 10^{10}\):

- the linear system can become badly scaled;
- forming \(I\pm\alpha\Omega/2\) can cause overflow, underflow, or loss of significance;
- the result depends strongly on matrix conditioning, precision, scaling, and solver implementation;
- the Cayley transform is undefined if \(I-\alpha\Omega/2\) is singular or numerically indistinguishable from singular.

Therefore, the correct arbitration is:

| Claim | Arbitration |
|---|---|
| Cayley is exactly orthogonality-preserving | **Yes, in exact arithmetic** |
| Cayley is unconditionally stable at \(|\alpha|\ge10^{10}\) | **No** |
| Cayley universally dominates Householder or polar QR | **No** |
| A safeguarded/scaled Cayley implementation can be robust | **Yes, conditionally** |

For extreme steps, **Householder QR or a numerically stable polar decomposition is the stronger default retraction** when the required guarantee is bounded loss of orthogonality. Cayley can be retained as a fast path only with:

- step scaling or angle reduction;
- stable linear solves rather than explicit inversion;
- residual and orthogonality checks;
- fallback to QR or polar retraction;
- explicit precision-dependent error thresholds.

The mathematically defensible guarantee is thus conditional:

\[
\|Q_{\text{new}}^{T}Q_{\text{new}}-I\|
\le
C\,u\,\kappa\!\left(I-\frac{\alpha}{2}\Omega\right)
+
O(u^2),
\]

provided the system is sufficiently well-conditioned and the implementation uses a backward-stable solver. Here \(u\) is unit roundoff and \(C\) depends on dimensions and the factorization.

### 2. PMTP 88-byte descriptors and RCU/QSBR snapshot isolation

An 88-byte layout alone provides **no memory-ordering guarantee**. Descriptor size, alignment, packing, and cache-line placement are representation properties; acquire/release semantics must be implemented through the language and hardware memory model.

A sound publication protocol requires:

1. Writer initializes the descriptor and its referenced immutable state.
2. Writer publishes the pointer or version using a **release** store.
3. Reader obtains the published pointer using an **acquire** load.
4. Reader enters an RCU/QSBR read-side critical section before dereferencing the snapshot.
5. Writer retires old state only after every pre-existing reader has passed a grace period.
6. Reclamation uses the correct domain, address identity, and generation/version checks.

The architectural guarantee should be stated as:

> If publication uses release, consumption uses acquire, readers register before dereference, and reclamation waits for a valid grace period, then a reader observes a fully initialized immutable snapshot and cannot access reclaimed state.

Acquire/release by itself does **not** guarantee:

- protection against use-after-free;
- atomicity of an 88-byte descriptor;
- multi-copy atomicity across all devices;
- correct behavior when fields are independently mutable;
- ordering across CUDA, XLA, Triton, C++20, and Rust without platform-specific mappings.

If the descriptor itself must be atomically replaced, an 88-byte object is generally too large for a single universally lock-free atomic operation. The usual superior design is an atomically published pointer, index, or compact version word referring to an immutable 88-byte payload.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no automatic cross-silicon equivalence among these environments. Their memory and execution models differ:

- **C++20**: acquire/release applies within the C++ abstract machine and requires a data-race-free program.
- **Rust**: atomic orderings provide comparable language-level semantics, but unsafe pointer publication and reclamation still require a separately correct ownership protocol.
- **CUDA**: visibility and ordering depend on scope—thread, block, device, or system—and on the relevant CUDA atomic/fence primitives.
- **Triton**: compiler lowering and supported atomic/fence semantics must be verified for the target backend; source-level intent is not by itself a proof.
- **XLA**: operations may be fused, reordered, replicated, or lowered differently unless the relevant side effects and synchronization are explicitly represented.

Consequently, “conformance” must mean **observational equivalence under a defined contract**, not identical instruction sequences. The contract should specify:

- descriptor ABI, endian convention, alignment, and padding;
- ownership and lifetime rules;
- publication and reclamation protocol;
- legal concurrent accesses;
- permitted snapshot versions;
- numerical tolerances for retractions;
- supported device scopes;
- behavior under retries, duplication, fusion, and asynchronous execution.

## Definitive synthesis

The strongest defensible architecture is a **two-tier design**:

1. **Numerical layer**
   - Use Cayley retraction only when scaled conditioning and residual checks pass.
   - Apply step normalization for extreme magnitudes.
   - Fall back to Householder QR or polar retraction when conditioning, overflow, or orthogonality thresholds fail.
   - Guarantee only a stated backward-error bound, never unconditional stability for \(|\mathrm{step}|\ge10^{10}\).

2. **Concurrency layer**
   - Keep the 88-byte descriptor immutable after publication.
   - Publish a pointer/index/version atomically with release semantics.
   - Acquire-load that publication before access.
   - Protect the referenced object through RCU/QSBR.
   - Reclaim only after a verified grace period.
   - Use platform-specific fence scopes and a conformance test suite.

Under those preconditions, the exact architectural guarantees are:

\[
\textbf{Snapshot safety:}
\quad
\text{no reader observes partially initialized state or reclaimed state;}
\]

\[
\textbf{Retraction safety:}
\quad
Q^TQ=I
\text{ in exact arithmetic, and }
\|Q^TQ-I\|
\le \varepsilon_{\text{implementation}}
\text{ in finite precision;}
\]

\[
\textbf{Cross-backend safety:}
\quad
\text{equivalent observable behavior only where the declared ABI, memory scope,}
\]
\[
\text{lifetime protocol, and numerical tolerance contract are satisfied.}
\]

Claims that any one kernel is unconditionally superior at extreme steps, that an 88-byte descriptor is inherently atomic, or that C++20/Rust semantics automatically transfer to CUDA, XLA, and Triton should be rejected absent benchmark data, formal memory-model mappings, and machine-checked or stress-tested implementations.