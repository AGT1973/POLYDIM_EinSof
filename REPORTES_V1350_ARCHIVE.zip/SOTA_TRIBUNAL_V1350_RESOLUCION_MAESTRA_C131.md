# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 131

The available record does **not contain the eight Tribunal models’ reports, the six V1350 kernel specifications, or reproducible conformance data**. Therefore, no evidence-based arbitration can establish model-by-model winners or certify exact POLYDIM-specific guarantees. The defensible SOTA synthesis is a conditional architectural specification, not a claim that these guarantees have already been demonstrated.

## 1. Cayley/Stiefel retraction under extreme steps

For \(X \in \mathrm{St}(n,p)\), a Cayley update is commonly written

\[
Y(\alpha)
=
\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
\left(I+\frac{\alpha}{2}\Omega\right)X,
\qquad
\Omega^\top=-\Omega.
\]

The Cayley transform is a valid Stiefel retraction and is second-order accurate under the canonical metric.[1][2] Its orthogonality follows algebraically in exact arithmetic because the Cayley factor is orthogonal.

That does **not** imply numerical stability for \(|\alpha|\ge 10^{10}\). The relevant issue is the conditioning and implementation of the solve

\[
\left(I-\frac{\alpha}{2}\Omega\right)Z
=
\left(I+\frac{\alpha}{2}\Omega\right)X.
\]

For real skew-symmetric \(\Omega\), the exact matrix is nonsingular for every real \(\alpha\), but finite-precision behavior can still be dominated by overflow, scaling loss, inaccurate skew-symmetrization, poor low-rank solves, or cancellation. A literal dense inverse is therefore not an acceptable extreme-step implementation.

**Arbitrated result:**

- **Householder QR** is the preferred correctness fallback when the primary requirement is a numerically orthonormal output for arbitrary large steps. It should be implemented through stable blocked Householder transformations, not by forming \(Q\) through an unstable normal-equations path.
- **Polar retraction** is mathematically attractive because
  \[
  Y = Z(Z^\top Z)^{-1/2}
  \]
  gives the nearest Stiefel point in the Frobenius norm, but the Gram matrix and inverse square root require robust scaling and conditioning controls. Unregularized formation of \(Z^\top Z\) can square the condition number.
- **Cayley** is preferable for moderate steps, skew-symmetric low-rank updates, and situations where preserving the rational orthogonal action is important. At extreme steps it requires a scaled, structure-preserving solve and a residual check; otherwise it cannot be certified as superior to QR.

The mathematically strongest design is thus a **hybrid adaptive retraction**:

1. Enforce \(\Omega\leftarrow(\Omega-\Omega^\top)/2\).
2. Scale the problem using a power-of-two factor so intermediate values remain finite.
3. Evaluate Cayley through a structured solve or low-rank Sherman–Morrison–Woodbury formulation, never an explicit inverse.
4. Check
   \[
   \frac{\|Y^\top Y-I\|}{\max(1,p)\epsilon}
   \quad\text{and}\quad
   \frac{\|(I-\tfrac{\alpha}{2}\Omega)Y-(I+\tfrac{\alpha}{2}\Omega)X\|}
   {\|(I+\tfrac{\alpha}{2}\Omega)X\|}.
   \]
5. Fall back to Householder QR when the residual, orthogonality defect, overflow-risk estimate, or iteration budget exceeds its bound.
6. Optionally use polar refinement only when a nearest-point property is required and the scaled Gram computation is certified.

**Exact guarantee that can legitimately be stated:** if the Cayley path is computed with a backward-stable structured solve and the acceptance tests pass, the result is a numerically controlled Stiefel point. Without those implementation and acceptance conditions, there is no unconditional guarantee for \(|\alpha|\ge10^{10}\).

## 2. PMTP 88-byte descriptors and snapshot isolation

An 88-byte descriptor size by itself provides **no memory-ordering guarantee**. Neither alignment nor object size establishes atomicity for the complete descriptor. In particular, a reader must not assume that copying 88 bytes is indivisible or that a release store of one field publishes all other fields unless the publication protocol explicitly creates a happens-before relationship.

The sound RCU/QSBR design is:

- Construct a complete immutable descriptor in private storage.
- Publish a pointer, index, or generation token with **release** semantics.
- Read the publication token with **acquire** semantics.
- Dereference only the fully initialized immutable descriptor selected by that token.
- Retire the old descriptor only after the RCU/QSBR grace-period condition proves that all pre-publication readers have exited.
- Reclaim memory only after that condition, not merely after observing a newer generation.

Conceptually:

\[
\text{initialize descriptor}
\;\prec\;
\text{release publish}
\;\prec_{\text{sw}}\;
\text{acquire read}
\;\prec\;
\text{descriptor access}.
\]

Here \(\prec_{\text{sw}}\) denotes a synchronizes-with edge. The guarantee concerns the **published pointer/version**, not an 88-byte by-value object copy.

**Required architectural guarantee:**

> A reader that acquires a published descriptor observes one fully initialized immutable snapshot, and reclamation of that snapshot cannot occur until the applicable RCU/QSBR grace period has completed.

This requires explicit assumptions:

- the publication word is naturally aligned and accessed atomically;
- descriptor fields are immutable after publication;
- readers register and report quiescent states correctly;
- reclamation is deferred through the same domain as publication;
- device/host visibility is handled separately where GPUs or accelerators are involved;
- release/acquire operations are not silently lowered to relaxed operations by a backend.

Acquire/release alone does **not** protect against a writer mutating an already-published descriptor, ABA reuse, premature reclamation, data races on non-atomic fields, or incoherent host/device caches. If descriptors must be updated in place, the design needs a stronger protocol—such as per-field atomics, sequence locks with validation, or immutable copy-and-publish.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

A single “multi-silicon conformance” claim is too broad unless the memory model and numerical contract are defined separately for each execution layer.

### C++20 and Rust

C++20 can express the publication protocol using atomic release/acquire operations and an RCU/QSBR library or carefully specified reclamation scheme. Rust can express the same protocol, but safe Rust does not automatically make reclamation correct: `Arc`, epochs, hazard pointers, or another verified ownership mechanism is still required. `unsafe` code must preserve the aliasing, lifetime, and atomic-ordering invariants.

The portable language-level guarantee is therefore:

- atomic publication establishes visibility of prior initialization;
- immutable post-publication fields may be read non-atomically after successful acquisition;
- reclamation is correct only if the selected RCU/epoch protocol is correctly implemented.

### CUDA

CUDA requires separating C++ atomic ordering from host/device visibility and synchronization. A device-side release/acquire pair is not, by itself, a universal host-device publication guarantee. The implementation must specify scope—block, device, or system—and use the appropriate CUDA memory operations and stream/event synchronization. Descriptor storage must also obey alignment and lifetime constraints.

A valid CUDA guarantee must name:

- atomic scope;
- address space;
- producer and consumer locations;
- cache-coherence assumptions;
- stream/event or system-fence protocol;
- reclamation authority.

### Triton

Triton provides useful atomic and device-memory primitives, but it is not a drop-in replacement for a general C++20 RCU implementation. Backend lowering, supported scopes, barriers, and cache behavior must be tested for the targeted compiler and GPU architecture. A Triton kernel can implement a bounded publication protocol, but the exact guarantee is backend-specific unless verified through generated code and litmus tests.

### XLA

XLA is a graph/compiler IR rather than a general shared-memory concurrency model. Buffer aliasing, asynchronous execution, fusion, replication, and device ordering can invalidate assumptions based on ordinary C++ atomics. Snapshot isolation should normally be expressed functionally—immutable buffers, explicit data dependencies, and ordered token/state edges—rather than as an ad hoc lock-free pointer protocol inside an XLA computation.

Consequently, “XLA conformance” cannot mean that arbitrary C++20 acquire/release code has identical semantics after compilation. It must mean that the computation’s explicit data-dependency graph preserves the stated snapshot property.

## Definitive arbitration

The strongest defensible synthesis is:

1. **Retraction:** use a scaled, residual-checked Cayley implementation for its structure-preserving and second-order properties; use stable Householder QR as the mandatory extreme-step fallback. Do not claim unconditional Cayley superiority at \(|\mathrm{step}|\ge10^{10}\). The literature supports Cayley as a valid Stiefel retraction, but not an automatic extreme-step finite-precision guarantee.[1][2]
2. **Descriptor publication:** publish an immutable descriptor indirectly through an atomically acquired pointer/index/version. Release/acquire orders initialization and observation; RCU/QSBR grace periods order observation and reclamation. The 88-byte size is an ABI/layout fact, not a synchronization primitive.
3. **Portability:** define one abstract contract and provide backend-specific realizations. C++20 and Rust can implement the language-level protocol; CUDA needs explicit scope and system-visibility rules; Triton needs backend validation; XLA should use explicit functional data dependencies rather than assume conventional lock-free shared-memory semantics.
4. **Certification:** the six kernels are certifiable only after numerical stress tests, memory-model litmus tests, reclamation tests, generated-code inspection, and cross-silicon differential testing. In the absence of the eight reports and such test artifacts, attributing a definitive result to Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, or Perplexity would be unsupported.