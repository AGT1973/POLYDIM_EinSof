# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 109

No verifiable outputs from the six named Tribunal models—or formal specifications for the “V1350 kernels” and “PMTP 88-byte Descriptor”—were provided, so a model-by-model arbitration cannot honestly be claimed. The defensible SOTA synthesis is therefore a **conditional architectural specification**, not a finding that any particular Tribunal reached it.

## 1. Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For \(X\in\mathrm{St}(n,p)\), a valid retraction must return \(Y\) satisfying

\[
Y^\top Y=I_p
\]

up to the implementation’s stated floating-point tolerance.

| Method | Mathematical behavior | Extreme-step assessment |
|---|---|---|
| Cayley retraction | Applies an orthogonal transform, typically \((I-\tfrac{\tau}{2}A)^{-1}(I+\tfrac{\tau}{2}A)X\), with skew-symmetric \(A\) | Orthogonality-preserving in exact arithmetic, but requires a well-conditioned solve and careful scaling |
| Householder QR | Factors \(Z=QR\), then chooses a sign convention for \(R\) | Generally the strongest default for numerical robustness; requires rank/reorthogonalization safeguards |
| Polar retraction | \(Z(Z^\top Z)^{-1/2}\) | Geometrically canonical and often highly accurate, but the Gram matrix can overflow, underflow, or become ill-conditioned for huge \(\tau\) |

The superior arbitration is **not “Cayley always wins.”** For an unbounded raw step, no finite-precision method has an unconditional stability guarantee. A step of \(10^{10}\) can cause overflow, loss of significance, singular solves, or rank collapse before the retraction is evaluated.

The exact guarantee should instead be:

1. Compute a bounded effective step using norm-based scaling or trust-region clipping.
2. Form the trial point with overflow-safe scaling.
3. Use Householder QR as the baseline retraction.
4. Use Cayley only when its skew system is demonstrably well-conditioned and the solve is backward-stable.
5. Use polar retraction when the required accuracy and conditioning of \(Z^\top Z\) are certified.
6. Verify \( \|Y^\top Y-I\| \) and reject or recompute if the bound is exceeded.

Thus, the **SOTA default** is a safeguarded QR retraction, with Cayley as an optimized path—not a blanket claim that Cayley is more stable under arbitrary extreme steps. Polar decomposition has a closed-form Stiefel retraction, while Cayley, QR, and polar are all recognized retraction choices.[13][14]

A mathematically meaningful contract is:

\[
\|Y^\top Y-I\| \le c\,u\,\kappa_{\mathrm{alg}},
\]

where \(u\) is unit roundoff and \(\kappa_{\mathrm{alg}}\) captures conditioning and implementation growth. The contract must specify \(c\), norm, precision, rank assumptions, and fallback behavior; “stable for \(|\mathrm{step}|\ge10^{10}\)” by itself is not a theorem.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering is sufficient for **publication visibility**, but not by itself for complete RCU reclamation safety.

The required publication pattern is:

\[
\text{initialize descriptor and pointed-to state}
\;\prec_{\mathrm{sb}}\;
\text{release-store publication pointer}
\]

and the reader performs:

\[
\text{acquire-load publication pointer}
\;\prec_{\mathrm{hb}}\;
\text{read descriptor and immutable payload}.
\]

A release store followed by an acquire load of the **same atomic publication location**, when the acquire observes that release or its release sequence, makes prior initialization visible to the reader.[1][3][6]

For RCU/QSBR, the descriptor additionally needs:

- An atomically published generation, epoch, or pointer.
- Reader entry/exit or quiescent-state announcements.
- Writer-side grace-period detection.
- Deferred reclamation only after every pre-existing reader has passed a quiescent state.
- Immutable payloads, or separately synchronized mutable fields.
- Correct lifetime management for every pointer reachable from the 88-byte object.

Release/acquire does **not** alone guarantee:

- Atomicity of an arbitrary 88-byte descriptor.
- A coherent snapshot if fields are read independently.
- Safe reclamation after publication.
- Ordering between unrelated atomic variables.
- Portability of lock-free behavior across CPUs or accelerators.

A robust snapshot protocol is therefore:

```text
writer:
    fully initialize immutable object
    publish pointer or generation with release

reader:
    enter read-side critical section
    load pointer/generation with acquire
    validate generation if a coherent multi-object snapshot is required
    access immutable state
    leave critical section / announce quiescence

writer:
    replace publication pointer
    wait for a grace period
    reclaim the old object
```

If the descriptor itself must be copied atomically, its size and alignment must be checked against the target’s atomic capabilities. Otherwise, publish a pointer to an immutable descriptor rather than assuming an 88-byte atomic transaction.

The exact architectural guarantee should be stated as:

> A reader that acquires a successfully published generation and remains inside the read-side critical section observes fully initialized immutable state associated with that generation; reclamation occurs only after a grace period covering that reader.

That is stronger and more accurate than claiming that “Acquire/Release provides snapshot isolation” unconditionally. Formal RCU work likewise distinguishes release-acquire publication from grace-period reclamation and shows that quiescent-state ordering is needed before deallocation.[9]

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single common execution or memory model spanning all five environments. Conformance must therefore be defined at the **algorithmic and ABI-contract level**, with backend-specific implementations.

### Portable guarantees

The common denominator can guarantee:

- Identical descriptor field meanings, widths, alignment, and endianness.
- Identical mathematical retraction and validation rules.
- Explicit precision and accumulation requirements.
- No reliance on host-language object layout without serialization.
- No reliance on undocumented warp, block, stream, compiler, or device ordering.
- Explicit publication, reader-protection, and reclamation phases.
- Differential testing against a high-precision reference.
- Backend-specific synchronization mapped to the strongest supported primitive.

### Non-portable assumptions

The following cannot be claimed without target-specific evidence:

- A CUDA device-wide atomic or fence having identical semantics to C++20 or Rust.
- XLA preserving arbitrary pointer identity, aliasing, or host-style RCU lifetimes.
- Triton providing a general-purpose cross-program RCU mechanism.
- A CUDA kernel and a Rust/C++ host thread sharing one unmodified memory model.
- Lock-free 88-byte atomics on every target.
- Bitwise-identical floating-point results across CUDA, XLA, Triton, C++20, and Rust.

C++20 and Rust provide well-defined acquire/release abstractions, but synchronization is established through the appropriate atomic object; it is not a universal barrier over unrelated memory locations.[1][3] Device execution systems may require separate kernel-launch, stream, event, or device-fence protocols. XLA commonly treats computation as an optimized graph/program rather than as a general shared-memory object system, so an RCU design must be expressed as explicit versioned buffers or host-managed epochs.

## Definitive arbitration

The strongest defensible V1350 architecture is:

1. **Numerics:** bounded-step, overflow-safe Stiefel update with Householder QR as the mandatory correctness fallback; Cayley is an optional fast path subject to conditioning and postcondition checks; polar is an optional accuracy path with explicit Gram-matrix conditioning checks.
2. **Descriptor:** 88 bytes is an ABI/layout requirement, not an atomicity guarantee. Publish an immutable descriptor or descriptor pointer with release; acquire it on the read side; use QSBR/RCU grace periods before reclamation.
3. **Portability:** define one language-neutral mathematical and memory contract, then provide backend mappings and conformance tests for each target. Do not claim one universal low-level memory model.
4. **Validation:** every implementation must test orthogonality residual, descriptor-generation consistency, publication visibility, reclamation safety, overflow behavior, and cross-backend numerical tolerances.
5. **Failure behavior:** on failed conditioning, rank loss, stale generation, unsupported atomic capability, or residual violation, reject, retry with a safer path, or fall back to a host/device-supported implementation.

Consequently, the mathematically superior and architecturally honest SOTA position is **conditional robustness with verified fallbacks**, not unconditional Cayley superiority, unconditional Acquire/Release snapshot isolation, or automatic multi-silicon conformance.