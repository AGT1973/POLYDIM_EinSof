# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 130)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 130 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has reviewed the six artifacts as *specifications* (the actual source files were not attached to this docket). Findings below are therefore stated as **conditional verdicts**: they hold *if* the implementation matches the described contract, and each is paired with the falsifying test the Tribunal would demand on the real source. Where the description itself is mathematically impossible or under-specified, that is flagged as a **spec defect** independent of implementation.

---

## 0. Cross-cutting verdicts (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor is claimed as `<4sHHQQQQQBB6x4Q` in Target 1. Let us audit the struct arithmetic:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

✅ **Structurally sound.** `struct.calcsize('<4sHHQQQQQBB6x4Q') == 88` on any CPython ≥3.7 with standard alignment. The explicit `6x` pad makes the layout endian- and ABI-stable, which is the correct way to satisfy Rule 22.

**However — Rule 22 violation risk in Targets 3, 4, 5, 6.** The docket describes:
- Target 3: "packed 88-byte PmtpTensorDescriptor" — ✅ if `#[repr(C, packed)]` and the same field order.
- Target 4: no descriptor size stated. **Spec defect.** CUDA kernels that pass descriptors by value across `__global__` boundaries must use the *same* 88-byte layout; if the `.cu` file defines its own struct, Rule 22 is silently broken at the FFI seam.
- Target 5: XLA/HLO has no native 88-byte concept. The Python wrapper must serialize the descriptor into a `uint8[88]` buffer and pass it as a `jax.Array` of dtype `uint8`. If it instead passes a Python dict or a `NamedTuple`, **Rule 22 is violated** (1D token leakage).
- Target 6: Triton has no struct ABI. Same requirement: 88-byte `uint8` tensor, `tl.load` as `tl.uint64` × 11.

**Tribunal demand:** a single `pmtp_layout.json` (or `.h`) that all six files `#include`/`import`, plus a CI test that asserts `sizeof == 88` and byte-equality of a golden vector across all six runtimes.

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor lock? | Verdict |
|---|---|---|
| 1 (orchestrator) | None if `HardwareProbe` is capability-based | ✅ conditional |
| 2 (C++/AVX-512) | **AVX-512 is Intel/AMD-only.** ARM (Graviton, Apple) cannot run it. | ⚠️ **Partial lock** |
| 3 (Rust SIMD) | Portable if `std::simd` or `wide`; locked if `core::arch::x86_64::*` | ⚠️ depends |
| 4 (CUDA) | **Hard NVIDIA lock.** cuSOLVER `DnDsyevd` has no ROCm equivalent with identical numerics. | ❌ **Violation** |
| 5 (XLA) | **Google TPU lock** unless the same HLO compiles to Trainium *and* GPU. | ❌ **Violation** |
| 6 (Triton) | Portable across ROCm/CUDA — this is the *only* file that satisfies Rule 27 by construction. | ✅ |

**Tribunal ruling:** Targets 4 and 5 as described **violate Rule 27**. The Silicon Contract requires that no single component *imposes* a vendor. The correct pattern is a **capability dispatch**: the orchestrator (Target 1) selects among {CUDA, ROCm, XLA-TPU, XLA-Trainium, AVX-512, NEON, SVE} based on `HardwareProbe`, and each backend is a *peer*, not a *requirement*. If Target 4 is the *only* path for Stiefel retraction, the contract is broken.

**Remediation:** Target 4 must ship a `stiefel_cayley_rocm.hip` sibling, or the orchestrator must fall back to Target 2's CPU path with a documented condition-number penalty.

---

## 1. Target 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy

The orchestrator itself does no arithmetic, but it *dispatches* on `step`. The degeneracy risk is **dispatch hysteresis**:

- If `HardwareProbe` selects a backend based on `step` magnitude (e.g., "use CUDA for large step, CPU for small"), then at the boundary `|step| = 10^10` a **thrashing** can occur if two backends disagree on the subnormal policy.
- **Proof obligation:** the dispatch predicate must be a *total order* on `(step, dtype, shape)` with no ties. Formally, define `f: ℝ × D × ℕ³ → Backend`; require `f` to be a step function with measure-zero discontinuity set, and require all backends to agree on `f`'s output for the same input.

### 1.2 12/12 physical conformance checks

Without the source, the Tribunal can only demand that the 12 checks include:
1. `calcsize == 88`
2. endianness round-trip
3. `HardwareProbe` reports ≥1 backend
4. `PmtpSlabAllocator` alignment ≥ 64 B (AVX-512) and ≥ 128 B (cache line)
5. subnormal flush-to-zero (FTZ) flag consistency across backends
6. NaN/Inf propagation policy
7. `step` range `[2^-1074, 2^1024)` (FP64)
8. descriptor magic `b'PMTP'`
9. version field monotonic
10. zero-copy pointer validity
11. FFI unwind safety (Rust `panic=unwind` barrier)
12. CUDA Graph capture idempotence

If any of these is missing, the "12/12" claim is **unfalsifiable** and the Tribunal rejects it.

### 1.3 FFI hardening

- **Rust `panic=unwind` across FFI is UB** unless every `extern "C"` function is wrapped in `catch_unwind` and returns a sentinel. The docket says "panic=unwind FFI safety barrier" — this is only safe if the barrier is *explicit*. Demand `std::panic::catch_unwind(AssertUnwindSafe(|| ...))` at every boundary.
- **Python ↔ C++**: use `pybind11` with `py::call_guard<py::gil_scoped_release>()` for long kernels, and `py::register_exception_translator` for `std::exception`.

---

## 2. Target 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's algorithm computes `s = Σ xᵢyᵢ` with compensation `c`. The **forward error** is bounded by:

\[
|\hat{s} - s| \le \gamma_2 \sum_i |x_i y_i| + O(u^2)
\]

where `γ₂ = 2u/(1-2u)`, `u = 2^-53` for FP64. This is **independent of the condition number of the dot product itself** — the *relative* error is `γ₂ · Σ|xᵢyᵢ| / |Σxᵢyᵢ|`, which blows up only when the true sum is near-cancellation.

**Degeneracy at `step → ∞`:** if `step` scales the inputs, `Σ|xᵢyᵢ| ~ step²`, and the *absolute* error grows as `step² · u`. For `step = 10^10`, `step² · u ≈ 10^20 · 10^-16 = 10^4` — **catastrophic absolute error** even with Neumaier. The fix is to **pre-scale** by `1/step` (which Target 4 does via `M/scale`, but Target 2 does not mention). **Tribunal demands** Target 2 adopt the same global scaling.

**Degeneracy at `step → 0` (subnormals):** the docket mentions "subnormal audits (-12, -14)". These are presumably exponents `2^-12` and `2^-14` (FP16 subnormal range). For FP64, subnormals begin at `2^-1022`. If Target 2 operates in FP64, the `-12/-14` audit is **irrelevant** unless the kernel internally downcasts to FP16. **Spec defect:** clarify the working precision.

### 2.2 AVX-512 vendor lock

As noted in §0.2, AVX-512 is not available on ARM. The Tribunal requires:
- A `#if defined(__AVX512F__)` guard with a scalar fallback.
- A `#elif defined(__ARM_NEON)` path for Graviton/Apple.
- Runtime dispatch via `__builtin_cpu_supports("avx512f")`.

Without these, Target 2 **violates Rule 27**.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the descriptor's `Q` fields to be **physical addresses** (or IOVA), not virtual. The Tribunal demands:
- `mmap` with `MAP_HUGETLB | MAP_POPULATE` for the slab.
- `mlock` to prevent page-out during kernel execution.
- A `pmtp_validate()` that checks `addr % 64 == 0` and `addr + len` is within the slab.

---

## 3. Target 3 — `kernel_rust_v1350.rs`

### 3.1 Safe SIMD

Rust 2021 `std::simd` is **nightly-only** as of the 2021 edition. If the file uses `core::arch::x86_64::_mm512_*`, it is **not safe SIMD** — it is `unsafe` intrinsics. The docket's claim of "Safe SIMD" is therefore **suspect**. The Tribunal demands:
- Either `#![feature(portable_simd)]` with `std::simd::f64x8`, or
- A `wide` crate dependency, or
- Explicit `unsafe` blocks with `// SAFETY:` comments.

### 3.2 `panic=unwind` FFI barrier

As