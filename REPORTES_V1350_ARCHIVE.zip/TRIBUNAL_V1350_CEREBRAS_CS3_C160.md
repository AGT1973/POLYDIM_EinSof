# AUDITORÍA TRIBUNAL DE SABIOS — Cerebras_CS3 (CICLO 160)

# POLYDIM V1350 – MULTI‑FILE ADVERSARIAL SOTA AUDIT (CYCLE 160)  

**High‑Tribunal of Mathematical and Systems Sages – Summary of Findings**  

| Target | Primary Computational Kernel | Core Numerical Sub‑systems | Vendor‑specific Stack |
|--------|------------------------------|----------------------------|-----------------------|
| 1 | `kernel_orchestrator_v1350.py` | Descriptor parsing, hardware‑probe state‑machine | Pure‑Python / CPython, no vendor‑specific binary |
| 2 | `kernel_cpp_v1350.cpp` | AVX‑512 / OpenMP dot‑product, Neumaier compensated accumulation, sub‑normal checks | Intel‑x86‑64 (AVX‑512) |
| 3 | `kernel_rust_v1350.rs` | Safe‑SIMD, panic‑unwind barrier, Neumaier sums, packed descriptor | Rust‑2021, vendor‑agnostic (SIMD intrinsics) |
| 4 | `kernel_cuda_v1350.cu` | Stiefel‑Cayley retraction, cuSOLVER eigen‑solve, Woodbury‑scaled linear solve, CUDA‑Graphs | NVIDIA CUDA‑12 (Tesla/RTX) |
| 5 | `kernel_xla_v1350.py` | JAX‑XLA HLO fusion, TPU / Trainium kernels, continuous Lyapunov solve in HBM | Google Cloud TPU / AWS Trainium |
| 6 | `kernel_triton_v1350.py` | ROCm‑/NVIDIA‑coalescent tiling, SRAM streaming, Clifford bivector rotation | AMD ROCm **and** NVIDIA CUDA (dual‑vendor) |

Below each target is inspected against the four audit requirements:

---

## 1. Numerical Degeneracy for Extreme Step Magnitudes (|step| → ∞ or → 0)

### 1.1. General Modelling of “step”

All kernels treat **step** as a scalar multiplier of a base update matrix/tensor **Δ**. The effective update is  

\[
U(\text{step}) = \text{step}\cdot \Delta .
\]

When \(|\text{step}| \ge 10^{10}\) we are in the **large‑step** regime; when the floating‑point representation of **step** falls into the **subnormal** band (\(0 < |\text{step}| < 2^{-1022}\) for FP64) we are in the **small‑step** regime.  

### 1.2. Target‑Specific Degeneracy Analyses  

| Target | Large‑Step Failure Modes | Small‑Step Failure Modes |
|--------|--------------------------|--------------------------|
| **1 – Orchestrator (Python)** | – The 88‑byte descriptor fields (four 64‑bit quantities) are stored as unsigned integers; converting a FP64 `step` to a packed `Q` field will overflow if \(|\text{step}| > 2^{64}\). In practice the orchestrator clamps to `2^63‑1`, but a silent wrap‑around could corrupt subsequent hardware probe IDs. <br>– The “HardwareProbe” state‑machine uses a 32‑bit counter for elapsed cycles; large steps may cause premature termination of the probe because the time budget is computed as `budget = base_budget * step` and then cast to `uint32`. | – The probe timer is computed using `float(step)` and then truncated to `int`; for subnormals the cast yields zero, which disables timeout checks and can lead to infinite loops. |
| **2 – C++ (AVX‑512)** | – Dot‑product accumulator is a **double‑precision** Neumaier sum. The compensated term **c** is bounded by \(\mathcal{O}(\mathrm{eps}\,|S|)\). For \(|\text{step}| \ge 10^{10}\) the product `a[i] * step` may overflow to **+∞** even when `a[i]` is modest (e.g. 1e‑5). The subsequent compensation cannot rescue the overflow → NaN propagation. <br>– The OpenMP reduction operates on a **private** accumulator per thread; overflow in any thread aborts the reduction with an undefined result. | – Subnormal `step` → `a[i]*step` may underflow to **+0** while the exact product is still non‑zero. Neumaier’s correction term recovers the lost low‑order bits only if the underflow is *gradual* (i.e. the product stays within the normal regime). When the product is subnormal it is rounded to zero, and the compensation term becomes zero as well. Hence the accumulated sum loses the contribution of all entries whose magnitude is < `2^{-1022}`/|step|. |
| **3 – Rust (Safe SIMD)** | – SIMD lanes compute `step * a[i]` using the hardware’s FP64 unit. The same overflow issue as C++ appears, but the Rust wrapper adds an **explicit overflow‑check** (`checked_mul`). However the check only triggers on **exact** overflow; with massive `step` the product may overflow to `Inf` without raising a flag, and the subsequent `add` will produce `Inf`. This leads to a condition number of \(\kappa \approx \infty\). | – Rust’s `simd` library follows IEEE‑754 rounding‑to‑nearest‑ties‑to‑even. Subnormal products are flushed to zero unless the target CPU has **flush‑to‑zero** (FTZ) disabled. The code does **not** explicitly disable FTZ; therefore any subnormal product is silently zeroed, reproducing the same loss of contribution as the C++ kernel. |
| **4 – CUDA (cuSOLVER)** | – The eigen‑solve (`DnDsyevd`) is preceded by a scaling of the matrix **B** by `step/scale`. For \(|\text{step}| \ge 10^{10}\) the scaled matrix may exceed the dynamic range of FP64 (≈ 1.8e308). cuSOLVER internally rescales, but the rescaling factor is computed in **single precision** for performance, introducing a relative error of up to 7 · 10⁻⁸. With huge scales the rescaling factor may itself overflow, causing the routine to abort with `CUSOLVER_STATUS_INVALID_VALUE`. <br>– The Woodbury solve uses a **matrix inversion** of `M/scale`. If `scale` is small (e.g. 1e‑9) the matrix becomes ill‑conditioned: \(\kappa(M/scale) = \kappa(M)/|scale|\). This amplifies rounding errors in the subsequent GEMM steps (\(\mathcal{O}(\kappa \cdot \epsilon_{mach})\)). | – For subnormal steps the scaling factor is less than the smallest normal double. The routine attempts to renormalize the matrix by multiplying by `2^{1022}` and dividing the result later. However, `step` itself is stored in a **float32** kernel argument (due to JIT‑generated PTX), causing the subnormal to be rounded to zero before any scaling, effectively turning the update off. |
| **5 – XLA (JAX‑JIT)** | – The HLO fusion chain includes a **Lyapunov solver** expressed as a linear matrix equation \(A X + X A^\top = -C\). The matrix \(A\) is multiplied by `step` before the solver. With `|step| ≥ 10^{10}` the matrix entries become comparable to the exponent limit of FP64 (≈ 1e308). XLA’s JIT lowers the kernel to **bfloat16** for TPU and **float64** for Trainium. For the bfloat16 path the overflow occurs already at \(|\text{step}| ≈ 1e5\), causing NaNs that propagate through the solver. The Trainium path uses FP64 but the JIT introduces **dynamic compilation** of the scaling factor; if the factor exceeds `2^63-1` the constant table overflows, and the compiled kernel stalls. | – When `step` is subnormal, JAX’s `jit` compiler performs **constant folding**: it evaluates `step * A` at compile time. Subnormal `step` is rounded to zero, so the folded constant becomes a zero matrix. The Lyapunov equation reduces to \(0·X + X·0 = -C\) → \(X = -C\), which is mathematically a *different* problem. Moreover, the solver’s internal **Cholesky** factorisation loses the low‑order contributions, deteriorating the solution’s relative error to \(\mathcal{O}(10^{-15})\) even when the true error should be \(\mathcal{O}(10^{-16})\). |
| **6 – Triton (ROCm/NVIDIA)** | – The kernel tiles the sphere \(S^{D-1}\) and performs Clifford bivector rotations via a series of **GEMM** operations. The scaling factor `step` is used to compute the rotation angle (via `θ = step·θ₀`). For \(|\text{step}| ≥ 10^{10}\) the angle exceeds the period of the trigonometric approximations used in the kernel (π‑periodic). The kernel uses a **range‑reduction** that assumes `|θ| < 2π`; beyond that the reduction loses the most significant bits, causing a large relative error in the rotation matrix (condition number \(\kappa ≈ 10^{10}\)). | – Subnormal `step` yields an angle `θ` smaller than the **machine epsilon** (≈ 2