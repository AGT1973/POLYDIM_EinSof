# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 72)

# POLYDIM V1350 — High Tribunal Audit, Cycle 72

**Presiding Sages:** Numerical Analysis, Systems/FFI, Hardware Portability, Formal Methods
**Verdict class:** *Conditional Conformance* — 4 of 6 targets pass with hardening; 2 require remediation before SOTA claim.

Below is the audit, target by target, followed by cross-cutting findings on Rules 22 and 27, then a consolidated remediation ledger.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Binary descriptor `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly (little-endian, standard `struct` alignment disabled):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major, version_minor | `HH` | 4 |
| flags, dtype_code | `HH` | 4 |
| n_rows, n_cols, n_slabs, n_epochs | `QQQQ` | 32 |
| scale_exp, retract_code | `BB` | 2 |
| pad | `6x` | 6 |
| reserved[4] | `4Q` | 32 |
| **Total** | | **84** |

**Finding 1.1 — CRITICAL.** The format string `<4sHHQQQQQBB6x4Q` yields **84 bytes**, not 88. The declared "88-byte PMTP" is violated by 4 bytes. Either:
- the pad must be `10x` (→ 88), or
- the reserved array must be `5Q` (→ 88), or
- the header must include an explicit `I` CRC32 (→ 88).

This is a **Rule 22 hard failure** at the wire level: any peer that trusts the 88-byte stride will misalign every subsequent descriptor, producing silent slab corruption. Recommend `struct.calcsize` assertion at import time:

```python
assert struct.calcsize("<4sHHQQQQQBB10x4Q") == 88
```

### 1.2 HardwareProbe / PmtpSlabAllocator

- Multi-silicon probe is fine, but the allocator must guarantee **page-aligned, hugepage-backed** slabs for zero-copy PMTP. If `mmap(MAP_HUGETLB)` fails and falls back to 4 KiB pages, the CUDA/XLA zero-copy path silently degrades to staged copies — a Rule 27 portability hazard (see §7).
- **12/12 physical conformance checks** are necessary but not sufficient: they must include a *negative* check that the descriptor stride is exactly 88 and that `n_slabs * 88` fits in `size_t` without overflow. Add `n_slabs < 2**48` guard.

### 1.3 Degeneracy at step → ∞ / step → 0

The orchestrator itself is step-agnostic, but it forwards `scale_exp` as a raw `uint8`. If `scale_exp` encodes `log2(step)`, then:
- `step ≥ 10^10` ⇒ `scale_exp ≥ 34` — fine in `uint8`.
- `step → 0` subnormal ⇒ `scale_exp` underflows to 0 and the *actual* scale is lost. **Recommendation:** store `scale_exp` as `int16` biased by 1023 (IEEE-style), or carry a separate `int8 subnormal_shift`.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant is the correct choice over Kahan for non-monotone magnitude sequences. The error bound is:

$$
|\hat{s} - s| \le \big(2u + O(u^2)\big)\sum_i |x_i y_i|, \quad u = 2^{-53}.
$$

**Asymptotic condition number** of the compensated dot is

$$
\kappa_{\text{comp}} = \frac{\sum_i |x_i y_i|}{|\sum_i x_i y_i|} = \kappa_{\text{naive}},
$$

i.e., compensation does **not** reduce the condition number — it only removes the *forward* rounding amplification. For ill-conditioned inputs (cancellation), the *relative* error still scales as `u · κ`. This must be documented; the SOTA claim "compensated ⇒ accurate" is only true in the *absolute* sense.

### 2.2 Subnormal audits at −12, −14

If the audit thresholds are `2^{-12}` and `2^{-14}` in the *exponent* sense (i.e., `1e-12`, `1e-14` in decimal), then on AVX-512 with FTZ/DAZ enabled (the default under `-ffast-math`), **all subnormals are flushed to zero** and the audit is vacuous. Two fixes:

1. Compile the audit TU with `-fno-fast-math -mno-ftz` (or `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)`).
2. Add a runtime probe: `_mm_getcsr() & 0x8040` must be 0 before the audit runs.

**Finding 2.2 — HIGH.** Without this, the "subnormal audit" is a no-op on the very hardware it targets.

### 2.3 Zero-copy PMTP validation

The C++ side must validate the 88-byte descriptor *before* dereferencing. Given Finding 1.1, the C++ `static_assert(sizeof(PmtpDescriptor) == 88)` will **fail to compile** if the struct mirrors the Python format. This is actually the *good* outcome — it forces the discrepancy to surface. Ensure the struct is `#pragma pack(1)` and that `offsetof` checks are emitted for every field.

### 2.4 step → ∞ / step → 0

- `step ≥ 10^10`: the compensated sum's `t` accumulator can overflow `double` if `|x_i y_i|` are large. Guard with `std::isfinite` on the running sum and a `long double` fallback (x87 80-bit) on x86-64.
- `step → 0`: subnormal inputs to `_mm512_fmadd_pd` are handled correctly *only* if FTZ is off (see 2.2). Otherwise the compensated term `t` becomes 0 and the compensation silently vanishes.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the correct choice** for a Rust library exposed over FFI, but only if every `extern "C"` function is wrapped in `std::panic::catch_unwind` and the panic payload is converted to an error code. `panic = "abort"` would be UB across the FFI boundary (unwinding into C++ is UB per the C++ ABI). Verify:

```rust
#[no_mangle]
pub extern "C" fn pmtp_step(...) -> i32 {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1,
    }
}
```

**Finding 3.1 — MEDIUM.** If any `extern "C"` fn lacks `catch_unwind`, a panic in Rust will unwind into C++ and invoke `std::terminate` at best, UB at worst.

### 3.2 Packed 88-byte descriptor

Same as Target 1: `#[repr(C, packed)]` with `#[cfg(test)] assert_eq!(size_of::<PmtpTensorDescriptor>(), 88)`. Given the Python format is 84 bytes, **one of the two is wrong**. The Tribunal rules that the *canonical* layout must be fixed in a single IDL (e.g., a `.h` with `static_assert`) and all three languages must be generated from it.

### 3.3 Safe SIMD + Neumaier

Rust's `std::simd` (nightly) or `wide`/`packed_simd` crates do not expose FTZ control. On x86-64, the MXCSR is per-thread and inherited; if the C++ side sets FTZ, the Rust side inherits it. **Recommendation:** Rust kernel must explicitly clear FTZ/DAZ at entry via `core::arch::x86_64::_mm_setcsr` and restore on exit, or document that it requires the caller to have done so.

### 3.4 step → ∞ / step → 0

Identical to C++: `f64` overflow at large step, subnormal flush at small step. Rust's `f64::is_subnormal` is stable and should gate the audit.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)

The Cayley retraction is

$$
Y(\alpha) = \left(I + \tfrac{\alpha}{2} A\right)^{-1}\left(I - \tfrac{\alpha}{2} A\right) X, \quad A = G X^\top - X G^\top,
$$

where `A` is skew-symmetric. The condition number of the solve is

$$
\kappa_2\!\left(I + \tfrac{\alpha}{2} A\right) = \frac{1 + \tfrac{|\alpha|}{2}\|A\|_2}{1 - \tfrac{|\alpha|}{2}\|A\|_2} \quad \text{for } \tfrac{|\alpha|}{2}\|A\|_2 < 1.
$$

**Finding 4.1 — HIGH.** As `step → ∞` (i.e., `α → ∞`), `κ → ∞` and the retraction becomes numerically singular. The `cuSOLVER DnDsyevd` path (symmetric eigensolver) is **the wrong primitive** for a skew-symmetric `A`: you want `cusolverDnDsyevd` only if you symmetrize, but the Cayley solve is a *linear* solve, not an eigenproblem. If the intent is to use the eigendecomposition of `A` to compute the matrix exponential (a *different* retraction), then the code is mislabeled. **Clarify:** Cayley ⇒ `getrf/getrs`; exponential ⇒ `syevd` on `iA`.

### 4.2 Globally scaled Woodbury solve `(M/scale) W = (step/scale) B`

The Woodbury identity is

$$
(M + UCV)^{-1} = M^{-1} - M^{-1}U(C^{-1} + VM^{-1}U)^{-1}VM^{-1}.
$$

Scaling both sides by `1/scale` is a **left preconditioner**, not a similarity transform. It changes the *residual* but not the *solution* only if `scale` is applied consistently to `B`. Verify:

$$
(M/\text{scale}) W = (\text{step}/\text{scale}) B \iff M W = \text{step} \cdot B.
$$

This is correct **iff** `scale ≠ 0` and `scale` is finite. As `step → ∞`, `step/scale` can