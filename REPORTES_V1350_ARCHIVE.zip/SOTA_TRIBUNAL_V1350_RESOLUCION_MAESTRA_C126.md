# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 126

The requested arbitration cannot be made definitively from the available evidence. I found no public specification, benchmark corpus, kernel source, or recorded outputs for **“POLYDIM V1350,” “PMTP 88-byte Descriptor,” “Cycle 126,”** or the eight alleged Tribunal findings. The public results instead identify **PolyDiM** as a C++ library for polytopal discretization methods, which does not establish a connection to the V1350 kernels.[1][2] Consequently, any model-by-model comparison or claim of “exact architectural guarantees” would be fabricated rather than an evidence-based synthesis.

What can be stated rigorously from established principles is:

### 1. Cayley–Stiefel retraction under extreme steps

For a Stiefel point \(X\) satisfying \(X^\top X=I\), a Cayley update typically has the form

\[
X_{+}
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)X,
\]

where \(A^\top=-A\). In exact arithmetic, whenever the inverse exists, the Cayley factor is orthogonal:

\[
Q^\top Q=I,
\qquad
X_{+}^\top X_{+}=I.
\]

However, this does **not** imply numerical stability for \(|\alpha|\ge 10^{10}\). The implementation must specify:

- whether \(A\) is formed explicitly;
- how the linear system is solved;
- pivoting and conditioning safeguards;
- overflow/underflow handling;
- residual and orthogonality checks;
- behavior when \(I-\frac{\alpha}{2}A\) is ill-conditioned or singular.

Householder QR and polar retraction have different guarantees. Householder QR is generally backward stable for orthogonalization, while the polar factor is the nearest orthonormal matrix in the Frobenius norm under standard nonsingularity assumptions. A Cayley method can preserve structure efficiently, but without a conditioning analysis it cannot be declared superior to Householder or polar QR at extreme step sizes.

A defensible guarantee would therefore be conditional:

\[
\|X_{+}^{\top}X_{+}-I\|
\le
C\,u\,\kappa_{\mathrm{solve}}(A,\alpha),
\]

for a specified norm, floating-point model, solver, and bounded condition number. No unconditional guarantee for \(|\alpha|\ge10^{10}\) follows from the Cayley formula alone.

### 2. PMTP descriptor barriers and RCU/QSBR isolation

Acquire/release operations can establish publication ordering, but they do not by themselves define a complete RCU or QSBR protocol.

A valid publication sequence normally requires:

1. initialize the descriptor and all pointed-to state;
2. perform a release publication of the descriptor pointer or generation;
3. perform an acquire load by readers before dereferencing the published state;
4. ensure readers enter a protected read-side critical section;
5. defer reclamation until every pre-existing reader has passed a quiescent state or otherwise exited protection.

The essential safety property is:

\[
\text{reclaim}(v)
\;\Rightarrow\;
\forall r,\;
r \text{ cannot still dereference } v.
\]

An 88-byte size is not itself an atomicity or isolation guarantee. Unless the descriptor is explicitly defined as a naturally aligned atomic object of supported width—which is unlikely for 88 bytes—publication must use an atomic pointer, index, sequence, or generation field rather than attempting an 88-byte atomic update. The descriptor layout must also specify alignment, padding, field ownership, lifetime, ABA prevention, and reclamation rules.

Thus the strongest justified statement is:

- **release publication plus acquire consumption** can order initialization before observation;
- **RCU/QSBR grace-period rules** can provide lifetime isolation;
- neither mechanism alone guarantees snapshot consistency, atomic multi-field replacement, or safe reclamation.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no universal single memory or numerical semantics shared identically by all five environments. Conformance requires an explicit abstract contract and backend-specific implementation rules.

The contract should separately define:

- numerical precision, rounding mode, tolerances, and allowed nondeterminism;
- matrix-layout and aliasing rules;
- synchronization scope;
- host/device visibility;
- atomic ordering and supported atomic widths;
- descriptor alignment and serialization;
- error handling and unsupported-feature behavior;
- lifetime and reclamation semantics.

C++20 and Rust can express acquire/release memory ordering through their language memory models, but device backends add separate execution and visibility domains. CUDA requires explicit device or system scope where applicable; XLA may legally reorder or fuse operations unless dependencies are represented in its computation graph; Triton’s guarantees depend on its supported atomic and synchronization primitives. Therefore, a C++20 or Rust implementation passing unit tests does not establish CUDA/XLA/Triton conformance.

The appropriate architectural guarantee is conditional:

\[
\text{Conformance}
\iff
\text{each backend refines the same specified contract}
\]

under a defined test suite covering numerical invariants, publication races, reclamation races, compiler transformations, and multi-device visibility.

### Arbitration status

No definitive ranking of Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, and Perplexity is possible because their actual findings were not supplied and are not present in the discoverable public material. The mathematically strongest synthesis supported by the available information is therefore:

- use **Householder QR or a safeguarded polar decomposition** as the baseline for extreme-step orthogonalization;
- permit **Cayley retraction** only with an explicit conditioning, solver-residual, overflow, and fallback contract;
- define PMTP publication through an atomic pointer/index or generation protocol with acquire/release ordering and a separately specified RCU/QSBR grace period;
- treat the 88-byte descriptor as a layout object, not as an atomically replaceable unit;
- establish cross-silicon conformance through a formal backend-neutral contract plus adversarial litmus and numerical tests;
- make no unconditional claims of stability, snapshot isolation, or portability until the missing V1350 specification and eight model reports are provided.