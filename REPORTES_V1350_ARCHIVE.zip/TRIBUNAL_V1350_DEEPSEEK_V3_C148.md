# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 148)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 148 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been asked to audit six artifacts against three named rules (R22, R27) and two numerical limits (`|step| ≥ 1e10`, `step → 0`). We proceed file-by-file, then render a consolidated verdict. Where the artifacts are not physically in front of us, we audit the *specification as stated* and flag every claim that is not falsifiable from the description alone. This is the honest posture: an audit that pretends to have read code it has not seen is worthless.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us count bytes with the rigor the Tribunal demands.

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major | `H` | 2 |
| version_minor | `H` | 2 |
| flags | `Q` | 8 |
| n_rows | `Q` | 8 |
| n_cols | `Q` | 8 |
| stride | `Q` | 8 |
| dtype_code | `Q` | 8 |
| rank | `B` | 1 |
| pad_a | `B` | 1 |
| pad_b | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

**Verdict:** byte count is exact. `struct.calcsize` will return 88 **only if** the format string is compiled with `=` (native, no alignment) or the platform's natural alignment happens to coincide. On x86-64 with default `@` alignment, `4sHH` is 8 bytes (fine), but `Q` requires 8-byte alignment — the two `H` fields followed by `Q` are already aligned, so no padding is inserted. **However**, on a 32-bit ARM target with `@` alignment, `Q` is 8-byte aligned and the layout will still be 88 because the `6x` pad absorbs the difference. **Recommendation:** mandate `struct.Struct("<4sHHQQQQQBB6x4Q")` with explicit little-endian and assert `size == 88` at import time. Do not rely on `@`.

### 1.2 Multi-silicon HardwareProbe

The probe must be **idempotent** and **side-effect-free**. Two failure modes:

- **Probe-induced thermal throttling** on Apple Silicon / Snapdragon when the probe issues a sustained AVX-512 or SVE micro-benchmark. Cap probe duration at ≤ 5 ms and use `RDTSC`/`CNTVCT_EL0` deltas, not wall-clock.
- **NUMA topology drift** on dual-socket EPYC: the probe must re-run if `sched_getcpu()` migrates. Cache the probe result keyed by `(cpu_id, numa_node)`.

### 1.3 PmtpSlabAllocator

A slab allocator for 88-byte descriptors is **pathological**: 88 is not a power of two, and the next power-of-two bucket (128) wastes 31%. Worse, 88 = 8·11, so a slab of 4096 bytes holds 46 descriptors with 48 bytes of tail waste. **Recommendation:** either (a) pad the descriptor to 96 bytes (12·8, cache-line-friendly for 64B lines with 1.5 lines) or (b) use a segregated free-list with exact 88-byte cells and a bitmap. The current design is a **memory-bandwidth tax** on every inter-agent message.

### 1.4 12/12 physical conformance checks

The Tribunal cannot verify 12 unnamed checks. **Demand:** enumerate them. A conformance suite that is not enumerated is a marketing claim, not an audit artifact.

### 1.5 Numerical degeneracy at `step → ∞` and `step → 0`

The orchestrator itself does not perform arithmetic on `step`, but it **routes** it. Two hazards:

- **`step → ∞`:** if `step` is serialized into the 88-byte descriptor as a `Q` (unsigned 64-bit), a negative or NaN step will silently wrap. **Fix:** store `step` as `d` (double) in the reserved region, or as a signed `q` with an explicit sentinel.
- **`step → 0`:** subnormal `step` (|step| < 2⁻¹⁰²²) will be flushed to zero by any downstream kernel compiled with `-ffast-math` or `-ftz=true`. The orchestrator must **reject** `step` in the subnormal range unless the target kernel advertises `FTZ=0`.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:

```
s = x[0]*y[0]; c = 0
for i in 1..n-1:
    t = s + x[i]*y[i]
    if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
    else:                  c += (x[i]*y[i] - t) + s
    s = t
return s + c
```

**Error bound (Neumaier 1974):** `|result − exact| ≤ (2u + O(nu²)) · Σ|xᵢyᵢ|`, where `u = 2⁻⁵³`. This is **not** a true compensated sum — it is a *corrected* sum with one compensation term. For `n > 10⁶` and condition number `κ = Σ|xᵢyᵢ| / |Σxᵢyᵢ| > 10¹⁰`, the residual `c` itself accumulates error. **Recommendation:** for `n > 10⁵`, escalate to **Ogita–Rump–Oishi (ORO) two-product / two-sum** with `K = 2` or `K = 3` iterations. The asymptotic condition number for Neumaier is `κ_eff = κ · (1 + nu)`, which is **linear** in `n` — unacceptable for the `10¹⁰` regime.

### 2.2 Subnormal audits at `-12` and `-14`

These are almost certainly **exponent thresholds** (i.e., `2⁻¹²` and `2⁻¹⁴` relative to some scale). Two issues:

- **`-12`:** `2⁻¹² ≈ 2.44e-4`. This is **not** subnormal in FP64 (subnormal threshold is `2⁻¹⁰²²`). If the audit is checking for values below `2⁻¹²`, it is checking for *small*, not *subnormal*. **Terminology error.**
- **`-14`:** `2⁻¹⁴ ≈ 6.10e-5`. Same issue.

**If** the intent is FP32 subnormals (`2⁻¹²⁶`), the thresholds are wrong by 112 orders of magnitude. **Demand:** clarify the exponent base and the target precision.

### 2.3 Zero-copy PMTP validation

Zero-copy requires that the 88-byte descriptor's `stride` field matches the actual memory layout. **Hazard:** if `stride` is in *elements* but the consumer interprets it as *bytes*, you get silent OOB reads. **Fix:** encode units in `flags` (bit 0: `STRIDE_IN_BYTES`).

### 2.4 AVX-512 + OpenMP

- **AVX-512 downclocking** on Skylake-X: sustained 512-bit FMA drops core frequency by ~15–20%. For a Neumaier loop, the compensation branch (`if |s| >= |t|`) is **data-dependent** and will mispredict. **Recommendation:** use branchless `copysign`-based selection or `_mm512_mask_blend_pd`.
- **OpenMP `reduction(+:s,c)`** is **not** valid for Neumaier — the compensation term is order-dependent. Use `reduction` only on the final `s + c`, or use a tree-reduction with explicit pairwise merging.

### 2.5 Degeneracy at `step → ∞`

If `step` enters as a multiplier on the gradient, `step · g` overflows to `inf` when `step > DBL_MAX / |g|`. The subsequent `x - step·g` becomes `-inf`, and the next iteration produces `NaN`. **Fix:** clamp `step` to `[2⁻¹⁰⁰⁰, 2¹⁰⁰⁰]` at the kernel boundary, or use a scaled representation `(step, scale)` with `step/scale` in `[1, 2)`.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` FFI safety barrier

This is **the single most dangerous claim in the entire audit.** `panic = unwind` across an FFI boundary is **undefined behavior** unless every `extern "C"` function is wrapped in `std::panic::catch_unwind`. The Rust reference is explicit: unwinding past an `extern "C"` frame is UB (it was `abort` in older editions; in Rust 2021 it is still UB per the reference, though `extern "C-unwind"` exists for the specific case of cross-language unwinding).

**Concrete hardening:**

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(desc: *const PmtpTensorDescriptor) -> i32 {
    let result = std::panic::catch_unwind(|| {
        // ... actual work ...
    });
    match result {
        Ok(v) => v,
        Err(_) => -1,  // sentinel; caller must check
    }
}
```

**Additionally:** `catch_unwind` requires `UnwindSafe`. Raw pointers are `UnwindSafe` only if you assert it. Use `AssertUnwindSafe` with a comment justifying the invariant.

**Verdict:** as stated, the FFI barrier is **not sound**. This is a **P0 finding**.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust's `#[repr(C, packed)]` on a struct containing `u64` fields will produce **unaligned loads** on every field access. On x86-64 this is a performance penalty; on ARM64 it is a **SIGBUS** for `ldp`/`stp` on unaligned addresses. **Fix:** use `#[repr(C)]` with explicit `_pad: [u8; N]` fields, or `#[repr(C, align(8))]` and accept 96 bytes. **Do not use `packed` for a hot-path descriptor.**

### 3.3 Safe SIMD

Rust's `std::simd` is still nightly-only as of the 2021 edition. If the kernel uses `core::arch::x86