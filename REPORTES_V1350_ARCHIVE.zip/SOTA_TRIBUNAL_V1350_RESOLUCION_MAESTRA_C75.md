# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 75

The supplied search evidence does **not contain the six Tribunal reports, the V1350 kernel specifications, or an authoritative PMTP descriptor definition**. Therefore, no defensible arbitration can declare a measured winner or an existing “exact architectural guarantee.” The strongest valid synthesis is a **conditional design specification** grounded in established Stiefel-retraction and memory-model principles.

## 1. Extreme-step Stiefel retraction

For \(X\in\mathrm{St}(n,p)\), where \(X^\top X=I\), the standard candidates are:

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)\bigl(I+\Xi^\top\Xi\bigr)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley update of the form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=\left(I-\frac12 W\right)^{-1}
 \left(I+\frac12 W\right)X,
\]

with \(W^\top=-W\) constructed from \(X\) and \(\Xi\). Polar, QR, and Cayley retractions are recognized Stiefel-manifold constructions; the literature identifies Cayley as second-order under the canonical metric, while polar-type constructions have favorable Euclidean-metric properties.[1][2]

### Arbitration

| Criterion | Cayley | Householder/QR | Polar |
|---|---:|---:|---:|
| Exact orthogonality in exact arithmetic | Yes, if the Cayley linear solve is nonsingular | Yes | Yes |
| Behavior for \(\lVert\Xi\rVert\ge 10^{10}\) | Not intrinsically safe | Not intrinsically safe | Not intrinsically safe |
| Overflow/underflow exposure | High in \(W\), products, and solves | High in \(X+\Xi\) and norm calculations | High in \(\Xi^\top\Xi\) |
| Backward-stable implementation path | Conditional | Strong, with pivot/sign safeguards | Strong, with scaled SVD/eigendecomposition |
| Deterministic cross-platform behavior | Difficult | Possible with specified conventions | Possible but expensive |
| Best default for extreme steps | No | Yes, if scaled and rank-defect policy exists | Yes when high accuracy is required |

The decisive point is that **no retraction is automatically stable merely because it preserves orthogonality algebraically**. At \(\lVert\Xi\rVert\approx10^{10}\), naïve formation of \(X+\Xi\), \(\Xi^\top\Xi\), or \(W\) can overflow, lose relative information, or encounter rank deficiency. The polar formula explicitly contains \(\Xi^\top\Xi\), and QR operates on \(X+\Xi\); both therefore require scaling and finite-value checks.[2]

A mathematically superior V1350 policy is:

1. Compute a power-of-two scale \(s\) such that \(\widehat{\Xi}=\Xi/s\) is safely representable.
2. Form the update using scaled quantities.
3. Use **Householder QR with deterministic sign convention** as the robust default.
4. Use a scaled polar/SVD path when the specification requires the closest orthonormal factor.
5. Use Cayley only when the skew system is demonstrably well-conditioned and the implementation uses a stable solve rather than explicit inversion.
6. Detect rank deficiency and return a specified status; do not silently manufacture an orthogonal frame from non-finite or numerically singular input.

Thus, the exact guarantee should be:

\[
\widehat X^\top\widehat X=I+E,\qquad
\lVert E\rVert\le C(n,p)u+\tau_{\mathrm{cond}},
\]

provided the input is finite, scaling succeeds, and the chosen factorization satisfies its stated condition bound. Here \(u\) is machine unit roundoff and \(\tau_{\mathrm{cond}}\) is an explicit conditioning-dependent tolerance. **Bitwise equality and unconditional stability at every step magnitude cannot be guaranteed.**

## 2. PMTP 88-byte descriptors and RCU/QSBR

Acquire/release operations alone do not make an arbitrary 88-byte descriptor an atomic snapshot. The key distinction is:

- **Release** on publication orders prior descriptor initialization before the publication event.
- **Acquire** by a reader orders subsequent reads after observing that publication.
- Neither operation, by itself, makes a multiword descriptor update indivisible.
- If readers can observe fields while a writer modifies them in place, acquire/release is insufficient.

The correct architecture is **immutable-generation publication**:

```text
construct descriptor D completely
initialize all payload and metadata
release-store publication pointer/version to D
reader acquire-loads publication pointer/version
reader accesses only immutable D
retire D after RCU/QSBR grace period
```

If the 88-byte object is copied or updated in place, the design needs an additional mechanism: a seqlock with validation, a double-buffer protocol, a 128-bit or wider atomic publication token where supported, or an RCU-protected pointer to an immutable object.

The exact guarantee should be stated as:

> A reader that performs an acquire load of the published generation and remains inside the RCU/QSBR read-side critical section observes one completely initialized descriptor generation. It observes no partially initialized fields and no reclamation of that generation before its read-side quiescent-state report.

This guarantee requires:

- one atomic publication variable, or an atomic pointer to the descriptor;
- release publication after all descriptor writes;
- acquire observation before any descriptor reads;
- immutable descriptor contents after publication;
- correct reader registration and grace-period completion;
- no premature reclamation;
- defined alignment and lifetime for the 88-byte storage;
- no assumption that the entire 88-byte region is lock-free or atomically copied.

QSBR additionally requires that every participating reader eventually report quiescence. A stalled or permanently active reader can prevent reclamation indefinitely; that is a liveness limitation, not a memory-ordering failure.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

The search evidence establishes an XLA GPU compilation route in which HLO fusion can be converted to TritonIR and then lowered toward PTX.[15] It does **not** establish a V1350-specific conformance matrix across CUDA, XLA, Triton, C++20, and Rust.

Accordingly, source-level equivalence is not an architectural guarantee. The conformance contract must be expressed at the **observable semantic boundary**:

| Area | Required guarantee |
|---|---|
| Numerical result | Same defined result within an explicitly specified error bound |
| Orthogonality | \(X^\top X=I+E\), with a stated norm bound |
| NaN/Inf behavior | Identical classification and specified propagation |
| Descriptor publication | Same acquire/release and reclamation protocol |
| Layout | Explicit size, alignment, offsets, endianness, and padding |
| Atomics | Only operations supported by the target memory model are permitted |
| Synchronization | No dependence on undocumented warp, block, stream, or compiler behavior |
| Determinism | Reduction order, QR sign convention, and tie-breaking are specified |
| Failure behavior | Overflow, rank deficiency, timeout, and unsupported hardware have defined statuses |

CUDA and Triton operate under GPU execution and memory models that differ materially from C++20 and Rust’s abstract memory models. XLA may legally fuse, reorder, or transform operations unless the intermediate representation preserves the required semantics. Rust’s safety guarantees also do not automatically validate foreign GPU memory ordering or FFI lifetime assumptions.

The correct portable implementation therefore uses:

- an ABI-stable descriptor schema generated from one canonical layout definition;
- compile-time size and offset assertions in C++20 and Rust;
- explicit serialization/deserialization rather than language-dependent struct layout;
- backend-specific atomic and fence implementations;
- litmus tests for publication, reclamation, and stale-read prevention;
- numerical differential tests across all backends;
- conformance tests on every supported GPU architecture and compiler version.

## Definitive arbitration

The defensible SOTA synthesis is:

1. **Extreme Stiefel updates:** scaled Householder QR is the default robust path; scaled polar/SVD is the high-accuracy path; Cayley is an optimized conditional path, not an unconditional extreme-step winner.
2. **PMTP descriptors:** use immutable, generation-based descriptors published by a release store and consumed by acquire loads under RCU/QSBR. An 88-byte object must not be treated as one atomic unit without a platform-specific proof.
3. **Cross-silicon portability:** guarantee semantic equivalence, not identical instruction sequences or unrestricted bitwise identity. Every numerical, layout, atomic, synchronization, and failure property must be explicit and tested.
4. **Unconditional claims are rejected:** neither “Cayley is always more stable at \(10^{10}\)” nor “acquire/release atomically snapshots 88 bytes” follows from the available evidence.

The available sources support the standard mathematical distinctions among Cayley, QR, and polar retractions, but they do not validate any V1350-specific benchmark, Tribunal vote, descriptor ABI, or implementation-level guarantee.[1][2][15]