# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 122)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 122 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has examined the six artifacts as *specifications* (the actual source files were not attached to this docket). Where a claim is unverifiable from the docket alone, it is flagged **[UNVERIFIED — SOURCE REQUIRED]**. Where the claim is mathematically decidable from the stated design, the Tribunal rules on the merits.

---

## 0. Cross-Cutting Findings (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens / 88-byte PMTP

The 88-byte descriptor is claimed as `<4sHHQQQQQBB6x4Q` in Python `struct` notation. Let us audit the byte budget:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version, flags | `HH` | 4 |
| dims (4× `Q`) | `QQQQ` | 32 |
| strides (4× `Q`) | `QQQQ` | 32 |
| dtype, rank | `BB` | 2 |
| pad | `6x` | 6 |
| aux (4× `Q`) | `QQQQ` | 32 |
| **Total** | | **112** |

**RULING: FAIL.** The declared format string sums to **112 bytes**, not 88. Either (a) the format string is wrong, (b) the "88-byte" claim is wrong, or (c) the descriptor is a *different* struct than the one shown. This is a **Rule 22 violation** at the wire level: any peer that trusts the "88" constant will misalign every subsequent field. **This must be resolved before any inter-agent traffic is permitted.**

Correct 88-byte layouts that *do* fit:
- Drop `aux` to 2×`Q` (16 B) → 96 B. Still wrong.
- Drop `aux` entirely and use `4sHHQQQQQBB2x` → 4+4+32+32+2+2 = **76 B**. Pad to 88 with `12x`.
- Or: `4sHHQQQQQBB6x2Q` → 4+4+32+32+2+6+16 = **96 B**.

The Tribunal demands the canonical 88-byte layout be published as a single source of truth (a `.h`/`.rs`/`.py` triple with a static assert `sizeof == 88` in C++, `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` in Rust, and `assert struct.calcsize(fmt) == 88` in Python).

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Verdict |
|---|---|---|
| 1 (orchestrator) | none if probe is runtime | **PASS** if `HardwareProbe` is dlopen-based |
| 2 (C++ AVX-512) | Intel/AMD ISA, not vendor | **PASS** (ISA, not vendor) |
| 3 (Rust SIMD) | portable via `std::simd` | **PASS** |
| 4 (CUDA) | **NVIDIA-only** (cuSOLVER, CUDA Graphs) | **FAIL** unless a HIP/ROCm sibling exists |
| 5 (XLA) | **Google TPU + AWS Trainium** | **CONDITIONAL** — two vendors, but no CPU/AMD path |
| 6 (Triton) | AMD + NVIDIA | **PASS** |

**RULING:** Target 4 is the sole hard vendor-lock. Rule 27 requires either (a) a documented `kernel_hip_v1350.cpp` sibling, or (b) an explicit `#ifdef` fallback to Target 2's AVX-512 path when `cuSOLVER` is absent. Target 5's dual-vendor claim is acceptable *only* if the HLO is emitted through a vendor-neutral frontend (JAX) — which it is — but the Tribunal notes that "pure FP64" on Trainium is a **hardware capability question**: Trainium's `NeuronCore` does not expose IEEE-754 binary64 at full rate. **[UNVERIFIED — requires AWS Neuron SDK spec citation.]**

### 0.3 Numerical degeneracy at `|step| → ∞` and `step → 0`

This is the deepest issue and it recurs in Targets 4, 5, 6. We treat it once, rigorously.

Let `W = (step/scale) · B` be the globally scaled Woodbury solve (Target 4). The Cayley retraction on the Stiefel manifold is

```
Y(step) = (I − (step/2) A)⁻¹ (I + (step/2) A) Y₀,   A = Y₀ᵀ H − Hᵀ Y₀  (skew)
```

**Asymptotic condition number.** Let `A` have spectral radius `ρ(A)`. Then

```
κ(I − (step/2)A) = (1 + (step/2)ρ) / (1 − (step/2)ρ)   for step·ρ < 2
```

- **`step → 0`:** `κ → 1`. Well-conditioned. But the *update* `Y − Y₀ = O(step)` is lost to rounding when `step < ε_mach · ‖Y₀‖ / ‖A‖`. For FP64, `ε ≈ 2.2e-16`. If `step < 1e-16`, the retraction is a **no-op** — the manifold point does not move. This is a *silent* degeneracy: no NaN, no exception, just stagnation. **Recommendation:** clamp `step` to `[ε_mach^{1/2} · scale, 2/ρ(A) · (1 − ε_mach^{1/2})]` and emit a `PMTP_FLAG_STEP_CLAMPED` bit in the descriptor's `flags` field.
- **`step → ∞` (`|step| ≥ 1e10`):** `κ → ∞` as `step·ρ → 2`. The Cayley retraction has a **pole at `step = 2/ρ(A)`**. Beyond it, `I − (step/2)A` is indefinite and the "retraction" leaves the Stiefel manifold entirely (the result is not orthogonal). For `|step| ≥ 1e10`, unless `ρ(A) ≤ 2e-10`, the solve is **numerically meaningless**. **Recommendation:** the Woodbury scaling `W = (step/scale) B` does *not* fix this — it only rescales the RHS, not the pole location. The correct fix is to **reparameterize** `step = 2 tan(θ/2) / ρ(A)` with `θ ∈ (−π, π)`, which maps the entire real line to the open interval and eliminates the pole. This is the standard "Cayley → exponential map" bridge.

**Subnormal audit (`-12, -14`).** The claim of "subnormal audits at exponents −12, −14" is ambiguous. If it means *denormal* FP64 values (`~1e-308`), then `-12` and `-14` are **not** subnormal — they are ordinary small numbers. If it means *decimal exponents* `1e-12`, `1e-14`, those are also normal. **RULING: the subnormal audit as described is mislabeled.** True subnormal FP64 begins at `2^-1022 ≈ 2.2e-308`. The Tribunal demands the audit be re-specified: either (a) flush-to-zero (FTZ) behavior at `|x| < 2^-1022`, or (b) gradual underflow preservation. AVX-512 defaults to **gradual underflow** unless `MXCSR.FTZ` is set; OpenMP does not change this. **Recommendation:** explicitly set/clear FTZ and DAZ in the C++ core and document the choice in the PMTP `flags` field.

---

## 1. Target 1 — `kernel_orchestrator_v1350.py`

**Claims:** Multi-silicon `HardwareProbe`, `PmtpSlabAllocator`, 88-byte descriptor, 12/12 physical conformance checks.

**Findings:**

1. **Descriptor size (see §0.1):** the shown format string is 112 B. **FAIL.**
2. **`PmtpSlabAllocator`:** no alignment guarantee is stated. For AVX-512 (Target 2) the slab must be **64-byte aligned**; for CUDA (Target 4) it must be **256-byte aligned** (or `cudaMalloc`-compatible). If the allocator returns `mmap`-backed pages without `posix_memalign`, Target 2 will fault on `vmovapd`. **Recommendation:** `PmtpSlabAllocator(alignment=256)` with a `static_assert` in the C++ consumer.
3. **12/12 conformance checks:** the Tribunal cannot verify these without the check list. **[UNVERIFIED.]** However, the Tribunal notes that "12/12" is a *cardinality* claim, not a *coverage* claim. A 12-check suite that omits (a) endianness, (b) alignment, (c) FTZ/DAZ state, and (d) `step` clamping is **not** a physical conformance suite. **Recommendation:** publish the 12 checks as a table with pass/fail criteria.
4. **`HardwareProbe`:** if it uses `cpuid` + `dlopen("libcuda.so")` + `dlopen("libamdhip64.so")`, it is vendor-neutral. If it hard-codes paths, it violates Rule 27. **[UNVERIFIED.]**

**Verdict:** **CONDITIONAL FAIL** pending descriptor-size correction and alignment guarantee.

---

## 2. Target 2 — `kernel_cpp_v1350.cpp`

**Claims:** C++20 AVX-512 / OpenMP, Neumaier compensated dot products, subnormal audits, zero-copy PMTP validation.

**Findings:**

1. **Neumaier summation.** The Neumaier variant of Kahan is *conditionally* correct: it recovers the lost low-order bits when `|sum| ≥ |x|`, and uses the Kahan branch otherwise. The error bound is
   ```
   |computed − exact| ≤ (2ε + O(nε²)) · Σ|xᵢ|
   ```
   This is **not** a *correctly rounded* dot product. For a true correctly-rounded result, use `_mm512_fmadd_pd` with a two-product (Dekker) split, or `std::fma` in a double-double accumulator. **Recommendation:** if the PMTP contract requires correctly-rounded dot products (it should, for cross-silicon bit-reproducibility), Neumaier is insufficient. Upgrade to **Ogita–Rump–Oishi (ORO) AccSum** or **double-double**.
2. **AVX-512 + OpenMP