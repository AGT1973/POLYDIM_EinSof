# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 143)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 143 · Multi-File Adversarial SOTA Review

**Presiding Sages:** Numerical Analysis, Systems Programming, Heterogeneous Compute, Formal Methods
**Verdict posture:** Adversarial. Claims are treated as unproven until demonstrated.

---

## 0. Preliminary Observations on the Audit Itself

Before touching the six targets, the Tribunal notes a structural issue with the submission: **no source code was provided**. The audit is therefore conducted against the *architectural claims* as stated. Every finding below is conditional on the claim being implemented as described. Where a claim is mathematically impossible or internally inconsistent, we say so unconditionally.

Three claims in the brief are already suspect on their face and will be revisited:

1. **"88-byte binary descriptor `<4sHHQQQQQBB6x4Q`"** — this format string does not sum to 88 bytes. See §2.
2. **"Stiefel Cayley retraction in R^(2K×2K) via cuSOLVER DnDsyevd"** — `DnDsyevd` is a *symmetric* eigensolver; Cayley retraction on Stiefel does not require it. See §4.
3. **"continuous Lyapunov solve in HBM, pure FP64"** on TPU/Trainium — neither backend exposes FP64 at competitive throughput. See §5.

---

## 1. Numerical Degeneracy at `step → ∞` and `step → 0`

### 1.1 The `step → ∞` regime (|step| ≥ 10¹⁰)

**Claim under audit (Target 4):** "globally scaled Woodbury solve (M/scale) W = (step/scale) B".

The scaling trick is the standard remedy for overflow in Woodbury:
```
(M) W = step · B   ⟹   (M/s) (s W) = step · B   ⟹   (M/s) W' = (step/s) B
```
This is **algebraically exact** but numerically only conditionally safe. The Tribunal demands the following proof obligations:

**Theorem (scaling invariance of the relative error).** Let `M ∈ R^{n×n}` be SPD with condition number `κ(M)`. Let `s > 0`. Then the relative forward error of the scaled solve satisfies
```
‖Ŵ − W‖ / ‖W‖  ≤  κ(M) · u + O(u²)
```
*independent of s*, provided `s` is chosen so that `‖M/s‖` and `‖step·B/s‖` are both in the normal range.

**Proof sketch.** The scaled system is `(M/s) W' = (step/s) B`. Its solution is `W' = s W`. Backward error analysis (Higham, *Accuracy and Stability*, Thm 7.2) gives `(M/s + Δ) Ŵ' = (step/s) B` with `‖Δ‖ ≤ c·u·‖M/s‖`. Dividing by `s`: `(M + sΔ) Ŵ = step·B`, and `‖sΔ‖ ≤ c·u·‖M‖`. The perturbation is *scale-invariant*. ∎

**Corollary (the actual danger).** The scaling trick protects against **overflow**, not against **ill-conditioning**. If `κ(M) ≥ 1/u ≈ 10¹⁶` (FP64), no scaling saves you. The brief does not state a bound on `κ(M)`. **Finding 1.1a: missing condition-number guard.**

**Finding 1.1b — `step/scale` underflow.** If `scale` is chosen as `‖M‖_F` and `step = 10¹⁰`, then `step/scale` can be `O(1)` — fine. But if `scale` is chosen as `max(‖M‖, ‖step·B‖)` and `step·B` dominates, then `M/scale` underflows toward subnormal territory. The brief does not specify the scaling rule. **Demand: publish the exact `scale` formula and prove it keeps both operands in `[2^-1000, 2^1000]`.**

**Finding 1.1c — Cayley retraction at large step.** The Cayley retraction on Stiefel is
```
Y(τ) = (I − (τ/2) A)^{-1} (I + (τ/2) A) Y,   A = YᵀG − GᵀY  (skew)
```
As `τ → ∞`, `Y(τ) → −Y` (the antipode). The map is **not** a retraction in the limit — it degenerates to a fixed point. For `τ ≥ 10¹⁰`, the solve `(I − (τ/2)A)^{-1}` has condition number `≈ τ·‖A‖/2`, which for `τ = 10¹⁰` and `‖A‖ = O(1)` gives `κ ≈ 5·10⁹` — **catastrophic loss of ~9 digits**. **Finding 1.1d: no step-clipping / trust-region guard is documented.** Recommendation: clamp `τ ≤ τ_max` where `τ_max · ‖A‖ ≤ 10³`, or switch to a geodesic (matrix exponential) retraction for large steps.

### 1.2 The `step → 0` regime (subnormals)

**Claim under audit (Target 2):** "subnormal audits (−12, −14)".

The notation `(−12, −14)` is ambiguous. The Tribunal interprets it as the exponents `2^-12` and `2^-14` (i.e., `≈ 2.4·10⁻⁴` and `≈ 6.1·10⁻⁵`) — these are **not subnormal** in FP64 (subnormal threshold is `2^-1022`). If instead the intent is *decimal* exponents `10^-12`, `10^-14`, these are also normal. **Finding 1.2a: the "subnormal audit" claim is mislabeled.** True subnormal testing requires inputs near `2^-1022` (FP64) or `2^-126` (FP32).

**Finding 1.2b — Neumaier compensation under subnormals.** Neumaier's algorithm:
```
s = a + b;  c = (|a| ≥ |b|) ? (a − s) + b : (b − s) + a
```
When `a + b` is subnormal, the rounding error `c` is itself subnormal and may be flushed to zero by FTZ/DAZ modes. **AVX-512 with `_MM_FROUND_NO_EXC` does not flush, but `-ffast-math` and some OpenMP runtimes do.** The brief claims "Neumaier compensated dot products" but does not state the FP environment. **Demand: explicit `fesetenv(FE_DFL_ENV)` and `#pragma STDC FENV_ACCESS ON` in the C++ core, and `core::arch::x86_64::_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF)` in Rust.**

**Finding 1.2c — Cayley at `τ → 0`.** `Y(τ) → Y` (identity retraction), which is correct. But the *gradient* `dY/dτ|_{τ=0} = A Y` is computed via `(I − (τ/2)A)^{-1}` — at `τ = 0` this is `I`, and the solve is trivial. No degeneracy. **Pass.**

**Finding 1.2d — Lyapunov at small step (Target 5).** The continuous Lyapunov equation `A X + X Aᵀ = −Q` has solution `X = ∫₀^∞ e^{At} Q e^{Aᵀt} dt`. For small `step`, the discrete-to-continuous conversion `A_d = I + step·A_c` loses precision when `step·‖A_c‖ < u`. **Finding: the XLA kernel must document the `step` floor below which it switches to a direct continuous solver (Bartels–Stewart) rather than the discrete iteration.**

---

## 2. Rule 22 Compliance — 88-Byte PMTP and Zero 1D Tokens

### 2.1 The format string does not sum to 88 bytes

The claimed descriptor format is:
```
<4sHHQQQQQBB6x4Q
```
Let us compute the size (little-endian, standard `struct` alignment disabled by `<`):

| Field | Type | Size (bytes) |
|-------|------|--------------|
| `4s`  | char[4] | 4 |
| `H`   | uint16 | 2 |
| `H`   | uint16 | 2 |
| `Q`   | uint64 | 8 |
| `Q`   | uint64 | 8 |
| `Q`   | uint64 | 8 |
| `Q`   | uint64 | 8 |
| `Q`   | uint64 | 8 |
| `B`   | uint8  | 1 |
| `B`   | uint8  | 1 |
| `6x`  | pad    | 6 |
| `4Q`  | uint64[4] | 32 |

**Sum: 4 + 2 + 2 + 8·5 + 1 + 1 + 6 + 32 = 88 bytes.** ✓

**Correction to the Tribunal's preliminary suspicion:** the format string *does* sum to 88 bytes. The Tribunal withdraws Finding 0.1. However, note that `4Q` is **not** a standard `struct` format character — Python's `struct` does not accept `4Q` as a repeat count for `Q` in the format string; it requires `QQQQ`. **Finding 2.1a: the format string as written is not parseable by `struct.calcsize`.** The correct string is `<4sHHQQQQQBB6xQQQQ`. This is a **concrete, reproducible bug** if the string is used verbatim.

### 2.2 Cross-language layout conformance

The Tribunal demands a **bit-exact** layout proof across Python, C++, Rust, and CUDA. The 88-byte descriptor must satisfy:

- **Python:** `struct.calcsize('<4sHHQQQQQBB6xQQQQ') == 88` ✓
- **C++:** `#pragma pack(push,1)` with `char[4]; uint16_t; uint16_t; uint64_t[5]; uint8_t; uint8_t; uint8_t[6]; uint64_t[4];` → `sizeof == 88` ✓
- **Rust:** `#[repr(C, packed)]` with the same fields → `size_of == 88` ✓
- **CUDA:** same as C++ ✓

**Finding 2.2a — endianness.** The `<` prefix forces little-endian. On a big-endian host (IBM POWER, some ARM BE), the C++/Rust/CUDA sides will silently produce a different byte layout unless they explicitly byte-swap. **Demand: a `POLYDIM_BYTE_ORDER` compile-time assertion, or a runtime `htole