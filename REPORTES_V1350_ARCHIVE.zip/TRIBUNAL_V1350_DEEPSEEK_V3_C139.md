# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 139)

# POLYDIM V1350 — High Tribunal Adversarial Audit (Cycle 139)

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute
**Verdict class:** *Conditional Pass with Mandatory Remediations* — 4 of 6 targets fail at least one Rule; 2 targets require FFI hardening before production.

Below is the full audit. Claims are separated into **Verified**, **Unverifiable from artifact alone**, and **Refuted / Degenerate**.

---

## 0. Cross-cutting invariants (apply to all 6 targets)

### 0.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version | `H` | 2 |
| flags | `H` | 2 |
| dims (K) | `Q` | 8 |
| stride0 | `Q` | 8 |
| stride1 | `Q` | 8 |
| offset | `Q` | 8 |
| nbytes | `Q` | 8 |
| rank | `B` | 1 |
| dtype | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

**Verified:** 4+2+2+8+8+8+8+8+1+1+6+32 = **88 bytes exactly**. Alignment is 8 (largest member `Q`), so `sizeof == 88` under `#pragma pack` or explicit `__attribute__((packed))`. **Rule 22 (88-byte PMTP) is structurally satisfied at the layout level.**

**Caveat (Rule 22 semantic):** Rule 22 also forbids *1-D token streams* in inter-agent communication. The descriptor is a fixed-size record — good. But **Target 5 (XLA)** and **Target 6 (Triton)** must be checked for whether they ever serialize variable-length HLO/IR blobs across the agent boundary. See §5, §6.

### 0.2 Rule 27 (Silicon Contract — no vendor lock)

| Target | Vendor coupling | Rule 27 |
|---|---|---|
| 1 orchestrator | Multi-silicon probe (claimed) | ✅ if probe is truly polymorphic |
| 2 C++ AVX-512 | Intel/AMD x86 only | ⚠️ **ISA lock**, not vendor lock — acceptable if a scalar fallback exists |
| 3 Rust SIMD | portable via `std::simd` | ✅ |
| 4 CUDA | **NVIDIA-only** (cuSOLVER, CUDA Graphs) | ❌ **hard vendor lock** |
| 5 XLA | **Google TPU / AWS Trainium** | ❌ **dual vendor lock** |
| 6 Triton | ROCm + CUDA | ⚠️ dual-vendor but open ISA path |

**Finding:** Targets 4 and 5 violate Rule 27 as written. Remediation: a `PmtpBackend` trait with a CPU reference implementation must be the *default* dispatch, with CUDA/XLA as accelerators, not as the only path.

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator
- **Verified (structural):** A multi-silicon probe that returns a capability bitmask is the correct pattern for Rule 27. The 12/12 physical conformance checks are only meaningful if each check is *independently falsifiable* — the audit cannot confirm this from the description alone.
- **Unverifiable:** Whether the probe uses `cudaGetDeviceProperties`, `hipGetDeviceProperties`, `xla_client` topology, and `sysfs` CPU flags in a *non-blocking* manner. If any probe call blocks on a missing driver, the orchestrator becomes a DoS vector.

### 1.2 Numerical degeneracy at step extremes
The orchestrator itself does not perform arithmetic on `step`, but it *routes* it. **Required invariant:** the orchestrator must clamp or reject `|step| ≥ 1e10` and `0 < |step| < DBL_MIN` **before** dispatch, otherwise downstream kernels see inputs they cannot represent.

**Recommendation:** add a `PmtpStepGuard` that enforces
```
step ∈ {0} ∪ [DBL_MIN_NORMAL, 1e10]
```
and emits a structured `PMTP_ERR_STEP_RANGE` (88-byte record) rather than a Python exception, to preserve Rule 22.

### 1.3 Rule 22 compliance
- Descriptor layout ✅.
- **Risk:** Python `dict`/`json` payloads between orchestrator and subprocesses are 1-D token streams. **Refuted unless** the orchestrator uses `struct.pack('<4sHHQQQQQBB6x4Q', ...)` for *every* IPC message. Demand a code-level grep for `json.dumps` / `pickle` on the hot path.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product
Neumaier's variant of Kahan–Babuška:
```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
    else:                c += (x_i*y_i - t) + s
    s = t
return s + c
```
**Error bound (verified):** for `n` terms, `|result − exact| ≤ (2u + O(nu²)) · Σ|x_i y_i|`, where `u = 2⁻⁵³`. This is **unconditionally stable** — no cancellation blow-up. ✅

### 2.2 Subnormal audits at −12, −14
- `2⁻¹² ≈ 2.44e-4`, `2⁻¹⁴ ≈ 6.10e-5` — these are **normal** doubles, not subnormals. If the audit is testing *scaled* quantities (e.g., `step · 2⁻¹²`), then with `step → 0` you enter the subnormal range at `step < 2⁻¹⁰²²⁺¹² ≈ 2⁻¹⁰¹⁰`.
- **Degeneracy:** AVX-512 `vfmadd` on subnormals is **not** guaranteed to be FTZ-free. If the kernel is compiled with `-ffast-math` or `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON)`, the −12/−14 audits will silently pass on normal inputs and fail catastrophically on subnormal ones.
- **Demand:** explicit `_MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_OFF)` and a unit test that feeds `DBL_MIN/2`.

### 2.3 Zero-copy PMTP validation
- **Verified if:** the kernel validates `magic == 'PMTP'`, `version`, `nbytes == prod(dims)*sizeof(dtype)`, and `offset + nbytes ≤ slab_size` **before** dereferencing. Any missing check is a TOCTOU / OOB read.
- **FFI hardening:** the C++ side must treat the 88-byte descriptor as `const volatile` and re-validate after any `mmap`/`mprotect` boundary.

### 2.4 Rule 27
AVX-512 is an **ISA lock**, not a vendor lock. Acceptable **only if** a scalar/AVX2 fallback is compiled in. Demand `#ifdef __AVX512F__` guards with a runtime `__builtin_cpu_supports("avx512f")` dispatch.

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier
**This is the most dangerous claim in the audit.**

- `panic = unwind` across an `extern "C"` boundary is **undefined behavior** in Rust 2021 unless the function is marked `extern "C-unwind"`. A panic unwinding into C++/CUDA code will corrupt the stack.
- **Correct pattern:** `extern "C"` functions must wrap bodies in `std::panic::catch_unwind` and convert to an error code, **or** the crate must be compiled with `panic = abort` for the FFI surface.
- **Verdict:** ❌ **Refuted as stated.** `panic = unwind` is *not* a safety barrier; it is a safety *hazard* at the FFI edge.

### 3.2 Neumaier sums
Same bound as §2.1. ✅ **Provided** the Rust code does not use `f64::mul_add` under `-C target-feature=+fma` without checking that the compiler preserves the compensation term. LLVM is permitted to reassociate under `fast-math` flags — Rust does not enable these by default, so ✅.

### 3.3 Packed 88-byte descriptor
- `#[repr(C, packed)]` on a struct with `u64` fields produces **unaligned** field access. On x86 this is slow but legal; on ARM (Trainium host, Graviton) it is a **SIGBUS**.
- **Demand:** `#[repr(C, align(8))]` with explicit `_pad: [u8; 6]` — this yields `size_of == 88` **and** `align_of == 8`, which is what the C++ side expects.

### 3.4 Rule 22 / Rule 27
- ✅ 88-byte record.
- ✅ No vendor lock (Rust SIMD is portable).

---

## 4. TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)
Cayley retraction: `Y = (I − ½W)⁻¹ (I + ½W) X`, where `W = A Xᵀ − X Aᵀ` is skew-symmetric.

- **Verified:** `W` skew ⇒ `(I − ½W)` is invertible for all real `W` (eigenvalues of `W` are purely imaginary, so `1 − ½λ ≠ 0`). ✅
- **Condition number:** `κ(I − ½W) = max|1 − ½iλ| / min|1 − ½iλ| = sqrt(1 + ¼λ_max²) / 1`. For `‖W‖ = O(step)`, `κ ≈ ½|step|·‖A‖`. **At `step = 1e10`, κ ≈ 5e9 · ‖A‖** — near the edge of FP64 resolvability (`1/u ≈ 4.5e15`). **Degeneracy confirmed for large step.**

### 4.2 Globally scaled Woodbury solve `(M/scale) W = (step/scale) B`
- Scaling by `scale` is a **preconditioner**,