# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 155)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 155 · Six-Component Adversarial Review

**Preliminary note on scope.** No source files were attached to this submission. The audit below is therefore conducted against the *architectural claims* as stated in the brief, using the canonical semantics that each named primitive (Neumaier summation, Cayley retraction, Woodbury identity, Lyapunov solve, PMTP descriptor) implies. Where a claim is under-specified, I flag it as **UNVERIFIABLE** rather than assume a favorable reading. This is the correct posture for a tribunal: silence in the record is not evidence of correctness.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let me lay out the struct arithmetic explicitly, because the brief asserts "88 bytes" and the format string must be checked, not trusted.

| Field | Format | Size (bytes) |
|---|---|---|
| magic | `4s` | 4 |
| version_major | `H` | 2 |
| version_minor | `H` | 2 |
| flags | `Q` | 8 |
| n_rows | `Q` | 8 |
| n_cols | `Q` | 8 |
| stride | `Q` | 8 |
| scale_bits | `Q` | 8 |
| dtype | `B` | 1 |
| rank | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

**Verdict: arithmetic is correct.** 4+2+2+8+8+8+8+8+1+1+6+32 = 88. ✓

**But three adversarial observations:**

**(a) Native alignment vs. packed layout.** Python's `struct` with `<` is *standard size, no alignment* — so 88 is the packed size. However, `Q` fields at offsets 8, 16, 24, 32, 40 are 8-aligned only because the preceding fields happen to sum to a multiple of 8. The `4Q` reserved block starts at offset 56 (8-aligned ✓). **The layout is accidentally alignment-clean.** If anyone ever inserts a `B` before a `Q`, the descriptor silently becomes misaligned for C/Rust/CUDA consumers. **Recommendation:** add a `_Static_assert(sizeof(PmtpTensorDescriptor) == 88, ...)` in the C++ header, `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` in Rust, and a `struct.calcsize` assertion in Python. This is the *only* way to make the 88-byte contract enforceable across four languages.

**(b) Endianness.** `<` forces little-endian. On a big-endian host (POWER9, some s390x), the orchestrator will produce descriptors that the C++/Rust/CUDA kernels misread. **This is a Rule 27 (Silicon Contract) violation** if any target platform is BE. Either pin to LE explicitly in the contract, or use `=` with a documented ABI.

**(c) `scale_bits: Q` as a bit-pattern.** Storing a float scale as a `Q` bit-pattern is correct for bit-exactness, but the brief does not state whether it's IEEE-754 binary64 or a fixed-point Q-format. If it's binary64, then `scale = 0` (all-zero bits) and `scale = -0.0` (sign bit set) are *distinct* bit patterns that compare equal numerically. Downstream Woodbury solves that divide by `scale` will produce `+inf` vs `-inf` respectively. **This is a latent degeneracy at the descriptor layer.**

### 1.2 "12/12 physical conformance checks"

**UNVERIFIABLE** without the check list. A tribunal cannot certify a count without the enumeration. If the 12 checks are the usual suspects (magic, version, dtype∈{fp32,fp64}, rank≤max, strides monotone, scale≠0, scale finite, n_rows·n_cols ≤ allocator cap, reserved==0, pad==0, alignment, checksum), then the *critical* missing check is **`scale` subnormal detection** — see §1.3.

### 1.3 Degeneracy at step → ∞ and step → 0

The orchestrator's `PmtpSlabAllocator` and `HardwareProbe` are not themselves numerical, but they *gate* the numerical kernels. Two failure modes:

- **step → ∞ (|step| ≥ 10¹⁰):** If `scale_bits` encodes `step` or a function of it, and the orchestrator validates `scale` only for finiteness, then `scale = 1e300` passes. Downstream Woodbury `(M/scale) W = (step/scale) B` becomes `(M/1e300) W = (1e10/1e300) B` → the RHS underflows to zero, the solve returns `W = 0`, and the retraction silently becomes the identity. **The orchestrator must reject `|scale| > 2^512` or similar.**
- **step → 0 (subnormal):** `scale = 5e-324` (min subnormal) passes a finiteness check. `step/scale = 1e-10 / 5e-324 = 2e313` → overflow to `+inf`. The Woodbury solve then produces `NaN` via `inf - inf`. **The orchestrator must reject `0 < |scale| < 2^-1022` (i.e., subnormal scale).**

**Recommendation:** Add checks 13 and 14: `isnormal(scale)` and `|scale| ∈ [2^-512, 2^512]`. The "12/12" claim should become "14/14."

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan summation achieves a *forward* error bound of

$$|\hat{s} - s| \le \left(2u + \mathcal{O}(nu^2)\right) \sum_{i=1}^{n} |x_i y_i|$$

where `u = 2^-53` for binary64. This is **not** a backward-stable algorithm in the classical sense — it is *forward-stable with a condition-number factor*. The relevant asymptotic condition number for the dot product is

$$\kappa_{\text{dot}} = \frac{\sum_i |x_i y_i|}{|\sum_i x_i y_i|}$$

which is **unbounded** when catastrophic cancellation occurs (e.g., `x·y` near zero with large `|x_i y_i|`). Neumaier *does not fix this* — it only removes the `n·u` growth of naive summation. **The brief's claim of "compensated dot products" must not be read as "cancellation-immune."**

**Adversarial test:** `x = [1e16, 1, -1e16]`, `y = [1, 1, 1]`. True sum = 1. Naive = 0. Neumaier = 1. ✓ But `x = [1e308, 1e308, -1e308, -1e308]`, `y = [1,1,1,1]`: true = 0, Neumaier returns 0 but the *intermediate* `1e308 + 1e308 = inf` → `inf - 1e308 - 1e308 = NaN`. **Neumaier does not protect against overflow in the running sum.** For `|step| ≥ 10¹⁰` with large operands, this is a live risk.

**Recommendation:** Pair Neumaier with a *scaling* pass (compute `max|x_i y_i|`, scale by `2^-⌈log2 max⌉`, sum, rescale). This is the standard "scaled compensated summation" and is what LAPACK's `DLASSQ` does.

### 2.2 Subnormal audits at -12, -14

The brief cites exponents -12 and -14. These are **not** IEEE-754 binary64 subnormal thresholds (which are `2^-1022` and below). They are almost certainly **decimal exponents** in a test harness: `1e-12` and `1e-14`. If so:

- `1e-12` is a *normal* binary64 (≈ `2^-39.86`). No subnormal handling required.
- `1e-14` is also normal (≈ `2^-46.5`).

**If the audit is claiming subnormal coverage at these magnitudes, it is mislabeled.** True subnormal tests require `1e-308` to `5e-324`. **This is a material misrepresentation in the brief and should be corrected before any certification.**

If instead -12/-14 are *bit-exponent* offsets (i.e., `2^-12`, `2^-14`), they are still normal. Either way, **the subnormal audit as described does not exercise subnormals.**

### 2.3 Zero-copy PMTP validation

Zero-copy requires that the 88-byte descriptor's `n_rows`, `n_cols`, `stride`, and `dtype` exactly match the memory the kernel will read. The adversarial failure mode: **TOCTOU** — the orchestrator validates the descriptor, then the producer mutates the underlying buffer before the kernel reads it. Zero-copy without a generation counter or seqlock is a data race. **Recommendation:** add a `generation: Q` field (using 8 of the 32 reserved bytes) and have the kernel re-check it after the first read.

### 2.4 AVX-512 / OpenMP

- **AVX-512 downclocking** on Skylake-X and Ice Lake server parts can reduce throughput by 15–40% for mixed workloads. The brief does not state whether the kernel uses 512-bit or 256-bit vectors. If 512-bit, the "SOTA" claim needs a frequency-normalized benchmark.
- **OpenMP `reduction(+:...)`** does *not* use Neumaier compensation. If the kernel parallelizes the dot product with `#pragma omp parallel for reduction(+:acc)`, the compensation is lost. **The brief must specify that Neumaier is applied per-thread and the per-thread results are combined with a compensated tree reduction.**

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the single most dangerous claim in the brief.** `panic = unwind` across an FFI boundary is **undefined behavior** unless every `extern "C"` function is wrapped in `std::panic::catch_unwind`. The Rust reference is explicit: unwinding past an `extern "C"` frame is UB (it was made abort-on-unwind in Rust 1.71+ for `extern "C"`, but the *default* for `extern "Rust"` and for `panic=unwind