# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 135)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 135 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal treats each target as a *claim of correctness* under adversarial perturbation. We do not accept "it compiles" as evidence. We require: (i) a stated numerical contract, (ii) a proof or counterexample at the boundary, (iii) a silicon-portability witness, and (iv) an FFI memory-safety argument. Where the artifact is not in front of us, we audit the *specification as stated* and flag every place where the spec is under-determined — because under-determination is where vendor lock and numerical degeneracy hide.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us count bytes with the rigor the format demands.

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Verdict:** byte-exact. Alignment is *not* guaranteed by `struct` default on all ABIs — `Q` requires 8-byte alignment, and the leading `4sHH` = 8 bytes puts the first `Q` at offset 8 ✓, the second at 16 ✓, …, the fifth at 40 ✓, then `BB` at 48, pad to 56, then `4Q` at 56, 64, 72, 80 → ends at 88. **Alignment is clean on LP64 and on Windows x64.** On a 32-bit ABI with `Q` alignment 4, the layout still packs to 88 but the *natural* alignment is 4, so `memcpy`-based transport is mandatory. **Recommendation:** emit `_pack_ = 1` explicitly and assert `ctypes.sizeof == 88` at import time; do not rely on ABI defaults.

### 1.2 Multi-silicon HardwareProbe

The probe is the *only* place vendor lock can be legitimately quarantined. The Tribunal's Rule 27 test: **does the probe return a capability set, or a vendor enum?** If it returns `{"cuda": True, "rocm": True, "tpu": True, "trainium": True, "avx512": True}` — fine. If it returns `"nvidia"` — vendor lock, fail.

**Required invariant:** the orchestrator must select a kernel by *capability predicate*, never by *vendor string*. Formally, let `C = {c_1, …, c_n}` be the capability vector. The dispatch function `D: C → Kernel` must satisfy `D(C) = D(C')` whenever `C ≡ C'` under the capability algebra. Any `if vendor == "nvidia"` branch is a Rule 27 violation.

### 1.3 PmtpSlabAllocator

The slab allocator is where the 88-byte descriptor meets physical memory. The Tribunal demands:

- **Alignment:** every slab must be 64-byte aligned (cache line) *and* 4096-byte aligned (page) for zero-copy DMA. If the allocator returns 8-byte-aligned slabs, the CUDA/XLA zero-copy path silently degrades to a copy — a correctness-preserving but performance-violating outcome.
- **Descriptor atomicity:** the 88-byte descriptor must be written with a single `memcpy` under a release fence, or split into an 8-byte atomic header + 80-byte payload with a seqlock. A torn 88-byte write across a cache-line boundary (offset 56–63 straddles 64) is a **real** race. **This is the single most likely production bug in Target 1.**

### 1.4 12/12 physical conformance checks

Without the check list we cannot verify, but the Tribunal requires that the 12 checks include at minimum:

1. `sizeof(descriptor) == 88`
2. `alignof(descriptor) >= 8`
3. magic round-trip
4. endianness round-trip
5. slab alignment ≥ 64
6. slab alignment ≥ 4096 (for DMA)
7. descriptor write is atomic (seqlock or single-cache-line)
8. capability probe returns set, not enum
9. dispatch is vendor-agnostic
10. subnormal handling declared
11. step-magnitude guard present
12. FFI boundary is `extern "C"` with no C++ exceptions crossing

If any of 7, 8, 9, 10, 11 is missing, the "12/12" is a *count*, not a *conformance*.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:

```
s = 0; c = 0
for x, y:
    t = s + x*y
    if |s| >= |x*y|: c += (s - t) + x*y
    else:            c += (x*y - t) + s
    s = t
return s + c
```

**Error bound (Neumaier 1974):** for `n` terms with unit roundoff `u`,

```
|computed − exact| ≤ (u + O(n u²)) · Σ|x_i y_i|
```

i.e. **first-order accurate in `u`, independent of `n`** — the catastrophic cancellation of naive summation is removed to first order. This is the correct choice for the PMTP inner products.

**Adversarial case:** if `x*y` overflows to `inf` and `s` is finite, `t = inf`, `s - t = -inf`, `c += -inf + inf = NaN`. **Neumaier is not overflow-safe.** The Tribunal demands an explicit `isfinite` guard or a scaled variant (`x/scale`, `y/scale`, multiply back) whenever `|x|·|y| > DBL_MAX/2`.

### 2.2 Subnormal audits at −12 and −14

The notation `(-12, -14)` almost certainly means *exponent thresholds*: values below `2^-12` and `2^-14` are audited. Two readings:

- **Reading A (denormal detection):** `2^-12` and `2^-14` are *not* subnormal for FP64 (subnormal starts at `2^-1022`). So this must be FP32 or FP16. For FP32, subnormal starts at `2^-126`; `2^-12` and `2^-14` are *normal*. **This reading is inconsistent.**
- **Reading B (relative-magnitude audit):** the kernel audits whether any intermediate falls below `2^-12` or `2^-14` *relative to the max magnitude* — i.e. a dynamic-range audit. This is the only reading that makes sense for FP64.

**Tribunal ruling:** the spec is ambiguous. Demand the audit be stated as `|x| < 2^-12 · max|x|` (relative) or `|x| < 2^-1022` (absolute FP64 subnormal). As written, `(-12, -14)` is a **numerical degeneracy hazard**: if the kernel flushes these to zero (FTZ/DAZ), it silently violates IEEE-754 and the Neumaier compensation becomes meaningless.

**Concrete test:** feed `x = [1.0, 2^-13, 2^-15]`, `y = [1.0, 1.0, 1.0]`. Exact sum = `1 + 2^-13 + 2^-15`. With FTZ at `2^-14`, the `2^-15` term vanishes → relative error `2^-15 ≈ 3e-5`. **Unacceptable for a "SOTA" kernel.**

### 2.3 AVX-512 / OpenMP

- **AVX-512 downclocking:** on Skylake-X, sustained 512-bit FMA causes frequency throttling. The Tribunal requires a *measured* throughput claim, not a theoretical one. On Ice Lake / Sapphire Rapids this is largely resolved.
- **OpenMP reduction:** `#pragma omp parallel for reduction(+:s,c)` on Neumaier is **incorrect** — the compensation term is not associative. Each thread must accumulate its own `(s_i, c_i)` pair, then a *tree* of Neumaier merges must combine them. A naive `reduction(+:)` on `s` and `c` separately loses the compensation. **This is a correctness bug if present.**

### 2.4 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be *pinned* and *page-aligned*. The C++ side must validate:

```cpp
static_assert(sizeof(PmtpDescriptor) == 88);
static_assert(alignof(PmtpDescriptor) == 8);
```

and at runtime, `reinterpret_cast<uintptr_t>(ptr) % 4096 == 0`. Without the runtime check, zero-copy silently becomes a copy on misaligned slabs.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` FFI safety barrier

**This is the most dangerous line in the entire audit.** `panic = unwind` across an FFI boundary is **undefined behavior** unless every `extern "C"` function is wrapped in `catch_unwind`. The Rust reference is explicit: unwinding across `extern "C"` is UB (it was made abort-on-unwind in Rust 1.71+ for `extern "C"`, but `extern "C-unwind"` is the only sound way to unwind across FFI).

**Tribunal ruling:** `panic = unwind` is acceptable **only if** every FFI entry point is:

```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> i32 {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1,  // or a defined error code
    }
}
```

Otherwise, set `panic = abort` for the FFI crate. **This is a hard Rule 27 / soundness violation if unaddressed.**

### 3.2 Safe SIMD

Rust 2021 `std::simd` is nightly-only. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe` and require `#[target_feature(enable = "avx512f")]`. The "Safe SIMD" claim is only true if the kernel uses `std::simd` (nightly) or a safe wrapper like `wide` / `pulp`. **Demand the exact crate and version.**

### 3.3 Neumaier in Rust

Same overflow caveat as C++. Additionally, Rust's default is **no FTZ/DAZ** — good. But `-C target-feature=