# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 117

The requested arbitration cannot be made definitively from the available evidence: **POLYDIM V1350, its six kernels, PMTP’s 88-byte descriptor, and the eight Tribunal reports are not publicly identifiable or provided in the prompt**. The available literature supports only general mathematical and systems conclusions, not V1350-specific architectural guarantees.

## Evidence-based arbitration

### 1. Cayley–Stiefel retraction versus Householder/Polar QR for \(|\mathrm{step}|\ge 10^{10}\)

A Cayley transform is a valid Stiefel-manifold retraction and is second-order accurate under the canonical metric.[1][2] However, that fact does **not** establish numerical stability for arbitrarily large steps.

For an update of the form

\[
Y(\alpha)
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)X,
\]

where \(A^\mathsf{T}=-A\), the exact transform is orthogonal when the inverse exists. In floating-point arithmetic, extreme \(\alpha\) creates several risks:

- conditioning and roundoff in solving \(I-\frac{\alpha}{2}A\);
- overflow or loss of significance in forming scaled terms;
- instability if the implementation uses an iterative, incompletely converged solve;
- loss of orthogonality from finite-precision residuals.

The Cayley method is therefore **not unconditionally superior** at \(|\mathrm{step}|\ge 10^{10}\). Its stability depends on scaling, factorization, residual control, and the spectrum of \(A\).

Householder QR is generally the safer baseline for explicit orthogonalization because it uses backward-stable orthogonal transformations. Polar decomposition can provide a high-quality nearest-orthogonal factor, but its implementation must itself be stable—typically through SVD, a stable Newton–Schulz variant, or a carefully conditioned eigensolver. QR is usually preferable when the primary requirement is robust orthonormalization; polar methods are attractive when nearest-factor accuracy is the objective.

**Arbitrated result:** no unconditional “Cayley wins” guarantee is justified. A defensible SOTA design is:

1. scale or normalize the step before constructing the update;
2. use a stable solve rather than explicit inversion;
3. monitor residual and orthogonality error;
4. fall back to Householder QR or a stable polar kernel when conditioning or residual thresholds fail;
5. specify a finite-precision error bound and tested step range.

The strongest valid guarantee is conditional:

\[
\|Y^\mathsf{T}Y-I\|
\le
C\,u\,\kappa(\text{update solve})+\text{iteration residual},
\]

not exact orthogonality for arbitrary step magnitude.

### 2. PMTP 88-byte descriptors and Acquire/Release semantics

No public specification for “PMTP” or the claimed 88-byte descriptor was found, so its layout, ownership protocol, publication fields, and supported memory models cannot be verified.

In a conventional RCU/QSBR design, Acquire/Release ordering can provide snapshot publication only under explicit protocol conditions:

- the writer fully initializes the immutable object;
- the writer performs a **Release** store of the descriptor pointer, generation, or publication sequence;
- the reader performs an **Acquire** load of that publication field before dereferencing the object;
- readers announce quiescent-state participation before reclamation;
- reclamation waits until every pre-existing reader has passed through a grace period;
- descriptor fields are immutable after publication, or each mutable field has its own valid synchronization.

Acquire/Release alone does not automatically make an entire descriptor atomic, nor does it prevent reclamation races. If the 88-byte object crosses cache lines, is misaligned, or is updated piecemeal, readers may observe torn or internally inconsistent state unless the protocol avoids in-place mutation.

**Arbitrated result:** the exact architectural guarantee should be stated as:

> A reader observes a fully initialized, immutable snapshot if and only if publication uses a Release operation, acquisition uses a matching Acquire operation, and reclamation is delayed by a correctly implemented RCU/QSBR grace period.

It is not valid to claim that “Acquire/Release guarantees snapshot isolation” without those additional invariants. Sequential consistency, atomic pointer publication, version validation, or a seqlock may be required depending on whether descriptors are copied, replaced, or mutated in place.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

Cross-silicon conformance cannot be inferred from mathematical equivalence alone. CUDA, XLA, Triton, C++20 atomics, and Rust atomics expose different compilation and memory-model constraints:

- CUDA device memory ordering depends on scope and operation semantics.
- XLA may fuse, reorder, or lower operations according to its compiler IR semantics.
- Triton kernels require explicit synchronization and have backend-dependent lowering behavior.
- C++20 defines the host-language atomic model but does not automatically specify accelerator behavior.
- Rust’s atomic guarantees apply through the target platform’s supported memory model and do not by themselves define GPU kernel semantics.

Consequently, a portable implementation needs a common abstract contract, such as:

- descriptor publication is a release event;
- snapshot acquisition is an acquire event;
- object contents are immutable after publication;
- reclamation occurs only after a grace period;
- numerical kernels meet specified backward-error and orthogonality tolerances;
- unsupported atomic widths, scopes, or alignment requirements cause compilation failure or a documented fallback.

**Arbitrated result:** conformance should be claimed only per backend and per device architecture after litmus tests, compiler-lowering inspection, stress tests, and numerical differential testing. “Compiles on all five stacks” is not equivalent to “has identical ordering or numerical guarantees.”

## Definitive synthesis

The mathematically and architecturally defensible SOTA position is:

1. **Retraction:** use Cayley only with scaling, stable solves, residual checks, and a QR/polar fallback. Do not guarantee stability solely from the Cayley formula at \(|\mathrm{step}|\ge 10^{10}\).
2. **Snapshot protocol:** use Release publication plus Acquire observation, immutable snapshots, and a proven RCU/QSBR grace-period protocol. Descriptor size—88 bytes—does not itself provide atomicity or isolation.
3. **Portability:** define one abstract memory and numerical contract, then prove it separately for CUDA, XLA, Triton, C++20, and Rust through backend-specific implementation and validation.
4. **Guarantee boundary:** without the actual eight reports, kernel definitions, descriptor layout, device targets, compiler versions, and test data, no model-by-model arbitration or exact V1350 architectural guarantee can be established.

The search evidence confirms general Cayley-retraction properties, including its Stiefel validity and second-order behavior,[1][2] but it does not substantiate the proprietary V1350 claims.