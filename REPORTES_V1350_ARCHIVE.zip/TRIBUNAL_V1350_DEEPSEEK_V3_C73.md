# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 73)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 73 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been asked to audit six artifacts whose *source text was not supplied* — only their architectural claims. We therefore audit the **claims as stated**, flag every place where the claim is either (a) mathematically under-determined, (b) numerically degenerate, or (c) contract-violating, and we issue **conditional verdicts** keyed to the invariants that must hold for the claim to be true. Where a claim cannot be true as stated, we say so.

---

## §0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Claimed layout: `<4sHHQQQQQBB6x4Q`

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version | `H` | 2 | 4 |
| flags | `H` | 2 | 6 |
| dim0 | `Q` | 8 | 8 |
| dim1 | `Q` | 8 | 16 |
| dim2 | `Q` | 8 | 24 |
| dim3 | `Q` | 8 | 32 |
| stride | `Q` | 8 | 40 |
| dtype | `B` | 1 | 48 |
| rank | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| aux[4] | `4Q` | 32 | 56 |
| **Total** | | **88** | 88 |

**Verdict:** Structurally sound *only if* the compiler is told `alignas(8)` (or `#[repr(C, align(8))]`). Without explicit alignment, `Q` fields at offsets 8, 16, 24, 32, 40 are naturally aligned, but the trailing `4Q` at offset 56 is also 8-aligned — so the layout is *self-consistent*. **However**, `struct.pack('<4sHHQQQQQBB6x4Q')` in CPython produces exactly 88 bytes with **no padding**, whereas the C/Rust/CUDA counterparts will insert padding unless `#pragma pack(1)` / `#[repr(C, packed)]` is used. **This is the single most likely cross-language ABI break in the entire stack.**

**Rule 22 compliance (88-byte PMTP, zero 1D tokens):** The descriptor is a fixed-width record — good. But Rule 22 also forbids *1D token streams* in inter-agent communication. The `aux[4]` field is the danger zone: if any of the four `Q` slots is used as a **variable-length pointer** (e.g., a device address into a token buffer), the contract is violated. **Recommendation:** mandate that `aux[0..3]` are *scalar metadata only* (e.g., generation counter, checksum, epoch, flags), never pointers. Enforce with a static assert in each language.

### 0.2 Rule 27 — Silicon Contract (vendor lock)

| Target | Vendor exposure | Lock-in risk |
|---|---|---|
| 1 (orchestrator) | Multi-silicon probe | **Low** if probe is table-driven |
| 2 (C++/AVX-512) | Intel/AMD x86 | **Medium** — AVX-512 is absent on Zen 4 consumer, disabled on Alder Lake E-cores |
| 3 (Rust SIMD) | Portable via `std::simd` | **Low** |
| 4 (CUDA) | NVIDIA only | **High** — cuSOLVER `DnDsyevd` is NVIDIA-proprietary |
| 5 (XLA) | Google TPU / AWS Trainium | **High** — two-vendor split, neither is portable |
| 6 (Triton) | AMD ROCm + NVIDIA | **Medium** — Triton is portable in principle, but SRAM tiling is arch-specific |

**Verdict:** Targets 4 and 5 **violate Rule 27 as stated** unless the orchestrator (Target 1) can *transparently substitute* a fallback path. The Tribunal demands an explicit **capability-negotiation protocol**: the orchestrator must publish a `SiliconCapability` bitmask, and each kernel must declare its minimum capability. If Target 4 cannot run without cuSOLVER, it must be marked `REQUIRES: {NVIDIA, CUDA>=12, cuSOLVER}` and the orchestrator must refuse to dispatch on non-conforming hardware — *not* silently fall back to a numerically different algorithm.

---

## §1. Target 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator

**Claim:** Multi-silicon probe + slab allocator + 12/12 physical conformance checks.

**Audit:**
- A "12/12 conformance check" is only meaningful if the 12 checks are **independent**. If any two checks are logically implied by a third (e.g., "descriptor size == 88" implies "descriptor size % 8 == 0"), the count is inflated. **Demand:** publish the 12 predicates and their pairwise independence (a simple rank test over GF(2) on the boolean outcome vector).
- **Slab allocator degeneracy:** if slab size is a power of two and the descriptor is 88 bytes, then `88 * 2^k` is never a power of two. The allocator must therefore use **non-power-of-two slabs** or accept internal fragmentation. At `step → ∞` (see §7), if the allocator is asked to reserve `step` slabs, integer overflow in `size_t` is possible on 32-bit hosts. **Recommendation:** use `u64` slab counts and saturating arithmetic.

### 1.2 Numerical degeneracy at step extremes

The orchestrator itself does no arithmetic, but it *dispatches* based on `step`. If `step` is passed as a Python `float` and compared with `>= 1e10`, the comparison is exact for IEEE-754 doubles up to 2^53 ≈ 9.007e15, so `1e10` is representable. **No degeneracy at the orchestrator level**, provided `step` is never converted to `float32` before dispatch.

**Verdict:** **PASS with conditions** — publish the 12 predicates, mandate `u64` slab counts, and forbid `float32` step at the dispatch boundary.

---

## §2. Target 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's variant of Kahan:

```
s = 0; c = 0
for i: t = s + x[i]*y[i]
       if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i]
       else:                  c += (x[i]*y[i] - t) + s
       s = t
return s + c
```

**Error bound (Neumaier 1974):** for `n` terms with unit roundoff `u = 2^-53`,

```
|computed - exact| <= (u + O(n u^2)) * Σ|x_i y_i|
```

i.e., **the error is independent of cancellation**. This is the correct choice for the Stiefel/Woodbury inner products.

**Degeneracy at step → ∞:** if `step >= 1e10` and the dot product is `step * B`, then `x[i]*y[i]` can overflow `float64` only if `|x_i y_i| > 1.8e308`. With `step = 1e10` and `B` bounded by `1e298`, no overflow. **But** if the kernel uses `float32` anywhere in the accumulation, `step = 1e10` already overflows `float32` (max ≈ 3.4e38). **Demand:** static assert `sizeof(accumulator) == 8`.

**Degeneracy at step → 0 (subnormals):** the audit mentions `-12, -14` — presumably `2^-12` and `2^-14` test points. In `float64`, subnormals begin at `2^-1022`. `2^-12` and `2^-14` are **normal** in `float64` but **subnormal in `float16`** (min normal `2^-14`). If the kernel ever downcasts to `fp16` for the subnormal audit, the Neumaier compensation is **destroyed** because `fp16` has only 10 mantissa bits and the compensation term `c` is below the `fp16` ULP. **Verdict:** the subnormal audit at `-12, -14` is only meaningful in `fp16`; in `fp64` it is a no-op. Clarify the intended precision.

### 2.2 AVX-512 / OpenMP

- **AVX-512 downclocking:** on Skylake-X, sustained AVX-512 reduces core frequency by ~15–40%. For a *latency-bound* Stiefel retraction this is fine; for a *throughput-bound* dot product it can be a net loss. **Recommendation:** runtime dispatch via `__builtin_cpu_supports("avx512f")` and a scalar/AVX2 fallback.
- **OpenMP reduction:** `#pragma omp parallel for reduction(+:s,c)` on Neumaier is **incorrect** — the compensation term is order-dependent. Use `reduction(+:s)` on the *final* `s+c` per thread, or better, a tree reduction of `(s_i, c_i)` pairs with a compensated merge.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the descriptor's `aux` fields to carry **device pointers**, which §0.1 flagged as a Rule 22 risk. **Resolution:** the descriptor may carry a *handle* (opaque `u64` index into a side table), not a raw pointer. The side table lives in the orchestrator, not in the 88-byte record.

**Verdict:** **PASS with mandatory fixes** — (i) `alignas(8)` + `#pragma pack` discipline, (ii) compensated OpenMP reduction, (iii) clarify fp16 vs fp64 for the subnormal audit, (iv) handles not pointers in `aux`.

---

## §3. Target 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

**This is a category error.** `panic = unwind` *allows* unwinding across FFI boundaries, which is **undefined behavior** in Rust 2021 unless the boundary is `extern "C-unwind"`. The correct setting for an FFI safety barrier is `panic = abort` **or** `catch_unwind` at every `extern "C"` entry point.

**Recommendation:**
```rust
#[no_mangle]
pub extern "C" fn kernel_entry(desc: *const PmtpTensorDescriptor) -> i32 {
    let result = std::panic::catch_unwind(|| {