# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 165)

# POLYDIM V1350 — High Tribunal Audit, Cycle 165

**Presiding Sages:** Numerical Analysis, Systems Programming, Heterogeneous Compute, Formal Methods
**Verdict scope:** 6 components, 4 audit axes, adversarial step regimes.

---

## 0. Preliminary: What the Tribunal Can and Cannot Verify

The Tribunal notes at the outset that **no source files were attached to this docket**. The audit below is therefore conducted against the *architectural claims as stated in the brief*, using the canonical semantics of the named primitives (Neumaier summation, Cayley retraction, Woodbury identity, PMTP descriptor layout, etc.). Where a claim is *unfalsifiable without source*, the Tribunal marks it **[SOURCE-REQUIRED]** and issues a concrete falsification test rather than a pass/fail.

This is the honest posture. A tribunal that "passes" code it has not read is not a tribunal.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 The 88-byte descriptor: `<4sHHQQQQQBB6x4Q`

Let us actually sum the bytes, because this is the load-bearing claim of Rule 22.

| Field | Format | Size |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Arithmetic: 4+4+40+2+6+32 = 88.** ✅ Byte count is correct.

**But the Tribunal raises three structural objections:**

**(a) Alignment hazard.** With `struct` default alignment (`@` prefix) the layout is *not* 88 bytes — Python's `struct` inserts padding to satisfy native alignment. The claim `<...` (little-endian, standard size, **no alignment**) is required. If any consumer uses `@` or `=` prefix, the wire format silently diverges. **Recommendation:** assert `struct.calcsize('<4sHHQQQQQBB6x4Q') == 88` at import time and fail-closed.

**(b) The `6x` pad is a smell.** Six bytes of explicit padding between `BB` and `4Q` suggests the author is hand-aligning to an 8-byte boundary for the trailing `4Q` block. That is fine *if* the descriptor is memory-mapped and read by C/Rust/CUDA. It is *not* fine if the pad is ever repurposed — Rule 22's "zero 1D tokens" invariant depends on those bytes being canonically zero. **Falsification test:** `assert desc[18:24] == b'\x00'*6` on every serialization path.

**(c) Rule 22 compliance is a *protocol* property, not a *struct* property.** An 88-byte fixed-width record eliminates 1D token streams **only if** every inter-agent message is exactly one descriptor or an integer multiple thereof. The Tribunal cannot verify this from the format string alone. **[SOURCE-REQUIRED]**: grep for any `send(`, `write(`, `publish(` call whose payload is not `len % 88 == 0`.

### 1.2 Multi-silicon HardwareProbe

The claim "12/12 physical conformance checks" is a *test result*, not a *design property*. The Tribunal's concern: **what happens on check 11/12?** A probe that returns a boolean is a probe that lies. It must return a *capability vector* (AVX-512 width, subnormal flush-to-zero mode, PMTP BAR size, DnDsyevd availability) so downstream kernels can degrade gracefully. A binary pass/fail on heterogeneous silicon is a vendor-lock vector in disguise.

### 1.3 PmtpSlabAllocator

Slab allocation of 88-byte records is **pathological for cache lines**. 88 = 64 + 24. Two descriptors straddle three cache lines. If the allocator does not pad to 128 bytes *in memory* while keeping 88 bytes *on the wire*, every PMTP read is a 3-line fetch. **Recommendation:** separate `wire_size = 88` from `slot_size = 128`, and document the distinction in the descriptor header.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan summation has error bound (Higham, *Accuracy and Stability*, Thm 4.3, adapted):

$$|\hat{s} - s| \le \big(2u + O(nu^2)\big)\sum_{i=1}^{n}|x_i y_i|$$

where $u = 2^{-53}$ for FP64. The **condition number of the dot product** is

$$\kappa_{\text{dot}} = \frac{\sum |x_i y_i|}{|\sum x_i y_i|}$$

Neumaier is *forward-stable* but **not** immune to $\kappa_{\text{dot}} \to \infty$ (catastrophic cancellation). For POLYDIM's Stiefel/Woodbury pipeline, the dangerous case is $\langle q, B \rangle$ where $q \perp B$ — the true dot is ~0 but $\sum|x_i y_i|$ is $O(\|q\|\|B\|)$. **The compensated sum returns a small number with absolute error $O(u \sum|x_iy_i|)$, i.e. relative error $\to \infty$.** This is not a bug in Neumaier; it is a *misuse* if the result is later divided by a small quantity.

**Tribunal demand:** every Neumaier dot in the kernel must be paired with a **running bound** $\beta = u \sum|x_iy_i|$, and any downstream division must check $|\hat{s}| > c\beta$ before proceeding. Otherwise the Woodbury solve inherits an unbounded relative error.

### 2.2 Subnormal audits at $-12, -14$

The exponents $-12$ and $-14$ are suspicious. FP64 subnormals begin at $2^{-1022} \approx 2.2\times10^{-308}$. If the audit is checking values near $10^{-12}$ and $10^{-14}$, those are **normal** numbers — the audit is testing *smallness*, not *subnormality*. If the intent is FP32 (subnormals below $2^{-126} \approx 1.2\times10^{-38}$), then $-12/-14$ are still normal.

**Two possibilities:**
1. The exponents are **log10 of a scaled quantity** (e.g., step size in a normalized basis). Then the audit is meaningful but mislabeled.
2. The audit is **theater** — it checks that small numbers are small.

**Falsification test:** feed the kernel `np.nextafter(0.0, 1.0)` (smallest FP64 subnormal, $\approx 4.9\times10^{-324}$) and `np.finfo(np.float64).tiny` and verify the audit *fires*. If it does not, the "subnormal audit" is not auditing subnormals.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be **naturally aligned** in the mapped region. Combined with §1.1(a), the C++ side must use `alignas(8)` (or 16) on the descriptor struct and `static_assert(sizeof(PmtpDescriptor) == 88)`. **Without the static_assert, a compiler is free to pad to 96.** This is the single most likely silent Rule-22 violation in the entire stack.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier — **this is backwards**

The Rustonomicon is explicit: **`panic = "abort"` is the *safer* choice for FFI boundaries**, because unwinding across an `extern "C"` boundary is **undefined behavior** in the C++ ABI (until C++ exceptions are formally unified, which they are not). `panic = "unwind"` at an FFI edge means a Rust panic can unwind into C++ frames that have no landing pads — UB.

The correct pattern is:
- `panic = "abort"` globally, **or**
- `extern "C"` functions wrapped in `std::panic::catch_unwind` with `AssertUnwindSafe`, converting panics to error codes.

**The brief's claim that `panic = unwind` is a "safety barrier" is a category error.** It is the *opposite* of a safety barrier at the FFI edge. **[SOURCE-REQUIRED]** to see whether `catch_unwind` is actually present; if not, this is a **P0 correctness defect**.

### 3.2 Safe SIMD + Neumaier

Rust's `std::simd` (nightly) or `wide`/`packed_simd` crates: Neumaier in SIMD requires **lane-wise compensation vectors**, not a scalar compensation term. If the implementation uses a single scalar `c`, it is **not** Neumaier — it is Kahan-with-vector-accumulator, which has a *different* (weaker) error bound. **Falsification test:** compare against `rug::Float` at 256-bit precision on a vector of alternating-sign magnitudes $10^{15}, 1, -10^{15}, 1, \ldots$; a true Neumaier SIMD will match to ~1 ulp, a scalar-compensated version will not.

### 3.3 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` gives 88 bytes but **unaligned field access is UB-adjacent** (it's defined but generates unaligned loads, and `&packed.field` is a compile error). The correct pattern is `#[repr(C)]` with explicit `[u8; 6]` pad and `align(8)`, giving 88 bytes *and* aligned access. **Recommendation:** `#[repr(C, align(8))]` with a `_pad: [u8; 6]` field, plus `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);`.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Cayley retraction on Stiefel — the step → ∞ regime

The Cayley retraction on the Stiefel manifold $St(n,p)$ is

$$Y(\alpha) = \left(I - \tfrac{\alpha}{2}W\right)^{-1}\left(I + \tfrac{\alpha}{2}W\right)X, \quad W = A X^\top - X A^\top \in \mathfrak{so}(n)$$

As $\alpha \to \infty$, $Y(\alpha) \to -X$ (the antipode), **but the intermediate matrix $(I - \frac{\alpha}{2}W)$ becomes ill-conditioned**: its condition number grows like $\frac{\alpha}{2}\|W\|_2$. For $\alpha \ge 10^{10}$ and $\|W