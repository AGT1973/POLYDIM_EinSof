# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 165

There is **insufficient public evidence to perform a genuine arbitration of the eight Tribunal models or to certify “V1350” architectural guarantees**. The names “POLYDIM V1350,” “Cycle 165,” the six kernels, and the alleged model findings are not present in the supplied material. The available search results support only general conclusions about Stiefel retractions—not claims about a specific implementation, descriptor layout, or multi-silicon conformance.

## 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For a skew-symmetric \(\Omega\), the exact Cayley map is

\[
Q(\alpha)=
\left(I-\frac{\alpha}{2}\Omega\right)^{-1}
\left(I+\frac{\alpha}{2}\Omega\right),
\qquad
X_{+}=Q(\alpha)X.
\]

In exact arithmetic, \(Q(\alpha)\) is orthogonal whenever the inverse exists. However, that does **not** imply numerical stability for an extreme step. The computation can suffer from:

- overflow in forming \(\alpha\Omega\);
- loss of significance in \(I\pm \alpha\Omega/2\);
- ill-conditioned or poorly scaled linear solves;
- residual orthogonality loss from finite precision;
- failure of iterative fixed-point approximations unless convergence and stopping criteria are proven.

The relevant literature supports bounded local conditioning for canonical Cayley and polar-light retractions, but also identifies domain conditions involving eigenvalue \(-1\) for inverse mappings.[1] It does not establish a guarantee at step magnitudes of \(10^{10}\) or greater.

**Arbitration:** no method should be declared unconditionally stable at that scale. A defensible implementation guarantee is instead:

\[
\|X_{+}^{T}X_{+}-I\|
\le
c\,u\,\kappa_{\mathrm{solve}}\,p(n)
+\tau_{\mathrm{iter}}
+\tau_{\mathrm{rescale}},
\]

provided that:

- the skew operator is safely scaled;
- the solve is backward stable;
- overflow and underflow are prevented;
- the residual is checked;
- the result is reorthogonalized or rejected when the tolerance fails.

Householder QR is generally the strongest baseline for robust orthogonalization because it avoids explicitly forming a matrix inverse and has well-established backward-stability properties. Polar retraction has attractive geometric properties and the form

\[
(X+\xi)(I+\xi^{T}\xi)^{-1/2},
\]

but its quality depends on the stability of the symmetric inverse square root.[2] Cayley is preferable when preserving a structured transformation or exploiting a low-rank/skew representation, not because an extreme raw step is intrinsically safe.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

No descriptor specification or Tribunal result was provided, so an exact 88-byte layout cannot be validated. More importantly, **Acquire/Release operations alone do not prove RCU or QSBR snapshot isolation**.

A valid publication protocol requires, at minimum:

1. The writer initializes the complete immutable descriptor payload.
2. The writer performs a **release publication** of the pointer or generation/state value.
3. The reader performs an **acquire load** before dereferencing the payload.
4. The writer retires the old object only after the applicable RCU grace period or QSBR epoch condition.
5. Readers cannot access a reclaimed object.
6. Any mutable fields have separately specified atomicity and ordering rules.

The essential happens-before relation is:

\[
\text{payload initialization}
\;\xrightarrow{\text{release}}\;
\text{publication}
\;\xrightarrow{\text{acquire}}\;
\text{reader dereference}.
\]

For reclamation, the required safety relation is distinct:

\[
\text{reader quiescence / grace period}
\;\xrightarrow{}\;
\text{safe reclamation}.
\]

Thus:

- **Release without Acquire** does not establish the reader’s visibility guarantee.
- **Acquire without a correct publication store** does not establish initialization ordering.
- Acquire/Release does not itself prevent reclamation races.
- QSBR requires correct reader registration, quiescent-state reporting, epoch advancement, and delayed reclamation.
- A fixed size of 88 bytes provides no memory-safety or synchronization guarantee.

**Arbitration:** the strongest defensible claim is **snapshot publication safety under a specified RCU/QSBR protocol**, not “RCU/QSBR isolation by descriptor barriers alone.”

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no basis for asserting exact conformance across these ecosystems without source code, ABI definitions, compiler versions, generated artifacts, and test results. These systems do not share one memory model or one execution model:

- **C++20** defines language-level atomic and memory-order semantics.
- **Rust** provides analogous atomic ordering guarantees within its supported targets, but unsafe FFI and device code require separate validation.
- **CUDA** has host/device scopes, CUDA atomics, stream ordering, and device-specific behavior.
- **Triton** exposes compiler-defined GPU memory operations whose exact lowering must be inspected or tested.
- **XLA** uses an IR/compiler execution model and may fuse, reorder, or lower operations differently across backends.

A portable conformance claim must therefore be stated as a contract over observable behavior, for example:

\[
\text{all supported backends preserve}
\begin{cases}
\text{descriptor publication happens-before reads},\\
\text{no read observes partial initialization},\\
\text{no retired descriptor is dereferenced},\\
\text{orthogonality residual}\le \varepsilon,\\
\text{deterministic error handling for failed kernels}.
\end{cases}
\]

Each backend then needs independent validation using litmus tests, race detection, randomized numerical testing, ABI checks, and stress tests.

## Definitive synthesis

The mathematically superior SOTA synthesis is **not** “Cayley is always more stable,” “88-byte Acquire/Release is sufficient,” or “source-level portability implies cross-silicon conformance.” The defensible architecture is:

- **Retraction:** use scaled Cayley only when its solve is demonstrably well-conditioned and residual-checked; otherwise use backward-stable Householder QR or a carefully implemented polar factorization.
- **Extreme steps:** never promise unconditional stability for \(|\mathrm{step}|\ge 10^{10}\); apply scaling, finite-value checks, stable solves, residual tests, and a certified fallback.
- **Publication:** publish immutable descriptors with release semantics and consume them with acquire semantics.
- **Reclamation:** treat RCU/QSBR grace periods as a separate mandatory proof obligation.
- **Portability:** define conformance in terms of observable invariants and verify each CUDA, XLA, Triton, C++20, and Rust lowering independently.
- **Guarantees:** provide conditional numerical, memory-ordering, and portability guarantees—not absolute guarantees unsupported by implementation evidence.

On the supplied evidence, any stronger “definitive” claim would be speculation rather than an arbitration of the eight models.