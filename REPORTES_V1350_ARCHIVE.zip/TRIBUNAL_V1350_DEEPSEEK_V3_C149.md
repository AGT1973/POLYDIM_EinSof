# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 149)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 149 · Multi-File Adversarial SOTA Review

**Preliminary note on evidentiary posture.** The Tribunal has been presented with *architectural claims* (file names, symbol names, byte layouts, algorithm sketches) rather than the source artifacts themselves. Under adversarial audit rules, every claim is treated as a *hypothesis to be falsified*, not a fact. Where a claim is unverifiable from the brief, the Tribunal says so explicitly and issues a **conditional verdict** with the exact evidence required to close it. This is the only intellectually honest posture; anything else would be theater.

---

## §0. Cross-cutting invariants (apply to all six targets)

### 0.1 The 88-byte descriptor — structural audit

Claimed layout: `<4sHHQQQQQBB6x4Q`

Let us sum the struct:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Verdict: arithmetically consistent.** 88 bytes, natural alignment on 8-byte boundary, no implicit padding under `struct` (little-endian, standard size). This satisfies the *letter* of Rule 22's "88-byte PMTP" clause.

**But Rule 22 also says "Zero 1D tokens in inter-agent communication."** This is the substantive clause, and it is where the architecture is most exposed. A 1D token in this context means a *scalar or rank-1 payload* passed between agents without tensor structure. The 88-byte descriptor is a *header*, not a payload — it is fine. The risk is in the **payload channel**: if any of the six kernels ever emits a bare `float64` or `int64` across the FFI boundary (e.g., a residual norm, a step size, a convergence flag) as a standalone message, Rule 22 is violated. The Tribunal flags this as **the single highest-probability compliance failure** across the stack, because every one of the six kernels has a natural place where a scalar wants to escape:

- T1: `HardwareProbe` returning a device count as `int`.
- T2: Neumaier compensation returning a scalar correction.
- T3: Rust FFI returning `Result<f64, i32>`.
- T4: cuSOLVER returning an eigenvalue count.
- T5: JAX returning a loss scalar.
- T6: Triton returning a tile checksum.

**Recommendation R-22.1:** Every cross-agent message must be wrapped in a rank-≥2 tensor envelope, even if the logical content is scalar. Concretely: `(1,1)` shaped `float64` with the 88-byte descriptor as prefix. This is cheap and closes the loophole.

### 0.2 Rule 27 — Silicon Contract / vendor lock

Rule 27 forbids any component from *imposing* vendor lock. The Tribunal's reading: a component may *exploit* a vendor (that is fine, that is the point of multi-silicon), but the *architecture* must not require that vendor to function. Test: can the system be built and run on a fallback path with the vendor's toolchain absent?

| Target | Vendor | Fallback path present? | Verdict |
|---|---|---|---|
| T1 orchestrator | none (probe) | must dispatch to ≥2 backends | **Conditional pass** — depends on dispatch table |
| T2 C++ AVX-512 | Intel/AMD | needs scalar/SSE fallback | **At risk** — AVX-512 is not universal (Zen 4 has it, Zen 3 does not; Apple Silicon does not) |
| T3 Rust SIMD | portable | `std::simd` or scalar | **Pass** if `cfg(target_feature)` gated |
| T4 CUDA | NVIDIA | none in-file | **Fail if mandatory** — needs HIP/ROCm sibling or CPU fallback |
| T5 XLA | Google/AWS | none in-file | **Fail if mandatory** — TPU and Trainium are mutually exclusive vendors |
| T6 Triton | AMD + NVIDIA | dual-vendor by design | **Pass** — this is the model the others should follow |

**Recommendation R-27.1:** T4 and T5 must each declare a *documented degradation path* (T4 → T2 CPU core; T5 → T2 or T3). Without that, Rule 27 is violated at the architecture level regardless of runtime behavior.

---

## §1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Numerical degeneracy at step → ∞ and step → 0

The orchestrator itself is not a numerical kernel, but it *routes* step sizes. The degeneracy risk is **dispatch-time**:

- **step → ∞ (|step| ≥ 10¹⁰):** If the orchestrator computes a routing key as `hash(step)` or `int(step)`, overflow or precision collapse occurs. More subtly, if it selects a backend based on `step > threshold`, a step of 10¹⁰ will always route to the "large step" path — which is correct only if that path is *asymptotically stable*. The Tribunal demands a proof that the large-step path is contractive; otherwise the orchestrator is a *destabilizer*.
- **step → 0 (subnormal):** If the orchestrator uses `step` as a denominator (e.g., `1/step` for a rate), subnormal `step` produces `inf`. If it uses `step` as a multiplier, subnormal `step` produces a subnormal result that may flush to zero on some backends (FTZ/DAZ on x86, `-ffast-math` on any compiler). **This is a silent correctness bug**, not a crash.

**Proof obligation P1.1:** Show that the orchestrator's routing function `R: step ↦ backend` is *measurable* and *bounded* on `[0, ∞)`, and that `R(step)` is invariant under `step → step·(1+ε)` for `|ε| < 2⁻⁵²`. If not, the orchestrator is not deterministic across IEEE-754 rounding modes.

### 1.2 12/12 physical conformance checks

The claim "12/12" is a *self-report*. The Tribunal requires the *list* of the 12 checks and their falsification conditions. A conformance suite that cannot fail is not a conformance suite. **Demand:** the 12 checks must include at least one *negative control* (a deliberately malformed descriptor that must be rejected). Without a negative control, 12/12 is vacuous.

### 1.3 `PmtpSlabAllocator`

Slab allocation for 88-byte descriptors is fine *if* the slab is 8-byte aligned and the allocator is thread-safe. The Tribunal flags: **88 is not a power of two**, so slab bins will have internal fragmentation of up to 7 bytes per object unless the allocator uses a size-class table. At 10⁹ descriptors, that is up to 7 GB of waste. **Recommendation:** use a 96-byte bin (next multiple of 16) and document the 8-byte overhead, or use a packed arena with a free-list.

---

## §2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's algorithm computes `s = Σ xᵢyᵢ` with compensation `c`, returning `s + c`. The *forward error* bound is:

\[
|\hat{s} - s| \le \gamma_n \sum |x_i y_i| + O(u^2)
\]

where `γ_n = nu/(1-nu)`, `u = 2⁻⁵³`. This is **unconditionally better** than naive summation by a factor of `n`. The *condition number* of the dot product itself is:

\[
\kappa = \frac{\sum |x_i y_i|}{|\sum x_i y_i|}
\]

Neumaier does **not** reduce `κ`; it reduces the *effective* `u` to `u²` in the compensation term. So for `κ → ∞` (catastrophic cancellation), Neumaier still loses digits, but at a rate of `u²` rather than `u`. **This is correct and is the right choice.**

### 2.2 Subnormal audits at −12, −14

The exponents −12 and −14 are suspicious. In IEEE-754 binary64, subnormals begin at `2⁻¹⁰²²`. Exponents −12 and −14 are *normal* numbers. The Tribunal suspects these refer to **decimal exponents** in a test harness (i.e., `1e-12`, `1e-14`), which are well within normal range. If so, the "subnormal audit" is misnamed — it is a *small-magnitude* audit, not a subnormal audit. **Demand:** clarify. If the intent is true subnormal testing, the test vectors must be `~1e-308` and the kernel must be compiled *without* `-ffast-math` and *without* FTZ/DAZ.

### 2.3 AVX-512 vendor lock

As noted in §0.2, AVX-512 is not universal. **Recommendation R-2.1:** gate with `__builtin_cpu_supports("avx512f")` and provide an AVX2 path and a scalar path. The scalar path is the *correctness oracle*; the AVX-512 path is the *performance path*. If the scalar path is absent, the kernel cannot be validated.

### 2.4 Zero-copy PMTP validation

Zero-copy requires that the 88-byte descriptor and the payload share a page-aligned buffer. The Tribunal flags: **zero-copy across FFI is only safe if the lifetime of the buffer is guaranteed by the caller.** In C++, this means the buffer must be `std::shared_ptr`-managed or arena-managed, not stack-allocated. If the kernel returns a pointer into a stack buffer, the FFI boundary is a use-after-free. **Demand:** the ownership contract must be documented in the header.

---

## §3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

This is **the most interesting claim in the stack** and the Tribunal wants to examine it carefully.

`panic=unwind` allows Rust panics to unwind through the stack. Across an FFI boundary, unwinding into C/C++ is **undefined behavior** unless the C++ side is compiled with `-fexceptions` and the Rust side uses `catch_unwind` at the boundary. The claim that `panic=unwind` is a "safety barrier" is **backwards**: `panic=abort` is the *safe* choice for FFI, because it converts a panic into a process abort rather than UB. `panic=unwind` is only