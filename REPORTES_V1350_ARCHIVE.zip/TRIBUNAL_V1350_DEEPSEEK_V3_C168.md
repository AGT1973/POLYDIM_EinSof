# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 168)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 168 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has reviewed the six artifacts as *specifications*, not as compiled binaries. Where the source is not in evidence, we audit the *claimed* invariants and flag every place where the claim is under-determined. We do not grant "SOTA" on assertion alone.

---

## §0. Cross-Cutting Findings (read first)

| # | Finding | Severity | Applies to |
|---|---------|----------|------------|
| F1 | **88-byte descriptor is not 88 bytes.** `<4sHHQQQQQBB6x4Q` = 4+2+2+8+8+8+8+8+1+1+6+32 = **88** ✅ *only if* `Q` is 8 bytes and native alignment is honored. Under `#pragma pack(1)` it is 88; under default alignment it is **96** (padding before the trailing `4Q`). | **Critical** | T1, T2, T3 |
| F2 | **Neumaier ≠ Kahan.** Neumaier's compensation is *not* unconditionally backward-stable for non-monotone summation orders; the error bound is `|err| ≤ (n-1)u Σ|xᵢ|` **only** under the assumption of no intermediate overflow. At `|step| ≥ 10¹⁰` with `K ~ 10³` terms this is fine; at `step → 0` with subnormals it is **not**. | High | T2, T3 |
| F3 | **Rule 22 (zero 1D tokens)** is satisfied *structurally* by the 88-byte descriptor, but **not semantically** unless every field is a fixed-width scalar. `4s` (char[4]) is a 1D token in disguise if it carries a variable-length tag. | High | T1–T3 |
| F4 | **Rule 27 (Silicon Contract)** is **violated** by T4 (cuSOLVER) and T5 (TPU/Trainium HLO). Both are vendor-locked at the *algorithmic* level, not merely the *runtime* level. | **Critical** | T4, T5 |
| F5 | **Step → ∞ degeneracy** is unhandled in T4 (Cayley retraction loses orthogonality) and T5 (Lyapunov solve becomes ill-conditioned as `‖A‖·step → ∞`). | **Critical** | T4, T5 |
| F6 | **Step → 0 subnormal audit** is claimed for T2 (`-12, -14`) but the *exponent range* of the audit is not specified. FP64 subnormals live at `2⁻¹⁰²²`; FP32 at `2⁻¹²⁶`. The claim "-12, -14" is dimensionally ambiguous. | High | T2 |

---

## §1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout audit

```
struct PmtpDescriptor {          // claimed 88 bytes
    char     magic[4];           //  4
    uint16_t version;            //  2
    uint16_t flags;              //  2
    uint64_t n_rows;             //  8
    uint64_t n_cols;             //  8
    uint64_t stride;             //  8
    uint64_t dtype;              //  8
    uint64_t checksum;           //  8
    uint8_t  rank;               //  1
    uint8_t  pad0;               //  1
    uint8_t  reserved[6];        //  6
    uint64_t aux[4];             // 32
};                               // = 88
```

**Verdict.** The layout is 88 bytes **iff**:
- `Q` is `unsigned long long` (8 B) — true on LP64, **false on LLP64/Windows** where `long long` is 8 but `unsigned long` is 4. The spec must pin `uint64_t`.
- The compiler does **not** insert padding. With `alignof(uint64_t)=8`, the struct's natural alignment is 8; the trailing `4Q` is already 8-aligned, so **no padding is inserted** — but the *total* size must be a multiple of 8, and 88 is. ✅
- **However**: if `magic[4]` is followed by `uint16_t`, the compiler may pad `magic` to 4 (already 4) — fine. The `BB6x` sequence is 8 bytes, aligned. ✅

**Recommendation.** Emit `static_assert(sizeof(PmtpDescriptor)==88, "PMTP ABI drift")` in **all three** of T1/T2/T3, and a Python `ctypes.Structure` with `_pack_ = 1` cross-checked against `struct.calcsize("<4sHHQQQQQBB6x4Q") == 88`.

### 1.2 Rule 22 compliance

Rule 22 forbids **1D tokens** in inter-agent communication. The 88-byte descriptor is a *fixed-width record*, which is the correct primitive. **But**:
- `magic[4]` is a 4-byte string. If any agent writes a *variable-length* magic (e.g., `"v1350\0"` vs `"v1350.1\0"`), the field becomes a 1D token. **Enforce a 4-byte enum**, not a string.
- `aux[4]` is a 4-element array — this is a **1D token** if interpreted as a vector. It must be documented as *four independent scalars* (e.g., `aux_scale`, `aux_seed`, `aux_epoch`, `aux_crc`), not a vector.

**Verdict:** Rule 22 is **conditionally satisfied**. Fix the two items above.

### 1.3 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe**: no vendor-lock *if* the probe is a runtime dispatch table. ✅
- **Slab allocator**: must guarantee 64-byte alignment for AVX-512 (T2) and 128-byte for cache-line isolation on Zen4/SPR. The spec does not state alignment. **Flag.**

---

## §2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Standard Neumaier:

```
s = 0; c = 0;
for i: t = s + x[i]*y[i];
       if |s| >= |x[i]*y[i]|: c += (s - t) + x[i]*y[i];
       else:                  c += (x[i]*y[i] - t) + s;
       s = t;
return s + c;
```

**Error bound (Neumaier 1974):** `|computed − exact| ≤ (n−1)u Σ|xᵢyᵢ| + O(u²)`, **provided no intermediate overflow**.

**Degeneracy at `|step| ≥ 10¹⁰`:**
- If `x[i]*y[i]` overflows FP64 (`> 1.8e308`), the compensation term becomes `NaN` and the sum is poisoned. With `step = 10¹⁰` and `K = 10³`, `x·y` can reach `10²⁰` — safe. **But** if the caller passes `step²` (as Cayley retraction does in T4), `step² = 10²⁰`, and `x·y` can reach `10⁴⁰` — still safe. **The real risk is `step⁴`** in the Woodbury path: `10⁴⁰` squared = `10⁸⁰` — safe, but `step⁸ = 10⁸⁰` squared = `10¹⁶⁰` — approaching overflow. **Flag: the spec must bound the polynomial degree of `step` in the dot product.**

**Degeneracy at `step → 0` (subnormals):**
- FP64 subnormals: `|x| < 2⁻¹⁰²² ≈ 2.2e-308`. Neumaier's compensation **fails** when `x[i]*y[i]` is subnormal because the `s - t` subtraction loses the compensation bits. The error bound degrades to `O(u)` *absolute*, not relative.
- The claimed audit at `-12, -14` is **ambiguous**: if these are *decimal* exponents (`10⁻¹²`, `10⁻¹⁴`), they are **not subnormal** — they are normal FP64. If they are *binary* exponents (`2⁻¹²`, `2⁻¹⁴`), they are also normal. **The subnormal audit is not actually testing subnormals.** This is a **critical spec defect**.

**Recommendation.** Replace Neumaier with **Kahan–Babuska** or **Ogita–Rump–Oishi (TwoProd + TwoSum)** for the subnormal regime, and add an explicit `std::fenv` check for `FE_UNDERFLOW`.

### 2.2 AVX-512 / OpenMP

- **AVX-512 downclocking** on Skylake-X: the spec must pin `AVX512_USE` to `AVX512VL` + `AVX512DQ` only, avoiding `AVX512F` heavy ops. **Flag.**
- **OpenMP `reduction(+:s,c)`** is **not** Neumaier-safe: the reduction tree reorders terms, breaking the compensation invariant. **Critical.** Use `reduction(+:s)` with a separate `c` array and a final Neumaier pass, or use `#pragma omp simd reduction` with a custom combiner.

### 2.3 Zero-copy PMTP validation

- Zero-copy requires the descriptor's `stride` to match the physical layout. If `stride != n_cols * sizeof(dtype)`, the "zero-copy" is a lie. **Flag: add a `static_assert` or runtime check.**

---

## §3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` FFI safety

- `panic=unwind` across an FFI boundary is **UB** unless the panic is caught at the boundary. Rust 2021 requires `extern "C"` functions to be `#[no_mangle]` and **not** unwind. The correct pattern is `extern "C-unwind"` (Rust 1.71+) or `catch_unwind` at the boundary.
- **Verdict:** the claim "panic=unwind FFI safety barrier" is **incorrect** as stated. It is a *hazard*, not a barrier. **Critical.**

### 3.2 Packed 88-byte descriptor

- `#[repr(C, packed)]` on the descriptor will **misalign** `u64` fields, causing unaligned loads on some architectures (ARM64 is fine, x86 is