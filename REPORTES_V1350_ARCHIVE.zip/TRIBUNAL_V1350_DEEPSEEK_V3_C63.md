# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 63)

# POLYDIM V1350 — High Tribunal Audit, Cycle 63

**Presiding note.** The Tribunal treats each target as a *claim of correctness* under adversarial perturbation. We do not accept "it compiles" as evidence. We require: (i) a numerical-stability certificate, (ii) a wire-format certificate, (iii) a vendor-neutrality certificate, (iv) an FFI-safety certificate. Where a certificate is absent, we mark the component **CONDITIONAL** and demand remediation.

---

## 0. Cross-cutting invariants the Tribunal will test against

Let the PMTP descriptor be the 88-byte struct:

```
<4sHHQQQQQBB6x4Q
```

Field budget: `4s`=4, `H`×2=4, `Q`×5=40, `B`×2=2, `6x`=6, `Q`×4=32 → **4+4+40+2+6+32 = 88 bytes**. ✅ Structurally the format is *self-consistent* and `struct.calcsize` will return 88 on any LP64 platform with default alignment. **However** — see §2 — the `6x` pad assumes the compiler/`struct` module does not insert *additional* padding between `B B` and the trailing `Q` block. On x86-64 SysV, `Q` requires 8-byte alignment; after `4sHHQQQQQBB` we are at offset 4+2+2+8·5+1+1 = **50**, then `6x` → 56, which is 8-aligned. ✅ The pad is *load-bearing*; removing it would silently shift to 56→56 (still aligned) but change size to 82. The Tribunal flags this as **fragile but currently correct**.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Multi-silicon HardwareProbe
**Claim:** probes CPU/GPU/TPU/Trainium/ROCm without vendor lock.
**Audit:** A probe that *enumerates* vendors is fine; a probe that *requires* one is not. The Tribunal demands the probe return a **capability bitmask**, not a selected backend. If `HardwareProbe` returns a single `backend` enum, Rule 27 is violated at the orchestrator level (the orchestrator becomes the lock-in point).

**Verdict:** **CONDITIONAL** — pass iff probe is a pure function `env → frozenset[Capability]` with no side effects on import.

### 1.2 PmtpSlabAllocator
**Claim:** slab allocator for 88-byte descriptors.
**Audit:** 88 is not a power of two. A naive slab allocator with 64-byte cache lines will produce **1.375 descriptors per line** → 37.5% internal fragmentation on the last descriptor of each line, and *false sharing* if two agents write adjacent descriptors. The Tribunal requires:
- Either pad to 128 bytes (cache-line aligned) **on the wire is forbidden** (Rule 22 says 88), so padding must be **in-memory only**, with the wire serializer stripping it.
- Or use a **SoA layout** with a separate 88-byte packed array and a 64-byte-aligned index array.

**Verdict:** **CONDITIONAL** — must document that the 88-byte wire form is *not* the in-memory form.

### 1.3 12/12 physical conformance checks
Without the check list, the Tribunal can only note: 12 checks is a *count*, not a *proof*. Demand the checks be enumerated and each be a **total function** (no exceptions on malformed input — return `False`).

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška:

```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
    else:                c += (x_i*y_i - t) + s
    s = t
return s + c
```

**Theorem (Neumaier 1974; Higham Thm 4.3).** For `n` terms with `|x_i y_i| ≤ M` and unit roundoff `u`,

```
|fl(Σ x_i y_i) − Σ x_i y_i| ≤ (2u + O(nu²)) · Σ|x_i y_i|
```

i.e. the *forward* error is bounded by `2u · Σ|x_i y_i|`, **independent of n** to first order. The **condition number** of the dot product is

```
κ = (Σ|x_i y_i|) / |Σ x_i y_i|
```

Neumaier does **not** reduce κ; it makes the *realized* error `≈ u·κ·|result|` rather than `≈ n·u·κ·|result|`. So the asymptotic condition number is unchanged — **the algorithm is backward-stable, not better-conditioned**. Any claim of "improved conditioning" is **rejected**.

### 2.2 Subnormal audits at −12, −14

Subnormals in IEEE-754 binary64 begin at `2^-1022 ≈ 2.2e-308`. An "audit at −12, −14" almost certainly means **decimal exponents** `1e-12`, `1e-14` — these are **normal**, not subnormal. The Tribunal flags this as a **terminology error** in the audit spec. If the intent was `2^-12`, `2^-14`, those are also normal. **True subnormal testing requires `2^-1022` and below.**

**Verdict:** **REJECTED as stated.** Demand the audit be re-specified in terms of `DBL_MIN`, `DBL_TRUE_MIN`, and `FLT_MIN`.

### 2.3 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be **trivially copyable** and **standard-layout**. In C++20:

```cpp
static_assert(sizeof(PmtpDescriptor) == 88);
static_assert(std::is_trivially_copyable_v<PmtpDescriptor>);
static_assert(std::is_standard_layout_v<PmtpDescriptor>);
```

If any of these fail, `memcpy`/`reinterpret_cast` across the FFI boundary is UB. **Demand these static_asserts be present.**

### 2.4 AVX-512 + OpenMP

AVX-512 downclocking on Skylake-X is a *performance* hazard, not correctness. But **OpenMP reduction with `reduction(+:s)` is NOT Neumaier** — it is naive summation with a tree, which has `O(log n · u)` error, not `O(u)`. If the code uses `#pragma omp parallel for reduction(+:s)` on the Neumaier loop, the compensation term `c` is **not reduced** and the result is **wrong**. **Demand explicit `reduction` on both `s` and `c` with a custom combiner, or a two-pass scheme.**

**Verdict:** **CONDITIONAL** — likely bug.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

**This is a serious error.** Rust's `extern "C"` ABI **aborts on unwind** since Rust 1.71 (RFC 2945 / `C-unwind` split). If the crate is compiled with `panic = "unwind"` and a panic crosses an `extern "C"` boundary, the behavior is **defined as abort** — not as a caught unwind. So `panic = unwind` does **not** provide an FFI safety barrier; it provides an **abort barrier**.

The correct pattern is:
```rust
#[no_mangle]
pub extern "C" fn entry(...) -> c_int {
    std::panic::catch_unwind(|| { ... })
        .map(|_| 0).unwrap_or(-1)
}
```
with `panic = "abort"` for the release profile to eliminate the unwinding tables entirely.

**Verdict:** **REJECTED.** The stated safety model is inverted.

### 3.2 Packed 88-byte descriptor

```rust
#[repr(C, packed)]
pub struct PmtpTensorDescriptor { ... }
```

`repr(packed)` on a struct containing `u64` fields produces **unaligned references**, which are UB to take (`&self.field`). The Tribunal demands either:
- `#[repr(C)]` with explicit `_pad: [u8; 6]`, or
- `#[repr(C, align(8))]` and accept 88 bytes only if the natural layout already yields 88.

**Verdict:** **CONDITIONAL** — `repr(packed)` is a footgun here.

### 3.3 Safe SIMD

`std::simd` is still nightly as of Rust 2021 edition. If the crate uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" is therefore a **misnomer** unless the crate wraps every intrinsic in a `unsafe` block with a documented invariant. Demand the invariant list.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction

For `Y ∈ St(n,p) = {Y : YᵀY = I_p}`, the Cayley retraction is

```
R_Y(ξ) = (I − ½ W)^{-1} (I + ½ W) Y,   W = A Yᵀ − Y Aᵀ,   A = ξ Yᵀ − Y ξᵀ
```

**Stability:** `(I − ½W)` is invertible iff `½W` has no eigenvalue 1. Since `W` is skew-symmetric, its eigenvalues are purely imaginary, so `I − ½W` is **always** invertible and well-conditioned: `κ₂(I − ½W) = 1` exactly (normal matrix with eigenvalues `1 − iλ/2`, `|1 − iλ/2| ≥ 1`). ✅ **Numerically safe.**

**But:** the claim says "in `R^(2K × 2K)`". The Stiefel manifold `St(n,p)` has `n = 2K`, `p = 2K`? Then `St(2K, 2K) = O(2K)`, the orthogonal group. The Cayley retraction on `O(2K)` is fine, but the **dimension of the tangent space is `K(2K−1)`**, not `4K²`. If the code allocates `4K²` tangent components, it is **over-parameterized** and the retraction is not a bijection. **Demand clarification.**

### 4.2 cuSOLVER `DnDsyevd` — **this is the wrong routine**

`DnDsyevd` is the **