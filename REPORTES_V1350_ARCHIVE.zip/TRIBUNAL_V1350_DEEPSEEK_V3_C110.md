# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 110)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 110 · Six-Component Adversarial SOTA Review

**Presiding note.** The Tribunal treats each target as a *claim of correctness* under adversarial input, not as a marketing artifact. Where a claim cannot be discharged by proof or by a cited invariant, it is marked **UNVERIFIED** and the burden shifts to the submitter. All numerical claims are evaluated in IEEE-754 binary64 unless stated.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly (little-endian, `struct` native alignment suppressed by `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major | `H` | 2 |
| version_minor | `H` | 2 |
| n_rows | `Q` | 8 |
| n_cols | `Q` | 8 |
| stride | `Q` | 8 |
| dtype_tag | `Q` | 8 |
| flags | `Q` | 8 |
| rank | `B` | 1 |
| pad0 | `B` | 1 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

**Verdict:** 88-byte claim is arithmetically correct. **Rule 22 (88-byte PMTP) satisfied at the wire level.**

### 1.2 Rule 22 — "Zero 1D tokens in inter-agent communication"

The descriptor is a *fixed-width record*, not a token stream. However, Rule 22 as stated forbids **1D token vectors** in inter-agent traffic. Two failure modes:

- **Failure A (semantic):** If `reserved[0..3]` is ever used to carry a variable-length payload pointer, the record degenerates into a 1D token channel. **Recommendation:** freeze `reserved` as `MUST_BE_ZERO` and enforce via a `ctypes` validator on both producer and consumer.
- **Failure B (alignment):** `<` disables padding, so the struct is *packed*. On ARM64 with `-mstrict-align`, an unaligned `Q` load is a fault. The orchestrator must memcpy into an aligned local before field access. **UNVERIFIED** whether the Python side does this.

### 1.3 HardwareProbe / PmtpSlabAllocator

- **Multi-silicon probe:** no vendor-lock *if* the probe returns a capability bitmask rather than a vendor enum. If it returns `"nvidia"|"amd"|"tpu"|"trainium"`, that is a **soft vendor-lock** (Rule 27 violation).
- **Slab allocator:** must guarantee 64-byte alignment for AVX-512 and 128-byte for some ROCm paths. No proof supplied. **UNVERIFIED.**

### 1.4 12/12 physical conformance checks

Without the check list, the Tribunal can only note: a 12/12 self-report is **not** evidence. Demand the checks be *falsifiable* (e.g., "descriptor round-trips through `mmap` + `memcmp` on a big-endian host").

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Standard Neumaier:

```
s = 0; c = 0
for i: t = s + x_i*y_i
       if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
       else:                c += (x_i*y_i - t) + s
       s = t
return s + c
```

**Error bound (Ogita–Rump–Oishi):** for `n` terms, `|result − exact| ≤ (2u + O(nu²)) · Σ|x_i y_i|`, with `u = 2⁻⁵³`. This is *conditionally* accurate: the bound scales with `Σ|x_i y_i|`, not with `|Σ x_i y_i|`.

**Degeneracy at step → ∞ (|step| ≥ 10¹⁰):**
- If `x_i` are Stiefel tangent vectors and `step` multiplies them, `Σ|x_i y_i| ~ step²`. The *relative* error stays ~`nu²`, but the *absolute* error grows as `step²`. If downstream code compares against a fixed tolerance, it will falsely report convergence failure. **Recommendation:** normalize `step` out of the dot product; compute `⟨x,y⟩` on unit vectors and scale afterward.
- **Catastrophic case:** if `step` is applied *inside* the loop as `x_i * step`, and `step = 1e10`, then `x_i*step` may overflow to `inf` for `|x_i| > 1.8e298`. Not reachable for normalized Stiefel points, but **UNVERIFIED** for unnormalized inputs.

**Degeneracy at step → 0 (subnormals):**
- The audit mentions `-12, -14` — presumably exponents. In binary64, subnormals live below `2⁻¹⁰²² ≈ 2.2e-308`. A value with exponent `-12` or `-14` is **not subnormal**; it is a perfectly normal number near `1e-4`. **The audit's own terminology is wrong.** If the intent was `2⁻¹²` and `2⁻¹⁴`, those are also normal.
- **Real subnormal hazard:** Neumaier's branch `if |s| >= |x_i*y_i|` is *not* subnormal-safe in the sense that if both are subnormal, the subtraction `s - t` may lose all bits. **Recommendation:** flush-to-zero (FTZ) is *forbidden* here; instead, detect `|s| < 2⁻¹⁰²²` and fall back to a Kahan–Babuska two-sum with explicit scaling.

### 2.2 Zero-copy PMTP validation

"Zero-copy" + "validation" is a contradiction unless validation is done on a *read-only mapped* view. If validation writes to the buffer (e.g., checksum in-place), it is not zero-copy. **UNVERIFIED.**

### 2.3 AVX-512 / OpenMP

- AVX-512 downclocking on Skylake-X is a *performance* issue, not correctness. Not a Rule 27 violation.
- OpenMP `reduction(+:s,c)` on Neumaier is **incorrect** — the compensation term is order-dependent. Must use `reduction` on a struct with a custom combiner, or serialize the compensation. **This is a likely latent bug.**

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

This is **backwards**. `panic=unwind` across an FFI boundary is *undefined behavior* in Rust unless the boundary is `extern "C-unwind"`. The correct hardening is:

- `panic=abort` for the FFI crate, **or**
- `extern "C-unwind"` on every exported symbol, **or**
- `catch_unwind` at every entry point.

**Recommendation:** wrap every `#[no_mangle] pub extern "C"` in `std::panic::catch_unwind` and return a sentinel error code. Otherwise a panic in Rust will unwind into C++ and corrupt the stack.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust's `#[repr(C, packed)]` gives 88 bytes but **unaligned field access is UB** in Rust for references. Must use `read_unaligned` / `write_unaligned`. If the code uses `&desc.n_rows`, that is **UB** on strict-align targets. **UNVERIFIED.**

### 3.3 Safe SIMD

`std::simd` is still nightly. If the crate uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" is a misnomer unless wrapped. **UNVERIFIED.**

### 3.4 Neumaier in Rust

Same numerical analysis as Target 2. Rust's `f64::mul_add` (FMA) can *replace* Neumaier for the dot product with a single rounding, giving `|error| ≤ u·|Σ|` — strictly better. **Recommendation:** use `mul_add` and drop Neumaier unless FMA is unavailable.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in R^(2K × 2K)

The Cayley retraction on the Stiefel manifold `St(n,p)`:

```
Y(τ) = (I − (τ/2) A)⁻¹ (I + (τ/2) A) Y,   A = XᵀV − VᵀX  (skew)
```

For `X ∈ R^(2K × 2K)` (square, so `St(2K,2K) = O(2K)`), `A` is `2K × 2K` skew-symmetric. The retraction is **exact** (Cayley is a rational approximation to the exponential, and on `O(n)` it stays on the manifold for any `τ`).

**Degeneracy at step → ∞:**
- As `τ → ∞`, `Y(τ) → −Y(0)` (the antipode). The map is *not* injective at infinity; it wraps. For `τ = 1e10`, `(τ/2)A` dominates and the solve is ill-conditioned: `cond(I − (τ/2)A) ~ τ·‖A‖`. **Condition number grows linearly in τ.** For `τ = 1e10` and `‖A‖ ~ 1`, `cond ~ 1e10`, and the solve loses ~10 digits. **Recommendation:** cap `τ` at `O(1/‖A‖)` and use a line search.
- **Woodbury scaling `(M/scale) W = (step/scale) B`:** this is a *no-op* if `scale` is a scalar — it cancels. If `scale` is a matrix, it changes the problem. **UNVERIFIED** what `scale` is. If `scale = step`, then `W = B` trivially, which cannot be the intent.

### 4.2 cuSOLVER `DnDsyevd`

`DnDsyevd` is the *divide-and-conquer* symmetric eigensolver. It is **not** a Cayley solver. Using it to compute `(I − (τ/2)A)⁻¹` requires forming the matrix and inverting — `O(n³)` and numerically worse than a direct skew-symmetric solve. **Recommendation:** use `cusolverDnSsytrf` (Bunch–Kaufman) or exploit skew-symmetry via a Hessenberg reduction.

### 4.3 CUDA Graphs

Graph