# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 163

The requested **definitive arbitration is not possible from the available evidence**: no public, verifiable specifications or reports for “POLYDIM V1350,” its six kernels, the “PMTP 88-byte Descriptor,” or the eight claimed Tribunal findings were provided or located. The following is therefore a **conditional SOTA synthesis**, not a certification of those artifacts.

## 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

No method can be guaranteed stable solely because it is labeled Cayley, Householder, polar, or QR. Stability depends on scaling, conditioning, floating-point format, rank preservation, and implementation details.

For a tangent update \(X+\eta\), with \(X^\top X=I\), the polar retraction is

\[
R_{\mathrm{polar}}(X,\eta)
=
(X+\eta)\bigl(I+\eta^\top\eta\bigr)^{-1/2}.
\]

The Cayley form generally requires solving a system involving a skew-symmetric operator. The relevant numerical distinction is:

- **Polar retraction:** orthogonality is recovered through a positive-definite inverse square root; it is usually the strongest default for large perturbations, provided the inverse square root is computed with a backward-stable eigensolver, SVD, or equivalent robust method.
- **Householder QR:** often has excellent practical stability and avoids explicitly forming normal equations, but sign conventions, rank deficiency, and loss of smoothness at sign changes must be handled.
- **Classical Gram–Schmidt QR:** should not be accepted for this regime without reorthogonalization.
- **Cayley retraction:** can preserve orthogonality algebraically, but extreme step sizes can make the associated linear solve poorly scaled. It requires norm scaling, pivoting or stable factorization, residual checks, and a fallback path.

Published Stiefel-retraction analyses report bounded forward conditioning for canonical Cayley and polar-light retractions in their stated domains, while standard treatments identify QR and polar decomposition as established retraction choices.[4][5][14] Those results do **not** establish stability for an unscaled finite-precision implementation at \(10^{10}\)-scale steps.

### Arbitration

The mathematically strongest architectural policy is:

1. Compute the update using **scale-aware arithmetic**:
   \[
   \eta = s\widehat{\eta},\qquad
   s = 2^k,\quad \|\widehat{\eta}\|\ \text{in a safe range}.
   \]
2. Prefer **polar or Householder QR** as the reference implementation.
3. Permit Cayley only when:
   - the solve is backward stable;
   - the residual satisfies a specified bound;
   - the resulting orthogonality defect is checked;
   - failure triggers a polar/Householder fallback.
4. Verify
   \[
   \|Q^\top Q-I\| \le \tau_{\mathrm{orth}},
   \qquad
   \frac{\|Q-(X+\eta)\|}{\|X+\eta\|}\le \tau_{\mathrm{back}},
   \]
   with tolerances explicitly parameterized by dimension and machine precision.

**Guarantee:** conditional backward stability and an orthogonality-error bound after successful validation.

**Not guaranteed:** finite output, bounded forward error, or convergence for arbitrary \(|\mathrm{step}|\ge10^{10}\) without assumptions on scaling, matrix dimensions, precision, and conditioning.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release ordering is necessary but not sufficient for snapshot isolation. A release publication followed by an acquire observation establishes a synchronizes-with relationship only when the acquire reads from the relevant release sequence or otherwise satisfies the language/runtime memory model.[2][6][7]

The descriptor must therefore be treated as an **immutable publication record**, not as a mutable object whose fields are independently updated. A correct protocol is:

```text
writer:
    allocate and fully initialize immutable payload
    publish payload/version with release semantics
    retire old payload only after a grace period

reader:
    enter RCU/QSBR read-side critical section
    acquire-load published pointer/version
    read immutable payload
    exit read-side critical section
```

For QSBR, readers must reliably announce quiescent states, and reclamation must wait until every reader that could have observed the prior version has passed through a quiescent state.[3][15] Release/acquire pairs provide visibility ordering, but they do not by themselves prevent premature reclamation, ABA reuse, torn multiword state, or readers retaining pointers after leaving their protected region.

### Required 88-byte invariants

The descriptor contract should specify:

- exact byte layout, alignment, endianness, and padding;
- one atomic publication word or pointer/version pair;
- immutable fields after publication;
- no unaligned or torn atomic access;
- a generation counter or equivalent ABA defense;
- a defined reclamation mechanism;
- reader critical-section lifetime;
- release publication and acquire consumption on the **same synchronization variable**;
- validation of descriptor version, length, and checksum/tag where applicable.

If the 88-byte record contains fields that must change atomically as a group, ordinary acquire/release loads of separate fields are inadequate. Use an indirection to an immutable object, a seqlock-style protocol with carefully specified reader retry rules, or a platform-supported atomic representation whose width and alignment are guaranteed.

**Guarantee:** with immutable snapshots, correct acquire/release publication, and a completed RCU/QSBR grace period, readers see a fully initialized version and reclamation does not race with protected readers.

**Not guaranteed:** atomicity of the entire 88-byte descriptor, global total ordering among readers, or safety from relaxed operations used on publication/reclamation metadata.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single common memory model that allows an unqualified claim of identical behavior across all five targets.

| Layer | What can be specified portably | Main limitation |
|---|---|---|
| C++20 | `release` store and matching `acquire` load establish language-level synchronization | Does not automatically define CUDA device/host visibility or framework scheduling |
| Rust | Atomic orderings are aligned with C++20 semantics; acquire/release establish the corresponding happens-before relation | Same cross-device and reclamation limitations |
| CUDA | Device-scope atomics, fences, and stream/event synchronization can define GPU ordering | Scope, cache visibility, host interaction, and kernel boundaries matter |
| Triton | Correctness depends on the generated GPU operations and supported atomic/fence primitives | The source-level abstraction is not a universal C++/Rust memory model |
| XLA | Operations are subject to compiler lowering, fusion, scheduling, and device runtime semantics | Mutable shared-memory protocols are generally unsuitable unless expressed through supported synchronization constructs |

The only defensible cross-silicon guarantee is therefore a **refinement contract**:

1. Define the abstract state machine independently of any backend.
2. Make publication data immutable.
3. Represent synchronization through backend-specific primitives.
4. Require backend conformance tests for:
   - no torn descriptor reads;
   - no stale payload after an acquired publication;
   - no use-after-reclamation;
   - monotonic version behavior;
   - correct behavior under delayed readers and writer/reader overlap.
5. Validate numerical kernels by residuals and orthogonality defects, not by bitwise equality across backends.
6. Treat cross-backend numerical equivalence as tolerance-based:
   \[
   \|Q^\top Q-I\|\le \tau_{\mathrm{backend}},
   \qquad
   \frac{\|f_{\mathrm{backend}}-f_{\mathrm{ref}}\|}
        {\max(1,\|f_{\mathrm{ref}}\|)}
   \le \tau_{\mathrm{value}}.
   \]

## Definitive arbitration

The strongest synthesis supported by established numerical-linear-algebra and memory-model principles is:

- **Retraction:** use a scale-aware polar or Householder-QR reference path; use Cayley only with stable solves, residual checks, and mandatory fallback.
- **Descriptor:** publish immutable snapshots through a single well-defined release/acquire protocol; protect pointer lifetime with RCU/QSBR grace periods; do not claim that 88 bytes are atomically transferable as one unit.
- **Portability:** specify semantic invariants once, then implement and test them separately for CUDA, XLA, Triton, C++20, and Rust. Do not infer cross-silicon conformance from source-code similarity.
- **Architectural guarantee:** successful operations provide validated orthogonality and snapshot-consistency bounds under explicit precision, alignment, synchronization-scope, and reclamation assumptions.
- **Rejected claim:** unconditional stability at \(|\mathrm{step}|\ge10^{10}\), unconditional snapshot isolation from acquire/release alone, and exact behavioral equivalence across all five execution ecosystems.