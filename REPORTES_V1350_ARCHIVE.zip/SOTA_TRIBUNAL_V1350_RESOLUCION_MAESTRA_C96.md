# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 96

The available evidence does **not** contain the six tribunal reports or any verifiable specification for “POLYDIM V1350,” “PMTP,” or its 88-byte descriptor. Therefore, no evidence-based arbitration can identify what Claude, Qwen, Kimi, Gemini, DeepSeek, or Perplexity concluded, nor can it honestly claim an implementation-specific guarantee. The defensible SOTA synthesis is a **conditional architecture**, with guarantees stated only under explicit numerical, memory-model, and backend assumptions.

## 1. Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For \(X\in\mathrm{St}(n,p)\), \(X^\top X=I\), standard candidates include

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)(I+\Xi^\top\Xi)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley map of the form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=\left(I-\frac12 W\right)^{-1}
 \left(I+\frac12 W\right)X,
\]

where \(W^\top=-W\) is constructed from \(X\) and the tangent direction. These formulas and their differing computational costs are documented in the Stiefel-retraction literature.[1]

### Arbitration

**No method is automatically stable merely because it is a Cayley transform.** At an extreme step, the decisive issue is the conditioning and scaling of the actual linear-algebra kernels:

- **Unscaled Cayley:** not acceptable as a blanket guarantee. Forming \(W\) with entries of order \(10^{10}\), followed by an unprotected solve, can cause overflow, loss of significance, or backend-dependent results.
- **Householder QR:** generally the safest baseline for rank-revealing orthogonalization, provided the implementation uses blocked Householder reflectors, stable pivot/sign conventions, and scaling.
- **Polar:** gives the closest orthonormal factor in Frobenius norm, but the inverse square root and its iterative implementation require bounded, convergence-checked kernels.
- **Cayley:** attractive when implemented in low-rank form with equilibration, norm-based step clipping, stable solves, and residual checks. It preserves orthogonality analytically because the Cayley transform of a skew-symmetric matrix is orthogonal, but finite-precision preservation is implementation-dependent.[2]

The mathematically superior policy is therefore **not “Cayley always wins.”** It is:

\[
\boxed{
\text{Cayley for ordinary bounded steps;}
\quad
\text{scaled polar/Householder fallback for extreme or ill-conditioned steps.}
}
\]

A valid extreme-step kernel should:

1. Rescale the tangent direction before constructing \(W\).
2. Compute the transform using a factored or low-rank solve rather than explicitly forming an \(n\times n\) inverse.
3. Use QR or polar fallback when scaling, pivot growth, or residual tests fail.
4. Verify

   \[
   \|Y^\top Y-I\| \le \tau_{\mathrm{orth}}
   \]

   and reject or recompute if the tolerance is exceeded.
5. Make the sign/phase convention deterministic across backends.

The available sources support Cayley, QR, and polar retractions as legitimate alternatives, but do **not** support a universal theorem that Cayley is more stable than Householder QR or polar decomposition for \(|\mathrm{step}|\ge10^{10}\).[1][3]

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

No supplied source establishes the layout or semantics of the claimed 88-byte PMTP descriptor. Consequently, its exact field alignment, atomicity, versioning, ownership, and publication protocol cannot be certified.

The correct architectural rule is:

\[
\boxed{
\text{Release publishes a fully initialized immutable snapshot;}
\quad
\text{Acquire observes that snapshot before dereference.}
}
\]

A minimum publication protocol is conceptually:

```cpp
// Writer
new_snapshot->initialize_non_atomic_fields();
descriptor->snapshot.store(new_snapshot, std::memory_order_release);

// Reader
auto* s = descriptor->snapshot.load(std::memory_order_acquire);
use_immutable_snapshot(s);
```

For RCU/QSBR, acquire/release alone is insufficient to solve reclamation. The design also requires:

- readers to announce entry before loading or dereferencing the snapshot;
- writers to retire replaced snapshots rather than immediately freeing them;
- reclamation only after every pre-existing reader has passed a quiescent state or otherwise demonstrated that it cannot hold the old pointer;
- atomic publication of the complete pointer/version state;
- no reader access to mutable fields after publication unless those fields have their own synchronization.

Thus the exact guarantee should be stated as:

> If initialization happens-before a release publication, and a reader performs an acquire observation before dereferencing the snapshot, the reader observes a fully initialized snapshot. RCU/QSBR additionally guarantees safe reclamation only when reader registration, grace-period detection, and retirement are correctly implemented.

An 88-byte size does **not** itself guarantee atomicity. A descriptor must specify:

- alignment;
- which fields are atomic;
- whether the published unit is a pointer, tagged pointer, index, or versioned record;
- whether a 128-bit or larger state is ever read atomically;
- cache-line placement and false-sharing policy;
- lifetime and reclamation rules.

For GPU and heterogeneous execution, host C++ memory-order semantics cannot simply be assumed to transfer to CUDA, XLA, or Triton device memory. Device scopes, fences, stream/event ordering, and host-device synchronization must be specified separately.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no evidence in the supplied material of a conformance test suite or six-backend implementation. Therefore, “multi-silicon conformance” cannot be claimed as an achieved result.

The strongest defensible architecture is a **backend-independent semantic contract** with backend-specific realizations:

| Contract | Required guarantee |
|---|---|
| Orthogonality | \(Y^\top Y\) satisfies a declared tolerance |
| Determinism | Same defined input, precision, seed, and reduction policy produce equivalent output |
| Publication | Readers never observe partially initialized snapshots |
| Reclamation | No retired snapshot is freed while reachable by a reader |
| Numerical failure | Invalid conditioning or residuals trigger fallback or an explicit error |
| ABI | Descriptor size, alignment, offsets, endianness, and atomic fields are compile-time checked |
| Cross-backend behavior | Differences are bounded by declared floating-point tolerances, not assumed bitwise identical |

### Language/runtime mapping

- **C++20:** use `std::atomic` with explicit acquire/release operations and a separately verified RCU/QSBR implementation. The C++ memory model governs C++ objects, not arbitrary device allocations.
- **Rust:** use atomics and ownership/lifetime discipline for host-side publication, but `unsafe` remains necessary for FFI, shared-memory layouts, device pointers, and reclamation boundaries. Rust’s type system does not automatically prove a foreign RCU protocol correct.
- **CUDA:** specify memory scope—thread, block, device, or system—and use the corresponding atomics/fences and stream/event ordering.
- **Triton:** treat kernel launch and program-instance ordering as explicit; do not infer general-purpose RCU semantics from ordinary tensor operations.
- **XLA:** account for compiler scheduling, asynchronous execution, replicated buffers, and backend-specific lowering. Snapshot publication should normally be represented through explicit data dependencies or runtime synchronization rather than assumed language-level atomics.

## Definitive arbitration

The only technically supportable SOTA synthesis is:

1. **Retraction:** use a scaled, low-rank Cayley implementation as the fast path; use Householder QR or a robust polar implementation as a residual-checked fallback. No unconditional extreme-step stability guarantee is valid.
2. **Descriptor:** publish immutable snapshots with release semantics and consume them with acquire semantics; combine this with a complete RCU/QSBR grace-period protocol. Acquire/release alone does not guarantee reclamation safety.
3. **Conformance:** define one abstract semantic specification and test every backend against it using orthogonality residuals, visibility litmus tests, reclamation stress tests, ABI assertions, randomized differential tests, and multi-silicon tolerance envelopes.
4. **Guarantee boundary:** promise only conditional guarantees backed by residual checks, explicit memory scopes, and tested backend mappings—not universal bitwise identity or unconditional stability at \(10^{10}\)-scale steps.

Claims that a particular tribunal model definitively established stronger guarantees would require the six actual reports and the V1350/PMTP specifications, which are not present in the available evidence.