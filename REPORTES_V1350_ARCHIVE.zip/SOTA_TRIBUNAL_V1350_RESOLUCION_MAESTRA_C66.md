# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 66

I cannot produce a **definitive arbitration of the six Tribunal models** from the material available: no Claude, Qwen, Kimi, Gemini, DeepSeek, or Perplexity findings, nor a V1350 specification, were provided. The available search results identify PolyDiM as a PDE discretization library, not the claimed V1350 architecture, so attributing exact V1350 guarantees would be unsupported.[5][6][12]

The mathematically defensible synthesis is therefore conditional:

## 1. Stiefel retraction under \(|\mathrm{step}| \ge 10^{10}\)

For \(X \in \mathrm{St}(n,p)\) and a tangent direction \(\Xi\), a Cayley update generally has the form

\[
Y(t)=\left(I-\frac{t}{2}A\right)^{-1}
     \left(I+\frac{t}{2}A\right)X,
\]

where \(A^\mathsf{T}=-A\). In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists, so it preserves \(Y^\mathsf{T}Y=I\).

That does **not** imply numerical stability for extreme \(t\):

- The solve may become ill-conditioned or suffer cancellation.
- Finite-precision orthogonality depends on the factorization, scaling, pivoting, and residual correction.
- A large step does not make the method globally accurate; it can move far from the intended tangent approximation.
- If the implementation forms \(I\pm tA/2\) explicitly, overflow, underflow, loss of significance, and poor conditioning are possible.

Householder QR is typically the strongest baseline for robust orthogonalization because it uses backward-stable reflectors. Polar retraction has attractive geometric properties and is second-order in the usual retraction sense; QR retraction is generally first-order.[11] Neither QR nor polar decomposition provides an unconditional guarantee at arbitrary step magnitude: the input can itself be badly scaled or nearly rank deficient.

**Arbitration:** no method should be declared unconditionally superior for \(|t|\ge 10^{10}\). A defensible architecture would:

1. use a scaled/skew-symmetric Cayley solve when its condition estimate is acceptable;
2. compute a backward-error and orthogonality residual;
3. fall back to Householder QR or a carefully implemented polar correction when thresholds fail;
4. optionally cap or normalize the effective step while preserving the requested direction.

The strongest realistic guarantee is conditional:

\[
\|Y^\mathsf{T}Y-I\|
\le c\,u\,\kappa(\text{update})+\text{solver error},
\]

where \(u\) is unit roundoff. An exact, step-independent finite-precision guarantee is not justified.

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

An 88-byte layout alone guarantees only size and alignment properties if those are explicitly specified and validated. It does **not** establish memory ordering or snapshot isolation.

For an immutable-payload, versioned descriptor, the essential publication pattern is:

1. Fully initialize payload and metadata using ordinary non-atomic operations.
2. Publish the descriptor pointer or generation using a **release** operation.
3. Readers load the published value using **acquire**.
4. Readers enter an RCU/QSBR read-side critical section before dereferencing.
5. Writers retire old objects only after a grace period confirms that all pre-existing readers have quiesced.

The ordering requirement is conceptually:

\[
\text{payload initialization}
\;\xrightarrow{\text{release}}\;
\text{publication}
\;\xrightarrow{\text{acquire}}\;
\text{reader dereference}.
\]

Acquire/release does not by itself solve reclamation. It establishes visibility; RCU/QSBR supplies lifetime protection. A correct guarantee therefore requires all of the following:

- no reader dereference before acquiring a published version;
- no mutation of an object after publication, unless every field has its own valid synchronization;
- reader registration before loading the pointer;
- retirement after replacement, not before;
- reclamation only after a proven grace period;
- defined behavior for ABA, generation wraparound, and descriptor reuse;
- explicit host/device memory-scope semantics where GPU agents participate.

If CUDA, XLA, or Triton kernels access the descriptor, C++20 or Rust atomics alone do not automatically define GPU visibility. The implementation must map operations to the target platform’s supported memory scopes and synchronization primitives. Thus the exact guarantee should be stated as:

> A reader observes a fully initialized immutable descriptor version if and only if publication uses release semantics, acquisition uses acquire semantics at a compatible scope, and reclamation occurs after a valid RCU/QSBR grace period.

An 88-byte size constraint is orthogonal to that guarantee.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

“Multi-silicon conformance” is not a single property. These systems have different execution and memory models:

| Layer | What can be specified portably | What requires backend-specific validation |
|---|---|---|
| C++20 | Object representation, atomic orders, defined host behavior | Device compilation, GPU scopes, ABI details |
| Rust | Type/layout guarantees with explicit representation; ownership discipline | Atomic lowering, FFI ABI, device support |
| CUDA | GPU execution, scopes, synchronization, atomics supported by the target | Architecture-specific ordering and compiler lowering |
| Triton | Kernel-level program semantics within supported primitives | Backend lowering, layouts, atomics, synchronization scope |
| XLA | Stable HLO-level semantics and compiler contracts | Backend-dependent lowering, aliasing, synchronization, numerical details |

A valid conformance claim needs a formal contract covering:

- descriptor byte layout, offsets, endianness, and alignment;
- supported integer and floating-point widths;
- atomic widths and scopes;
- publication and reclamation protocol;
- permitted compiler transformations;
- numerical tolerances;
- synchronization boundaries;
- behavior under multiple GPU generations and CPU targets;
- litmus tests and stress tests;
- ABI and serialization versioning.

The correct SOTA position is therefore **contract-based portability**, not source-level equivalence. The kernels may be conformant only if every backend passes the same observable-behavior test suite, including:

\[
\text{layout}
+\text{publication ordering}
+\text{snapshot visibility}
+\text{reclamation safety}
+\text{numerical tolerance}
+\text{failure-path behavior}.
\]

## Definitive arbitration

Based on the evidence available, the following claims are supportable:

- **Cayley:** exactly orthogonality-preserving in exact arithmetic, but not unconditionally stable for extreme steps in finite precision.
- **Householder QR:** the preferred robust fallback for re-orthogonalization, not a proof of arbitrary-step correctness.
- **Polar:** geometrically attractive and second-order as a retraction, but not automatically superior under extreme scaling or deficient inputs.[11]
- **PMTP:** an 88-byte descriptor does not imply memory safety or snapshot isolation.
- **Acquire/release:** necessary for publication visibility in the stated pattern, but insufficient without correct RCU/QSBR lifetime management.
- **Cross-silicon conformance:** cannot be guaranteed from language-level source compatibility; it requires explicit memory-scope mappings, ABI specifications, backend implementations, and differential testing.
- **Exact architectural guarantees:** impossible to formulate without the six model reports, the V1350 kernel definitions, the descriptor field map, target architectures, and the intended memory model.

Accordingly, the mathematically strongest architecture is a **guarded hybrid**: scaled Cayley updates with residual-based validation, Householder QR fallback, immutable versioned descriptors, release/acquire publication at explicitly defined scopes, RCU/QSBR grace-period reclamation, and a backend-neutral conformance suite whose guarantees are stated per target rather than assumed globally.