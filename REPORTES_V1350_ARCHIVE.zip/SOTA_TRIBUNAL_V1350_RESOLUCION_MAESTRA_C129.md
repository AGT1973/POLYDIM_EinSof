# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 129

The eight Tribunal findings cannot be independently compared because their reports, kernel specifications, and benchmark traces were not provided. A definitive arbitration therefore must distinguish **provable architectural guarantees** from claims that require empirical validation. Based on the stated requirements, the mathematically strongest synthesis is:

1. **Use a safeguarded polar retraction as the numerical reference path.**
2. **Permit Cayley only with explicit conditioning checks and a bounded-step fallback.**
3. **Treat acquire/release as necessary but not sufficient for PMTP snapshot isolation.**
4. **Define cross-silicon conformance through an explicit language-neutral memory and numerical contract, not source-level similarity.**

## 1. Stiefel retraction under \(\lvert\mathrm{step}\rvert \ge 10^{10}\)

For \(X \in \mathrm{St}(n,p)\), the polar retraction is

\[
R_X(\xi)=(X+\xi)\left(I_p+\xi^{T}\xi\right)^{-1/2}.
\]

The matrix \(I_p+\xi^{T}\xi\) is positive definite for finite \(\xi\), so the inverse square root is defined mathematically. The polar form therefore provides the cleanest global admissibility argument and is the appropriate **correctness oracle** for extreme steps.[12]

The Cayley update is based on solving a system involving a skew-symmetric operator, typically of the form

\[
(I-\alpha \Omega)Y=(I+\alpha \Omega)X,
\qquad \Omega^T=-\Omega .
\]

In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists. However, numerical stability is controlled by the conditioning of the solve and by whether the chosen parameterization approaches its excluded singular set. Recent Stiefel-retraction analysis explicitly identifies an eigenvalue condition involving \(-1\) for the canonical Cayley construction.[3] Consequently, orthogonality in exact arithmetic does **not** imply bounded forward error for an extreme step.

### Arbitration

- **Polar retraction:** best reference implementation for extreme magnitudes, provided the \(p\times p\) inverse square root is computed with a backward-stable eigensolver, Schur method, or SVD and scaled arithmetic.
- **Householder/QR:** strong practical fallback, especially when rank-revealing and sign conventions are fixed. It is generally stable, but its result may differ by a right orthogonal factor unless the convention is specified.
- **Cayley:** acceptable as a fast path only when a condition estimate, scaling policy, and residual test pass. It must not be advertised as unconditionally stable for \(\lvert\mathrm{step}\rvert \ge 10^{10}\).

The exact guarantee should be stated as:

\[
\widehat X^T\widehat X=I_p+E,
\qquad
\|E\|\le c\,u\,\kappa_{\mathrm{alg}}\,\mathrm{poly}(n,p),
\]

where \(u\) is machine unit roundoff and \(\kappa_{\mathrm{alg}}\) is the condition number of the selected numerical path. The implementation must reject or fall back when this bound exceeds the configured tolerance.

Thus, the superior architecture is:

```text
Cayley fast path
    ├─ scale step and operator
    ├─ estimate conditioning
    ├─ solve with pivoting or stable structured method
    ├─ verify orthogonality and residual
    └─ fall back to polar, then Householder/QR if required
```

No implementation can guarantee finite-precision orthogonality independent of matrix dimension, conditioning, overflow, underflow, or the supplied tolerance. The strongest defensible claim is **verified bounded error with deterministic fallback**, not unconditional stability.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

A release store followed by an acquire load of the **same atomic publication variable** establishes a synchronizes-with relationship; writes sequenced before the release become visible to operations sequenced after the acquiring load.[1][11] RCU verification work likewise relies on release/acquire ordering for publication and on quiescent-state ordering before reclamation.[2]

For an 88-byte PMTP descriptor, the descriptor itself should not be treated as one atomic object unless the target platform explicitly guarantees such atomicity. The safe design is:

- immutable payload fields initialized before publication;
- an atomic generation, pointer, or sequence word used as the publication point;
- release publication by the writer;
- acquire observation by readers;
- reader-side protection before dereferencing;
- QSBR or equivalent grace-period completion before reclamation.

A correct publication pattern is conceptually:

```cpp
descriptor->fields = initialized_value;
descriptor->generation.store(new_generation,
                             std::memory_order_release);
```

and:

```cpp
auto g = descriptor->generation.load(std::memory_order_acquire);
consume_descriptor_fields();
```

The acquire must read from the relevant release sequence. An acquire fence placed somewhere else, or a relaxed load of the descriptor fields, does not automatically create the required publication edge.

### Exact guarantee

For each reader \(R\) and publisher \(P\):

\[
P:\; \text{initialize payload}
\;\mathrel{\mathrm{sb}}\;
\text{release-publish}(v)
\]

and, if

\[
R:\; \text{acquire-load}(v)
\]

reads that value or its release sequence, then

\[
\text{initialize payload}
\;\mathrel{\mathrm{hb}}\;
\text{reader payload access}.
\]

For reclamation, publication ordering alone is insufficient. The writer must additionally establish:

\[
\text{reader protection or entry}
\;\mathrel{\mathrm{hb}}\;
\text{reader quiescence}
\;\mathrel{\mathrm{hb}}\;
\text{reclamation}.
\]

The guarantee is therefore **safe immutable snapshot observation and deferred reclamation**, not transactional isolation in the database sense. If readers can observe multiple independently published descriptors, PMTP must define whether a snapshot consists of:

- one generation token;
- a seqlock-style double-read validation;
- an RCU root pointer;
- or an immutable aggregate object.

For a coherent multi-field snapshot, the preferred design is an immutable descriptor or immutable root object published through one atomic pointer/generation. A reader that sees generation \(g\) must consume only fields belonging to \(g\). Updating fields individually, even with release stores, does not guarantee a coherent 88-byte snapshot.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no automatic theorem that identical-looking code has identical memory semantics across these systems. C++20 and Rust provide language-level memory models; CUDA, Triton, and XLA additionally impose device, compiler, lowering, and execution-model constraints. Therefore conformance must be defined at the **abstract contract level**.

The common contract should specify:

- descriptor layout, alignment, endianness, and padding;
- publication variable and generation protocol;
- legal memory orders;
- lifetime and reclamation rules;
- numerical tolerance and NaN/Inf behavior;
- deterministic tie-breaking and QR sign conventions;
- overflow, underflow, and extreme-step handling;
- whether operations are synchronous, stream-ordered, or asynchronously visible.

### C++20 and Rust

C++20 and Rust can express acquire/release publication, but the implementation must use the corresponding atomic object consistently. Rust’s ownership and aliasing rules strengthen lifetime reasoning, but they do not by themselves establish cross-device visibility. Unsafe code, FFI, DMA, GPU mappings, and custom allocators still require an explicit synchronization contract.

### CUDA

CUDA conformance requires separating:

- host/device visibility;
- block/device/system scope;
- stream ordering;
- atomic ordering and fence scope.

A device acquire/release operation does not automatically provide host visibility or system-wide ordering unless the selected scope and synchronization mechanism provide it.

### Triton and XLA

Triton kernels and XLA computations may be transformed, fused, reordered, or replicated by their compilation pipelines. A source-level atomic or barrier abstraction is not enough unless its lowering preserves the required scope and happens-before relation. XLA’s functional and asynchronous execution model particularly requires publication through supported runtime-visible synchronization mechanisms rather than assumptions about source execution order.

### Arbitration

The only defensible multi-silicon guarantee is:

> Every backend conforms if, for every permitted execution, its lowered implementation preserves the specified abstract publication order, lifetime rule, descriptor ABI, and numerical error contract.

This must be tested with litmus tests and differential tests, including:

- publication-before-observation;
- stale-generation rejection;
- reader-protection-before-reclamation;
- concurrent writer and reader stress;
- descriptor misalignment and padding checks;
- extreme Cayley steps;
- polar/QR fallback equivalence within tolerance;
- NaN, Inf, overflow, and underflow cases;
- repeated execution across architectures and compiler optimization levels.

## Definitive SOTA architecture

The six kernels should share the following design:

1. **Numerical kernel**
   - Cayley as an optimized path.
   - Conditioning and residual checks.
   - Polar retraction as the mathematical reference.
   - Householder/QR as a robust fallback.
   - Explicit orthogonality and residual tolerances.

2. **Descriptor kernel**
   - 88-byte ABI frozen with static layout assertions.
   - Immutable payload.
   - One atomic publication token or root pointer.
   - Release publication and acquire consumption.
   - Generation validation for coherent snapshots.
   - QSBR/RCU grace period before reclamation.

3. **Portability kernel**
   - Backend-neutral happens-before specification.
   - Explicit memory scope for each accelerator.
   - No reliance on incidental compiler ordering.
   - Differential numerical and concurrency tests.
   - Fail-closed behavior when a backend cannot provide the required scope or atomicity.

The resulting guarantees are:

- **Mathematical:** exact-manifold preservation in exact arithmetic; bounded finite-precision deviation when the residual checks pass.
- **Numerical:** no unconditional stability claim for extreme Cayley steps; verified fallback to polar or QR.
- **Memory:** release/acquire publication visibility for the same atomic publication object.
- **RCU/QSBR:** no reclamation while a protected reader may still access the object, assuming the grace-period protocol is correctly implemented.
- **ABI:** byte-level descriptor compatibility only where layout, alignment, padding, and endianness are explicitly fixed.
- **Cross-silicon:** conformance only when each backend preserves the abstract memory-order, lifetime, and numerical contracts.

Without the eight actual Tribunal reports, it is not possible to attribute particular findings to Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, or Perplexity, nor to declare a majority finding. The synthesis above is the strongest architecture that follows from the stated technical requirements and the available mathematical and memory-model evidence.