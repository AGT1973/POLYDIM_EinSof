# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 136

The requested arbitration cannot be performed as a factual comparison of the eight Tribunal models because their individual reports, the definitions of the six V1350 kernels, and an authoritative POLYDIM specification were not provided. The available evidence does not establish that “POLYDIM V1350,” “Cycle 136,” or the claimed eight-model evaluation is a publicly verifiable benchmark. Therefore, the guarantees below are the strongest defensible synthesis—not a claim that all eight models agreed.

## 1. Cayley Stiefel retraction under \(\lvert\text{step}\rvert \ge 10^{10}\)

A Cayley update is a valid Stiefel-manifold retraction when constructed from a skew-symmetric generator and evaluated stably; the Cayley transform preserves orthogonality in exact arithmetic. The cited literature describes Cayley-based retractions as efficient updates for large, non-square Stiefel parameters.[14]

However, **no unconditional numerical-stability guarantee exists for an arbitrary step of magnitude \(10^{10}\)**. At such scales, the result depends on:

- floating-point precision;
- scaling and conditioning of the skew generator;
- the method used to solve the Cayley linear system;
- overflow, underflow, and loss of significance;
- whether the implementation forms \(I-\alpha W\) explicitly;
- residual monitoring and fallback behavior.

The mathematically defensible arbitration is therefore:

\[
\text{Cayley} \not\Rightarrow \text{stable for arbitrary extreme steps}.
\]

A robust implementation should use a stable solve for

\[
(I-\alpha W)Q_{+}=(I+\alpha W)Q,
\]

rather than explicit inversion, and should verify

\[
\|Q_{+}^{T}Q_{+}-I\|
\]

against a precision-dependent tolerance. If the residual or solve condition estimate fails, it should reduce the step, rescale the generator, or fall back to a numerically stable orthogonalization.

**Householder QR** is generally the most reliable fallback for rank-revealing orthogonalization, while **polar decomposition** provides the closest orthogonal factor in the Frobenius norm but can be more expensive and itself requires a stable numerical implementation. Thus the architectural guarantee should be:

> For extreme steps, the kernel guarantees an orthonormal output only conditionally: if the stable solve and residual test pass. Otherwise it must return a documented failure or invoke QR/polar fallback; silent acceptance is not a valid SOTA guarantee.

A stronger unconditional claim—“Cayley is superior to Householder or polar QR for every \(\lvert\text{step}\rvert \ge 10^{10}\)”—is mathematically unsupported.

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

Acquire/release semantics provide the required visibility relation only when they operate on the **same synchronization atomic**. A release store followed by an acquire load that reads from that release synchronizes the threads; preceding writes become visible after the acquire.[5] Rust documents the same C++ memory-ordering model and specifies that acquire loads observe writes ordered before a matching release.[1]

For an 88-byte descriptor, this means:

- The descriptor payload must be fully initialized before publishing its pointer, version, or sequence token with a release operation.
- Readers must acquire that same publication token before accessing the payload.
- The descriptor must not be modified in place while readers may hold a snapshot.
- Reclamation requires a valid RCU/QSBR grace-period protocol, not merely acquire/release on the descriptor.
- A reader’s quiescent-state announcement must be ordered so that the writer cannot reclaim storage until all pre-existing readers have exited.

RCU verification work specifically treats release/acquire ordering as necessary for ensuring that reader accesses finish before a writer deallocates an unreachable node.[15] QSBR separates logical removal from physical reclamation: removal may occur first, but reuse or deallocation must wait for a grace period.[8]

The exact guarantee should therefore be stated as:

> A PMTP descriptor is snapshot-safe if readers acquire the publication/version atomic, access an immutable descriptor generation, and the writer reclaims that generation only after a completed QSBR/RCU grace period covering every reader that could have observed it.

Acquire/release alone does **not** guarantee:

- atomicity of an 88-byte load or store;
- freedom from torn reads;
- protection against ABA;
- reclamation safety;
- a globally consistent multi-field snapshot;
- ordering across different atomic variables without an explicit protocol.

If the descriptor is read as multiple machine words, the design needs immutable generations, a seqlock-style validation protocol, an atomic pointer/handle, or equivalent indirection. A size of exactly 88 bytes has no inherent memory-ordering significance.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no basis for asserting byte-for-byte or memory-model equivalence across all five environments without a conformance suite and explicitly defined backend contracts.

The strongest portable abstraction is:

1. **C++20/Rust host layer:** use the language memory model and matching acquire/release operations. Rust’s atomic orderings are specified to match C++20’s semantics.[1]
2. **CUDA device layer:** separately specify device-scope visibility, stream/event ordering, and host-device publication. Host-language atomics do not automatically establish device-memory ordering.
3. **XLA:** treat operations as graph-level computations whose legal reorderings and aliasing are governed by the compiler and backend; expose snapshot publication through explicit synchronization or immutable buffers.
4. **Triton:** specify synchronization and memory effects in terms supported by the target GPU and compiler; do not assume that a C++ atomic annotation maps directly to Triton semantics.
5. **Numerical kernels:** define precision, accumulation mode, NaN/Inf behavior, tolerance, layout, alignment, and fallback behavior independently of the programming language.

The correct conformance claim is consequently:

> Cross-silicon conformance is achieved only for a declared contract and tested implementation matrix; it cannot be inferred from shared source-level terminology such as “acquire,” “release,” “Cayley,” or “snapshot.”

A suitable test suite must verify, at minimum:

- Stiefel residual:
  \[
  \|Q^{T}Q-I\| \le \tau_{\text{orth}};
  \]
- Cayley-vs-QR/polar agreement within a declared numerical tolerance;
- behavior for \(\lvert\text{step}\rvert\) spanning ordinary, large, and overflow-prone ranges;
- descriptor publication before reader visibility;
- absence of torn or mixed-generation snapshots;
- reclamation only after a completed grace period;
- identical layout, alignment, endianness, and versioning across host and device;
- deterministic handling of unsupported operations and numerical failure;
- compiler and architecture combinations for every claimed backend.

## Definitive arbitration

The defensible SOTA synthesis is:

- **Cayley:** efficient and geometrically valid, but not unconditionally stable for extreme steps; stable solve plus residual validation and QR/polar fallback are mandatory.
- **Householder QR:** preferred reliability baseline for orthonormalization and fallback.
- **Polar factor:** preferred when nearest-orthogonal projection is the objective and its numerical cost is acceptable.
- **PMTP descriptor:** acquire/release establishes publication visibility only through a matching synchronization atomic; RCU/QSBR grace periods establish reclamation safety.
- **88-byte layout:** an ABI/layout choice, not a synchronization guarantee.
- **Multi-silicon support:** a contractual, test-backed property, not a consequence of source-level portability.
- **Exact architectural guarantee:** immutable versioned snapshots, release publication, acquire consumption, explicit grace-period reclamation, stable numerical solves, residual checks, defined fallbacks, and backend-specific synchronization mappings.

Any stronger statement—especially unconditional extreme-step stability, automatic 88-byte snapshot atomicity, or universal CUDA/XLA/Triton/C++20/Rust memory-model equivalence—would exceed what the available findings substantiate.