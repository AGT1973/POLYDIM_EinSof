# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 64)

# POLYDIM V1350 — High Tribunal Audit, Cycle 64

**Presiding Sages:** Numerical Analysis, Systems Programming, Heterogeneous Compute, Formal Methods.
**Verdict posture:** Adversarial. Claims are treated as unproven until a proof, a bound, or a reproducible artifact is produced.

---

## 0. Preliminary: what the audit can and cannot certify

The six targets are described by **specification**, not by source. The Tribunal therefore audits:

1. **Internal consistency** of each spec against its stated mathematical contract.
2. **Cross-component invariants** (88-byte descriptor, Rule 22, Rule 27).
3. **Degeneracy regimes** at `|step| → ∞` and `step → 0`.
4. **FFI / ABI hardening** at the C++/Rust/CUDA/Python boundaries.

Any claim below that depends on unseen code is flagged **[UNVERIFIED — requires artifact]**.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 Descriptor layout `<4sHHQQQQQBB6x4Q`

Let us count bytes explicitly (little-endian, standard `struct` alignment disabled by `<`):

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version_major, version_minor | `HH` | 4 |
| flags_a, flags_b | `QQ` | 16 |
| ptr_A, ptr_B, ptr_C | `QQQ` | 24 |
| n_rows, n_cols | `BB` | 2 |
| pad | `6x` | 6 |
| reserved | `4Q` | 32 |
| **Total** | | **88** |

**Arithmetic check:** 4+4+16+24+2+6+32 = **88**. ✅ Rule 22 byte-count satisfied *at the layout level*.

**Adversarial finding 1.1 — `BB` for `n_rows, n_cols` is a latent overflow.**
`n_rows, n_cols ∈ [0,255]`. Any tensor with a dimension ≥ 256 silently truncates mod 256. For a "V1350" kernel claiming to handle `R^(2K×2K)` Stiefel retraction (Target 4), `2K` must satisfy `2K ≤ 255`, i.e. `K ≤ 127`. **This is not stated anywhere in the spec.** Either:
- (a) the descriptor is a *tile* descriptor (dimensions ≤ 255 per tile), in which case the spec must say so, or
- (b) it is a bug.

**Required remediation:** publish the invariant `n_rows, n_cols ≤ 255` as a pre-condition, or widen to `HH` (which would push the struct to 90 bytes and break Rule 22 — so the correct fix is to document the tile semantics).

**Adversarial finding 1.2 — `6x` padding is not alignment-safe across ABIs.**
`<` disables alignment, so the struct is *packed*. On x86-64 this is fine for `memcpy`, but if any consumer takes `&desc->ptr_A` and dereferences it as `uint64_t*`, the pointer is at offset 12 — **misaligned by 4 bytes**. On ARM64 this is a fault; on x86-64 it is a performance cliff. **Recommendation:** either (i) reorder fields so all `Q` are 8-aligned and use `6x` only at the tail, or (ii) mandate `memcpy`-only access and forbid pointer aliasing into the descriptor.

**Adversarial finding 1.3 — "12/12 physical conformance checks" is unfalsifiable as stated.**
The Tribunal demands the *list* of the 12 checks and their pass criteria. Without them, this is a marketing claim, not an audit result. **[UNVERIFIED]**

### 1.2 `PmtpSlabAllocator`

No size class, alignment, or NUMA policy is specified. For a multi-silicon probe (CPU + CUDA + ROCm + TPU + Trainium), the allocator must expose:
- **device-affine slabs** (pinned host, device-resident, unified),
- **alignment ≥ 64 B** (AVX-512) and **≥ 128 B** (cache-line + prefetch),
- **zero-copy eligibility flags** in the descriptor (currently absent from the 88-byte layout — see §3.2).

**Finding 1.4:** The descriptor has **no field for memory space** (host/device/unified/pinned). Zero-copy PMTP validation (Target 2) therefore cannot be enforced from the descriptor alone. This is a **Rule 22 semantic gap**: the 88 bytes are byte-compliant but not *information-complete*.

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška:

```
s = 0; c = 0
for x_i, y_i:
    t = s + x_i*y_i
    if |s| >= |x_i*y_i|: c += (s - t) + x_i*y_i
    else:                c += (x_i*y_i - t) + s
    s = t
return s + c
```

**Theorem (Neumaier 1974; Higham 2002, Thm 4.3).** For `x, y ∈ R^n` with `fl(x_i y_i)` exact-rounded products,

```
|fl_neumaier(x·y) − x·y| ≤ (2u + O(nu²)) · Σ_i |x_i y_i| + O(u²)·|x·y|
```

where `u = 2^{-53}` (FP64). The **forward error is bounded relative to `Σ|x_i y_i|`, not to `|x·y|`**. Hence:

- **Condition number** `κ = Σ|x_i y_i| / |x·y|`. Neumaier is **backward stable** but **not forward-stable** when `κ → ∞` (catastrophic cancellation).
- **Asymptotic:** as `n → ∞`, the running compensation `c` accumulates `O(nu)` rounding of its own; the effective bound degrades to `O(nu)·Σ|x_i y_i|`.

**Adversarial finding 2.1 — the spec does not state `κ`.** For a Stiefel retraction (Target 4) the inner products are `⟨Y, A Y⟩` with `Y` orthonormal; `κ` is bounded by `‖A‖_F / |λ_min|`. If `A` is ill-conditioned (e.g. Lyapunov solve in Target 5 with `λ_min → 0`), Neumaier **does not save you**. The spec must publish `κ_max` per kernel.

### 2.2 Subnormal audits at `-12, -14`

Subnormals in FP64 live in `[2^{-1074}, 2^{-1022})`. The exponents `-12` and `-14` are **not subnormal** — they are ordinary normal numbers. **Finding 2.2:** the spec's terminology is wrong. If the intent is *denormal flushing* (FTZ/DAZ), the relevant thresholds are `2^{-1022}` (DAZ) and `2^{-1074}` (FTZ). If the intent is *scaling exponents* for a Woodbury solve, then `-12, -14` are scale factors, not subnormal audits. **The Tribunal demands clarification.**

**Finding 2.3 — AVX-512 FTZ/DAZ interaction.** If `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON)` is set, Neumaier's compensation term `c` can be flushed to zero when `|c| < 2^{-1022}`, silently destroying the compensation. **Recommendation:** explicitly clear FTZ/DAZ in the compensated-dot-product translation unit, or document that subnormal compensation is sacrificed.

### 2.3 Zero-copy PMTP validation

Without a memory-space field in the descriptor (§1.4), "zero-copy" cannot be validated. **Finding 2.4:** the C++ kernel must either (a) accept a side-channel `MemorySpace` enum, or (b) extend the descriptor (breaking Rule 22). The Tribunal recommends (a) with a **signed capability token** (see §6).

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier — **this is backwards**

**Finding 3.1 (critical).** `panic = unwind` across an FFI boundary is **undefined behavior** in Rust unless the boundary is `extern "C-unwind"` (stabilized 1.71) or the panic is caught with `catch_unwind`. The standard `extern "C"` ABI **aborts** on unwind. The spec's claim that `panic = unwind` provides an "FFI safety barrier" is **inverted**: `panic = abort` is the *safe* default for FFI, and `unwind` requires explicit `C-unwind` annotations.

**Required remediation:**
```rust
#[no_mangle]
pub extern "C-unwind" fn pmtp_dot(...) -> f64 { ... }
```
or wrap every `extern "C"` entry in `std::panic::catch_unwind` and return a sentinel. Otherwise a panic in Rust = UB in C++.

### 3.2 Packed 88-byte `PmtpTensorDescriptor`

Rust's `#[repr(C, packed)]` matches the Python `<` layout **only if** the field order and types match exactly. **Finding 3.2:** `#[repr(packed)]` makes `&desc.ptr_A` a misaligned reference — **taking a reference to a packed field is UB in Rust** (E0793). The kernel must use `addr_of!` + `read_unaligned`. The spec does not mention this. **[UNVERIFIED — requires artifact]**

### 3.3 Safe SIMD

`std::simd` is nightly-only as of Rust 2021 stable. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. **Finding 3.3:** "Safe SIMD" is a misnomer unless the kernel is on nightly `portable_simd`. The spec must state the toolchain.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in `R^(2K×2K)`

Cayley retraction: `Y(τ) = (I − (τ/2)W)^{-1} (I + (τ/2)W) Y`, `W = A Y Yᵀ − Y Yᵀ A` (skew-symmetric).

**Theorem (Wen & Yin 2013).** Cayley is a **second-order retraction** on the Stiefel manifold; `Y(τ)` is orthonormal to machine precision **iff** the linear solve is accurate.

**Adversarial finding 4.1 — `DnDsy