# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 99)

# POLYDIM V1350 — High Tribunal Audit, Cycle 99

**Presiding note.** The Tribunal treats the six artifacts as *specifications* (source not attached). Findings are therefore stated as **conditional verdicts**: each claim is either (a) provable from the stated invariants, (b) refutable by a counterexample the Tribunal constructs, or (c) *unverifiable* pending source. We flag each explicitly. No component is granted "SOTA" status on assertion alone.

---

## 0. Cross-cutting invariants (Rules 22 & 27)

### Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor is claimed as `<4sHHQQQQQBB6x4Q`.

Let us *count*:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

✅ **Struct size is arithmetically 88 bytes.** Alignment: `Q` requires 8-byte alignment; the leading `4sHH` = 8 bytes, so the first `Q` lands on offset 8 — aligned. The trailing `4Q` starts at offset 48 — aligned. `6x` pad is *exactly* what's needed to push `BB` (offset 46–47) to the `4Q` boundary at 48. **No implicit padding is required**; `sizeof == 88` under both `#pragma pack` and default alignment on x86-64/AArch64. This is a *correct* layout.

⚠️ **Rule 22 verdict (conditional):** The descriptor is 88 bytes, but Rule 22 also forbids **1D tokens** in inter-agent communication. The Tribunal cannot verify from the spec alone that the orchestrator never emits a bare `float32[D]` or `int64[K]` payload. **Required evidence:** a static scan of `kernel_orchestrator_v1350.py` for any `send(`/`recv(` whose payload is not a `PmtpTensorDescriptor` or a `PmtpSlab`. Absent that, Rule 22 is **unproven**.

### Rule 27 — Silicon Contract / vendor lock

| Target | Vendor-specific surface | Lock risk |
|---|---|---|
| 1 orchestrator | `HardwareProbe` multi-silicon | Low if probe is *capability-based*, not `if vendor=="nvidia"` |
| 2 C++ | AVX-512 + OpenMP | **Medium** — AVX-512 is Intel/AMD-only; needs runtime dispatch (CPUID) + scalar fallback |
| 3 Rust | `std::simd` / `core::arch` | Low if `#[target_feature]` gated |
| 4 CUDA | cuSOLVER `DnDsyevd`, CUDA Graphs | **High** — hard NVIDIA lock unless a HIP/ROCm shim exists |
| 5 XLA | `@jax.jit` on TPU/Trainium | **High** — PJRT plugin lock |
| 6 Triton | ROCm + CUDA | Medium — Triton abstracts both, but `tl.` intrinsics differ |

**Rule 27 verdict:** Targets 4 and 5 **violate** a strict reading of Rule 27 unless the orchestrator's `HardwareProbe` can *route around* them (i.e., CUDA path is optional, XLA path is optional). The spec asserts "multi-silicon" but does not prove **capability negotiation**. **Demand:** a `CapabilityMatrix` object with `{avx512, cuda, rocm, tpu, trainium, neon}` booleans and a total order of fallbacks.

---

## 1. Numerical degeneracy: `step → ∞` and `step → 0`

This is the Tribunal's central concern. We treat `step` as the Cayley/Woodbury step size.

### 1a. `step → ∞` (|step| ≥ 10¹⁰)

**Target 4 (CUDA, Woodbury).** The spec says the solve is *globally scaled*: `(M/scale) W = (step/scale) B`. Let `s = step`. The Woodbury identity for `(I + s A)^{-1}` is:

```
(I + sA)^{-1} = I − U (I + s Vᵀ A U)^{-1} s Vᵀ A
```

As `s → ∞`, `(I + sA)^{-1} → 0` **only if A is invertible**. If `A` has a null space (which it does — Stiefel tangent space is rank-deficient by construction, `A = Aᵀ`, `A v = 0` for `v` in the normal bundle), then:

```
(I + sA)^{-1} v  →  v   for v ∈ null(A)
```

**Degeneracy:** the scaled form `(M/scale) W = (step/scale) B` with `scale = ‖step‖` gives `M/scale → 0` and `step/scale → 1`. The linear system becomes `0 · W = B`, i.e., **singular**. The spec's "global scaling" *does not* fix this — it merely renormalizes the RHS. **Counterexample:** take `M = I`, `B = e₁`, `step = 10¹⁰`. Then `M/scale = 10⁻¹⁰ I`, `step/scale = 1`, and `W = 10¹⁰ e₁`. The solution *exists* but its condition number is `10¹⁰`. In FP64 (`ε ≈ 2.2e-16`), the relative error is `~10⁻⁶` — **six digits lost**.

**Proof of asymptotic condition number.** For the Cayley retraction `R(s) = (I − sA/2)(I + sA/2)^{-1}` on the Stiefel manifold, the Jacobian's condition number satisfies:

```
κ(R(s)) = Θ(s · ‖A‖₂)   as s → ∞
```

because `(I + sA/2)^{-1}` has smallest singular value `~2/(s‖A‖)` while the largest is `O(1)`. **Therefore any `step ≥ 10¹⁰` with `‖A‖₂ = O(1)` yields `κ ≥ 10¹⁰`.** The spec's claim of "globally scaled Woodbury" is **numerically insufficient**; the correct fix is a **Cayley step limiter**:

```
s_eff = min(s, s_max),  s_max = c / ‖A‖_F,  c ≈ 1
```

or a **trust-region** on the Stiefel tangent.

**Target 5 (XLA, Lyapunov).** Continuous Lyapunov `A X + X Aᵀ = −Q`. As `step → ∞`, if the integrator is explicit (e.g., forward Euler on `dX/dt = AX + XAᵀ + Q`), the stability region is `|1 + s λ| ≤ 1` for all eigenvalues `λ` of the Kronecker operator `I⊗A + A⊗I`. For `s = 10¹⁰` and `Re λ < 0`, `|1 + sλ| ≫ 1` → **catastrophic divergence**. The spec says "continuous Lyapunov solve in HBM" — if this is a *direct* Bartels–Stewart / Hammarling solve, `step` is irrelevant and the concern is moot; if it is a *time-stepped* solve, `step → ∞` is **unconditionally unstable**. **Demand:** clarify direct vs. iterative.

**Target 6 (Triton, Clifford bivector rotations).** Rotors `R = exp(θ B)` with `B² = −1`. As `step → ∞`, `θ = step · ‖B‖ → ∞`, and `cos θ, sin θ` lose all precision: for `θ = 10¹⁰`, `θ mod 2π` has absolute error `~10¹⁰ · ε ≈ 2e-6`, so `sin θ` is wrong in the 6th digit. **Fix:** Payne–Hanek reduction, or clamp `θ` to `[−π, π]` via the rotor's double-cover (`R` and `−R` represent the same rotation).

### 1b. `step → 0` (subnormals)

**Target 2 (C++, subnormal audits at −12, −14).** The spec claims audits at exponents −12 and −14. In IEEE-754 binary64, the subnormal range begins at `2⁻¹⁰²² ≈ 2.2e-308`. Exponents −12 and −14 correspond to `~2.4e-4` and `~6.1e-5` — **these are normal numbers**, not subnormals. **The spec's terminology is wrong.** If the intent is *decimal* exponents, then `10⁻¹²` and `10⁻¹⁴` are still normal. **Verdict:** the "subnormal audit" is mislabeled; it is a *small-magnitude* audit. True subnormal handling requires:

- FTZ/DAZ flags off (or explicitly tested),
- Neumaier compensation to preserve the low-order bits,
- a test vector like `x = 5e-324` (min subnormal) and `y = 1e-308`.

**Neumaier compensated dot product.** The algorithm:

```
s = 0; c = 0
for i: t = s + x_i y_i
       if |s| ≥ |x_i y_i|: c += (s − t) + x_i y_i
       else:               c += (x_i y_i − t) + s
       s = t
return s + c
```

This is **correct** and gives `O(ε)` *relative* error even for ill-conditioned sums, **provided no intermediate underflows**. As `step → 0`, `x_i y_i → 0`; if `x_i y_i < 2⁻¹⁰²²`, the product itself is subnormal and Neumaier's compensation term `(s − t) + x_i y_i` is **exact only if the product is exact** — which it is *not* for subnormal products (the product is rounded to a subnormal, losing bits). **Therefore Neumaier does not save you in the subnormal regime.** The correct fix is **scaling**: pre-scale `x` and `y` by `2^k` so products land in the normal range, then unscale.

**Target 3 (Rust, panic=unwind FFI barrier).** `panic=unwind` across an FFI boundary is **UB** unless every `extern "C"` function is wrapped in `catch_unwind`. The spec claims a "panic=unwind FFI safety barrier" — this is only sound if:

```rust
#[no_mangle]
pub extern "C" fn entry