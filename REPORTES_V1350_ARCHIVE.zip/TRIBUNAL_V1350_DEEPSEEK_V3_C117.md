# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 117)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 117 · Six-Component Adversarial SOTA Review

**Tribunal posture.** We treat each kernel as a *numerical operator* on a state manifold, not as a code artifact. Claims of "12/12 conformance" and "88-byte descriptor" are treated as *invariants to be falsified*, not asserted. Where the prompt supplies only a signature (e.g. `<4sHHQQQQQBB6x4Q`), we audit the *implied* contract and flag what cannot be verified from the artifact alone.

---

## 0. Cross-cutting invariants (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens, 88-byte PMTP

The struct format `<4sHHQQQQQBB6x4Q` decodes as:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version_major | `H` | 2 | 4 |
| version_minor | `H` | 2 | 6 |
| flags | `Q` | 8 | 8 |
| n_rows | `Q` | 8 | 16 |
| n_cols | `Q` | 8 | 24 |
| stride | `Q` | 8 | 32 |
| dtype_code | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| layout | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| reserved | `4Q` | 32 | 56 |
| **total** | | **88** | |

**Verdict (Rule 22):** The 88-byte size is *structurally* satisfied **iff** the compiler honors `#pragma pack(1)` / `__attribute__((packed))` / `#[repr(C, packed)]` on every ABI boundary. This is the single most common silent violation. A `Q` field at offset 8 is naturally aligned; a `Q` at offset 40 is aligned; but the trailing `4Q` at offset 56 is aligned. **No misalignment trap exists in this layout** — good. However:

- **Rust**: `#[repr(C, packed)]` on a struct containing `u64` produces *unaligned references*; taking `&desc.n_rows` is UB. Must use `read_unaligned` or `addr_of!`. **Recommendation:** split into `#[repr(C)]` with explicit `[u8; 6]` padding and `align(8)` — the 88-byte size is preserved and references become sound.
- **C++**: `#pragma pack(push,1)` around the struct is required; `static_assert(sizeof(PmtpDescriptor)==88)` must be present in *every* TU that includes the header, not just one.
- **Python (orchestrator, XLA, Triton)**: `struct.calcsize('<4sHHQQQQQBB6x4Q')` returns 88 on CPython — but `struct` uses native alignment for `Q` only if `=` prefix is used. With `<` it is little-endian standard size, so 88 holds. **However**, `ctypes.Structure` with default alignment will *not* produce 88; must set `_pack_ = 1`.

**Zero 1D tokens:** The descriptor carries `rank` and `n_rows/n_cols/stride` — a 1D tensor is representable (`rank=1`). Rule 22 forbids *emitting* 1D tokens in inter-agent traffic. **Audit finding:** none of the six kernels as described *enforce* `rank >= 2` at the descriptor boundary. This is a **Rule 22 violation risk** in all six. Required fix: a `PMTP_VALIDATE` macro/inline that rejects `rank < 2` before serialization, with a distinct error code (not a silent clamp).

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Lock severity |
|---|---|---|
| orchestrator | none (probe only) | none |
| C++ AVX-512 | Intel/AMD ISA | **soft lock** — AVX-512 is not on all SKUs (e.g. Alder Lake E-cores, Zen 4 mobile) |
| Rust SIMD | portable via `std::simd` or `wide` | none if `target_feature` gated |
| CUDA | NVIDIA + cuSOLVER | **hard lock** |
| XLA | Google TPU *or* AWS Trainium | **hard lock per backend** |
| Triton | AMD ROCm *or* NVIDIA | **hard lock per backend** |

**Verdict (Rule 27):** Targets 4, 5, 6 **violate** Rule 27 as written unless the orchestrator dispatches to a *functionally equivalent* fallback (C++/Rust path) when the vendor runtime is absent. The prompt describes CUDA/XLA/Triton as *core components*, not optional accelerators — this is the violation. **Required remediation:** each vendor kernel must expose a `capability_probe()` returning a `SiliconContract` enum, and the orchestrator must have a documented degradation path. Without that, Rule 27 is breached.

### 0.3 Numerical degeneracy at `|step| → ∞` and `step → 0`

This is the deepest issue and it recurs in every kernel. We treat it once, then specialize.

Let `step ∈ ℝ` be the integration/retraction step. Three regimes:

**(A) `step → 0` (subnormal regime, `|step| < 2^-1022` in FP64).**
- Neumaier compensation: the compensation term `c` accumulates the rounding error of `sum + x`. When `x` is subnormal, `sum + x` may round to `sum` exactly, so `c += (sum - (sum + x)) + x` yields `c += x` — *correct*, but `c` itself may underflow to subnormal and lose bits. **Asymptotic condition number** of the compensated sum is `κ ≈ 1 + |c|/|sum|`; as `step → 0`, `|c|/|sum| → 0` only if the summands are O(1). If the summands are themselves O(step), then `c` and `sum` underflow *together* and the compensation is vacuous. **Recommendation:** scale the accumulator by `1/step` before summation, sum in O(1), then rescale. This is the standard "scaled Neumaier" trick and it is *not* mentioned in the prompt.
- Subnormal audits at `-12, -14` (presumably exponents `2^-12`, `2^-14` for FP16/BF16 boundary checks): these are *not* subnormal in FP64. If the audit is meant to test FP16 subnormals, the kernel must actually run in FP16 — but Target 5 claims "pure FP64". **Contradiction flagged.**

**(B) `step → ∞` (`|step| ≥ 10^10`).**
- Cayley retraction (Target 4): `Y = (I - (step/2)W)^{-1}(I + (step/2)W) X`. As `step → ∞`, `(step/2)W` dominates; the inverse is `≈ -(2/step)W^{-1}` and the product `≈ -X` — i.e. the retraction degenerates to a *reflection*, not a rotation. The Stiefel manifold is preserved only if `W` is skew-symmetric and the solve is exact. **Condition number of the Woodbury solve:** `κ(M) = κ(I + (step/2)W)`. For skew `W` with eigenvalues `±iλ`, `κ = sqrt((1 + (step λ/2)^2)/(1 + 0))`... more precisely `|1 + i step λ/2| = sqrt(1 + (step λ/2)^2)`, so `κ ≈ step·λ_max/2`. At `step = 10^10`, `κ ≈ 5·10^9 · λ_max` — **catastrophic loss of ~10 digits** in FP64. The "globally scaled Woodbury solve (M/scale) W = (step/scale) B" mitigates this *only if* `scale ≈ step·λ_max`, which requires knowing `λ_max` — i.e. a power iteration or Lanczos pre-pass. **The prompt does not mention this pre-pass.** Without it, the scaling is heuristic and the condition number bound is not proven.
- Lyapunov solve (Target 5): `A X + X A^T = -Q`. As `step → ∞`, if `A` is the step-scaled generator, the solve becomes stiff; the Bartels–Stewart algorithm's backward error grows as `O(step · eps · κ(V))` where `V` diagonalizes `A`. **Pure FP64 does not save you** — the condition number is the enemy, not the precision.
- Clifford bivector rotations (Target 6): `R = exp(step · B)` where `B` is a bivector. As `step → ∞`, `exp` wraps modulo `2π` in the compact case, but for non-compact bivectors (boost-like) it diverges exponentially. **Streaming** rotations compound the error: `N` streaming steps give error `O(N · step · eps)`. At `step = 10^10` and `N = 10^6`, this is `O(10^16 · eps)` — total loss.

**Tribunal ruling on degeneracy:** *None of the six kernels as described provides a proven asymptotic condition-number bound.* The prompt asserts "SOTA" but supplies no `κ(step)` analysis. This is the central audit failure.

---

## 1. `kernel_orchestrator_v1350.py`

**Claims:** Multi-silicon HardwareProbe, PmtpSlabAllocator, 88-byte descriptor, 12/12 conformance.

**Audit:**

1. **HardwareProbe.** "Multi-silicon" implies runtime detection of AVX-512 / CUDA / ROCm / TPU. The probe must be *idempotent* and *cached* — repeated `cpuid`/`cudaGetDeviceCount` calls in a hot loop are a performance bug. More seriously: **probing CUDA initializes the CUDA context**, which is a *side effect* that violates the "probe" contract. Recommendation: use `cudaDeviceGetAttribute` on a lazily-created context, or `nvmlDeviceGetCount` (no context). Same for ROCm (`hipGetDeviceCount` initializes).

2. **PmtpSlabAllocator.** "Slab" implies fixed-size 88-byte allocations. **Alignment:** 88 is not a power of two; a slab of 88-byte objects has stride 88, so object `k` starts at `88k`. For SIMD loads (AVX-512 wants 64-byte alignment), `88k mod 64` cycles through `{0, 24, 48, 8, 32, 