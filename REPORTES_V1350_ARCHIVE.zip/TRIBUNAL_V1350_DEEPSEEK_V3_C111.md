# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 111)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 111 · Adversarial SOTA Review

**Presiding note.** The Tribunal treats each target as a *claim* to be falsified. Where source is not in evidence, we audit the *specification as stated* and flag unverifiable assertions as **UNPROVEN**. We do not grant "SOTA" by assertion.

---

## §0. Cross-cutting invariants (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens, 88-byte PMTP

The 88-byte descriptor is claimed as `<4sHHQQQQQBB6x4Q`. Let us *count*:

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `HH` | 4 |
| five `Q` | `QQQQQ` | 40 |
| two `B` | `BB` | 2 |
| pad | `6x` | 6 |
| four `Q` | `4Q` | 32 |
| **Total** | | **88** |

✅ **Structurally conformant.** Alignment: `Q` requires 8-byte alignment. Offsets: 0,4,8,16,24,32,40,48,56,64,72,80. All `Q` fields land on 8-byte boundaries. `6x` pad is *correct and necessary* — without it the trailing `4Q` would begin at offset 50, misaligned. **Verdict: PASS on layout.**

**Rule 22 (Zero 1D tokens).** The rule as stated ("no 1D tokens in inter-agent communication") is *underspecified*. The Tribunal reads it as: **no scalar/rank-1 payloads may cross the agent boundary; all inter-agent traffic must be rank-≥2 tensors or the 88-byte descriptor.** Under that reading:

- T1, T3, T6: descriptor is the only inter-agent payload → **PASS**.
- T2 (C++): "zero-copy PMTP validation" — if validation returns a scalar `bool`/`int` across the FFI boundary, that is a **1D token** and violates Rule 22. **FLAG.**
- T4 (CUDA): CUDA Graphs capture host-side scalars (step, scale) — if these are marshalled as rank-0 tensors, **FLAG**.
- T5 (XLA): `@jax.jit` with pure FP64 — JAX scalars are rank-0 arrays, not 1D. **PASS**, but only if the Lyapunov residual is returned as a rank-2 matrix, not a scalar norm.

**Tribunal demand:** publish the exact FFI signature of every cross-boundary call. Rule 22 cannot be certified from prose.

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Verdict |
|---|---|---|
| T1 | Multi-silicon probe — *if* probe is table-driven | PASS (conditional) |
| T2 | AVX-512 → Intel-only on consumer; AMD Zen4+ has it | **PARTIAL LOCK** |
| T3 | Rust 2021 + `panic=unwind` — portable | PASS |
| T4 | cuSOLVER `DnDsyevd` → **NVIDIA-only** | **HARD LOCK** |
| T5 | `@jax.jit` → XLA backend; TPU *and* Trainium claimed | PASS (conditional on PJRT) |
| T6 | Triton → AMD ROCm *and* NVIDIA | PASS (conditional) |

**Finding:** T4 violates Rule 27 as written. `cuSOLVER` has no portable equivalent; the Cayley retraction is mathematically backend-agnostic but the *implementation* is not. **Remediation:** abstract the eigensolver behind a `SymmetricEigensolver` trait with cuSOLVER / LAPACK / rocSOLVER backends. Until then, T4 is **NON-COMPLIANT**.

---

## §1. Numerical degeneracy: step → ∞ and step → 0

This is the Tribunal's central concern. We treat each target's update as a map `Φ_step : M → M` on the Stiefel manifold `St(2K, 2K)` (or `S^{D-1}` for T6).

### 1.1 The Cayley retraction (T4) — asymptotic analysis

Cayley retraction: `R_X(-step·G) = (I - (step/2)W)^{-1}(I + (step/2)W)`, `W = G Xᵀ - X Gᵀ` skew.

**Claim (T4):** "globally scaled Woodbury solve `(M/scale) W = (step/scale) B`."

Let `A = I - (step/2)W`. As `step → ∞`:
- `A → -(step/2)W`, so `R → -I` **iff `W` is invertible**. But `W` is skew-symmetric of even dimension `2K`, so `det(W) = pf(W)² ≥ 0` and `W` is **generically invertible but can be singular** (e.g., `W = 0` at a critical point).
- **Degeneracy:** at `W = 0` (gradient vanishes), `R = I` for *all* step. The retraction is *step-independent* — a fixed point. This is *correct* but means the "step → ∞" limit is **not** `-I`; it is `I`. The claim of a well-defined `step → ∞` limit is **FALSE in general**.

**Condition number.** `κ₂(A) = κ₂(I - (step/2)W)`. For skew `W` with eigenvalues `±iλ_j`:
```
σ_j(A) = sqrt(1 + (step·λ_j/2)²)
κ₂(A) = sqrt(1 + (step·λ_max/2)²) / sqrt(1 + (step·λ_min/2)²)
      → λ_max/λ_min  as step → ∞
```
So `κ₂(A) → κ₂(W)` — **bounded by the spectral spread of `W`, not by step.** This is the *good* news: the Woodbury scaling `M/scale` is a **no-op** on the condition number (it cancels). The scaling is therefore **cosmetic** unless `scale` is chosen to prevent overflow in `step·λ_max`.

**Overflow threshold.** With FP64, `step·λ_max/2 > 2^1023` overflows. For `step = 10^10` and `λ_max ~ 10^3`, `step·λ_max/2 ~ 5·10^12` — safe. For `step = 10^300`, overflow. **The `scale` parameter is the overflow guard, not a conditioning fix.** The spec's framing is **misleading**.

**Subnormal regime (`step → 0`).** `A → I`, `R → I + step·W + O(step²)`. The Woodbury solve `(M/scale)W = (step/scale)B` with `step < 2^-1022` produces **subnormal `step/scale`**, and `step·W` underflows to zero if `W` entries are `O(1)`. **Result: the retraction silently becomes the identity.** No subnormal audit is claimed for T4. **FLAG.**

**Tribunal demand:** T4 must implement a *denormal-aware* branch: if `|step| < 2^-1000`, use the first-order Taylor `R ≈ I + step·W` directly, bypassing the solve.

### 1.2 Neumaier compensated dot (T2, T3)

Neumaier summation error bound: `|error| ≤ (u + O(nu²)) Σ|x_i|` where `u = 2^-53`. **This is step-independent** — the compensation is *exact* for the summation, but the *inputs* `x_i = step · g_i` inherit the step scaling.

**Degeneracy at `step → ∞`:** if `step = 10^10` and `g_i ~ 10^-10`, products are `O(1)` — fine. If `g_i ~ 10^10`, products overflow. **No overflow guard is claimed.** **FLAG.**

**Degeneracy at `step → 0`:** if `step < 2^-1022 / max|g_i|`, all products are subnormal. Neumaier's compensation term `(t - sum) - c` is itself subnormal and **loses the compensation**. The compensated sum degrades to naive summation. **FLAG.** T2's "subnormal audits (-12, -14)" — presumably exponents `2^-12`, `2^-14` — are *far above* the subnormal threshold `2^-1022`. **The audit is testing the wrong regime.** This is a **serious methodological error**.

**Tribunal demand:** re-run subnormal audits at exponents `-1020` through `-1074` (the true subnormal range for FP64). Exponents `-12, -14` are *normal* numbers.

### 1.3 Stiefel projection (T6, `S^{D-1}`)

Projection `x ← x / ‖x‖`. As `step → ∞`, `x` may overflow before normalization. As `step → 0`, `‖x‖` may underflow to zero → **division by zero → NaN**. **No guard claimed.** **FLAG.**

**Fix:** use `x / max(‖x‖, ε)` with `ε = 2^-500`, or better, `x · (1/‖x‖)` computed via `frexp`/`ldexp` to avoid intermediate overflow.

### 1.4 Lyapunov solve (T5)

Continuous Lyapunov `A X + X Aᵀ = -Q`. Condition number `κ(X) ≤ κ(A)² · κ(Q)`. As `step → ∞`, `A = A₀ + step·G` — the spectrum of `A` scales with `step`, so `κ(A) → κ(G)` (bounded) but the *absolute* eigenvalues grow, and the solve's backward error grows as `step · u`. **At `step = 10^10`, backward error ~ `10^10 · 2^-53 ~ 10^-6`** — acceptable. At `step = 10^15`, backward error ~ `10^-1` — **catastrophic**. **FLAG: no step cap claimed.**

**Tribunal demand:** T5 must publish a `step_max` derived from `u · step · ‖A‖ < tol`.

---

## §2. FFI hardening (T2 ↔ T3 boundary)

The C++/Rust boundary is the highest-risk surface. Recommendations:

1. **`panic=unwind` is necessary but not sufficient.** A Rust panic unwinding across an `extern "C"` boundary is **UB** unless the function is `extern "C-unwind"` (Rust 1.71+). **Verify the ABI string.** If T3 uses `extern "C"` with `panic=unwind`, it is **unsound**.
