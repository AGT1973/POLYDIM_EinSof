# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 73

The requested **Cycle 73 tribunal findings cannot be independently arbitrated** from the available evidence: no public, verifiable records for “POLYDIM V1350,” its six kernels, the six model reports, or the “PMTP 88-byte Descriptor” were found. The defensible synthesis is therefore a **conditional architecture**, not a claim that those proprietary results are established.

### 1. Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For \(X\in\mathrm{St}(n,p)\), standard alternatives include

\[
R_{\mathrm{polar}}(X,\Xi)
=(X+\Xi)(I+\Xi^\top\Xi)^{-1/2},
\]

\[
R_{\mathrm{QR}}(X,\Xi)=\operatorname{qf}(X+\Xi),
\]

and a Cayley update of the form

\[
R_{\mathrm{Cayley}}(X,\Xi)
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\]

with an appropriate skew-symmetric \(W\). These are recognized Stiefel-manifold retractions, but they have different numerical and implementation properties.[1][3][10]

**Arbitrated result:**

- No method can be guaranteed stable merely because the mathematical step magnitude is \(10^{10}\).
- A direct Cayley solve can become ill-conditioned or overflow if \(W\) is formed or scaled naively.
- Polar retraction is geometrically attractive—it produces the closest orthonormal factor in Frobenius norm—but requires a stable inverse square root or equivalent factorization.
- Householder QR is generally the most defensible production fallback for rank-revealing, backward-stable orthogonalization, provided the input is scaled and the \(R\)-factor signs are canonicalized.
- The superior design is **adaptive**, not a universal claim that Cayley dominates QR or polar:

\[
\alpha=\min\!\left(1,\frac{\alpha_{\max}}{\|\Xi\|}\right),
\qquad
\widehat{\Xi}=\alpha\Xi,
\]

followed by a stable Cayley or polar/QR implementation. If scaling, factorization, residual, or conditioning checks fail, fall back to Householder QR.

The exact invariant that should be guaranteed is a measured residual,

\[
\|Y^\top Y-I\| \le \tau_{\mathrm{orth}},
\]

together with finite-value checks and deterministic sign conventions. No unconditional guarantee of accuracy at \(10^{10}\) is mathematically credible in finite precision without specifying datatype, matrix dimensions, conditioning, overflow behavior, and tolerance.

### 2. PMTP 88-byte descriptor and RCU/QSBR

The named 88-byte format is not documented in the available sources, so its layout, atomic fields, alignment, and ownership protocol cannot be verified. The relevant general rule is:

- **Release** publishes a fully initialized descriptor or snapshot.
- **Acquire** reads the publication pointer and guarantees visibility of writes sequenced before that release.
- A reader must remain inside a valid RCU/QSBR read-side protection interval while dereferencing the snapshot.
- Reclamation requires a grace-period proof: every reader that could have observed the old pointer must have exited or reported a quiescent state before destruction.

Acquire/release alone does **not** provide RCU safety. It does not prevent reclamation while a reader still holds a pointer, nor does it automatically make a multi-field descriptor update atomic. The protocol must separately guarantee:

\[
\text{publish}_{\mathrm{release}}
\;\prec\;
\text{read}_{\mathrm{acquire}}
\;\prec\;
\text{dereference within read-side epoch}
\;\prec\;
\text{grace period}
\;\prec\;
\text{reclaim}.
\]

A robust descriptor contract would therefore require:

- fixed, documented byte layout and alignment;
- no torn access to publication metadata;
- immutable contents after publication, or versioned copy-on-write updates;
- acquire loads for snapshot acquisition;
- release stores or read-modify-write operations for publication;
- explicit QSBR registration and quiescent-state reporting;
- reclamation only after a completed grace period;
- prohibition on readers retaining pointers beyond the protected interval.

For C++20, the memory-order argument must be expressed using the language memory model; for Rust, the equivalent must be upheld through atomics, ownership, lifetimes, and—where necessary—carefully audited unsafe code. A byte count such as 88 bytes is not itself an architectural guarantee.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single memory or execution model shared identically by all five environments. Consequently, “multi-silicon conformance” cannot mean bitwise or scheduling identity across them.

The valid target is **semantic conformance**:

- identical descriptor schema and endianness;
- explicit alignment and padding rules;
- defined integer and floating-point widths;
- no dependence on host pointer size or ABI padding;
- explicit synchronization at host/device and kernel boundaries;
- deterministic handling of NaNs, infinities, signed zero, and overflow where required;
- validation of orthogonality residuals rather than exact matrix equality;
- a common litmus-test suite for publication, snapshot isolation, and reclamation;
- architecture-specific implementations constrained by the same abstract contract.

CUDA and Triton require explicit device synchronization and careful treatment of global-memory visibility. XLA may fuse, reorder, or lower operations under its compiler semantics; therefore a source-level acquire/release assumption cannot automatically be transferred into an XLA computation. C++20 and Rust can specify host-side atomic ordering, but device execution requires an explicitly supported interoperability boundary.

### Definitive synthesis

The strongest defensible SOTA architecture is:

1. **Numerics:** scaled adaptive Cayley/polar retraction with Householder-QR fallback; reject outputs failing finite-value, conditioning, or orthogonality-residual checks.
2. **Publication:** immutable copy-on-write snapshots published with release semantics and consumed with acquire semantics.
3. **Reclamation:** QSBR/RCU grace periods are mandatory; acquire/release is necessary for visibility but insufficient for lifetime safety.
4. **Portability:** define a language-neutral wire-format and abstract memory protocol, then implement and test it separately for CUDA, XLA, Triton, C++20, and Rust.
5. **Guarantees:** promise only explicitly testable properties—orthogonality residual bounds, no use-after-reclamation under the stated protocol, layout compatibility, and semantic snapshot isolation.

Claims such as “Cayley is unconditionally stable for steps \(\ge 10^{10}\),” “88-byte descriptors are safe with acquire/release alone,” or “all five platforms have identical memory behavior” are not mathematically or architecturally justified by the available evidence.