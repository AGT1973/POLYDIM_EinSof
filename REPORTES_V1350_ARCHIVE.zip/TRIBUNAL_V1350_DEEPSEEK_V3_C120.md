# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 120)

# POLYDIM V1350 — High Tribunal Audit, Cycle 120

**Presiding Sages:** Numerical Analysis, Systems Security, Heterogeneous Compute
**Verdict class:** Adversarial SOTA — findings are graded *Confirmed*, *Conditional*, or *Refuted*.

---

## 0. Preliminary: what the Tribunal can and cannot verify

The Tribunal has been handed **six filenames and a specification summary**, not the source trees. Every claim below is therefore audited at the level of *architectural contract* — the invariants the code must satisfy to be correct — and any finding that depends on a line of code is flagged **[NEEDS SOURCE]** so the authors cannot hide behind the summary. Where the summary itself is internally inconsistent, that is a finding.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 88-byte descriptor `<4sHHQQQQQBB6x4Q`

Let us actually count, because this is the single most audited artifact in the whole stack.

| Field | Format | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| version, flags | `HH` | 4 |
| 5 × `Q` (offsets/lengths) | `QQQQQ` | 40 |
| 2 × `B` | `BB` | 2 |
| pad | `6x` | 6 |
| 4 × `Q` | `4Q` | 32 |
| **Total** | | **88** |

**Confirmed: 88 bytes, no implicit padding under `struct` with `<` (little-endian, standard size, no alignment).** This is the *only* correct way to get 88; if anyone removes the `<` the struct becomes 96 on LP64 due to `Q` alignment. **Recommendation:** add a `ctypes.sizeof` / `struct.calcsize` assertion at import time and a `static_assert(sizeof(...) == 88)` in the C++/Rust mirrors. **[NEEDS SOURCE]** for the assertion.

### 1.2 Rule 22 — zero 1D tokens in inter-agent communication

The descriptor is a **flat 88-byte record**, not a 1D token stream. That is compliant *provided* the orchestrator never serializes it as a Python list, JSON array, or `bytes` of length ≠ 88. The `6x` pad is the classic smuggling vector: a naive `pickle` of the struct will re-emit the pad as zeros, which is fine, but a `numpy.frombuffer(..., dtype='V88')` followed by `.tolist()` will explode into 88 1D tokens. **Finding: Conditional.** Add a `__reduce__` that refuses to pickle and a `to_bytes()` that asserts `len == 88`.

### 1.3 Multi-silicon HardwareProbe

The probe must not *branch on vendor string* to select a kernel — that is the vendor-lock smell (Rule 27). It must branch on **capability bits** (AVX-512F, `sm_90`, `gfx942`, TPU generation). **Finding: Conditional** pending source. If `HardwareProbe` returns `"nvidia"` and the orchestrator does `if vendor == "nvidia": import cuda_kernel`, that is a Rule 27 violation.

### 1.4 PmtpSlabAllocator

Slab allocation of 88-byte records is fine, but the allocator must guarantee **8-byte alignment** for the `Q` fields. If it packs records at 88-byte stride starting from an odd base, every `Q` load is misaligned on strict-alignment ISAs (SPARC, some ARM). **Recommendation:** `align = lcm(88, 8) = 88` is already 8-aligned, so stride 88 from an 8-aligned base is safe. **Confirmed** if base is 8-aligned.

### 1.5 12/12 physical conformance checks

Without the list, the Tribunal notes that "12/12" is a *count*, not a *proof*. Demand the checks be enumerated and each be a **falsifiable predicate** (e.g., `sizeof == 88`, `magic == b'PMTP'`, `offset + length <= slab_size`). **Finding: Unverifiable as stated.**

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product — asymptotic condition number

Neumaier's variant of Kahan–Babuška gives a **forward error bound**

\[
|\hat{s} - s| \le \big(2u + O(nu^2)\big)\sum_i |x_i y_i| + O(u^2)|s|
\]

with \(u = 2^{-53}\) for FP64. The **effective condition number** of the compensated dot is

\[
\kappa_{\text{Neumaier}} = \frac{\sum_i |x_i y_i|}{|s|} \quad\text{(not the classical } \kappa = \|x\|\|y\|/|s| \text{)}
\]

This is the key result: Neumaier is **componentwise backward stable**, so it does *not* blow up when \(\|x\|\|y\| \gg |s|\) due to cancellation — it blows up only when the *sum of absolute products* is huge relative to the result, which is the true conditioning. **Confirmed correct choice.**

### 2.2 Subnormal audits at −12 and −14

The exponents −12 and −14 are suspicious. In FP64, subnormals begin at \(2^{-1022} \approx 2.2\times10^{-308}\). Exponents −12/−14 correspond to **FP32 subnormals** (\(2^{-126}\)) only if the mantissa is scaled by \(2^{-112}\) or so. **Finding: Ambiguous.** If the audit is "does the kernel produce values with exponent ≤ −12 in *decimal*", that is \(10^{-12}\), which is *normal* in FP64 and *normal* in FP32. The Tribunal suspects the authors mean **FP32 subnormal boundary** and the kernel is silently downcasting. **Demand:** explicit `std::fpclassify` on the accumulator, and a `-ffast-math`-off build flag. `-ffast-math` will flush subnormals to zero and invalidate the audit.

### 2.3 Zero-copy PMTP validation

Zero-copy means the 88-byte descriptor is `reinterpret_cast` from the slab. **FFI hardening:** the C++ side must

1. `static_assert(sizeof(PmtpDescriptor) == 88)`,
2. `static_assert(alignof(PmtpDescriptor) == 8)`,
3. validate `magic == 0x50544D50` ("PMTP" LE) **before** dereferencing any `Q` field,
4. bounds-check `offset + length` against the slab size passed in the same call.

Without (3) and (4), a malicious orchestrator can hand a forged descriptor and get arbitrary read. **Finding: Conditional — mandatory hardening.**

### 2.4 AVX-512 + OpenMP

`#pragma omp parallel for` over a Neumaier reduction is a **race** unless each thread has a private compensation term and the final merge is itself Neumaier-compensated. **Finding: Likely bug [NEEDS SOURCE].** The merge of \(T\) partial sums each with error \(O(u\sum|x_iy_i|)\) gives total error \(O(Tu\sum|x_iy_i|)\) — still backward stable, but only if the merge is compensated. A naive `+=` merge loses the guarantee.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic = unwind` as FFI safety barrier

This is **the single most dangerous claim in the stack.** `panic = unwind` across an `extern "C"` boundary is **undefined behavior** in Rust unless the function is `extern "C-unwind"` (stabilized 1.71) *and* the C++ side is compiled with `-fexceptions` and matching unwinder. The default `extern "C"` aborts on unwind since Rust 1.81 (the `C-unwind` ABI split). **Finding: Refuted as stated.** The correct barrier is:

```rust
#[no_mangle]
pub extern "C" fn pmtp_dot(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(v) => { /* write out */ 0 }
        Err(_) => -1,  // never unwind across FFI
    }
}
```

with `panic = "abort"` in the release profile *or* `catch_unwind` at every boundary. `panic = unwind` alone is **not** a safety barrier; it is a safety *hazard*.

### 3.2 Packed 88-byte descriptor

Rust: `#[repr(C, packed)]` gives 88 bytes but **misaligns `u64` fields**, forcing unaligned loads (slow on x86, fault on some ARM). The correct form is `#[repr(C)]` with explicit `_pad: [u8; 6]` — same 88 bytes, 8-aligned. **Finding: Conditional.** If the source uses `packed`, demand `#[repr(C)]` + manual pad.

### 3.3 Safe SIMD

`std::simd` is still nightly. If the kernel uses `core::arch::x86_64::_mm512_*`, those are `unsafe`. "Safe SIMD" in stable Rust 2021 means **`wide` or `pulp` crates**, which wrap intrinsics. **Finding: Conditional** — the safety claim is only true if the unsafe blocks are encapsulated and `#[target_feature(enable = "avx512f")]` is applied to a `unsafe fn` called only after runtime detection.

### 3.4 Neumaier in Rust

Same math as C++. Rust's `f64::mul_add` (FMA) is **not** a substitute for Neumaier — FMA reduces rounding but does not compensate cancellation. **Confirmed** if the source uses the two-sum/two-product formulation.

---

## TARGET 4 — `kernel_cuda_v1350.cu`

### 4.1 Stiefel Cayley retraction in \(\mathbb{R}^{2K\times 2K}\)

The Cayley retraction on the Stiefel manifold \(St(n,p)\) is

\[
Y(\tau) = \left(I - \tfrac{\tau}{2}W\right)^{-1}\left(I + \tfrac{\tau}{2}W\right)X, \quad W = A X^\top - X A^\top
\]

where \(A\) is the ambient gradient. For \(X \in \mathbb{R}^{2K \times 2K}\) (square, \(n = p = 2K\)), \(W\) is skew-symmetric and the Cayley transform is **orthogonal by construction** — no need for cuSOLVER at all. **Finding: Suspicious.** Why is `DnDsyevd` (symmetric eigensolver) invoked? Either (a) the manifold is not Stiefel but Grassmann and the summary is wrong, or (b) the