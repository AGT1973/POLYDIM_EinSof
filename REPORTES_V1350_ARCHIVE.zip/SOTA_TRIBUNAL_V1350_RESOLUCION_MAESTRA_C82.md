# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 82

The public evidence available here does **not contain the six Tribunal reports, V1350 kernel specifications, or PMTP ABI definitions** needed to validate the requested arbitration. The search results identify PolyDiM as a PDE-oriented C++ library, not a V1350 architecture, and provide no authoritative record of the named kernels or model findings.[4][6][13] Therefore, no defensible claim of a definitive SOTA result or exact architectural guarantee can be attributed to those six models.

A technically sound arbitration, based on established numerical-analysis and concurrency principles, is:

## 1. Cayley–Stiefel retraction versus Householder or polar QR

For a Stiefel point \(X\in\mathbb{R}^{n\times p}\), \(X^\top X=I\), a Cayley update typically has the form

\[
X_{+}=\left(I-\frac{\tau}{2}A\right)^{-1}
       \left(I+\frac{\tau}{2}A\right)X,
\qquad A^\top=-A.
\]

In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists. However, that does **not** imply numerical stability for arbitrarily large \(|\tau|\). For \(|\tau|\ge 10^{10}\), the implementation is dominated by:

- conditioning of \(I-\frac{\tau}{2}A\);
- overflow, underflow, and loss of significance;
- quality of the linear solve;
- accumulation of orthogonality error;
- scaling and representation of \(A\).

A Cayley kernel should therefore not be advertised as unconditionally stable at extreme steps. It requires scaling, a backward-stable solve, residual checks, and an orthogonality acceptance test such as

\[
\|X_{+}^{\top}X_{+}-I\| \le c\,u\,\kappa_{\mathrm{solve}},
\]

where \(u\) is machine unit roundoff.

Householder QR is generally the preferred **robust retraction** when a reliable orthonormal basis is required. It is backward stable under standard assumptions and does not require forming an extreme Cayley rational transform. Polar retraction is geometrically attractive and can be highly accurate, but its implementation must use a stable SVD or a stable Newton–Schulz variant with appropriate scaling; an unscaled iteration is not guaranteed for extreme inputs.

**Arbitrated result:**  

- **Best default for extreme-step robustness:** Householder QR.
- **Best geometric projection when implemented with a stable SVD:** polar retraction.
- **Cayley:** acceptable as a structure-preserving method only with explicit scaling, stable solves, residual certification, and fallback to QR or polar projection.

The exact guarantee that can be made is conditional:

> If the Cayley linear solve is backward stable, the transformed matrix is representable without overflow, and the residual and orthogonality tests pass, the result is a numerically certified approximate Stiefel point. No unconditional guarantee follows merely from the algebraic orthogonality of the exact Cayley transform.

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

An 88-byte layout, by itself, provides **no memory-ordering guarantee**. Correct RCU/QSBR snapshot isolation requires a protocol, not merely a descriptor size.

A valid publication sequence is conceptually:

1. Construct and fully initialize an immutable descriptor or pointed-to object.
2. Publish its pointer/version with **release** semantics.
3. Readers load the pointer/version with **acquire** semantics.
4. Readers announce entry into their read-side critical section before dereferencing.
5. Writers retire the old object only after the relevant grace period or QSBR condition completes.

The essential happens-before relation is

\[
\text{initialize object}
\;\xrightarrow{\mathrm{release}}\;
\text{publish pointer}
\;\xrightarrow{\mathrm{acquire}}\;
\text{reader dereference}.
\]

Acquire/release ordering is sufficient for publication visibility when the lifetime protocol is otherwise correct. It is **not by itself sufficient** to prevent reclamation races. Reclamation additionally requires a correct grace-period mechanism, reader registration, quiescent-state reporting, and protection against ABA or version reuse.

For the descriptor, the architecture should require:

- fixed, explicitly specified field offsets and alignment;
- no concurrent mutation of immutable snapshot fields;
- atomic publication of the pointer or generation state;
- release publication and acquire consumption;
- release retirement or equivalent ordering before grace-period observation;
- QSBR/RCU registration and quiescent-state rules;
- a generation counter or tagged pointer if ABA is possible;
- language-specific atomic types rather than ordinary non-atomic fields.

**Arbitrated result:** acquire/release is the correct minimum ordering for snapshot publication and consumption, but it cannot be promoted to a complete isolation guarantee without the full RCU/QSBR lifecycle. Sequential consistency is not generally required, while relaxed ordering is insufficient for publication unless additional synchronization establishes the same happens-before relation.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no single “multi-silicon conformance” guarantee across these systems without defining a restricted semantic core and testing each backend. CUDA, XLA, Triton, C++20, and Rust differ in:

- execution and synchronization models;
- floating-point contraction and reassociation;
- supported atomics and memory scopes;
- device memory ordering;
- alignment and aliasing rules;
- compiler lowering;
- supported integer widths and vector layouts;
- treatment of undefined behavior and data races.

A portable conformance claim must distinguish three levels:

| Level | Defensible guarantee |
|---|---|
| **Functional conformance** | Outputs satisfy specified tolerances and invariants on every supported backend. |
| **Numerical conformance** | Error bounds, determinism requirements, and reduction behavior are explicitly specified. |
| **Bitwise conformance** | Identical bits are produced; this requires tightly controlled arithmetic, ordering, compiler options, and hardware support. |

The strongest realistic architectural contract is:

> All backends implement the same abstract state machine, descriptor ABI, synchronization protocol, and numerical acceptance tests; backend-specific kernels may differ, but every result must satisfy the same invariant and error contract.

That contract should include:

\[
\|X^\top X-I\| \le \varepsilon_{\mathrm{orth}},
\]

a residual bound for linear solves,

\[
\frac{\|B\widehat{x}-b\|}{\|B\|\|\widehat{x}\|+\|b\|}
\le \varepsilon_{\mathrm{solve}},
\]

and explicit memory-safety and lifetime conditions for descriptors.

For CUDA and Triton, device-level memory scopes and barriers must be mapped explicitly to the abstract acquire/release protocol. XLA requires care because operation ordering may be transformed unless dependencies are represented in the graph. C++20 and Rust require atomics and synchronization primitives whose semantics are preserved by the target implementation; ordinary loads and stores cannot substitute for them.

## Definitive synthesis

The mathematically superior and architecturally defensible design is a **hybrid certified kernel**:

1. Use Cayley updates only as a fast structure-preserving proposal.
2. Scale extreme steps and solve the Cayley system with a backward-stable method.
3. Certify the residual and Stiefel constraint.
4. Fall back to Householder QR for guaranteed robust re-orthogonalization.
5. Use polar/SVD projection when nearest-point geometry is more important than throughput.
6. Publish immutable PMTP snapshots with release semantics and consume them with acquire semantics.
7. Complete reclamation only through a formally specified RCU/QSBR grace-period protocol.
8. Define one language- and backend-neutral ABI and invariant contract.
9. Validate every CUDA, XLA, Triton, C++20, and Rust implementation against adversarial numerical, memory-ordering, reclamation, and multi-device tests.

The exact guarantees that can legitimately be stated are conditional guarantees:

- **Stiefel correctness:** certified within a stated floating-point tolerance after acceptance or fallback.
- **Snapshot visibility:** all initialized fields published before release are visible to an acquire reader.
- **Lifetime safety:** retired snapshots are not reclaimed until the specified grace-period condition holds.
- **Cross-backend conformance:** every supported backend satisfies the same ABI, synchronization, error, and invariant contract.

Claims of unconditional Cayley stability for \(|\mathrm{step}|\ge 10^{10}\), isolation from descriptor size alone, or automatic conformance across all five programming/compiler ecosystems are not justified by the available evidence.