# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 139

The requested arbitration cannot be validated as stated: no public, authoritative record of the **“POLYDIM V1350” kernels**, **Cycle 139**, or the eight claimed Tribunal reports was found. The available results identify PolyDiM as a PDE library, not this kernel specification.[8][11][14] Therefore, no defensible model-by-model vote or exact implementation guarantee can be attributed to Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, or Perplexity.

A technically sound synthesis, conditional on the intended designs, is:

## 1. Cayley–Stiefel retraction under extreme steps

A Cayley map is not unconditionally stable for \(\lvert \text{step}\rvert \ge 10^{10}\). For a skew-symmetric generator \(A^\top=-A\), the exact Cayley transform

\[
Q(\alpha)=\left(I-\frac{\alpha}{2}A\right)^{-1}
          \left(I+\frac{\alpha}{2}A\right)
\]

is orthogonal in exact arithmetic whenever the inverse exists. However, extreme \(\alpha\) can produce:

- ill-conditioned linear solves;
- overflow or underflow in forming scaled terms;
- loss of skew-symmetry from floating-point rounding;
- amplified backward error if the implementation explicitly forms matrix inverses;
- poor gradient behavior as the map approaches its large-step limit.

The mathematically superior guarantee is therefore **conditional orthogonality**, not unconditional numerical stability:

\[
\widehat Q^\top \widehat Q
= I + O\!\left(u\,\kappa\!\left(I-\frac{\alpha}{2}A\right)\right),
\]

where \(u\) is machine precision. The implementation must solve the linear system using a backward-stable factorization and must not form an explicit inverse.

Householder QR generally offers the strongest numerical orthogonality guarantee for a dense retraction. Polar decomposition offers a geometrically natural nearest-orthogonal-point projection, but its stability depends on the chosen iteration or SVD implementation. A defensible ranking is:

1. **Householder QR**, for robust computed orthogonality;
2. **SVD-based polar factor**, for closest-point projection and rank-deficiency handling;
3. **Cayley**, when preserving a structured low-cost update is more important than unconditional extreme-step robustness.

For \(\lvert\text{step}\rvert\ge10^{10}\), the architectural guarantee should be:

> The kernel must either rescale, reject, or damp the step; use a stable solve; and return an explicit status if the requested tolerance cannot be met.

It should not promise that a raw Cayley update remains stable solely because the exact transform is orthogonal.

## 2. PMTP 88-byte descriptor and RCU/QSBR isolation

Acquire/release operations are necessary but not sufficient for snapshot isolation.

The minimum correct publication protocol is:

1. Writer initializes the complete immutable snapshot.
2. Writer publishes the descriptor or pointer with **release** semantics.
3. Reader loads the published pointer/token with **acquire** semantics.
4. Reader accesses only data reachable from that acquired snapshot.
5. Writer retires the old snapshot only after the RCU/QSBR grace-period condition is satisfied.
6. Reclamation occurs only after all pre-existing readers have quiesced.

This ordering is consistent with established QSBR guidance: an acquire load prevents later shared-data loads from moving before publication, while a release store prevents earlier shared-data loads from moving after reader acknowledgement.[5][13]

The exact guarantee is:

\[
\text{publish}_{\text{release}}(S)
\;\prec_{\text{sw}}\;
\text{load}_{\text{acquire}}(S),
\]

which establishes a happens-before relationship for initialization writes visible through \(S\). It does **not** by itself guarantee:

- atomicity of an 88-byte copy;
- protection against torn descriptor reads;
- safe reclamation;
- cross-device coherence;
- synchronization between CUDA, XLA, Triton, C++, and Rust memory models.

If the 88-byte object is directly copied concurrently, it must be treated as non-atomic unless the design uses an atomic indirection, a seqlock/version protocol, immutable storage, or an equivalent validated mechanism. The strongest architecture is:

\[
\text{atomic pointer/token} \rightarrow
\text{immutable 88-byte descriptor}.
\]

The descriptor itself should not be concurrently mutated after publication.

## 3. Multi-silicon and multi-language conformance

There is no single shared memory model spanning CUDA, XLA, Triton, C++20, and Rust. A guarantee established in C++20 cannot automatically be transferred to GPU kernels or compiler IR, and host acquire/release operations do not automatically establish device-wide ordering.

Conformance must therefore be defined through an explicit portability contract covering:

- descriptor layout, size, alignment, and endianness;
- pointer representation and address-space rules;
- publication and reclamation protocol;
- supported scopes of atomic operations;
- visibility domains between host, device, workgroups, and streams;
- compiler barriers versus hardware fences;
- numerical tolerances and NaN/Inf behavior;
- integer overflow and out-of-bounds behavior;
- deterministic status/error reporting.

The strongest realistic guarantee is:

> Bitwise-identical behavior is guaranteed only for explicitly supported targets, compiler versions, instruction paths, and memory scopes. Otherwise the implementation guarantees semantic equivalence within stated numerical and ordering tolerances.

CUDA and Triton require explicit device-scope or system-scope atomics and fences where host/device visibility is involved. XLA may legally reorder operations unless ordering is represented in its supported effect or synchronization mechanisms. C++20 and Rust provide language-level ordering guarantees only when the relevant objects and atomics are accessed through their defined models; those guarantees do not repair races in foreign or device memory.

## Definitive arbitration

The only defensible SOTA position is:

- **Retraction:** use Householder QR or SVD-based polar projection for unconditional extreme-step robustness; use Cayley only with stable solves, scaling, conditioning checks, and failure reporting.
- **Snapshot publication:** publish an immutable snapshot through an acquire/release atomic indirection; combine it with a formally defined RCU/QSBR grace period. Acquire/release alone does not make an 88-byte descriptor atomically readable or safely reclaimable.
- **Portability:** specify a target-by-target memory and numerical contract. Do not claim one universal guarantee across CUDA, XLA, Triton, C++20, and Rust without proof and conformance tests.

Accordingly, the exact architectural guarantees that can be justified are **conditional stability**, **happens-before publication of immutable snapshots**, and **contractual multi-target conformance**—not unconditional Cayley stability, atomicity of an 88-byte descriptor, or automatic cross-silicon memory-model equivalence.