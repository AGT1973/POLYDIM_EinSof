# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 142)

# POLYDIM V1350 — High Tribunal Audit, Cycle 142

**Presiding note.** The Tribunal has reviewed the six artifacts as *specifications*, not as compiled binaries. Where the submission asserts "12/12 physical conformance checks" or "88-byte descriptor," we treat those as claims to be falsified, not accepted. Findings below are grouped by the six audit requirements, then per-target.

---

## 0. Cross-cutting findings (apply to all six targets)

### 0.1 The 88-byte descriptor is *not* 88 bytes on the wire

The Python struct format `<4sHHQQQQQBB6x4Q` decomposes as:

| Field | Type | Bytes |
|---|---|---|
| magic | 4s | 4 |
| two H | HH | 4 |
| five Q | QQQQQ | 40 |
| two B | BB | 2 |
| pad | 6x | 6 |
| four Q | 4Q | 32 |
| **total** | | **88** |

Structurally correct. **But** `<` forces little-endian and *no alignment*, whereas the C++/Rust/CUDA sides almost certainly declare the descriptor as a `struct` with natural alignment. On x86-64, `Q` fields align to 8, so a naive `struct PmtpTensorDescriptor { uint32_t magic; uint16_t a,b; uint64_t c,d,e,f,g; uint8_t h,i; uint64_t j,k,l,m; };` will be **96 bytes** with 8 bytes of tail padding, not 88. This is the classic Rule 22 violation vector.

**Mandate:** every non-Python target must emit `static_assert(sizeof(PmtpTensorDescriptor) == 88, ...)` (C++), `const _: () = assert!(size_of::<PmtpTensorDescriptor>() == 88);` (Rust), and `#pragma pack(push,1)` / `#[repr(C, packed)]` respectively. The Python side must additionally assert `struct.calcsize(fmt) == 88` at import time. **The Tribunal does not accept "12/12 conformance" without these static asserts in the source.**

### 0.2 Rule 22 — "Zero 1D tokens"

The submission never defines "1D token." The Tribunal interprets this as: **no scalar (rank-0) or rank-1 payloads may cross the inter-agent boundary**; all inter-agent messages must be rank-≥2 tensors or the 88-byte descriptor. Under that reading:

- **TARGET 1** violates Rule 22 if `HardwareProbe` returns a Python `list[int]` of device IDs to the orchestrator (rank-1). Must be wrapped as `(N,1)` int64.
- **TARGET 5** violates Rule 22 if `jax.jit` returns a scalar loss to the host for logging. Must be `(1,1)`.
- **TARGET 6** violates Rule 22 if Triton kernels return a scalar `tl.sum` reduction to Python. Must be `(1,)` reshaped to `(1,1)`.

**No target in the submission demonstrates a rank-2 envelope on every FFI return path.** This is a **FAIL** on Rule 22 as stated, pending evidence.

### 0.3 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor lock? | Verdict |
|---|---|---|
| 1 (Python orchestrator) | None if `HardwareProbe` is plugin-based; **locked** if it hard-codes `torch.cuda.is_available()` | Conditional |
| 2 (C++ AVX-512) | **Locked to x86-64 with AVX-512** unless a scalar/AVX2 fallback path exists | **FAIL** as written |
| 3 (Rust SIMD) | Portable if `std::simd` or `wide`; locked if `core::arch::x86_64::*` | Conditional |
| 4 (CUDA) | **Locked to NVIDIA** by cuSOLVER `DnDsyevd` | **FAIL** |
| 5 (XLA) | **Locked to Google TPU / AWS Trainium** by HLO | **FAIL** |
| 6 (Triton) | Portable across ROCm/CUDA — this is the *only* target that satisfies Rule 27 | **PASS** |

Rule 27 as stated ("does any component impose vendor-lock?") is **violated by 4 of 6 targets**. The Tribunal notes that a "Silicon Contract" that permits vendor lock is not a contract; it is a preference.

---

## 1. Numerical degeneracy: step → ∞ and step → 0

### 1.1 TARGET 4 — Stiefel Cayley retraction (the critical case)

The Cayley retraction on the Stiefel manifold is
$$Y(\alpha) = (I - \tfrac{\alpha}{2} A)^{-1}(I + \tfrac{\alpha}{2} A)\, Y_0, \quad A = G Y_0^\top - Y_0 G^\top \text{ (skew)}.$$

**As α → ∞:** the map converges to $Y_\infty = -Y_0$ (the antipode) *only if* $A$ is invertible. If $A$ has a zero eigenvalue (which happens whenever $G$ is in the tangent space at $Y_0$ with a zero-curvature direction), then $(I - \tfrac{\alpha}{2}A)$ becomes singular for $\alpha = 2/\lambda_{\min}(A)$. **The submission's "globally scaled Woodbury solve (M/scale) W = (step/scale) B" does not fix this** — scaling both sides by `1/scale` is a similarity transform that leaves the condition number of the linear system invariant. The Tribunal demands:

$$\kappa_2(I - \tfrac{\alpha}{2}A) = \frac{1 + \tfrac{\alpha}{2}\sigma_{\max}(A)}{1 - \tfrac{\alpha}{2}\sigma_{\max}(A)} \xrightarrow{\alpha \to \infty} \infty.$$

**Proof of degeneracy:** Let $\sigma_{\max}(A) = \lambda > 0$. Then $\kappa_2 \to \infty$ as $\alpha \to 2/\lambda$. For $\alpha \ge 10^{10}$ and $\lambda \sim 1$, the system is numerically singular in FP64 (machine epsilon $2^{-52} \approx 2.2\times10^{-16}$; the smallest resolvable eigenvalue gap is $\sim \alpha^{-1} \sim 10^{-10}$, which is *above* eps but the *condition number* is $\sim 10^{10}$, so backward error $\sim 10^{-6}$ — unacceptable for a "SOTA" claim).

**Mandate:** clamp $\alpha \le \alpha_{\max} = 2/(\lambda + \epsilon)$ with $\lambda$ estimated via a few Lanczos steps, or switch to a QR-based retraction when $\kappa_2 > 10^{12}$.

**As α → 0:** $Y(\alpha) \to Y_0$ linearly, which is fine, but the *subnormal* regime is the problem. If `step` is stored as a subnormal FP64 ($< 2^{-1022} \approx 2.2\times10^{-308}$), then `step/scale` underflows to zero, and the Woodbury solve returns $W = 0$, so $Y(\alpha) = Y_0$ — a silent no-op. **The submission's "subnormal audits (-12, -14)" in TARGET 2 refer to decimal exponents, i.e. $10^{-12}, 10^{-14}$, which are *not* subnormal in FP64.** This is a category error. True subnormal audit requires checking `fpclassify(x) == FP_SUBNORMAL` and flushing or promoting.

### 1.2 TARGET 2 — Neumaier compensated dot products

Neumaier summation has *forward* error $O(\epsilon)$ independent of $n$, but the *compensation term* itself can underflow. For inputs with $|x_i| \sim 10^{-160}$ (near subnormal), the products $x_i y_i$ underflow to subnormal or zero, and the compensation $c$ becomes meaningless. **The "-12, -14" audit is insufficient**; the Tribunal demands an audit at $10^{-300}$ and $10^{-320}$ (true subnormal boundary).

### 1.3 TARGET 5 — Continuous Lyapunov solve in FP64

The Lyapunov equation $A X + X A^\top = -Q$ has solution $X = \int_0^\infty e^{At} Q e^{A^\top t} dt$. As $\|A\| \to \infty$ (large step), the integral is dominated by $t \sim 1/\|A\|$, and the Bartels–Stewart algorithm's condition number scales as $\kappa \sim \|A\|^2 / \lambda_{\min}(Q)$. For $\|A\| \sim 10^{10}$, $\kappa \sim 10^{20}$ — **beyond FP64**. The submission's claim of "pure FP64" is a *liability*, not a feature, in this regime. **Mandate:** either use extended precision (double-double) or reformulate as a matrix sign function with scaling-and-squaring.

### 1.4 TARGET 6 — Clifford bivector rotations

Streaming Clifford bivector rotations $R = e^{B\theta/2}$ with $\theta \to \infty$: the exponential is periodic in $\theta$ (period $4\pi$ for spinors), so large $\theta$ is *not* degenerate *if* reduced mod $4\pi$. **But** if the submission does not reduce, then $\cos(\theta/2), \sin(\theta/2)$ lose precision for $\theta \sim 10^{10}$ (argument reduction error $\sim \theta \cdot \epsilon \sim 10^{-6}$). **Mandate:** Payne–Hanek reduction before exponentiation.

### 1.5 TARGET 1 — PmtpSlabAllocator

If slab sizes are computed as `size = base * 2**k` with `k` derived from `step`, then `step → ∞` overflows `size_t` and `step → 0` yields `size = 0` (zero-size allocation, UB in C, `MemoryError` in Python). **Mandate:** clamp `k ∈ [k_min, k_max]` with `k_min ≥ 0`, `k_max ≤ 62` on 64-bit.

### 1.6 TARGET 3 — Rust Neumaier sums

Same as TARGET 2, plus: Rust's `f64::mul_add` (FMA) is *not* guaranteed to be correctly rounded on all targets (it is on x86-64 with FMA3, but the Rust reference says "may be implemented as `a*b+c`"). **Mandate:** use `core::intrinsics::fmaf64` or verify via `cfg(target_feature = "fma")`.

---

## 2. Rule 22 compliance (88-byte PMTP, zero 1D tokens)

**Verdict: FAIL across all six targets as submitted.**

- No target shows a `static_assert` / `const