# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 133

The requested **definitive arbitration cannot be established from the available evidence**: no authoritative record of “POLYDIM V1350,” Cycle 133, the six kernels, or the eight tribunal outputs was provided or located. The public material found is insufficient to attribute findings to Claude, Qwen, Kimi, Gemini, DeepSeek, Cerebras CS-3, GLM Z.IA, and Perplexity. One search result is an unrelated PolyDiM PDE library, while another appears to be an unverified GitHub design document rather than a conformance specification.[1][2]

A technically defensible SOTA synthesis is therefore conditional:

## 1. Cayley–Stiefel retraction under \(|\mathrm{step}|\ge 10^{10}\)

For \(X\in\mathrm{St}(D,K)\), a Cayley update of the form

\[
X^{+}
=
\left(I-\frac12 W\right)^{-1}
\left(I+\frac12 W\right)X,
\qquad W^{T}=-W,
\]

is attractive because the exact transform is orthogonal in exact arithmetic. Low-rank Sherman–Morrison–Woodbury implementations can reduce the solve to a \(2K\times 2K\) system, which is advantageous when \(K\ll D\).[3]

However, **orthogonality in exact arithmetic does not imply numerical stability for an extreme step**. At \(|\mathrm{step}|\ge 10^{10}\), stability depends on:

- scaling or normalization of the tangent direction;
- conditioning of the reduced system \(I-\frac12V^{T}U\);
- finite-precision overflow, underflow, and cancellation;
- residual monitoring of \(X^{+T}X^{+}-I\);
- iterative refinement or a fallback factorization.

Accordingly, the architectural guarantee should be:

> **Cayley is the preferred fast path only with explicit norm scaling, condition estimation, residual verification, and a bounded fallback. It must not be claimed unconditionally superior to Householder or polar QR at extreme step magnitude.**

Householder QR generally offers stronger practical robustness for reorthogonalization because it explicitly constructs an orthogonal factor, while polar QR/SVD-style methods provide a strong projection onto the Stiefel manifold at higher cost. A mathematically sound policy is:

1. scale the tangent update before forming the Cayley system;
2. compute the low-rank Cayley update;
3. verify \(\|X^{+T}X^{+}-I\|\) and solve residuals;
4. fall back to Householder QR or a polar method when thresholds are exceeded.

No unconditional “Cayley wins at \(10^{10}\)” guarantee follows from the available evidence.

## 2. PMTP 88-byte descriptors and RCU/QSBR isolation

Acquire/release operations alone do **not** automatically guarantee snapshot isolation. Correctness requires a complete publication and reclamation protocol:

- the writer initializes the descriptor and pointed-to immutable state;
- the writer publishes the descriptor pointer or generation using a **release** store;
- the reader obtains it using an **acquire** load;
- the reader announces entry into its read-side critical section before dereferencing the snapshot;
- reclamation occurs only after every reader that could have observed the old generation has passed through a quiescent state.

QSBR documentation describes reclamation as safe only after all readers have entered quiescent states, and RCU implementations use release operations in grace-period coordination.[4][5] Thus:

> **Acquire/release ordering guarantees visibility and ordering; RCU/QSBR grace-period tracking guarantees lifetime and reclamation. Neither mechanism alone guarantees isolation.**

The 88-byte size is not itself a correctness property. The descriptor must additionally specify:

- alignment and atomic-width requirements;
- which fields are immutable after publication;
- generation/version validation;
- ownership of referenced memory;
- reader announcement and exit rules;
- reclamation and ABA protection;
- whether the descriptor crosses device or host memory domains.

The strongest legitimate guarantee is:

> A reader sees a fully initialized, internally consistent immutable snapshot, and that snapshot remains alive until the reader exits its protected read-side interval—provided the stated publication, validation, and grace-period protocol is followed.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no evidence establishing automatic semantic equivalence across all five environments. They have materially different execution and memory models:

- **C++20** provides a language-level atomic memory model, but not GPU-wide semantics by itself.
- **Rust** exposes atomic orderings and ownership guarantees, but unsafe foreign-function or device interfaces can bypass those guarantees.
- **CUDA** has host/device, block, grid, and system scopes whose visibility depends on the selected atomic and fence operations.
- **Triton** exposes compiler- and GPU-dependent atomic and synchronization behavior; exact guarantees must be tied to its documented lowering and target architecture.
- **XLA** is an optimizing graph compiler; operation ordering and aliasing guarantees must be expressed through supported primitives rather than assumed from source-level sequencing.

Therefore, “multi-silicon conformance” requires a formal portability contract, not merely compiling the same algorithm. At minimum it must define:

- numerical tolerances and NaN/Inf behavior;
- reduction associativity policy;
- supported dtypes and accumulation precision;
- memory-ordering scope;
- synchronization and progress assumptions;
- descriptor layout, alignment, and endianness;
- version/generation validation;
- reclamation behavior;
- deterministic versus nondeterministic execution;
- per-backend litmus tests and stress tests.

The exact architectural guarantee should be limited to:

> **Bitwise identity is not portable across these backends unless explicitly engineered and tested. Semantic equivalence within declared numerical, ordering, and lifetime contracts is achievable; unconditional cross-backend equivalence is not established.**

## Arbitration

| Question | Defensible ruling |
|---|---|
| Extreme-step Cayley versus Householder/polar QR | Cayley is a high-performance conditional fast path, not an unconditional stability winner. |
| PMTP acquire/release | Necessary for publication ordering, insufficient alone for RCU/QSBR isolation and reclamation. |
| Five-platform conformance | Requires an explicit memory/numerical ABI and backend-specific validation; compilation is not conformance. |

The mathematically superior synthesis is therefore a **verified adaptive architecture**:

\[
\text{scaled Cayley/SMW fast path}
\;\rightarrow\;
\text{residual and conditioning checks}
\;\rightarrow\;
\text{Householder or polar fallback},
\]

combined with:

\[
\text{release publication}
+
\text{acquire observation}
+
\text{generation validation}
+
\text{RCU/QSBR grace period},
\]

and a backend-neutral conformance specification implemented separately for CUDA, XLA, Triton, C++20, and Rust.

Claims stronger than these—especially unconditional extreme-step stability, isolation from acquire/release alone, or exact five-backend equivalence—are not justified by the available record.