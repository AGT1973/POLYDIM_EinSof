# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 147

The requested **Cycle 147 arbitration cannot be made definitively from the available evidence**: no public, verifiable reports from the eight named tribunal models or specification for the six “V1350 kernels” were provided. The available material supports general conclusions about Cayley/Stiefel retractions, but not the claimed PMTP layout, implementation details, benchmark results, or cross-silicon conformance.

### 1. Cayley–Stiefel stability at \(|\mathrm{step}|\ge 10^{10}\)

For \(X\in\mathrm{St}(n,p)\), a Cayley retraction has the form

\[
R_X(\eta)
=
\left(I-\frac12\Omega\right)^{-1}
\left(I+\frac12\Omega\right)X,
\]

with \(\Omega\) skew-symmetric. The Cayley transform is a valid Stiefel retraction and preserves orthogonality in exact arithmetic.[1]

However, that does **not** establish numerical stability for an extreme step. At \(|\mathrm{step}|\ge 10^{10}\):

- A direct solve involving \(I-\tfrac12\Omega\) may be badly scaled or ill-conditioned.
- Forming \(I+\tfrac12\Omega\) and \(I-\tfrac12\Omega\) can lose relative accuracy.
- The result may remain mathematically orthogonal while suffering substantial floating-point error.
- Overflow, underflow, cancellation, and loss of update-direction fidelity become implementation-dependent.

Householder QR and polar decomposition also have different failure modes. QR is generally backward stable when implemented with Householder reflectors, while polar methods can provide a geometrically natural nearest-orthogonal factor but may require iterative refinement or stable SVD/eigendecomposition. The literature treats Cayley, QR, and polar retractions as alternative valid retraction mechanisms, not as one universally dominant method.[3][4]

**Arbitrated guarantee:**

\[
\boxed{\text{No unconditional stability guarantee exists for Cayley, QR, or polar retraction at }10^{10}\text{ without a specified algorithm, precision, scaling, and error bound.}}
\]

A defensible V1350 implementation should:

1. Rescale or factor the step before forming the transform.
2. Use a stable linear solve rather than an explicit inverse.
3. Monitor \(\|Y^\top Y-I\|\).
4. Fall back to Householder QR or a carefully implemented polar projection when the residual exceeds tolerance.
5. Specify guarantees in terms of backward error, for example

\[
\frac{\|Y^\top Y-I\|}{u\,\kappa_{\mathrm{alg}}}
\le C(n,p),
\]

rather than claiming exact orthogonality.

Thus, a claim that Cayley is categorically superior to Householder QR or polar QR for extreme steps is unsupported.

### 2. PMTP 88-byte descriptor and RCU/QSBR isolation

No authoritative PMTP specification or layout was available, so the **88-byte size alone proves nothing** about memory ordering or snapshot isolation.

For RCU/QSBR, the required properties are semantic:

- A writer must fully initialize a new descriptor before publishing its pointer.
- Publication requires **release** ordering.
- A reader must acquire the published pointer before reading descriptor fields.
- Retiring an old descriptor requires a grace-period mechanism.
- Reclamation is safe only after every pre-existing reader has passed through a quiescent state or otherwise established a happens-before relation.

A correct abstract protocol is:

\[
\text{initialize descriptor}
\;\xrightarrow{\text{release}}\;
\text{publish pointer}
\;\xrightarrow{\text{acquire}}\;
\text{reader field accesses}.
\]

For QSBR, acquire/release on the pointer is necessary but may not by itself be sufficient; reader registration, quiescent-state reporting, writer grace-period detection, and reclamation ordering must also be specified. “Acquire/Release semantics” therefore cannot be certified merely by observing an 88-byte descriptor.

**Arbitrated guarantee:**

\[
\boxed{\text{Snapshot isolation is guaranteed only if publication, reader access, quiescent-state tracking, and reclamation jointly establish happens-before.}}
\]

The exact descriptor alignment, cache-line placement, atomic fields, padding, and ABI layout remain unverifiable from the supplied information.

### 3. CUDA, XLA, Triton, C++20, and Rust conformance

There is no basis for claiming exact multi-silicon conformance across all five environments without:

- normative kernel specifications;
- defined numerical tolerances;
- reference outputs;
- supported data types;
- memory-ordering contracts;
- compiler and runtime versions;
- architecture-specific test matrices;
- treatment of nondeterminism, fused operations, NaNs, and reduced precision.

These ecosystems do not share identical execution or memory models. C++20 and Rust provide language-level atomic and concurrency semantics, but CUDA, Triton, and XLA introduce backend-specific lowering, synchronization, aliasing, layout, and numerical behavior. A source-level implementation that compiles in all five environments is not thereby semantically equivalent.

**Minimum conformance criterion:**

For every kernel \(K\), backend \(b\), input class \(D\), and permitted nondeterminism set \(N_b\),

\[
\operatorname{Err}\!\left(
K_b(x),K_{\mathrm{ref}}(x)
\right)
\le \varepsilon_b
\quad
\forall x\in D,
\]

along with explicit checks for:

- descriptor publication and reclamation races;
- orthogonality residuals;
- overflow and extreme-step behavior;
- synchronization visibility;
- alignment and aliasing;
- deterministic versus nondeterministic outputs.

### Definitive arbitration

The strongest technically defensible synthesis is:

| Area | Supported finding | Guarantee that can be made |
|---|---|---|
| Extreme Stiefel updates | Cayley is a valid retraction; QR and polar are also valid alternatives.[1][3][4] | No unconditional winner at \(|\mathrm{step}|\ge10^{10}\); use scaling, stable solves, residual checks, and fallback |
| PMTP descriptor | Descriptor size does not establish memory semantics | Acquire/release plus a complete QSBR/RCU grace-period proof is required |
| Multi-silicon support | No evidence establishes V1350-specific equivalence | Conformance must be demonstrated by a normative specification and backend test matrix |

Accordingly, the **mathematically superior SOTA architecture** is not “Cayley everywhere” or “Acquire/Release everywhere.” It is a layered design:

\[
\boxed{
\text{stable manifold update}
+
\text{verified orthogonality residual}
+
\text{release/acquire publication}
+
\text{formal QSBR grace-period proof}
+
\text{backend-specific conformance tests}
}
\]

Any stronger statement—such as exact stability at \(10^{10}\), guaranteed snapshot isolation from the 88-byte layout alone, or exact CUDA/XLA/Triton/C++20/Rust equivalence—would be an unsupported architectural claim rather than an established result.