# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 164)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 164 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has received six artifacts. We do not have the source bytes in front of us; we audit against the *specification as stated in the brief* and against the mathematical claims implied by the named primitives. Where the brief is silent, we mark the finding as **UNVERIFIED — REQUIRES SOURCE**. We refuse to certify claims we cannot falsify.

---

## 0. Cross-Cutting Findings (apply to all six targets)

### 0.1 Rule 22 — Zero 1D tokens / 88-byte PMTP

The 88-byte descriptor is declared as `<4sHHQQQQQBB6x4Q`. Let us audit the struct layout.

| Field | Type | Bytes |
|---|---|---|
| magic | `4s` | 4 |
| two `H` | `H H` | 4 |
| five `Q` | `Q Q Q Q Q` | 40 |
| two `B` | `B B` | 2 |
| pad | `6x` | 6 |
| four `Q` | `Q Q Q Q` | 32 |
| **Total** | | **88** |

**Verdict:** 4+4+40+2+6+32 = 88. ✅ Arithmetic conforms. Alignment: the struct is 8-byte aligned (largest member `Q`), and 88 is a multiple of 8. ✅

**Adversarial finding A1 (Rule 22 semantics).** "Zero 1D tokens" is a *semantic* rule, not a layout rule. An 88-byte struct can still carry a 1D token if any of the five `Q` fields encodes a scalar rank-1 identifier. The Tribunal demands: **prove that every `Q` field is a rank-≥2 descriptor (shape tuple, stride tuple, or pointer pair)**, not a flat index. The brief does not establish this. **UNVERIFIED.**

**Adversarial finding A2 (endianness).** `<` forces little-endian. On big-endian hosts (IBM POWER, some s390x), the descriptor will be misread. If the FFI boundary is cross-architecture, this is a **silent corruption vector**. Recommend explicit `>!` or a byte-swap shim at the boundary.

### 0.2 Rule 27 — Silicon Contract / vendor lock

| Target | Vendor exposure | Lock severity |
|---|---|---|
| T1 orchestrator | Multi-silicon probe | Low (by design) |
| T2 C++ AVX-512 | Intel/AMD x86 only | **High** — AVX-512 is absent on Zen 2, all ARM, all RISC-V |
| T3 Rust SIMD | portable if `std::simd` or `wide` | Low–Medium |
| T4 CUDA | NVIDIA only | **Critical** — cuSOLVER `DnDsyevd` is NVIDIA-proprietary |
| T5 XLA | Google TPU / AWS Trainium | **Critical** — two mutually exclusive vendor stacks |
| T6 Triton | AMD ROCm + NVIDIA | Medium (Triton abstracts, but SRAM tiling is arch-specific) |

**Finding A3.** T4 and T5 **violate Rule 27** as stated. A "Silicon Contract" that permits a single-vendor kernel is not a contract; it is a monopoly. The Tribunal requires either (a) a documented fallback path (e.g., T4 → T2 CPU path when no CUDA device), or (b) an explicit exemption clause in Rule 27. **The brief provides neither.**

**Finding A4.** T5's claim of "Google Cloud TPU / AWS Trainium" in a *single* file is architecturally suspect. XLA backends for TPU and Trainium are distinct compilers with distinct HLO dialects. A single `@jax.jit` cannot target both without a backend-selection layer. **UNVERIFIED — likely a documentation overclaim.**

---

## 1. TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe / PmtpSlabAllocator

**Finding T1-a (slab allocator fragmentation).** A slab allocator for 88-byte descriptors has a natural slab size of 88·k. For cache-line alignment (64 B), 88 is *not* a divisor of 64 or 128. Every descriptor straddles a cache line boundary unless padded to 128 B. **Recommendation:** either pad to 128 B (violates Rule 22's 88-byte mandate) or accept 2-line fetches. The brief does not state which. **UNVERIFIED.**

**Finding T1-b (12/12 conformance checks).** "12/12" is a *count*, not a *proof*. The Tribunal demands the 12 predicates be enumerated and each shown to be a *necessary* condition, not merely a *sufficient* one. A conformance suite that passes 12/12 but omits the 13th critical check is worse than no suite — it induces false confidence.

### 1.2 Numerical degeneracy at step → ∞ / step → 0

The orchestrator itself does not perform arithmetic, but it *dispatches* to kernels that do. The critical question: **does the orchestrator clamp `step` before dispatch?**

- If `|step| ≥ 10^10` reaches T4's Cayley retraction, the Woodbury solve `(M/scale) W = (step/scale) B` is *scale-invariant* only if `scale` is chosen as `max(|step|, ||M||)`. If `scale` is fixed, `step/scale` overflows FP64 at `step ≈ 1.8e308`. **The brief does not state the scale policy.** **UNVERIFIED — HIGH RISK.**
- If `step → 0` (subnormal, `|step| < 2.2e-308`), the Cayley retraction `(I - step/2 · A)^{-1}(I + step/2 · A)` degenerates to identity. The retraction becomes a no-op, and the optimizer stalls silently. **Recommendation:** orchestrator must enforce `|step| ∈ [ε_mach · ||M||, 10^10]` with an explicit `StepClamped` telemetry event.

---

## 2. TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product

Neumaier's algorithm:
```
s = 0; c = 0
for x, y in zip(a, b):
    t = s + x*y
    if |s| >= |x*y|: c += (s - t) + x*y
    else:            c += (x*y - t) + s
    s = t
return s + c
```

**Theorem (Neumaier 1974).** For `n`-term dot products in FP64 with `u = 2^-53`, the compensated result satisfies `|fl(a·b) - a·b| ≤ (2u + O(nu²)) · Σ|a_i b_i|`. This is **first-order accurate** — the error is bounded by `2u · Σ|a_i b_i|`, independent of `n`. ✅

**Adversarial finding T2-a (catastrophic cancellation is *not* cured).** Neumaier bounds the error relative to `Σ|a_i b_i|`, not relative to `|a·b|`. If `a·b ≈ 0` but `Σ|a_i b_i| = 10^10`, the *relative* error is `2u · 10^10 / |a·b|`, which can be `O(1)`. **The brief's claim of "compensated" must not be read as "condition-number-free."** The condition number of the dot product is `κ = Σ|a_i b_i| / |a·b|`, and Neumaier gives `rel_err ≤ 2u · κ`. For `κ > 10^15`, the result is garbage regardless of compensation.

### 2.2 Subnormal audits (-12, -14)

The brief cites exponents `-12` and `-14`. These are **not** subnormal exponents in FP64 (subnormals begin at `-1022`). They are likely **FP32** subnormal thresholds (`-126`) or **fixed-point** Q-format exponents. **Finding T2-b:** the notation is ambiguous. If the audit is checking FP64 subnormals, the thresholds should be `-1022` and `-1074`. If FP32, `-126` and `-149`. **The brief's `-12`/`-14` are almost certainly a typo or a domain-specific scaling.** **UNVERIFIED — demand clarification.**

### 2.3 AVX-512 vendor lock

**Finding T2-c.** AVX-512 is absent on:
- All ARM (Apple M-series, Graviton, Ampere Altra)
- All RISC-V
- AMD Zen 1–3 (Zen 4 has AVX-512, Zen 5 full-width)
- Intel Alder Lake P-cores (fused off), all E-cores

A "multi-silicon" orchestrator (T1) dispatching to an AVX-512-only kernel is a **Rule 27 violation** unless a scalar/SSE fallback exists. **The brief does not mention one.** **UNVERIFIED — HIGH RISK.**

### 2.4 Zero-copy PMTP validation

Zero-copy requires the 88-byte descriptor to be **page-aligned** and **pinned** (for DMA). 88 is not a page multiple. **Finding T2-d:** zero-copy is only achievable if the descriptor is embedded in a page-aligned slab (T1's allocator). The C++ kernel must therefore *trust* T1's alignment guarantee — a cross-module invariant that must be asserted at runtime (`assert(((uintptr_t)desc & 63) == 0)`).

---

## 3. TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 `panic=unwind` as FFI safety barrier

**Finding T3-a (this is backwards).** The Rust FFI book explicitly recommends `panic=abort` for FFI boundaries, because unwinding across an FFI boundary is **undefined behavior** in the C ABI. `panic=unwind` is safe *only* if every `extern "C"` function is wrapped in `std::panic::catch_unwind`. The brief does not state that wrapping exists. **If it does not, this is a soundness hole, not a safety barrier.** **UNVERIFIED — CRITICAL.**

**Recommendation:** either (a) `panic=abort` + `#[no_mangle] extern "C"` with no unwinding, or (b) `panic=unwind` + `catch_unwind` at every boundary + `std::process::abort()` on `Err`. Option (b) is the only one that preserves the "safety barrier" claim.

### 3.2 Packed 88-byte descriptor

Rust's `#[repr(C, packed)]` on an 88-byte struct with `u64` fields produces **unaligned** field access