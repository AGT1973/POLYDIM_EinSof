# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 158

The requested arbitration cannot be made definitively from the available evidence: no public, verifiable specifications or outputs for **POLYDIM V1350**, its six kernels, the **PMTP 88-byte descriptor**, or the eight cited Tribunal-model reports were found. The search results contain only general references to Stiefel retractions and established RCU/QSBR implementations, not a V1350 conformance record. Therefore, any model-by-model “winner” or exact V1350 guarantee would be fabrication.

## 1. Extreme-step Stiefel retraction

For \(X\in\mathrm{St}(n,p)\), \(X^\top X=I\), a Cayley-style update commonly has the form

\[
X_{+}
=
\left(I-\frac{\alpha}{2}A\right)^{-1}
\left(I+\frac{\alpha}{2}A\right)X,
\]

where \(A^\top=-A\). In exact arithmetic, the transform is orthogonal whenever the inverse exists, so it preserves the Stiefel constraint.

However, for \(|\alpha|\ge 10^{10}\), that algebraic property does **not** imply a universal floating-point stability guarantee:

- The solve may be ill-conditioned or dominated by scaling, depending on \(A\), precision, and implementation.
- Forming \(I\pm \alpha A/2\) can cause overflow, underflow, cancellation, or loss of significance.
- A nominally skew-symmetric matrix can acquire a symmetric component through rounding.
- The result still requires residual verification and, in many implementations, reprojection.

A mathematically defensible ranking is therefore:

| Method | Extreme-step claim that can be justified |
|---|---|
| **Cayley/Stiefel retraction** | Structure-preserving in exact arithmetic; no unconditional finite-precision guarantee at \(|\alpha|\ge10^{10}\). Must use scaling, stable solves, skew-symmetrization, residual checks, and fallback logic. |
| **Householder QR** | Usually robust when implemented with backward-stable reflectors; returns an orthonormal factor, subject to overflow-safe norm computation and sign conventions. |
| **Polar retraction** | Provides the closest orthonormal factor in the Frobenius norm under standard assumptions; numerically strong, but requires a stable SVD or inverse-square-root computation and handling of rank deficiency. |

Thus the defensible SOTA conclusion is **not** that Cayley is unconditionally more stable than Householder or polar QR. The stronger guarantee belongs to a *hybrid policy*: use a scaled Cayley step only when its solve and orthogonality residual pass prescribed bounds; otherwise fall back to Householder QR or a polar factorization.

A valid architectural contract would specify, for tolerance \(\tau\),

\[
\|X_{+}^{\top}X_{+}-I\| \le \tau,
\]

and define behavior when the bound fails—typically retry, reduce the step, or invoke QR/polar fallback. Without such a contract and measured error bounds, “stable for all \(|\text{step}|\ge10^{10}\)” is not a valid guarantee.

## 2. PMTP 88-byte descriptor and RCU/QSBR

Acquire/release operations alone do not establish complete RCU snapshot isolation. A sound publication protocol requires at least:

1. The writer fully initializes the immutable object.
2. The writer publishes its pointer or generation with **release** semantics.
3. Readers load the publication state with **acquire** semantics before dereferencing the object.
4. Readers remain inside a registered read-side critical section or QSBR epoch.
5. Retention of the old object continues until every pre-publication reader has passed through a quiescent state.
6. Reclamation occurs only after the grace-period condition is proven.

The QSBR implementation references found in the search results explicitly rely on readers observing the relevant grace-period state and on ordering constraints around quiescent-state reporting.[3] Registration of reader threads before entering read-side critical sections is also required.[12]

Consequently, the exact guarantee should be stated as:

> A reader entering the protected read-side interval before publication observes either the old immutable snapshot or, subject to the specified publication order, a fully initialized new snapshot; it cannot observe partially initialized fields, and reclamation cannot occur before that reader reports quiescence.

That guarantee is conditional on the descriptor protocol. An 88-byte size, by itself, provides no atomicity or memory-ordering guarantee. In particular:

- A descriptor larger than the platform’s native atomic width cannot generally be updated atomically as one unit.
- Seqlock-style validation, pointer indirection, double buffering, or an atomic publication word may be required.
- The descriptor must define alignment, padding, endian representation, generation-counter width, and ownership of each field.
- CUDA, C++, Rust, and accelerator memory models must not be treated as interchangeable.

The strongest portable design is usually to keep the descriptor immutable after publication and atomically publish a pointer/version token, rather than attempting an 88-byte in-place atomic update.

## 3. CUDA, XLA, Triton, C++20, and Rust conformance

No evidence was found establishing implementation-level conformance for V1350 across those five environments. Such conformance cannot be inferred from mathematical equivalence.

The environments differ materially:

- **C++20**: acquire/release semantics are defined for specified atomic objects under the C++ memory model.
- **Rust**: equivalent guarantees require explicit atomic orderings and safe lifetime/reclamation discipline; Rust’s type system does not automatically make an RCU implementation correct.
- **CUDA**: device, block, system, and host visibility scopes matter; a device-local fence is not automatically a host-visible publication barrier.
- **Triton**: compiler lowering and supported atomic/fence primitives constrain what can be expressed portably.
- **XLA**: graph compilation, asynchronous execution, aliasing, and buffer donation mean that host-language memory-order assumptions do not automatically transfer to device execution.

A defensible conformance claim therefore requires a defined abstract specification plus per-backend tests for:

- orthogonality residuals and fallback behavior;
- descriptor alignment and layout;
- publication/read ordering;
- delayed reclamation under adversarial readers;
- generation-wrap handling;
- compiler optimization and aliasing behavior;
- host/device visibility;
- deterministic behavior under concurrent execution;
- numerical tolerances by datatype and backend.

## Arbitration

Based on the available evidence, the only supportable arbitration is:

- **Cayley versus QR/polar:** Cayley is algebraically structure-preserving, but QR—especially Householder QR—and carefully implemented polar decomposition provide stronger default numerical robustness for extreme steps. No unconditional Cayley superiority is established.
- **PMTP barriers:** acquire/release are necessary but insufficient without immutable publication, reader registration, grace-period tracking, and delayed reclamation. The 88-byte size does not itself imply atomic snapshot isolation.
- **Multi-silicon conformance:** unproven. It requires an explicit memory-model abstraction and backend-specific implementations and litmus tests.

Accordingly, the “exact architectural guarantees” that can responsibly be issued are conditional guarantees of the form:

\[
\text{success}
\Rightarrow
\|X^\top X-I\|\le\tau
\]

for the numerical kernel, and

\[
\text{reclaim}(o)
\Rightarrow
\forall r\in\mathrm{Readers}(o),\quad
r\text{ has passed a post-publication quiescent state}
\]

for reclamation. Stronger unconditional claims would require the missing V1350 specifications, source code, benchmark data, memory-model definitions, and the actual eight Tribunal reports.