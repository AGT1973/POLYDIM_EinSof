# RESOLUCIÓN MAESTRA SOTA — ARBITRAJE DIALÉCTICO CICLO 101

The six Tribunal outputs are not included in the prompt, so a literal model-by-model arbitration is impossible. The defensible SOTA synthesis is therefore a **conditional architectural decision**: use a safeguarded polar/Householder-QR path as the numerical reference, treat Cayley as an efficient bounded-step kernel rather than an unconditionally stable extreme-step method, and define PMTP snapshot correctness through an explicit publication/observation protocol—not through descriptor layout alone.

## 1. Stiefel retraction under \(\lvert\mathrm{step}\rvert\ge 10^{10}\)

Let \(X\in\mathrm{St}(n,p)\), \(X^{\mathsf T}X=I\), and let \(\Delta\) be a tangent update. A Cayley-style update typically has the form

\[
X_{+} = \left(I-\frac{\tau}{2}A\right)^{-1}
        \left(I+\frac{\tau}{2}A\right)X,
\qquad A^{\mathsf T}=-A.
\]

In exact arithmetic, the Cayley transform is orthogonal whenever the inverse exists. That does **not** imply numerical safety for arbitrarily large \(\tau\). At \(\tau\sim 10^{10}\), the computation may suffer from:

- overflow in forming \(\tau A\);
- loss of significance in \(I\pm \tau A/2\);
- ill-conditioning or singularity of the shifted solve;
- inaccurate triangular or iterative solves;
- loss of orthogonality from finite-precision residuals;
- overflow or underflow in mixed-precision implementations.

The correct arbitration is therefore:

| Method | Extreme-step status | Required role |
|---|---|---|
| **Cayley** | Orthogonal in exact arithmetic, but not unconditionally finite-precision stable for unrestricted \(\tau\) | Fast primary kernel only with scaling, step bounding, residual checks, and fallback |
| **Householder QR** | Strong backward-stability baseline when implemented with blocked Householder reflectors and stable pivot/sign conventions | Portable reference and fallback |
| **Polar retraction** | Geometrically canonical: \(Q=Z(Z^{\mathsf T}Z)^{-1/2}\), the nearest Stiefel point in Frobenius norm; stability depends on the factorization or iteration used | High-quality reference path, especially when a robust SVD/eigendecomposition or carefully controlled Newton–Schulz iteration is available |

Polar and QR retractions are standard alternatives to Cayley retractions; the cited manifold-optimization literature reports closed-form polar and QR constructions alongside Cayley, with different flop profiles.[10] Recent analysis specifically studies the conditioning of polar-light and canonical Cayley retractions, but conditioning results do not constitute a guarantee that an unscaled floating-point Cayley implementation remains safe at arbitrary step magnitudes.[13]

### Definitive kernel policy

The strongest claim that can be made is:

1. **Never promise unconditional Cayley stability for \(\lvert\tau\rvert\ge 10^{10}\).**
2. Scale the skew matrix before forming the Cayley solve:

   \[
   A = 2^s \widehat A,\qquad
   \|\widehat A\| \text{ kept in a safe implementation range},
   \]

   and evaluate the transform using a stable solve rather than explicit inversion.
3. Check both:
   \[
   r_{\mathrm{orth}}=\|X_{+}^{\mathsf T}X_{+}-I\|,
   \qquad
   r_{\mathrm{eq}}=\left\|
   \left(I-\frac{\tau}{2}A\right)X_{+}
   -
   \left(I+\frac{\tau}{2}A\right)X
   \right\|.
   \]
4. If either residual exceeds a precision-dependent threshold, or if scaling/solve diagnostics fail, fall back to **Householder QR** or a robust polar implementation.
5. For a specification-level guarantee, define the returned result as:
   \[
   X_{+}=\operatorname{Retract}_{X}(\Delta)
   \quad\text{only if}\quad
   r_{\mathrm{orth}}\le\varepsilon_{\mathrm{orth}}
   \]
   and otherwise return an explicit numerical-failure status—not a silently nonorthogonal matrix.

A Cayley implementation with Woodbury-style updates can be highly efficient, and periodic QR stabilization is a reasonable long-run strategy, but those are engineering techniques rather than proofs of arbitrary-step stability.[14] The mathematically superior guarantee is consequently **adaptive hybrid retraction**, not “Cayley always wins.”

## 2. PMTP 88-byte descriptor and RCU/QSBR snapshot isolation

An 88-byte descriptor is only a storage-format fact. It does not, by itself, establish memory ordering, atomicity, lifetime safety, or snapshot isolation.

The minimum correct publication protocol is:

### Publisher

1. Construct the immutable payload completely.
2. Publish the descriptor pointer, generation, or root token with **release** semantics.
3. Retire the old object only after the reclamation mechanism proves that no reader can still reference it.

### Reader

1. Enter an RCU/QSBR read-side critical section.
2. Load the published pointer or generation with **acquire** semantics.
3. Read the immutable descriptor and all objects reachable from that published root.
4. Exit the read-side critical section.
5. Do not retain the pointer after exit unless an independent ownership mechanism applies.

A release store makes preceding writes visible to a reader performing a corresponding acquire load; the C++ memory-order specification describes this release/acquire synchronization and its happens-before effect.[2] RCU descriptions likewise characterize a release publication followed by an acquire observation as the ordering needed for the reader to see the writer’s prior initialization.[6]

### What acquire/release guarantees

If the reader’s acquire observes the publisher’s release—or an appropriate release sequence—then:

\[
\text{initialization writes}
\;\mathrel{\text{happens-before}}\;
\text{reader’s subsequent accesses}.
\]

This guarantees **initialization visibility and ordering**.

### What it does not guarantee

Acquire/release alone does not guarantee:

- atomicity of an 88-byte descriptor as one indivisible operation;
- absence of torn reads if fields are independently updated;
- protection from reclamation or use-after-free;
- a consistent multi-field snapshot if the fields are mutated in place;
- a global total order across multiple publication variables;
- GPU-wide or cross-device visibility without the relevant platform mechanism.

Therefore the descriptor should be treated as **immutable after publication**, or represented by an atomically published pointer/root plus immutable generations. If the descriptor itself must be replaced atomically, publish a pointer to it, not the 88 bytes as an assumed atomic object.

### Snapshot guarantee

The exact architectural guarantee should be stated as:

> A reader that enters the read-side epoch before acquiring generation \(g\), and that observes a release publication of generation \(g\), reads a fully initialized and immutable object graph rooted at \(g\). Generation \(g\) cannot be reclaimed until every reader that could have observed \(g\) has passed a quiescent state.

This is stronger and more precise than saying “acquire/release provides snapshot isolation.” The isolation comes from the combination of:

- release/acquire publication;
- immutable post-publication state;
- generation or root identity;
- reader critical-section tracking;
- deferred reclamation.

QSBR is valid only if every participating reader reports quiescent states reliably. A stalled or non-cooperating reader can delay reclamation indefinitely; it cannot safely be ignored.

## 3. Multi-silicon conformance

CUDA, XLA, Triton, C++20, and Rust do not share one universal execution or memory model. A single source-level claim such as “portable acquire/release” is therefore too broad.

### Numerics

The portable numerical contract should specify:

- matrix dimensions and layouts;
- allowed floating-point formats;
- whether fused multiply-add is permitted;
- maximum orthogonality and equation residuals;
- NaN, infinity, and overflow behavior;
- deterministic versus nondeterministic reduction policy;
- fallback behavior when a backend cannot meet the tolerance.

The **reference semantics** should be defined in backend-independent mathematics. Each backend then supplies an implementation whose output satisfies the same residual contract within declared tolerances.

For Stiefel kernels, the conformance condition should include:

\[
\|Q^{\mathsf T}Q-I\| \le \varepsilon_{\mathrm{orth}},
\]

plus a retraction-equation or distance-to-reference bound. Exact bitwise equality across CUDA, XLA, Triton, C++20, and Rust should not be required unless every backend is constrained to identical arithmetic, contraction, reduction, and rounding behavior.

### Memory and synchronization

- **C++20 and Rust CPU implementations:** use the language memory model and explicit atomics. Rust’s atomic orderings express the same conceptual acquire/release relationships, but unsafe pointer lifetime and reclamation remain separate obligations.
- **CUDA:** host C++ atomics, device atomics, fences, streams, events, and cooperative mechanisms are not interchangeable. A CPU release does not automatically establish the required device-side visibility for arbitrary memory.
- **Triton:** synchronization and atomic capabilities depend on the target and compiler lowering. A Triton kernel should not be declared equivalent to a C++ RCU reader unless its generated operations are verified against the target’s memory model.
- **XLA:** operations may be compiled, fused, reordered, replicated, or placed across devices according to its execution semantics. Host-side RCU assumptions cannot simply be embedded in an XLA graph. Device synchronization and token/order dependencies must be modeled using supported XLA mechanisms.

Thus, PMTP snapshot isolation should be split into two layers:

1. **Host control-plane guarantee:** C++20/Rust RCU or QSBR publishes immutable descriptors safely.
2. **Device data-plane guarantee:** CUDA/XLA/Triton receive a generation-tagged immutable buffer through an explicit transfer, stream/event, or graph dependency protocol.

A device kernel must validate or receive the expected generation. If host publication advances from \(g\) to \(g+1\), an already launched device operation may legitimately continue using \(g\); it must not observe a partially updated object. This is achieved by immutable versioned buffers and lifetime retention until device completion—not by host acquire/release alone.

## Final arbitration

The technically strongest synthesis is:

- **Retraction:** adaptive Cayley for normal steps; scaled/stable solve; residual verification; Householder QR or robust polar fallback. No unconditional extreme-step Cayley guarantee.
- **Descriptor publication:** release publication of an immutable versioned root; acquire observation by readers; RCU/QSBR protects lifetime; the 88-byte size has no special atomicity implication.
- **Cross-backend conformance:** specify mathematical invariants, memory/lifetime protocols, tolerances, and failure states separately for CPU and accelerator domains. Require invariant-level equivalence, not accidental bitwise identity.
- **Architectural guarantee:** every committed kernel result is either within its declared numerical and visibility contract or is rejected/fails explicitly; no backend may silently return a nonorthogonal iterate, a torn descriptor, or a reclaimed snapshot.

Any Tribunal conclusion claiming that raw Cayley is stable for all \(\lvert\mathrm{step}\rvert\ge10^{10}\), that an 88-byte descriptor is atomically publishable merely because of its size, or that C++20 acquire/release automatically establishes CUDA/XLA/Triton visibility is mathematically or architecturally overstated.