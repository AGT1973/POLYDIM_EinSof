# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 107)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 107 · Multi-File Adversarial SOTA Review

**Presiding note.** The Tribunal has been given six artifacts and asked to render judgment on (i) numerical degeneracy at the extremes of `step`, (ii) Rule 22 (88-byte PMTP, zero 1D tokens), (iii) Rule 27 (Silicon Contract / vendor-lock), and (iv) to demand proofs, condition-number asymptotics, and FFI hardening. We proceed file-by-file, then render a consolidated verdict. Where the artifacts are described only by their *claims* (the Tribunal has not been shown the literal source), we audit the claims as stated and flag every place where the claim is either **unverifiable as written** or **provably insufficient**.

---

## 0. Notation and Standing Assumptions

- `step ∈ ℝ` is the integrator step (Cayley / Lyapunov / Woodbury scaling).
- `K` = Stiefel half-dimension; ambient `R^(2K × 2K)`.
- `M` = Woodbury mass/preconditioner matrix, `B` = RHS.
- `ε_mach ≈ 2.22e-16` (FP64), `ε_mach ≈ 1.19e-7` (FP32).
- Subnormal thresholds: FP64 `≈ 4.94e-324`, FP32 `≈ 1.40e-45`.
- The 88-byte descriptor is claimed as `<4sHHQQQQQBB6x4Q` → 4+2+2+8+8+8+8+8+1+1+6+32 = **88 bytes**. ✅ Structurally consistent.

---

## TARGET 1 — `kernel_orchestrator_v1350.py`

### 1.1 HardwareProbe (multi-silicon)
**Claim:** probes CPU/GPU/TPU/Trainium/ROCm and dispatches.

**Finding 1.1 (Rule 27 — Vendor Lock).** A *probe* is not a *contract*. Rule 27 requires that no component **impose** vendor lock. A probe that enumerates vendors is compliant **iff** the dispatch table is data-driven and the fallback path is a pure-CPU reference kernel. If the orchestrator hard-codes `if vendor == "nvidia": import cuda_kernel`, that is a soft lock. **Recommendation:** require a registry pattern (`entry_points` / plugin dict) with a mandatory `cpu_reference` entry that is always importable. Verdict: **CONDITIONAL PASS**, pending evidence of registry indirection.

### 1.2 PmtpSlabAllocator
**Claim:** slab allocator for 88-byte descriptors.

**Finding 1.2 (Alignment).** 88 = 8 × 11. For AVX-512 (64-byte cache line) and for `Q` fields (8-byte), the slab stride must be **padded to 128 bytes** internally or the allocator must guarantee 8-byte alignment with no straddling of 64-byte lines for the `Q` fields. If the slab packs descriptors at stride 88, every other descriptor straddles a cache line → **false sharing** in the multi-agent path. **Recommendation:** stride = 128, `__attribute__((aligned(64)))`, and a `static_assert(sizeof(PmtpDescriptor)==88)`.

### 1.3 88-byte binary descriptor `<4sHHQQQQQBB6x4Q`
**Finding 1.3 (Rule 22 — Zero 1D tokens).** The format is a **fixed-width binary record**, not a 1D token stream. This satisfies Rule 22 *provided* the inter-agent transport never serializes it as a variable-length token list. The `6x` pad is correct for 8-byte alignment of the trailing `4Q`. **However:** `4s` magic + `HH` version/flags + `BB` + `6x` + `4Q` = 4+2+2+1+1+6+32 = 48 bytes **before** the five `Q`s. Wait — recount: `4s`(4) `H`(2) `H`(2) `Q`(8) `Q`(8) `Q`(8) `Q`(8) `Q`(8) `B`(1) `B`(1) `6x`(6) `4Q`(32) = 4+2+2+40+1+1+6+32 = **88**. ✅ Arithmetic holds. **But** the `6x` pad is *misplaced*: it sits between `BB` and `4Q`, which is fine for alignment, yet the five `Q`s before `BB` already force 8-byte alignment, so `BB` lands at offset 40, `6x` at 42–47, `4Q` at 48–79… that is only 80 bytes. **Recount carefully:** 4+2+2 = 8; +5×8 = 48; +1+1 = 50; +6 = 56; +4×8 = 88. ✅ Correct. The Tribunal accepts the layout.

**Finding 1.4 (12/12 conformance checks).** Without the literal check list, the Tribunal cannot certify. **Demand:** the 12 checks must include (a) `sizeof==88`, (b) `alignof>=8`, (c) endianness assertion, (d) magic round-trip, (e) version monotonicity, (f) no uninitialized pad bytes (the `6x` must be zeroed — otherwise **information leak** across agents), (g) checksum over the 88 bytes. **If pad bytes are not zeroed, Rule 22 is violated in spirit** (hidden channel).

---

## TARGET 2 — `kernel_cpp_v1350.cpp`

### 2.1 Neumaier compensated dot product
**Claim:** Neumaier summation for `dot(a,b)`.

**Theorem 2.1 (Neumaier error bound).** For `n` terms with `|x_i| ≤ M`, Neumaier's compensated sum `s` satisfies
```
|s − Σx_i| ≤ (2ε + O(nε²)) · Σ|x_i| + O(ε²)·n·M
```
i.e. **relative error is O(ε) independent of n**, versus O(nε) for naive summation. ✅ This is the correct choice for the dot products feeding the Cayley/Woodbury path.

**Finding 2.1 (Degeneracy at step → ∞).** The dot product itself is step-independent. **But** the *caller* scales `B` by `step`. If `|step| ≥ 1e10`, then `step·B` can overflow FP64 only if `|B| > 1e298`. More insidiously, **catastrophic cancellation** appears in `M/scale − step·B` when `step` is huge: the subtraction loses all significant digits of the smaller term. **Proof sketch:** let `x = M/scale`, `y = step·B`, `|y| ≫ |x|`. Then `fl(x−y) = (x−y)(1+δ)`, `|δ| ≤ ε`, but the *absolute* error is `ε|y|`, so the *relative* error in the residual `x−y` is `ε|y|/|x−y| ≈ ε|y|/|y| = ε` only if `|x| ≪ |y|`; if `|x| ≈ |y|`, relative error blows up to `ε|y|/|x−y|` which can be `≫ 1`. **This is the classic cancellation degeneracy.** **Recommendation:** reformulate as `M/scale − step·B = scale⁻¹(M − scale·step·B)` and compute `scale·step` in extended precision (double-double) before multiplying `B`.

### 2.2 Subnormal audits (−12, −14)
**Claim:** audits at exponents −12 and −14 (presumably FP32 subnormal boundary region).

**Finding 2.2.** FP32 subnormals begin at `2^-126 ≈ 1.18e-38`; the *normal* minimum is `2^-126`. Exponents −12 and −14 are **nowhere near** the subnormal boundary — they are ordinary normal numbers. **The audit as described is mislabeled.** If the intent was FP64, subnormals begin at `2^-1022 ≈ 2.2e-308`; −12/−14 are still normal. **Verdict: the subnormal audit is either mis-specified or the exponents are log10 of something else.** The Tribunal demands the literal audit code. If the audit is meant to catch **flush-to-zero (FTZ/DAZ)** behavior under `-ffast-math` or `-ffinite-math-only`, then the exponents should be near `-126` (FP32) or `-1022` (FP64). **This is a material defect.**

### 2.3 Zero-copy PMTP validation
**Finding 2.3.** Zero-copy requires the 88-byte descriptor to be **POD** and **trivially copyable**. `static_assert(std::is_trivially_copyable_v<PmtpDescriptor>)` is mandatory. If any `Q` field is a pointer into a `std::vector`, zero-copy is a lie. **Demand:** the descriptor must contain only offsets/handles, never owning pointers.

### 2.4 AVX-512 / OpenMP
**Finding 2.4 (Rule 27).** AVX-512 is **Intel/AMD-specific**. On ARM (Apple Silicon, Graviton, Trainium host) this kernel cannot run. Rule 27 compliance requires a **portable fallback** (scalar or NEON) selected at runtime via `__builtin_cpu_supports`. If the orchestrator hard-dispatches to this kernel on non-x86, **vendor lock is imposed**. Verdict: **CONDITIONAL PASS** pending runtime dispatch evidence.

---

## TARGET 3 — `kernel_rust_v1350.rs`

### 3.1 Safe SIMD + `panic=unwind` FFI barrier
**Finding 3.1 (FFI hardening — critical).** `panic=unwind` across an FFI boundary is **undefined behavior** unless the panic is caught at the boundary. Rust's `extern "C"` functions **abort** on unwind since Rust 1.71 (the `C-unwind` ABI is required to unwind). **Recommendation:**
```rust
#[no_mangle]
pub extern "C" fn kernel_entry(...) -> c_int {
    match std::panic::catch_unwind(|| { /* ... */ }) {
        Ok(r) => r,
        Err(_) => -1, // sentinel; never unwind across FFI
    }
}
```
Additionally, `catch_unwind` requires `UnwindSafe`; raw pointers are not `UnwindSafe` by default — wrap in `AssertUnwindSafe` **only** if the pointee is not left in a torn state. **Verdict: the claim "panic=unwind FFI safety barrier" is only true if `catch_unwind` is