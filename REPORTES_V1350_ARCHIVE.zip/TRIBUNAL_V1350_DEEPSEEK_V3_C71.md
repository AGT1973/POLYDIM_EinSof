# AUDITORÍA TRIBUNAL DE SABIOS — DeepSeek_V3 (CICLO 71)

# POLYDIM V1350 — High Tribunal Audit
## Cycle 71 · Multi-File Adversarial SOTA Review

**Presiding note:** The Tribunal has been asked to audit six artifacts whose *source code was not transmitted with the brief*. What follows is therefore a **structural audit against the stated contracts**, not a line-by-line code review. Where a claim cannot be verified without the artifact, the Tribunal says so explicitly rather than fabricating a verdict. This is itself a Rule-22-compliant posture: no 1-D token of false confidence is emitted.

---

## 0. Preliminary: What the brief actually asserts

| Target | Claimed invariant | Verifiable from brief? |
|---|---|---|
| T1 orchestrator | 88-byte descriptor `<4sHHQQQQQBB6x4Q`; 12/12 conformance | **Struct layout yes; conformance no** |
| T2 C++ | Neumaier dot; subnormal audits at −12, −14 | Partial |
| T3 Rust | `panic=unwind` FFI barrier; packed 88-byte descriptor | Partial |
| T4 CUDA | Stiefel Cayley via `DnDsyevd`; scaled Woodbury `(M/s)W=(step/s)B` | Partial |
| T5 XLA | Lyapunov in HBM; pure FP64 | Partial |
| T6 Triton | S^(D−1) projection; Clifford bivector rotations | Partial |

**First Tribunal finding:** the brief conflates *architectural intent* with *verified behavior*. An audit that returns "PASS" on unread source is itself a Rule-22 violation. We proceed by deriving what *must* be true for each claim to hold, and flagging where the claim is under-determined.

---

## 1. Structural verification of the 88-byte descriptor

The format string `<4sHHQQQQQBB6x4Q` unpacks as:

| Field | Type | Bytes | Offset |
|---|---|---|---|
| magic | `4s` | 4 | 0 |
| version_major | `H` | 2 | 4 |
| version_minor | `H` | 2 | 6 |
| dim_k | `Q` | 8 | 8 |
| dim_d | `Q` | 8 | 16 |
| stride | `Q` | 8 | 24 |
| offset | `Q` | 8 | 32 |
| flags | `Q` | 8 | 40 |
| rank | `B` | 1 | 48 |
| dtype | `B` | 1 | 49 |
| pad | `6x` | 6 | 50 |
| reserved | `4Q` | 32 | 56 |
| **Total** | | **88** | |

**Verdict:** the layout is *arithmetically* 88 bytes and naturally aligned to 8 (all `Q` fields start at multiples of 8; the `6x` pad correctly realigns the trailing `4Q` block to offset 56). **This is the only claim in the brief that the Tribunal can fully verify from the text alone.**

**Caveat (Rule 22):** `struct.calcsize('<4sHHQQQQQBB6x4Q')` returns 88 *only* under the standard `struct` module. Under `ctypes.Structure` with default packing, the same fields would be 96 bytes due to trailing alignment. **The orchestrator MUST assert `calcsize == 88` at import time**, not merely document it. If it does not, the "12/12 conformance" claim is unverifiable.

---

## 2. Numerical degeneracy: `step → ∞` and `step → 0`

This is the Tribunal's central concern. The brief names two regimes: `|step| ≥ 10^10` and subnormal `step`.

### 2.1 The Woodbury scaling in T4

The CUDA kernel computes `(M/scale) W = (step/scale) B`. Let `s = scale`. The solution is invariant under `s` **only if** `s` is applied to *both* sides and `s` is finite and nonzero. Two failure modes:

**(a) `step → ∞`.** If `step = 10^10` and `scale` is chosen as `‖M‖_F` (a common heuristic), then `step/scale` may overflow FP32 but is safe in FP64 up to `~1.8e308`. **However**, the *condition number* of the scaled system is unchanged: `κ(M/s) = κ(M)`. Scaling does **not** improve conditioning — it only prevents overflow in the RHS. The Tribunal demands the kernel document this: **Woodbury scaling is an overflow guard, not a preconditioner.** If the code comments claim otherwise, that is a mathematical error.

**(b) `step → 0` (subnormal).** For `step < 2^-1022` in FP64, `step/scale` underflows to zero, and `W = 0`. The Cayley retraction `Y = (I − W/2)^{-1}(I + W/2) X` then returns `Y = X` — a silent no-op. **This is a numerical degeneracy, not a bug per se, but it must be detected.** The T2 "subnormal audits at −12, −14" (presumably exponents) suggest the C++ path *does* check this. The Tribunal requires the same guard in T4, T5, T6. **If any of the six components lacks a `step == 0` short-circuit, the architecture is non-conformant.**

**Proof obligation:** For the Cayley retraction to be a valid retraction onto the Stiefel manifold, `W` must satisfy `W^T X + X^T W = 0` (skew-symmetry in the tangent space). If `step → 0` silently zeroes `W`, the retraction degenerates to the identity — which *is* a valid retraction, but the *gradient information is lost*. The Tribunal rules: **`step == 0` must raise or log, never silently pass.**

### 2.2 Neumaier compensated summation

Neumaier's algorithm is *not* immune to `step → ∞`. The compensation term `c` accumulates the rounding error of each addition. For a dot product of length `n` with terms of magnitude `M`, the compensated result has error `O(n·ε²·M)` versus `O(n·ε·M)` for naive summation — a **quadratic improvement in ε**, not a change in the `n` dependence. For `n = 10^6` and `ε = 2^-53`, the compensated error is `~10^-22·M`, which is below the FP64 subnormal threshold for `M < 10^-286`. **The Tribunal finds Neumaier sufficient for the stated regime, but demands the kernel document the `n`-dependence explicitly.**

### 2.3 Asymptotic condition numbers

| Operation | κ | Regime |
|---|---|---|
| Cayley retraction | `κ(I − W/2) ≤ (1 + ‖W‖/2)/(1 − ‖W‖/2)` | Requires `‖W‖ < 2` |
| Woodbury solve | `κ(M) · κ(I + U C V)` | Unchanged by scaling |
| Lyapunov `AX + XA^T = Q` | `κ(X) ≤ κ(A)² · κ(Q)` | **Quadratic in κ(A)** |
| S^(D−1) projection | `1` (orthogonal) | Exact |
| Clifford bivector rotation | `1` (orthogonal) | Exact |

**Critical finding:** the Lyapunov solve in T5 has **quadratic** condition number growth. For `κ(A) = 10^5`, `κ(X) = 10^10` — at the edge of FP64 resolvability. **The Tribunal demands T5 implement iterative refinement or a Bartels–Stewart variant with condition estimation.** A single `jax.scipy.linalg.solve` call is insufficient.

---

## 3. Rule 22 compliance: zero 1-D tokens, 88-byte PMTP

**Definition (Rule 22, as inferred):** inter-agent communication must use the 88-byte PMTP descriptor; no variable-length or 1-D token streams.

**Audit:**

- **T1** defines the descriptor. ✅
- **T2** claims "zero-copy PMTP validation." Zero-copy implies the descriptor is passed by pointer, not serialized. ✅ *if* the pointer is to an 88-byte-aligned buffer.
- **T3** claims "packed 88-byte PmtpTensorDescriptor." Rust's `#[repr(C, packed)]` would produce 88 bytes but **unaligned `Q` fields**, causing UB on some architectures. The Tribunal requires `#[repr(C)]` with explicit `_pad: [u8; 6]` and `_reserved: [u64; 4]`, *not* `packed`. **If T3 uses `packed`, it violates the alignment half of Rule 22.**
- **T4, T5, T6** do not mention PMTP. **This is a Rule-22 gap.** Either they consume descriptors via T1's orchestrator (acceptable) or they emit raw tensors (violation). The brief does not say.

**Tribunal ruling:** Rule 22 compliance is **conditional** on T3's repr attribute and on T4–T6 routing all inter-agent data through T1. The brief does not establish either. **Non liquet.**

---

## 4. Rule 27: Silicon Contract and vendor lock

**Definition (inferred):** no component may impose vendor lock; each must run on at least one alternative silicon.

| Target | Vendor | Lock risk |
|---|---|---|
| T2 C++ AVX-512 | Intel/AMD | **High** — AVX-512 is absent on Apple Silicon, older AMD, and ARM. Needs a scalar/SVE fallback. |
| T3 Rust SIMD | portable | **Low** — `std::simd` or `wide` crate is portable. |
| T4 CUDA | NVIDIA | **Total** — `cuSOLVER DnDsyevd` has no AMD equivalent in the same API. |
| T5 XLA | Google/AWS | **High** — `@jax.jit` targets TPU/Trainium; CPU fallback exists but is not the stated target. |
| T6 Triton | AMD/NVIDIA | **Medium** — Triton now supports ROCm, but the brief's "coalescent SRAM tiling" may be NVIDIA-specific. |

**Tribunal ruling:** **T4 violates Rule 27 as stated.** `cuSOLVER DnDsyevd` is a vendor-locked primitive. The contract requires either (a) a HIP/rocSOLVER path, or (b) a documented "NVIDIA-only, opt-in" flag. The brief does not mention either. **T4 is non-conformant pending evidence.**

T2's AVX-512 is borderline: the *algorithm* (Neumaier dot) is portable, but the *implementation* is not. The Tribunal accepts T2 **only if** a `#ifdef __AVX512F__` fallback exists.

---

## 5. FFI hardening recommendations

The Tribunal issues the following concrete mandates:

1. **T3